// Trip History JavaScript for Driver Panel

// Global variables
let historyData = [];
let currentDriverId = localStorage.getItem('driverId');
let currentDriverName = localStorage.getItem('driverName') || 'Driver';

// Map account_id to driver_id if needed
if (!currentDriverId) {
    const accountId = localStorage.getItem('driverAccountId');
    if (accountId) {
        const accountDriverMap = {
            '35': '21', '36': '22', '37': '23', '38': '24', '39': '25'
        };
        currentDriverId = accountDriverMap[accountId];
        if (currentDriverId) {
            localStorage.setItem('driverId', currentDriverId);
        }
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    if (!currentDriverId) {
        console.log('Driver not logged in');
        window.location.href = '../../html/login.html';
        return;
    }

    console.log('🔍 Loading trip history for driver:', currentDriverId);
    
    // Update driver name in UI
    if (currentDriverName) {
        const driverNameElement = document.getElementById('driver-name');
        if (driverNameElement) {
            driverNameElement.textContent = currentDriverName;
        }
    }

    // Set default date filter (today)
    const today = new Date().toISOString().split('T')[0];
    const dateFilter = document.getElementById('dateFilter');
    if (dateFilter) {
        dateFilter.value = today;
    }

    // Fetch history data
    fetchTripHistory();
});

// Fetch trip history from API
async function fetchTripHistory() {
    try {
        console.log('📡 Calling API: /api/drivers/' + currentDriverId + '/trip-history');
        
        const response = await fetch(`http://localhost:8080/api/drivers/${currentDriverId}/trip-history`);
        const data = await response.json();
        
        console.log('📦 API Response:', data);
        
        if (data.success && data.data) {
            historyData = data.data.map(trip => ({
                id: trip.bookingId,
                customer: trip.customerName,
                phone: trip.customerPhone,
                pickup: trip.pickupLocation,
                dropoff: trip.dropoffLocation,
                distance: trip.distance ? `${trip.distance} km` : 'N/A',
                price: formatCurrency(trip.fare),
                status: trip.status,
                pickupTime: trip.pickupTime || trip.startTime,
                returnTime: trip.returnTime || trip.endTime,
                cancellationReason: trip.cancellationReason,
                rawData: trip
            }));
            
            console.log(`✅ Loaded ${historyData.length} history records`);
            renderTripsTable();
        } else {
            console.error('❌ Failed to fetch history');
            document.getElementById('tripsTableBody').innerHTML = 
                '<tr><td colspan="9" class="text-center p-4">Không có lịch sử chuyến đi</td></tr>';
        }
    } catch (error) {
        console.error('❌ Error fetching history:', error);
        document.getElementById('tripsTableBody').innerHTML = 
            '<tr><td colspan="9" class="text-center p-4 text-danger">Lỗi khi tải dữ liệu: ' + error.message + '</td></tr>';
    }
}

// Render trips table
function renderTripsTable() {
    const tbody = document.getElementById('tripsTableBody');
    const filtered = filterHistory();
    
    if (filtered.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="9" class="text-center p-4 text-muted">
                    <i class="bi bi-inbox" style="font-size: 3rem;"></i>
                    <p class="mt-2">Không có lịch sử chuyến đi phù hợp</p>
                </td>
            </tr>
        `;
        return;
    }
    
    tbody.innerHTML = filtered.map(trip => `
        <tr>
            <td><strong>#${trip.id}</strong></td>
            <td>
                <div style="line-height: 1.3;">
                    <div style="font-weight: 500;">${trip.customer || 'N/A'}</div>
                    <small class="text-muted">${trip.phone || 'N/A'}</small>
                </div>
            </td>
            <td><small class="text-secondary">${trip.pickup || 'N/A'}</small></td>
            <td><small class="text-secondary">${trip.dropoff || 'N/A'}</small></td>
            <td><small class="text-primary fw-semibold">${formatDate(trip.returnTime)}</small></td>
            <td><span class="badge bg-light text-dark">${trip.distance}</span></td>
            <td><strong class="text-success">${trip.price}</strong></td>
            <td style="text-align: center;">
                <span class="badge ${getStatusClass(trip.status)}" style="min-width: 90px; padding: 6px 10px;">
                    ${getStatusText(trip.status)}
                </span>
                ${trip.cancellationReason 
                    ? `<br><small class="text-danger mt-1 d-block">${trip.cancellationReason}</small>` 
                    : ''
                }
            </td>
            <td style="text-align: center;">
                <button class="btn btn-sm btn-info" onclick="viewTripDetail(${trip.id})" title="Xem chi tiết">
                    <i class="bi bi-eye"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

// Filter trips based on filters
function filterHistory() {
    let filtered = historyData;
    
    // Filter by status
    const statusFilter = document.getElementById('statusFilter');
    if (statusFilter && statusFilter.value !== 'all') {
        filtered = filtered.filter(t => t.status === statusFilter.value);
    }
    
    // Filter by date
    const dateFilter = document.getElementById('dateFilter');
    if (dateFilter && dateFilter.value) {
        const filterDate = new Date(dateFilter.value);
        filtered = filtered.filter(t => {
            const tripDate = parseDateTimeArray(t.returnTime);
            if (!tripDate) return false;
            return tripDate.toDateString() === filterDate.toDateString();
        });
    }
    
    // Filter by search
    const searchInput = document.getElementById('searchInput');
    if (searchInput && searchInput.value.trim()) {
        const search = searchInput.value.toLowerCase().trim();
        filtered = filtered.filter(t => 
            t.id.toString().includes(search) ||
            (t.customer && t.customer.toLowerCase().includes(search)) ||
            (t.phone && t.phone.includes(search))
        );
    }
    
    return filtered;
}

// Filter trips (called by onchange events)
function filterTrips() {
    renderTripsTable();
}

// Reset filters
function resetFilters() {
    const statusFilter = document.getElementById('statusFilter');
    const dateFilter = document.getElementById('dateFilter');
    const searchInput = document.getElementById('searchInput');
    
    if (statusFilter) statusFilter.value = 'all';
    if (dateFilter) dateFilter.value = '';
    if (searchInput) searchInput.value = '';
    
    renderTripsTable();
}

// Format date time
function formatDateTime(datetime) {
    if (!datetime) return 'N/A';
    
    // Handle array format [2025, 11, 4, 14, 30]
    if (Array.isArray(datetime)) {
        const [year, month, day, hour, minute] = datetime;
        return `${String(day).padStart(2, '0')}/${String(month).padStart(2, '0')}/${year} ${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
    }
    
    return String(datetime);
}

// Format date only
function formatDate(datetime) {
    if (!datetime) return 'N/A';
    
    // Handle array format [2025, 11, 4, 14, 30]
    if (Array.isArray(datetime)) {
        const [year, month, day] = datetime;
        return `${String(day).padStart(2, '0')}/${String(month).padStart(2, '0')}/${year}`;
    }
    
    return String(datetime).split(' ')[0];
}

// Parse date array to Date object
function parseDateTimeArray(datetime) {
    if (!datetime) return null;
    
    if (Array.isArray(datetime)) {
        const [year, month, day, hour = 0, minute = 0] = datetime;
        return new Date(year, month - 1, day, hour, minute);
    }
    
    return new Date(datetime);
}

// Format currency
function formatCurrency(amount) {
    if (!amount) return '0đ';
    return new Intl.NumberFormat('vi-VN', { 
        style: 'currency', 
        currency: 'VND',
        minimumFractionDigits: 0
    }).format(amount);
}

// Get status badge class
function getStatusClass(status) {
    const classes = {
        'pending': 'bg-warning',
        'confirmed': 'bg-info',
        'ongoing': 'bg-success',
        'completed': 'bg-primary',
        'cancelled': 'bg-danger'
    };
    return classes[status] || 'bg-secondary';
}

// Get status text
function getStatusText(status) {
    const texts = {
        'pending': '⏳ Chờ chấp nhận',
        'confirmed': '✅ Đã chấp nhận',
        'ongoing': '🚗 Đang thực hiện',
        'completed': '✔️ Hoàn thành',
        'cancelled': '❌ Đã hủy'
    };
    return texts[status] || status;
}

// View trip detail
function viewTripDetail(tripId) {
    const trip = historyData.find(t => t.id === tripId);
    if (!trip) {
        console.error('Trip not found:', tripId);
        return;
    }

    // Update modal content
    document.getElementById('modalCustomerName').textContent = trip.customer || 'N/A';
    document.getElementById('modalCustomerPhone').textContent = trip.phone || 'N/A';
    document.getElementById('modalPickup').textContent = trip.pickup || 'N/A';
    document.getElementById('modalDropoff').textContent = trip.dropoff || 'N/A';
    document.getElementById('modalDistance').textContent = trip.distance || 'N/A';
    document.getElementById('modalPrice').textContent = trip.price || '0đ';

    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('tripDetailModal'));
    modal.show();
}

// Export functions to window
window.filterTrips = filterTrips;
window.resetFilters = resetFilters;
window.viewTripDetail = viewTripDetail;
