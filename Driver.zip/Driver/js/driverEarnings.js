// Earnings Page JavaScript

// Import API functions
import { api } from '../../js/api.js';

// Global variables
let earningsData = {};
let currentDriverId = localStorage.getItem('driverId');

// Current date state
let currentDate = new Date();
let currentMonthKey = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}`;

// Format currency
function formatCurrency(amount) {
  return new Intl.NumberFormat('vi-VN', {
    style: 'currency',
    currency: 'VND',
    minimumFractionDigits: 0
  }).format(amount);
}

// Calculate average per trip
function calculateAverage(total, trips) {
  return Math.round(total / trips);
}

// Get month name
function getMonthName(dateStr) {
  const [year, month] = dateStr.split('-');
  const date = new Date(year, parseInt(month) - 1);
  return date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
}

// Fetch earnings data from API
async function fetchEarningsData(month, year) {
  try {
    if (!currentDriverId) {
      console.error('Driver ID not found');
      showEmptyState();
      return;
    }

    const response = await api.request(`/drivers/${currentDriverId}/earnings?month=${month}&year=${year}`, 'GET');
    
    if (response.success) {
      earningsData[`${year}-${String(month).padStart(2, '0')}`] = response.data;
      updateDisplay();
    } else {
      console.error('Failed to fetch earnings data:', response.message);
      showEmptyState();
    }
  } catch (error) {
    console.error('Error fetching earnings data:', error);
    showEmptyState();
  }
}

// Show empty state when no data
function showEmptyState() {
  document.getElementById('currentMonth').textContent = getMonthName(currentMonthKey);
  document.getElementById('totalEarnings').textContent = '₫0';
  document.getElementById('completedTrips').textContent = '0 trips';
  document.getElementById('avgPerTrip').textContent = '₫0';
  
  const weeklyGrid = document.querySelector('.weekly-grid');
  weeklyGrid.innerHTML = '<p class="text-muted">No earnings data available for this month</p>';
}

// Update display
function updateDisplay() {
  const data = earningsData[currentMonthKey];
  
  if (!data) {
    showEmptyState();
    return;
  }

  // Update month display
  document.getElementById('currentMonth').textContent = data.month || getMonthName(currentMonthKey);
  
  // Update summary
  document.getElementById('totalEarnings').textContent = formatCurrency(data.totalEarnings || 0);
  document.getElementById('completedTrips').textContent = `${data.completedTrips || 0} trips`;
  
  const avgPerTrip = data.completedTrips > 0 ? calculateAverage(data.totalEarnings || 0, data.completedTrips) : 0;
  document.getElementById('avgPerTrip').textContent = formatCurrency(avgPerTrip);
  
  // Update weekly breakdown
  updateWeeklyBreakdown(data.weeks || []);
}

// Update weekly breakdown
function updateWeeklyBreakdown(weeks) {
  const weeklyGrid = document.querySelector('.weekly-grid');
  const maxEarnings = Math.max(...weeks.map(w => w.earnings));
  
  weeklyGrid.innerHTML = weeks.map(week => {
    const percentage = (week.earnings / maxEarnings) * 100;
    return `
      <div class="week-card">
        <div class="week-label">Week ${week.week}</div>
        <div class="week-amount">${formatCurrency(week.earnings)}</div>
        <div class="week-bar">
          <div class="week-bar-fill" style="width: ${percentage}%"></div>
        </div>
      </div>
    `;
  }).join('');
}

// Navigate to previous month
function previousMonth() {
  const [year, month] = currentMonthKey.split('-').map(Number);
  const newDate = new Date(year, month - 2); // -2 because month is 1-indexed in our key
  currentMonthKey = `${newDate.getFullYear()}-${String(newDate.getMonth() + 1).padStart(2, '0')}`;
  
  // Fetch data for the new month
  const [newYear, newMonth] = currentMonthKey.split('-').map(Number);
  fetchEarningsData(newMonth, newYear);
}

// Navigate to next month
function nextMonth() {
  const [year, month] = currentMonthKey.split('-').map(Number);
  const newDate = new Date(year, month); // month already points to next month (0-indexed)
  currentMonthKey = `${newDate.getFullYear()}-${String(newDate.getMonth() + 1).padStart(2, '0')}`;
  
  // Fetch data for the new month
  const [newYear, newMonth] = currentMonthKey.split('-').map(Number);
  fetchEarningsData(newMonth, newYear);
}

// View detailed report
function viewDetailedReport() {
  alert('Detailed report feature coming soon!');
  // In production, this would navigate to a detailed report page
  // window.location.href = 'detailed-report.html?month=' + currentMonthKey;
}

// Download CSV
function downloadCSV() {
  const data = earningsData[currentMonthKey];
  
  if (!data) {
    alert('No data available for this month');
    return;
  }

  // Create CSV content
  let csvContent = "Week,Earnings,Trips\n";
  
  const tripsPerWeek = Math.round(data.completedTrips / data.weeks.length);
  
  data.weeks.forEach(week => {
    csvContent += `Week ${week.week},${week.earnings},${tripsPerWeek}\n`;
  });
  
  csvContent += `\nTotal,${data.totalEarnings},${data.completedTrips}\n`;
  csvContent += `Average per Trip,${calculateAverage(data.totalEarnings, data.completedTrips)}\n`;

  // Create download link
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  
  link.setAttribute('href', url);
  link.setAttribute('download', `earnings_${currentMonthKey}.csv`);
  link.style.visibility = 'hidden';
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// Event listeners
document.addEventListener('DOMContentLoaded', function() {
  // Check if driver is logged in
  if (!currentDriverId) {
    console.error('Driver not logged in');
    window.location.href = '../html/login.html';
    return;
  }

  // Fetch current month data on load
  const [year, month] = currentMonthKey.split('-').map(Number);
  fetchEarningsData(month, year);
  
  // Month navigation
  document.getElementById('prevMonth').addEventListener('click', previousMonth);
  document.getElementById('nextMonth').addEventListener('click', nextMonth);
  
  // Action buttons
  document.getElementById('viewDetailedReport').addEventListener('click', viewDetailedReport);
  document.getElementById('downloadCSV').addEventListener('click', downloadCSV);
});

// Export functions for use in other scripts if needed
window.earningsModule = {
  updateDisplay,
  previousMonth,
  nextMonth,
  viewDetailedReport,
  downloadCSV
};