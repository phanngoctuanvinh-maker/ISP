// Common Driver Functions - Load driver info for all pages

// Load driver info and update topbar
async function loadDriverInfo() {
    const driverId = localStorage.getItem('driverId');
    const driverNameElement = document.getElementById('driver-name');
    
    if (!driverId) {
        console.error('❌ No driver ID found in localStorage');
        if (driverNameElement) {
            driverNameElement.textContent = 'Driver';
        }
        return;
    }
    
    // First, try to load from localStorage (fast)
    const cachedName = localStorage.getItem('driverName');
    if (cachedName && driverNameElement) {
        driverNameElement.textContent = cachedName;
        console.log('✅ Driver name loaded from cache:', cachedName);
    }
    
    // Then try to fetch from API to update (if available)
    try {
        const response = await fetch(`http://localhost:8080/api/drivers/${driverId}`);
        
        if (!response.ok) {
            console.warn('⚠️ API returned error, using cached name');
            return;
        }
        
        const data = await response.json();
        
        if (data.success && data.driver && data.driver.fullName) {
            if (driverNameElement) {
                driverNameElement.textContent = data.driver.fullName;
            }
            
            // Update localStorage cache
            localStorage.setItem('driverName', data.driver.fullName);
            
            console.log('✅ Driver info updated from API:', data.driver.fullName);
        }
    } catch (error) {
        console.warn('⚠️ Error loading driver info from API:', error.message);
        // Keep using cached name
    }
}

// Auto load on page load
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', loadDriverInfo);
} else {
    loadDriverInfo();
}

// Export for use in other scripts
window.loadDriverInfo = loadDriverInfo;
