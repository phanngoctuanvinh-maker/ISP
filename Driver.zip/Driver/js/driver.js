// Driver Base JavaScript

// API sẽ được load từ script tag trong HTML (không dùng import)
// const api sẽ có sẵn từ ../../js/api.js

// Global variables
let currentDriverId = localStorage.getItem('driverId');
let driverName = localStorage.getItem('driverName') || 'Driver';

// Nếu chưa có driverId nhưng có account_id, thử map
if (!currentDriverId) {
  const accountId = localStorage.getItem('driverAccountId');
  if (accountId) {
    // Mapping table account_id -> driver_id (TẠM THỜI)
    const accountDriverMap = {
      '35': '21',  // driver1@drivenow.com
      '36': '22',  // driver2@drivenow.com
      '37': '23',  // driver3@drivenow.com
      '38': '24',  // driver4@drivenow.com
      '39': '25'   // driver5@drivenow.com
    };
    currentDriverId = accountDriverMap[accountId];
    if (currentDriverId) {
      localStorage.setItem('driverId', currentDriverId);
    }
  }
}

// Initialize page
document.addEventListener('DOMContentLoaded', function() {
  // Check if driver is logged in
  if (!currentDriverId) {
    console.log('Driver not logged in, redirecting to login');
    window.location.href = '../../html/login.html';
    return;
  }

  // Load driver name
  loadDriverInfo();
  
  // Load dashboard data if on dashboard page
  if (window.location.pathname.includes('driver.html')) {
    loadDashboardData();
  }
});

// Load driver info
async function loadDriverInfo() {
  try {
    const response = await api.request(`/drivers/${currentDriverId}/profile`, 'GET');
    
    if (response.success && response.data) {
      driverName = response.data.name || 'Driver';
      localStorage.setItem('driverName', driverName);
      
      // Update driver name in UI
      updateDriverNameDisplay();
    }
  } catch (error) {
    console.error('Error loading driver info:', error);
  }
}

// Update driver name in UI
function updateDriverNameDisplay() {
  const nameElements = document.querySelectorAll('.driver-name, #driver-name');
  nameElements.forEach(el => {
    if (el) {
      el.textContent = driverName;
    }
  });
}

// Handle logout
function handleLogout() {
  if (confirm("Bạn có chắc chắn muốn đăng xuất không?")) {
    // Clear local storage
    localStorage.removeItem('driverId');
    localStorage.removeItem('driverName');
    localStorage.removeItem('token');
    
    // Redirect to login
    window.location.href = "../../html/login.html";
  }
}

// Load dashboard data
async function loadDashboardData() {
  try {
    // Load dashboard stats
    const statsResponse = await api.request(`/drivers/${currentDriverId}/dashboard-stats`, 'GET');
    
    if (statsResponse.success) {
      updateDashboardStats(statsResponse.data);
    }

    // Load recent trips
    const tripsResponse = await api.request(`/drivers/${currentDriverId}/recent-trips`, 'GET');
    
    if (tripsResponse.success) {
      updateRecentTrips(tripsResponse.data);
    }
    
    // Update notification badge (check for assigned trips)
    updateNotificationBadge();
  } catch (error) {
    console.error('Error loading dashboard data:', error);
    showErrorState();
  }
}

// Update dashboard statistics
function updateDashboardStats(stats) {
  document.getElementById('trips-today').textContent = stats.tripsToday || 0;
  document.getElementById('today-earnings').textContent = formatCurrency(stats.todayEarnings || 0);
  document.getElementById('driver-rating').textContent = stats.averageRating ? stats.averageRating.toFixed(1) : 'N/A';
  
  // Calculate total trips instead of online time
  const totalTripsEl = document.getElementById('online-time');
  if (totalTripsEl) {
    totalTripsEl.textContent = stats.totalTrips || 0;
  }
}

// Load assigned trips (chuyến đi được phân công)
async function updateNotificationBadge() {
  try {
    const response = await fetch(`http://localhost:8080/api/drivers/${currentDriverId}/assigned-trips`);
    const data = await response.json();
    
    if (data.success && data.trips && data.trips.length > 0) {
      // Update notification badge on top bar
      const notificationBadge = document.getElementById('notification-count');
      if (notificationBadge) {
        notificationBadge.textContent = data.count;
        notificationBadge.style.display = 'inline-block';
      }
      
      // Update notification badge on sidebar
      const sidebarBadge = document.getElementById('sidebar-notification-badge');
      if (sidebarBadge) {
        sidebarBadge.textContent = data.count;
        sidebarBadge.style.display = 'inline-block';
      }
    } else {
      // Hide badges
      const notificationBadge = document.getElementById('notification-count');
      if (notificationBadge) notificationBadge.style.display = 'none';
      
      const sidebarBadge = document.getElementById('sidebar-notification-badge');
      if (sidebarBadge) sidebarBadge.style.display = 'none';
    }
  } catch (error) {
    console.error('Error loading notification count:', error);
  }
}

// Update recent trips table
function updateRecentTrips(trips) {
  const tbody = document.getElementById('recent-trips-body');
  
  if (!trips || trips.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="7" class="text-center p-4">
          <i class="bi bi-inbox text-muted" style="font-size: 2rem;"></i>
          <p class="text-muted mt-2 mb-0">Chưa có chuyến đi gần đây</p>
        </td>
      </tr>
    `;
    return;
  }

  tbody.innerHTML = trips.map(trip => `
    <tr>
      <td><strong>#${trip.bookingId}</strong></td>
      <td>${trip.customerName || 'N/A'}</td>
      <td>${truncateText(trip.pickupLocation || 'N/A', 30)}</td>
      <td>${truncateText(trip.dropoffLocation || 'N/A', 30)}</td>
      <td>${trip.distance ? trip.distance.toFixed(1) + ' km' : 'N/A'}</td>
      <td>${formatCurrency(trip.fare || 0)}</td>
      <td><span class="badge ${getStatusBadgeClass(trip.status)}">${getStatusText(trip.status)}</span></td>
    </tr>
  `).join('');
}

// Truncate long text
function truncateText(text, maxLength) {
  if (!text) return 'N/A';
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength) + '...';
}

// Get status badge class
function getStatusBadgeClass(status) {
  const classes = {
    'completed': 'bg-success',
    'ongoing': 'bg-warning',
    'cancelled': 'bg-danger',
    'pending': 'bg-info'
  };
  return classes[status] || 'bg-secondary';
}

// Get status text
function getStatusText(status) {
  const texts = {
    'completed': 'Hoàn thành',
    'ongoing': 'Đang thực hiện',
    'confirmed': 'Đã chấp nhận',
    'cancelled': 'Đã hủy',
    'pending': 'Chờ xác nhận'
  };
  return texts[status] || status;
}

// Format currency
function formatCurrency(amount) {
  return new Intl.NumberFormat('vi-VN', {
    style: 'currency',
    currency: 'VND',
    minimumFractionDigits: 0
  }).format(amount);
}

// Show error state
function showErrorState() {
  // Update stats with error indicators
  document.getElementById('trips-today').textContent = 'Error';
  document.getElementById('today-earnings').textContent = 'Error';
  document.getElementById('driver-rating').textContent = 'Error';
  document.getElementById('online-time').textContent = 'Error';

  // Update recent trips table
  const tbody = document.getElementById('recent-trips-body');
  tbody.innerHTML = `
    <tr>
      <td colspan="7" class="text-center p-4">
        <i class="bi bi-exclamation-triangle text-warning" style="font-size: 2rem;"></i>
        <p class="text-muted mt-2 mb-0">Failed to load dashboard data</p>
        <button class="btn btn-sm btn-outline-primary mt-2" onclick="loadDashboardData()">
          <i class="bi bi-arrow-clockwise"></i> Retry
        </button>
      </td>
    </tr>
  `;
}

// Make functions globally available
window.handleLogout = handleLogout;
window.loadDashboardData = loadDashboardData;