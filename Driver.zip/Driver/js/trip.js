// Trip Management JavaScript

// Global variables
let tripsData = [];
let currentDriverId = localStorage.getItem('driverId');

// Nếu chưa có driverId nhưng có account_id, thử map
if (!currentDriverId) {
  const accountId = localStorage.getItem('driverAccountId');
  if (accountId) {
    const accountDriverMap = {
      '35': '21', '36': '22', '37': '23', '38': '24', '39': '25'
    };
    currentDriverId = accountDriverMap[accountId];
    if (currentDriverId) {
      localStorage.setItem('driverId', currentDriverId);
    }
  }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    if (!currentDriverId) {
        console.log('Driver not logged in');
        window.location.href = '../../html/login.html';
        return;
    }
    
    fetchTripsData();
});

// Fetch trips data from API (assigned trips)
async function fetchTripsData() {
    try {
        if (!currentDriverId) {
            console.error('❌ Driver ID not found');
            return;
        }

        console.log('🔍 Fetching trips for driver ID:', currentDriverId);
        
        // Call the assigned-trips API
        const response = await fetch(`http://localhost:8080/api/drivers/${currentDriverId}/assigned-trips`);
        const data = await response.json();
        
        console.log('📦 API Response:', data);
        
        if (data.success && data.trips) {
            console.log(`✅ Found ${data.trips.length} trips`);
            
            tripsData = data.trips.map(trip => ({
                id: trip.bookingId,
                customer: trip.customerName,
                phone: trip.customerPhone,
                pickup: trip.pickupLocation,
                dropoff: trip.dropoffLocation,
                distance: trip.distance ? `${trip.distance} km` : 'N/A',
                price: formatCurrency(trip.fare),
                status: mapBackendStatusToFrontend(trip.status),
                time: trip.startTime,
                endTime: trip.endTime,
                rawData: trip
            }));
            
            console.log('🎯 Processed trips:', tripsData);
            renderTripsTable();
        } else {
            console.error('❌ Failed to fetch trips data');
            document.getElementById('tripsTableBody').innerHTML = 
                '<tr><td colspan="9" class="text-center p-4">Không có chuyến đi nào</td></tr>';
        }
    } catch (error) {
        console.error('❌ Error fetching trips data:', error);
        document.getElementById('tripsTableBody').innerHTML = 
            '<tr><td colspan="9" class="text-center p-4 text-danger">Lỗi khi tải dữ liệu</td></tr>';
    }
}

// Map backend status to frontend status
function mapBackendStatusToFrontend(backendStatus) {
    // Backend và Frontend đều dùng cùng status: pending, confirmed, ongoing, completed, cancelled
    // Không cần map, chỉ cần return trực tiếp
    return backendStatus;
}

// Format currency
function formatCurrency(amount) {
    if (!amount) return '0đ';
    return new Intl.NumberFormat('vi-VN', { 
        style: 'currency', 
        currency: 'VND',
        minimumFractionDigits: 0
    }).format(amount);
}

// Format datetime
function formatDateTime(datetime) {
    if (!datetime) return 'N/A';
    
    // Handle array format [2025, 11, 4, 14, 30]
    if (Array.isArray(datetime)) {
        const [year, month, day, hour, minute] = datetime;
        return `${String(day).padStart(2, '0')}/${String(month).padStart(2, '0')}/${year} ${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
    }
    
    return String(datetime);
}

// Format date only (for table display)
function formatDate(datetime) {
    if (!datetime) return 'N/A';
    
    // Handle array format [2025, 11, 4, 14, 30]
    if (Array.isArray(datetime)) {
        const [year, month, day] = datetime;
        return `${String(day).padStart(2, '0')}/${String(month).padStart(2, '0')}/${year}`;
    }
    
    return String(datetime).split(' ')[0]; // Get date part only
}

function filterTrips() {
    const statusFilter = document.getElementById('statusFilter').value;
    const dateFilter = document.getElementById('dateFilter').value;
    const searchInput = document.getElementById('searchInput').value.toLowerCase().trim();
    
    console.log('Filter:', { statusFilter, dateFilter, searchInput });
    
    const rows = document.querySelectorAll('#tripsTableBody tr');
    console.log('Total rows:', rows.length);
    
    let visibleCount = 0;
    
    rows.forEach(row => {
        // Lấy thông tin từ row attributes và cells
        const status = row.getAttribute('data-status');
        const tripId = row.getAttribute('data-trip-id');
        
        // Lấy tên khách hàng từ cell thứ 2 (index 1)
        const customerCell = row.cells[1];
        const customerName = customerCell ? customerCell.textContent.toLowerCase() : '';
        
        let showRow = true;
        
        // Filter by status
        if (statusFilter !== 'all' && status !== statusFilter) {
            showRow = false;
        }
        
        // Filter by search (tìm theo ID hoặc tên khách hàng)
        if (searchInput) {
            const matchId = tripId && tripId.includes(searchInput);
            const matchName = customerName.includes(searchInput);
            
            if (!matchId && !matchName) {
                showRow = false;
            }
        }
        
        // TODO: Filter by date (có thể implement sau)
        
        // Show/hide row
        row.style.display = showRow ? '' : 'none';
        if (showRow) visibleCount++;
    });
    
    console.log(`✓ Hiển thị ${visibleCount}/${rows.length} chuyến đi`);
}

// Reset filters
function resetFilters() {
    // Reset các input
    document.getElementById('statusFilter').value = 'all';
    document.getElementById('dateFilter').value = '';
    document.getElementById('searchInput').value = '';
    
    // Gọi lại filterTrips để hiển thị tất cả
    filterTrips();
}

// Render trips table
function renderTripsTable() {
    const tableBody = document.getElementById('tripsTableBody');
    
    if (!tripsData || tripsData.length === 0) {
        tableBody.innerHTML = '<tr><td colspan="9" class="text-center p-4 text-muted">Không có chuyến đi nào</td></tr>';
        return;
    }

    tableBody.innerHTML = tripsData.map(trip => `
        <tr data-trip-id="${trip.id}" data-status="${trip.status}">
            <td><strong>#${trip.id}</strong></td>
            <td>
                <div style="line-height: 1.3;">
                    <div style="font-weight: 500;">${trip.customer || 'N/A'}</div>
                    <small class="text-muted">${trip.phone || 'N/A'}</small>
                </div>
            </td>
            <td>
                <small class="text-secondary" style="line-height: 1.4;">${trip.pickup || 'N/A'}</small>
            </td>
            <td>
                <small class="text-secondary" style="line-height: 1.4;">${trip.dropoff || 'N/A'}</small>
            </td>
            <td>
                <small class="text-primary fw-semibold">${formatDate(trip.time)}</small>
            </td>
            <td><span class="badge bg-light text-dark">${trip.distance || 'N/A'}</span></td>
            <td><strong class="text-success">${trip.price || '0đ'}</strong></td>
            <td style="text-align: center;">
                <span class="badge ${getStatusClass(trip.status)}" style="min-width: 90px; padding: 6px 10px;">
                    ${getStatusText(trip.status)}
                </span>
            </td>
            <td style="text-align: center;">
                <button class="btn btn-sm btn-primary" onclick="viewTripDetail(${trip.id})" title="Xem chi tiết">
                    <i class="bi bi-eye-fill"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

// Get status badge class
function getStatusClass(status) {
    const classes = {
        'pending': 'bg-warning',
        'confirmed': 'bg-info',
        'ongoing': 'bg-success',
        'completed': 'bg-primary',
        'cancelled': 'bg-danger'
    };
    return classes[status] || 'bg-secondary';
}

// Get status text
function getStatusText(status) {
    const texts = {
        'pending': '⏳ Chờ chấp nhận',
        'confirmed': '✅ Đã chấp nhận',
        'ongoing': '� Đang thực hiện',
        'completed': '✔️ Hoàn thành',
        'cancelled': '❌ Đã hủy'
    };
    return texts[status] || status;
}

// View trip details in modal
function viewTripDetail(tripId) {
    const trip = tripsData.find(t => t.id === tripId);
    
    if (!trip) {
        console.error('Trip not found:', tripId);
        return;
    }
    
    // Điền thông tin vào modal
    document.getElementById('modalTripId').textContent = trip.id;
    document.getElementById('modalStatus').textContent = getStatusText(trip.status);
    document.getElementById('modalCustomerName').textContent = trip.customer || 'N/A';
    document.getElementById('modalCustomerPhone').textContent = trip.phone || 'N/A';
    document.getElementById('modalPickup').textContent = trip.pickup || 'N/A';
    document.getElementById('modalDropoff').textContent = trip.dropoff || 'N/A';
    document.getElementById('modalDateTime').textContent = formatDateTime(trip.time);
    document.getElementById('modalDistance').textContent = trip.distance || 'N/A';
    document.getElementById('modalPrice').textContent = trip.price || '0đ';
    
    // Thêm action buttons dựa vào status
    const footer = document.getElementById('modalFooter');
    let actionButtons = '';
    
    if (trip.status === 'pending') {
        // Chờ driver chấp nhận/từ chối
        actionButtons = `
            <button type="button" class="btn btn-success" onclick="acceptTrip(${trip.id})">
                <i class="bi bi-check-circle-fill"></i> Chấp nhận
            </button>
            <button type="button" class="btn btn-danger" onclick="rejectTrip(${trip.id})">
                <i class="bi bi-x-circle-fill"></i> Từ chối
            </button>
        `;
    } else if (trip.status === 'confirmed') {
        // Driver đã chấp nhận, có thể bắt đầu chuyến đi
        actionButtons = `
            <button type="button" class="btn btn-primary" onclick="startTrip(${trip.id})">
                <i class="bi bi-play-circle-fill"></i> Bắt đầu chuyến đi
            </button>
            <button type="button" class="btn btn-outline-danger" onclick="cancelTrip(${trip.id})">
                <i class="bi bi-x-circle"></i> Hủy chuyến
            </button>
        `;
    } else if (trip.status === 'ongoing') {
        // Đang thực hiện, có thể hoàn thành
        actionButtons = `
            <button type="button" class="btn btn-success btn-lg" onclick="completeTrip(${trip.id})">
                <i class="bi bi-check-circle-fill"></i> Hoàn thành chuyến đi
            </button>
        `;
    } else {
        // completed hoặc cancelled - chỉ xem
        actionButtons = `
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                <i class="bi bi-eye"></i> Đóng
            </button>
        `;
    }
    
    footer.innerHTML = actionButtons;
    
    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('tripDetailModal'));
    modal.show();
}

// Accept trip (chấp nhận chuyến đi - pending → confirmed)
async function acceptTrip(tripId) {
    if (confirm(`Bạn có chắc muốn CHẤP NHẬN chuyến đi #${tripId}?\n\nSau khi chấp nhận, bạn có thể bắt đầu chuyến đi.`)) {
        try {
            const response = await fetch(`http://localhost:8080/api/drivers/trips/${tripId}/accept`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            const data = await response.json();

            if (data.success) {
                alert('✅ Đã chấp nhận chuyến đi!\n\nBây giờ bạn có thể bắt đầu chuyến đi khi sẵn sàng.');
                
                // Close modal
                const modal = bootstrap.Modal.getInstance(document.getElementById('tripDetailModal'));
                if (modal) modal.hide();
                
                // Reload data
                await fetchTripsData();
            } else {
                alert('❌ Lỗi: ' + (data.message || 'Không thể chấp nhận chuyến đi'));
            }
        } catch (error) {
            console.error('Error accepting trip:', error);
            alert('❌ Lỗi kết nối đến server. Vui lòng thử lại!');
        }
    }
}

// Reject trip (từ chối chuyến đi - pending → cancelled)
async function rejectTrip(tripId) {
    if (confirm(`Bạn có chắc muốn TỪ CHỐI chuyến đi #${tripId}?\n\nChuyến đi sẽ bị hủy và chuyển vào Trip History.`)) {
        try {
            const response = await fetch(`http://localhost:8080/api/drivers/trips/${tripId}/reject`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            const data = await response.json();

            if (data.success) {
                alert('✅ Đã từ chối chuyến đi!\n\nChuyến đi đã được hủy và chuyển vào Trip History.');
                
                // Close modal
                const modal = bootstrap.Modal.getInstance(document.getElementById('tripDetailModal'));
                if (modal) modal.hide();
                
                // Reload data
                await fetchTripsData();
            } else {
                alert('❌ Lỗi: ' + (data.message || 'Không thể từ chối chuyến đi'));
            }
        } catch (error) {
            console.error('Error rejecting trip:', error);
            alert('❌ Lỗi kết nối đến server. Vui lòng thử lại!');
        }
    }
}

// Start trip (bắt đầu chuyến đi - confirmed → ongoing)
async function startTrip(tripId) {
    if (confirm(`Bạn có chắc muốn BẮT ĐẦU chuyến đi #${tripId}?\n\nChuyến đi sẽ chuyển sang trạng thái "Đang thực hiện".`)) {
        try {
            const response = await fetch(`http://localhost:8080/api/drivers/trips/${tripId}/start`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            const data = await response.json();

            if (data.success) {
                alert('✅ Đã bắt đầu chuyến đi!\n\nChúc bạn có chuyến đi an toàn! 🚗');
                
                // Close modal
                const modal = bootstrap.Modal.getInstance(document.getElementById('tripDetailModal'));
                if (modal) modal.hide();
                
                // Reload data
                await fetchTripsData();
            } else {
                alert('❌ Lỗi: ' + (data.message || 'Không thể bắt đầu chuyến đi'));
            }
        } catch (error) {
            console.error('Error starting trip:', error);
            alert('❌ Lỗi kết nối đến server. Vui lòng thử lại!');
        }
    }
}

// Complete trip (hoàn thành chuyến đi - ongoing → completed)
async function completeTrip(tripId) {
    if (confirm(`Bạn có chắc muốn HOÀN THÀNH chuyến đi #${tripId}?\n\nChuyến đi sẽ kết thúc và chuyển vào Trip History.`)) {
        try {
            const response = await fetch(`http://localhost:8080/api/drivers/trips/${tripId}/complete`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            const data = await response.json();

            if (data.success) {
                alert('✅ Chuyến đi hoàn thành!\n\nCảm ơn bạn đã hoàn thành tốt chuyến đi! 🎉');
                
                // Close modal
                const modal = bootstrap.Modal.getInstance(document.getElementById('tripDetailModal'));
                if (modal) modal.hide();
                
                // Reload data
                await fetchTripsData();
            } else {
                alert('❌ Lỗi: ' + (data.message || 'Không thể hoàn thành chuyến đi'));
            }
        } catch (error) {
            console.error('Error completing trip:', error);
            alert('❌ Lỗi kết nối đến server. Vui lòng thử lại!');
        }
    }
}

// Cancel trip (hủy chuyến đi khi đã confirmed)
async function cancelTrip(tripId) {
    const reason = prompt('Vui lòng nhập lý do hủy chuyến đi:');
    if (!reason) return;
    
    if (confirm(`Bạn có chắc muốn HỦY chuyến đi #${tripId}?\n\nChuyến đi sẽ bị hủy và chuyển vào Trip History.`)) {
        try {
            const response = await fetch(`http://localhost:8080/api/drivers/trips/${tripId}/reject`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ reason })
            });

            const data = await response.json();

            if (data.success) {
                alert('✅ Đã hủy chuyến đi!');
                
                // Close modal
                const modal = bootstrap.Modal.getInstance(document.getElementById('tripDetailModal'));
                if (modal) modal.hide();
                
                // Reload data
                await fetchTripsData();
            } else {
                alert('❌ Lỗi: ' + (data.message || 'Không thể hủy chuyến đi'));
            }
        } catch (error) {
            console.error('Error cancelling trip:', error);
            alert('❌ Lỗi kết nối đến server. Vui lòng thử lại!');
        }
    }
}

// ========== Helper Functions ==========

// Show notification
function showNotification(message, type) {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} notification-toast`;
    notification.style.cssText = `
        position: fixed;
        top: 80px;
        right: 20px;
        z-index: 9999;
        min-width: 300px;
        animation: slideIn 0.3s ease-out;
    `;
    notification.innerHTML = `
        <i class="bi bi-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
        ${message}
    `;
    
    document.body.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease-out';
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 3000);
}

// Add CSS for notification animation
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
    
    .notification-toast {
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        border-radius: 8px;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    
    .notification-toast i {
        font-size: 20px;
    }
`;
document.head.appendChild(style);

// Handle logout
function handleLogout() {
    if (confirm('Bạn có chắc muốn đăng xuất?')) {
        // Clear local storage
        localStorage.removeItem('driverId');
        localStorage.removeItem('driverName');
        localStorage.removeItem('token');
        
        // Redirect to login page
        window.location.href = '../../html/login.html';
    }
}

// Initialize page
document.addEventListener('DOMContentLoaded', function() {
    // Check if driver is logged in
    if (!currentDriverId) {
        console.error('Driver not logged in');
        window.location.href = '../html/login.html';
        return;
    }

    console.log('Trips page loaded');
    
    // Set current date as default for date filter
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('dateFilter').value = today;
    
    // Fetch trips data
    fetchTripsData();
    
    // Setup filter event listeners
    document.getElementById('statusFilter').addEventListener('change', filterTrips);
    document.getElementById('dateFilter').addEventListener('change', filterTrips);
    document.getElementById('searchInput').addEventListener('input', filterTrips);
});

// Export functions to window for HTML onclick access
window.filterTrips = filterTrips;
window.resetFilters = resetFilters;
window.viewTripDetail = viewTripDetail;
window.acceptTrip = acceptTrip;
window.rejectTrip = rejectTrip;
window.startTrip = startTrip;
window.completeTrip = completeTrip;
window.cancelTrip = cancelTrip;
window.handleLogout = handleLogout;
