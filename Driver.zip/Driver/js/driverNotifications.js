// Notifications Page JavaScript

// Global variables
let notificationsData = [];
let currentFilter = 'all';
let currentDriverId = localStorage.getItem('driverId');

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    console.log('🔔 Notifications page loaded, driver ID:', currentDriverId);
    
    if (!currentDriverId) {
        console.error('❌ Driver not logged in');
        window.location.href = '../../html/login.html';
        return;
    }
    
    setupFilterTabs();
    loadNotifications();
});

// Setup filter tabs
function setupFilterTabs() {
    const tabs = document.querySelectorAll('.tab-btn');
    tabs.forEach(tab => {
        tab.addEventListener('click', function() {
            // Remove active from all tabs
            tabs.forEach(t => t.classList.remove('active'));
            // Add active to clicked tab
            this.classList.add('active');
            // Filter notifications
            const filter = this.getAttribute('data-filter');
            currentFilter = filter;
            filterNotifications(filter);
        });
    });
}

// Load notifications from API
async function loadNotifications() {
    try {
        console.log('📡 Loading notifications for driver:', currentDriverId);
        showLoading();
        
        const response = await fetch(`http://localhost:8080/api/drivers/${currentDriverId}/assigned-trips`);
        const data = await response.json();
        
        console.log('📦 API Response:', data);
        
        if (data.success && data.trips) {
            notificationsData = data.trips.map(trip => ({
                id: trip.bookingId,
                customer: trip.customerName,
                phone: trip.customerPhone,
                pickup: trip.pickupLocation,
                dropoff: trip.dropoffLocation,
                distance: trip.distance ? `${trip.distance} km` : 'N/A',
                price: trip.fare,
                status: trip.status, // confirmed, renting, completed, cancelled
                time: trip.startTime,
                rawData: trip
            }));
            
            console.log('✅ Loaded', notificationsData.length, 'notifications');
            renderNotifications(notificationsData);
            updateBadges();
        } else {
            console.log('ℹ️ No trips found');
            showEmptyState();
        }
        
        hideLoading();
    } catch (error) {
        console.error('❌ Error loading notifications:', error);
        showEmptyState();
        hideLoading();
    }
}

// Render notifications
function renderNotifications(notifications) {
    const container = document.getElementById('notificationsContainer');
    
    if (!notifications || notifications.length === 0) {
        showEmptyState();
        return;
    }
    
    container.innerHTML = '';
    
    notifications.forEach(notif => {
        const card = createNotificationCard(notif);
        container.appendChild(card);
    });
}

// Create notification card element
function createNotificationCard(notif) {
    const card = document.createElement('div');
    card.className = 'notification-card';
    card.setAttribute('data-id', notif.id);
    card.setAttribute('data-status', notif.status);
    
    // Add 'new' class for pending trips
    if (notif.status === 'confirmed') {
        card.classList.add('new');
    }
    
    // Determine status badge
    let statusBadge = '';
    let actionButton = '';
    
    if (notif.status === 'confirmed') {
        statusBadge = '<span class="badge bg-warning">Chuyến đi mới</span>';
        actionButton = `
            <button class="btn btn-primary btn-sm" onclick="viewTripDetail(${notif.id})">
                <i class="bi bi-arrow-right-circle"></i> Xem & Xử lý
            </button>
        `;
    } else if (notif.status === 'renting') {
        statusBadge = '<span class="badge bg-primary">Đang thực hiện</span>';
        actionButton = `
            <button class="btn btn-info btn-sm" onclick="viewTripDetail(${notif.id})">
                <i class="bi bi-eye"></i> Xem chi tiết
            </button>
        `;
    } else if (notif.status === 'completed') {
        statusBadge = '<span class="badge bg-success">Hoàn thành</span>';
        actionButton = `
            <button class="btn btn-secondary btn-sm" onclick="viewTripDetail(${notif.id})">
                <i class="bi bi-eye"></i> Xem chi tiết
            </button>
        `;
    } else if (notif.status === 'cancelled') {
        statusBadge = '<span class="badge bg-secondary">Đã hủy</span>';
    }
    
    card.innerHTML = `
        <div class="notification-header">
            <div class="notification-title">
                <i class="bi bi-car-front"></i>
                <strong>Chuyến #${notif.id}</strong>
            </div>
            <div class="notification-time">
                <i class="bi bi-clock"></i>
                ${formatDateTime(notif.time)}
            </div>
        </div>
        
        <div class="notification-body">
            <div class="customer-info">
                <i class="bi bi-person-fill"></i>
                <div>
                    <strong>${notif.customer}</strong>
                    <small><i class="bi bi-telephone"></i> ${notif.phone}</small>
                </div>
            </div>
            
            <div class="route-compact">
                <div class="route-point pickup">
                    <i class="bi bi-geo-alt-fill"></i>
                    <span>${notif.pickup}</span>
                </div>
                
                <div class="route-arrow">
                    <i class="bi bi-arrow-right"></i>
                </div>
                
                <div class="route-point dropoff">
                    <i class="bi bi-geo-alt-fill"></i>
                    <span>${notif.dropoff}</span>
                </div>
            </div>
            
            <div class="price-tag">
                <i class="bi bi-cash-coin"></i>
                <strong>${formatCurrency(notif.price)}</strong>
            </div>
        </div>
        
        <div class="notification-footer">
            ${statusBadge}
            ${actionButton}
        </div>
    `;
    
    return card;
}

// Filter notifications
function filterNotifications(filter) {
    console.log('🔍 Filtering notifications:', filter);
    
    let filtered = notificationsData;
    
    if (filter === 'pending') {
        filtered = notificationsData.filter(n => n.status === 'confirmed');
    } else if (filter === 'accepted') {
        filtered = notificationsData.filter(n => n.status === 'renting' || n.status === 'completed');
    }
    
    renderNotifications(filtered);
}

// View trip detail (redirect to Active Trips)
function viewTripDetail(id) {
    window.location.href = `trip.html?id=${id}`;
}

// Update notification badges
function updateBadges() {
    const pendingCount = notificationsData.filter(n => n.status === 'confirmed').length;
    
    // Update topbar badge
    const topbarBadge = document.getElementById('notification-count');
    if (topbarBadge) {
        if (pendingCount > 0) {
            topbarBadge.textContent = pendingCount;
            topbarBadge.style.display = 'inline-block';
        } else {
            topbarBadge.style.display = 'none';
        }
    }
    
    // Update sidebar badge
    const sidebarBadge = document.getElementById('sidebar-notification-badge');
    if (sidebarBadge) {
        if (pendingCount > 0) {
            sidebarBadge.textContent = pendingCount;
            sidebarBadge.style.display = 'inline-block';
        } else {
            sidebarBadge.style.display = 'none';
        }
    }
}

// Show loading state
function showLoading() {
    const container = document.getElementById('notificationsContainer');
    container.innerHTML = `
        <div class="loading-state text-center py-5">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
            <p class="mt-3 text-muted">Đang tải thông báo...</p>
        </div>
    `;
}

// Hide loading state
function hideLoading() {
    const loadingState = document.querySelector('.loading-state');
    if (loadingState) {
        loadingState.remove();
    }
}

// Show empty state
function showEmptyState() {
    const container = document.getElementById('notificationsContainer');
    container.innerHTML = `
        <div class="empty-state text-center py-5">
            <i class="bi bi-bell-slash display-1 text-muted"></i>
            <h4 class="mt-3">Không có thông báo</h4>
            <p class="text-muted">Bạn chưa có chuyến đi nào được phân công</p>
        </div>
    `;
}

// Format currency
function formatCurrency(amount) {
    if (!amount) return 'N/A';
    return new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND'
    }).format(amount);
}

// Format date time
function formatDateTime(dateString) {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleString('vi-VN', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

// Logout function
function handleLogout() {
    if (confirm('Bạn có chắc muốn đăng xuất?')) {
        localStorage.removeItem('driverId');
        localStorage.removeItem('driverName');
        localStorage.removeItem('driverToken');
        localStorage.removeItem('token');
        window.location.href = '../../html/login.html';
    }
}

// Export functions to window for HTML onclick
window.viewTripDetail = viewTripDetail;
window.handleLogout = handleLogout;