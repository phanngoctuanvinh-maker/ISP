package com.carrentleproject.drivenow.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * ZaloPay Configuration
 * Chứa các thông tin cấu hình để kết nối với ZaloPay API
 */
@Configuration
public class ZaloPayConfig {
    
    // ZaloPay sandbox credentials
    @Value("${zalopay.app.id:553}")
    private String appId;
    
    @Value("${zalopay.key1:9phuAOYhan4urywHTh0ndEXiV3pKHr5Q}")
    private String key1;
    
    @Value("${zalopay.key2:Iyz2habzyr7AG8SgvoBCbKwKi3UzlLi3}")
    private String key2;
    
    @Value("${zalopay.endpoint.create:https://sandbox.zalopay.com.vn/v001/tpe/createorder}")
    private String createOrderEndpoint;
    
    @Value("${zalopay.endpoint.query:https://sandbox.zalopay.com.vn/v001/tpe/getstatusbyapptransid}")
    private String queryEndpoint;
    
    @Value("${zalopay.endpoint.refund:https://sandbox.zalopay.com.vn/v001/tpe/partialrefund}")
    private String refundEndpoint;
    
    @Value("${zalopay.callback.url:http://localhost:8080/api/zalopay/callback}")
    private String callbackUrl;
    
    public String getAppId() {
        return appId;
    }
    
    public String getKey1() {
        return key1;
    }
    
    public String getKey2() {
        return key2;
    }
    
    public String getCreateOrderEndpoint() {
        return createOrderEndpoint;
    }
    
    public String getQueryEndpoint() {
        return queryEndpoint;
    }
    
    public String getRefundEndpoint() {
        return refundEndpoint;
    }
    
    public String getCallbackUrl() {
        return callbackUrl;
    }
    
    /**
     * Get current timestamp string in specified format
     */
    public String getCurrentTimeString(String format) {
        Calendar cal = new GregorianCalendar(TimeZone.getTimeZone("GMT+7"));
        SimpleDateFormat fmt = new SimpleDateFormat(format);
        fmt.setCalendar(cal);
        return fmt.format(cal.getTimeInMillis());
    }
    
    /**
     * Generate random number string
     */
    public String getRandomNumber(int len) {
        Random random = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < len; i++) {
            sb.append(random.nextInt(10));
        }
        return sb.toString();
    }
}
