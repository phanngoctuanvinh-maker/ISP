package com.carrentleproject.drivenow.config;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.init.DatabasePopulatorUtils;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;

/**
 * Simple SQL migration runner that executes SQL scripts found under
 * classpath:db/migration/*.sql using Spring's ResourceDatabasePopulator.
 *
 * This supports SQL Server batch separator "GO" by setting the separator
 * so the scripts in this project (which contain GO markers) will run.
 *
 * The runner is guarded by the property `app.migrations.enabled` (default true).
 */
@Configuration
public class SqlMigrationRunner implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(SqlMigrationRunner.class);

    @Autowired
    private DataSource dataSource;

    @Value("${app.migrations.enabled:true}")
    private boolean migrationsEnabled;

    @Override
    public void run(ApplicationArguments args) throws Exception {
        if (!migrationsEnabled) {
            log.info("SQL migrations disabled by app.migrations.enabled=false");
            return;
        }

        log.info("Starting SQL migrations from classpath:db/migration");

        PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        Resource[] scripts = resolver.getResources("classpath:db/migration/*.sql");

        if (scripts == null || scripts.length == 0) {
            log.info("No SQL migration scripts found under classpath:db/migration");
            return;
        }

        // sort resources by filename to ensure deterministic ordering
        java.util.Arrays.sort(scripts, (a, b) -> a.getFilename().compareTo(b.getFilename()));

        ResourceDatabasePopulator populator = new ResourceDatabasePopulator();
        // SQL Server scripts in this repo use GO as batch separator
        populator.setSeparator("GO");
        populator.setContinueOnError(true);
        for (Resource r : scripts) {
            log.info("Adding migration script: {}", r.getFilename());
            populator.addScript(r);
        }

        try {
            DatabasePopulatorUtils.execute(populator, dataSource);
            log.info("SQL migrations executed");
        } catch (Exception ex) {
            log.error("Error executing SQL migration scripts", ex);
            // Do not rethrow to avoid killing the whole app; migrations are best-effort here.
        }
    }
}
