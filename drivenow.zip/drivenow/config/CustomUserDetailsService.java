package com.carrentleproject.drivenow.config;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.carrentleproject.drivenow.dao.AccountDAO;
import com.carrentleproject.drivenow.dao.CustomerDAO;
import com.carrentleproject.drivenow.model.Account;
import com.carrentleproject.drivenow.model.Customer;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private AccountDAO accountDAO;

    @Autowired
    private CustomerDAO customerDAO;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Account account = null;

        // Kiểm tra xem username là email hay phone
        if (username.contains("@")) {
            // Đăng nhập bằng email
            account = accountDAO.findByUsername(username)
                    .orElseThrow(() -> new UsernameNotFoundException("Email không tồn tại: " + username));
        } else {
            // Đăng nhập bằng phone
            Optional<Customer> customerOpt = customerDAO.findByPhone(username);
            if (customerOpt.isPresent()) {
                account = customerOpt.get().getAccount();
            } else {
                throw new UsernameNotFoundException("Số điện thoại không tồn tại: " + username);
            }
        }

        // Kiểm tra trạng thái tài khoản TRƯỚC KHI trả về UserDetails
        // Nếu tài khoản bị banned, throw exception ngay lập tức
        if ("banned".equalsIgnoreCase(account.getStatus())) {
            throw new org.springframework.security.authentication.DisabledException(
                "Tài khoản của bạn đã bị khóa. Vui lòng liên hệ quản trị viên để biết thêm chi tiết.");
        } else if (!"active".equalsIgnoreCase(account.getStatus())) {
            throw new org.springframework.security.authentication.DisabledException(
                "Tài khoản không khả dụng. Trạng thái: " + account.getStatus());
        }

        List<GrantedAuthority> authorities = new ArrayList<>();
        authorities.add(new SimpleGrantedAuthority("ROLE_" + account.getRole().toUpperCase()));

        // Return UserDetails - Account is active
        return new User(account.getUsername(), account.getPassword(), authorities);
    }
}
