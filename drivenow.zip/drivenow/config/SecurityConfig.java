package com.carrentleproject.drivenow.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {
    @Bean
    public org.springframework.web.cors.CorsConfigurationSource corsConfigurationSource() {
        org.springframework.web.cors.CorsConfiguration configuration = new org.springframework.web.cors.CorsConfiguration();
        // Allow all origins for testing (Postman, browser, etc.)
        configuration.addAllowedOriginPattern("*");
        configuration.setAllowedMethods(java.util.Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        configuration.setAllowedHeaders(java.util.Arrays.asList("*"));
        configuration.setAllowCredentials(false); // Must be false to allow all origins
        org.springframework.web.cors.UrlBasedCorsConfigurationSource source = new org.springframework.web.cors.UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }

    @Autowired
    private UserDetailsService userDetailsService;

    @Autowired
    private JwtAuthenticationFilter jwtAuthenticationFilter;

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @SuppressWarnings("deprecation")
    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
        authProvider.setUserDetailsService(userDetailsService);
        authProvider.setPasswordEncoder(passwordEncoder());
        return authProvider;
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authConfig) throws Exception {
        return authConfig.getAuthenticationManager();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .cors().and()
                .csrf(csrf -> csrf.disable())
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers(org.springframework.http.HttpMethod.OPTIONS, "/**").permitAll() // Cho phép
                                                                                                         // OPTIONS
                        .requestMatchers("/api/auth/**", "/auth/**", "/api/validation/**").permitAll()
                        .requestMatchers("/api/test/**").permitAll()
                        .requestMatchers("/api/cars/**").permitAll() // Allow public access to car search API
                        .requestMatchers("/api/long-term-cars/**").permitAll() // Allow public access to long-term car
                                                                               // rental API
                        .requestMatchers("/api/vehicles/**").permitAll() // Allow admin frontend to call vehicle
                                                                         // management API
                        .requestMatchers("/api/customers/**").permitAll() // Allow admin frontend to call customer
                                                                          // management API
                        .requestMatchers("/api/orders/**").permitAll() // Allow admin frontend to call order management
                                                                       // API
                        .requestMatchers("/api/drivers/**").permitAll() // Allow admin frontend to call driver
                                                                        // management API
                        .requestMatchers("/api/coupons/**").permitAll() // Allow admin frontend to call coupon
                                                                        // management API
                        .requestMatchers("/api/dashboard/**").permitAll() // Allow admin frontend to call dashboard API
                        .requestMatchers("/api/promotions/test", "/api/promotions/active", "/api/promotions",
                                "/api/promo-codes/**", "/api/vnpay/**")
                        .permitAll()
                        .requestMatchers("/api/payment/**").permitAll() // Allow payment endpoints
                        .requestMatchers("/api/payments/**").permitAll() // Allow payments list endpoint (with 's')
                        .requestMatchers("/api/zalopay/**").permitAll() // Allow ZaloPay payment endpoints
                        .requestMatchers("/api/profile/**", "/profile/**").authenticated()
                        // Allow booking endpoints for testing (temporary). Remove or secure in
                        // production.
                        .requestMatchers("/api/bookings/**").permitAll()
                        .requestMatchers("/api/accounts/**").permitAll() // Allow account endpoints for profile
                        .anyRequest().authenticated())
                .authenticationProvider(authenticationProvider())
                .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}
