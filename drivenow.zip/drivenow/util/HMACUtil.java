package com.carrentleproject.drivenow.util;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;

/**
 * HMAC Utility for ZaloPay integration
 * Dùng để tạo MAC signature cho các API call tới ZaloPay
 */
public class HMACUtil {
    
    public static final String HMACSHA256 = "HmacSHA256";
    
    /**
     * Generate HMAC hex string
     * @param algorithm - HMAC algorithm (e.g., HmacSHA256)
     * @param key - Secret key
     * @param data - Data to sign
     * @return MAC signature in hex format
     */
    public static String HMacHexStringEncode(String algorithm, String key, String data) {
        try {
            Mac hmac = Mac.getInstance(algorithm);
            SecretKeySpec secretKeySpec = new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), algorithm);
            hmac.init(secretKeySpec);
            
            byte[] hashBytes = hmac.doFinal(data.getBytes(StandardCharsets.UTF_8));
            
            // Convert bytes to hex string
            StringBuilder hexString = new StringBuilder();
            for (byte b : hashBytes) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            
            return hexString.toString();
        } catch (Exception e) {
            throw new RuntimeException("Error generating HMAC: " + e.getMessage(), e);
        }
    }
}
