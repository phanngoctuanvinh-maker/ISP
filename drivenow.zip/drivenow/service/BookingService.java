package com.carrentleproject.drivenow.service;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.carrentleproject.drivenow.dao.BookingCarRepository;
import com.carrentleproject.drivenow.dao.BookingRepository;
import com.carrentleproject.drivenow.dao.CarRepository;
import com.carrentleproject.drivenow.dao.CustomerDAO;
import com.carrentleproject.drivenow.dto.BookingRequest;
import com.carrentleproject.drivenow.dto.BookingPriceRequest;
import com.carrentleproject.drivenow.dto.BookingPriceResponse;
import com.carrentleproject.drivenow.dto.GroupBookingRequest;
import com.carrentleproject.drivenow.exception.BadRequestException;
import com.carrentleproject.drivenow.model.Booking;
import com.carrentleproject.drivenow.model.BookingCar;
import com.carrentleproject.drivenow.model.Car;
import com.carrentleproject.drivenow.model.Customer;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private BookingCarRepository bookingCarRepository;

    @Autowired
    private CarRepository carRepository;

    @Autowired
    private CustomerDAO customerDAO;

    @Transactional
    public Booking createBooking(BookingRequest req) {
        // Basic validation
        if (req.getCarId() == null)
            throw new BadRequestException("carId is required");
        if (req.getStartTime() == null || req.getEndTime() == null) {
            throw new BadRequestException("startTime and endTime are required");
        }

        // Convert accountId to customerId if needed
        Long finalCustomerId = req.getCustomerId();
        if (finalCustomerId != null) {
            // Check if this is accountId, try to find customer
            Customer customer = customerDAO.findByAccountAccountId(finalCustomerId.intValue()).orElse(null);
            if (customer != null) {
                finalCustomerId = customer.getCustomerId().longValue();
                System.out
                        .println("✅ Converted accountId " + req.getCustomerId() + " to customerId " + finalCustomerId);
            } else {
                // Maybe it's already customerId, keep it
                System.out.println("⚠️ Using provided ID as customerId: " + finalCustomerId);
            }
        }

        Car car = carRepository.findById(req.getCarId()).orElseThrow(() -> new RuntimeException("Car not found"));

        // Availability check: ensure no overlapping booking exists for this car
        var overlaps = bookingCarRepository.findOverlappingBookings(car.getId(), req.getStartTime(), req.getEndTime());
        if (overlaps != null && !overlaps.isEmpty()) {
            throw new RuntimeException("Car is already booked for the selected period");
        }

        // Validation for route types
        if (req.getTripType() != null && req.getTripType().equalsIgnoreCase("lien_tinh")
                && Boolean.TRUE.equals(req.getOneWay())) {
            // One-way inter-province requires a dropoff location
            if ((req.getDropoffLocation() == null || req.getDropoffLocation().isBlank())
                    && (req.getSpecificPickupAddress() == null || req.getSpecificPickupAddress().isBlank())) {
                throw new BadRequestException("One-way inter-province trip requires a dropoff location");
            }
        }

        // Server-side pricing calculation
        long hours = Duration.between(req.getStartTime(), req.getEndTime()).toHours();
        int days = (int) Math.max(1, Math.ceil(hours / 24.0));
        BigDecimal pricePerDay = car.getPricePerDay() == null ? BigDecimal.ZERO : car.getPricePerDay();
        BigDecimal basePrice = req.getBasePrice() != null ? req.getBasePrice()
                : pricePerDay.multiply(BigDecimal.valueOf(days));
        BigDecimal insuranceFee = req.getInsuranceFee() != null ? req.getInsuranceFee() : BigDecimal.ZERO;
        BigDecimal transferFee = req.getTransferFee() != null ? req.getTransferFee() : BigDecimal.ZERO;
        BigDecimal discountAmount = req.getDiscountAmount() != null ? req.getDiscountAmount() : BigDecimal.ZERO;
        BigDecimal totalAmount = basePrice.add(insuranceFee).add(transferFee).subtract(discountAmount);

        Booking booking = new Booking();
        booking.setCustomerId(finalCustomerId); // Use converted customerId
        booking.setCarId(req.getCarId()); // SET CAR ID!
        booking.setDriverId(req.getDriverId());
        booking.setStartTime(req.getStartTime());
        booking.setEndTime(req.getEndTime());

        // SET REQUIRED NOT NULL FIELDS
        booking.setPickupDate(req.getStartTime()); // pickup_date = pickup_time
        booking.setReturnDate(req.getEndTime()); // return_date = return_time
        booking.setTotalDays(days); // total_days calculated above

        booking.setBasePrice(basePrice);
        booking.setInsuranceFee(insuranceFee);
        booking.setTransferFee(transferFee);
        booking.setDiscountAmount(discountAmount);
        booking.setTotalAmount(totalAmount);
        booking.setPickupLocation(req.getPickupLocation());
        booking.setDropoffLocation(req.getDropoffLocation());
        // route-related fields
        booking.setTripType(req.getTripType());
        booking.setOneWay(req.getOneWay());
        booking.setPickupPoint(req.getPickupPoint());
        booking.setSpecificPickupAddress(req.getSpecificPickupAddress());
        booking.setAllowedKmPerDay(req.getAllowedKmPerDay());
        booking.setExceedFeePerKm(req.getExceedFeePerKm());
        booking.setFuelConsumption(req.getFuelConsumption() == null ? null : req.getFuelConsumption().doubleValue());
        booking.setPromoCode(req.getPromoCode());
        booking.setStatus("pending");
        booking.setCreatedAt(LocalDateTime.now());
        // Persist booking with computed totals (use server-side calculation above)
        // Note: do NOT overwrite computed basePrice/totalAmount with request values
        // here.
        booking = bookingRepository.save(booking);

        BookingCar bc = new BookingCar();
        bc.setBookingId(booking.getBookingId());
        bc.setCarId(car.getId());
        bc.setStartDate(req.getStartTime());
        bc.setEndDate(req.getEndTime());
        BigDecimal priceAtBooking = req.getPriceAtBooking() != null ? req.getPriceAtBooking() : pricePerDay;
        bc.setPriceAtBooking(priceAtBooking);
        bc.setTotalPrice(priceAtBooking.multiply(BigDecimal.valueOf(days)));
        bookingCarRepository.save(bc);

        // NOTE: Không cập nhật trạng thái xe ở đây
        // Trạng thái xe chỉ được cập nhật sang "rented" SAU KHI thanh toán thành công
        // Xe vẫn giữ trạng thái "available" cho đến khi payment được xác nhận

        return booking;
    }

    @Transactional
    public Booking createGroupBooking(GroupBookingRequest req) {
        // Basic validation
        if (req.getStartTime() == null || req.getEndTime() == null) {
            throw new BadRequestException("startTime and endTime are required");
        }

        if (req.getTripType() != null && req.getTripType().equalsIgnoreCase("lien_tinh")
                && Boolean.TRUE.equals(req.getOneWay())) {
            if ((req.getDropoffLocation() == null || req.getDropoffLocation().isBlank())
                    && (req.getPickupPoint() == null || req.getPickupPoint().isBlank())) {
                throw new BadRequestException("One-way inter-province trip requires a dropoff location");
            }
        }

        Booking booking = new Booking();
        booking.setCustomerId(req.getCustomerId());
        booking.setStartTime(req.getStartTime());
        booking.setEndTime(req.getEndTime());

        // Calculate total days for group booking
        long hours = Duration.between(req.getStartTime(), req.getEndTime()).toHours();
        int totalDays = (int) Math.max(1, Math.ceil(hours / 24.0));

        // SET REQUIRED NOT NULL FIELDS
        booking.setPickupDate(req.getStartTime());
        booking.setReturnDate(req.getEndTime());
        booking.setTotalDays(totalDays);

        booking.setPickupLocation(req.getPickupLocation());
        booking.setDropoffLocation(req.getDropoffLocation());
        // map route-related fields
        booking.setTripType(req.getTripType());
        booking.setOneWay(req.getOneWay());
        booking.setPickupPoint(req.getPickupPoint());
        booking.setSpecificPickupAddress(req.getSpecificPickupAddress());
        booking.setAllowedKmPerDay(req.getAllowedKmPerDay());
        booking.setExceedFeePerKm(req.getExceedFeePerKm());
        booking.setFuelConsumption(req.getFuelConsumption() == null ? null : req.getFuelConsumption().doubleValue());
        booking.setPromoCode(req.getPromoCode());

        booking.setStatus("pending");
        booking.setCreatedAt(LocalDateTime.now());

        // Prepare BookingCar items and compute totals BEFORE persisting the booking so
        // the booking can be created with a correct non-null total_amount.
        List<BookingCar> toSave = new ArrayList<>();
        BigDecimal totalSum = BigDecimal.ZERO;
        if (req.getCars() != null) {
            for (GroupBookingRequest.CarItem item : req.getCars()) {
                Car car = carRepository.findById(item.carId)
                        .orElseThrow(() -> new RuntimeException("Car not found: " + item.carId));
                java.time.LocalDateTime s = item.startDate != null ? item.startDate : req.getStartTime();
                java.time.LocalDateTime e = item.endDate != null ? item.endDate : req.getEndTime();

                // availability check
                if (s != null && e != null) {
                    var overlaps = bookingCarRepository.findOverlappingBookings(car.getId(), s, e);
                    if (overlaps != null && !overlaps.isEmpty()) {
                        throw new RuntimeException("Car " + car.getId() + " is already booked for the selected period");
                    }
                }

                long carHours = Duration.between(s, e).toHours();
                int days = (int) Math.max(1, Math.ceil(carHours / 24.0));
                BigDecimal pricePerDay = car.getPricePerDay() == null ? BigDecimal.ZERO : car.getPricePerDay();
                BigDecimal priceAtBooking = item.priceAtBooking != null ? item.priceAtBooking : pricePerDay;
                BigDecimal totalPrice = item.totalPrice != null ? item.totalPrice
                        : priceAtBooking.multiply(BigDecimal.valueOf(days));

                BookingCar bc = new BookingCar();
                // bookingId will be set after booking is persisted
                bc.setCarId(car.getId());
                bc.setStartDate(s);
                bc.setEndDate(e);
                bc.setPriceAtBooking(priceAtBooking);
                bc.setTotalPrice(totalPrice);
                toSave.add(bc);

                totalSum = totalSum.add(totalPrice == null ? BigDecimal.ZERO : totalPrice);
            }
        }

        // persist booking with totals
        booking.setBasePrice(req.getBasePrice() != null ? req.getBasePrice() : totalSum);
        booking.setTotalAmount(req.getTotalAmount() != null ? req.getTotalAmount() : totalSum);
        booking = bookingRepository.save(booking);

        // now persist BookingCar rows
        // NOTE: Không cập nhật trạng thái xe ở đây
        // Trạng thái xe chỉ được cập nhật sang "rented" SAU KHI thanh toán thành công
        for (BookingCar bc : toSave) {
            bc.setBookingId(booking.getBookingId());
            bookingCarRepository.save(bc);
        }

        return booking;
    }

    /**
     * Get booking by ID
     */
    public Booking getBookingById(Long bookingId) {
        return bookingRepository.findById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found with ID: " + bookingId));
    }

    /**
     * Get all bookings by customer ID
     */
    public List<Booking> getBookingsByCustomerId(Long customerId) {
        return bookingRepository.findByCustomerId(customerId);
    }

    /**
     * Get all bookings
     */
    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }

    /**
     * Get bookings by status
     */
    public List<Booking> getBookingsByStatus(String status) {
        return bookingRepository.findByStatus(status);
    }

    /**
     * Update booking status
     */
    @Transactional
    public Booking updateBookingStatus(Long bookingId, String newStatus) {
        Booking booking = getBookingById(bookingId);
        booking.setStatus(newStatus);
        booking.setUpdatedAt(LocalDateTime.now());
        return bookingRepository.save(booking);
    }

    /**
     * Cancel booking
     */
    @Transactional
    public Booking cancelBooking(Long bookingId) {
        Booking booking = getBookingById(bookingId);
        booking.setStatus("cancelled");
        booking.setUpdatedAt(LocalDateTime.now());

        // Cập nhật trạng thái xe về available
        List<BookingCar> bookingCars = bookingCarRepository.findByBookingId(bookingId);
        for (BookingCar bc : bookingCars) {
            try {
                Car car = carRepository.findById(bc.getCarId()).orElse(null);
                if (car != null) {
                    car.setStatus("available");
                    carRepository.save(car);
                }
            } catch (Exception ex) {
                // ignore
            }
        }

        return bookingRepository.save(booking);
    }

    /**
     * Calculate booking price (server-side pricing algorithm)
     * This method computes all pricing components before actual booking
     */
    public BookingPriceResponse calculateBookingPrice(BookingPriceRequest req) {
        // Validate input
        if (req.getCarId() == null) {
            throw new BadRequestException("carId is required");
        }
        if (req.getStartDate() == null || req.getEndDate() == null) {
            throw new BadRequestException("startDate and endDate are required");
        }

        // Get car info
        Car car = carRepository.findById(req.getCarId())
                .orElseThrow(() -> new RuntimeException("Car not found"));

        // Parse dates
        LocalDateTime startDateTime = LocalDateTime.parse(req.getStartDate());
        LocalDateTime endDateTime = LocalDateTime.parse(req.getEndDate());

        // Calculate duration
        long durationMs = Duration.between(startDateTime, endDateTime).toMillis();
        double durationHours = durationMs / (1000.0 * 60 * 60);
        int durationDays = (int) Math.max(1, Math.ceil(durationHours / 24.0));

        // Base price (theo ngày)
        BigDecimal pricePerDay = car.getPricePerDay() != null ? car.getPricePerDay() : BigDecimal.ZERO;
        double basePrice = pricePerDay.doubleValue() * durationDays;

        // Insurance fee (2% giá thuê)
        double insuranceFee = basePrice * 0.02;

        // Service fee (dựa vào khoảng cách hoặc cố định)
        double serviceFee;
        double distanceKm = req.getDistanceKm() != null ? req.getDistanceKm() : 0;

        if (distanceKm > 0) {
            serviceFee = distanceKm * 2000; // 2000đ/km
        } else {
            serviceFee = 10000; // Phí cố định 10k
        }

        // Allowed km and exceed fee
        Double allowedKm = null;
        double exceedFee = 0;
        double extraKm = 0;

        if (car.getDailyKmLimit() != null && car.getDailyKmLimit() > 0) {
            allowedKm = car.getDailyKmLimit().doubleValue() * durationDays;

            if (distanceKm > allowedKm) {
                extraKm = distanceKm - allowedKm;
                double exceedFeePerKm = car.getExceedFeePerKm() != null
                        ? car.getExceedFeePerKm().doubleValue()
                        : 5000;
                exceedFee = extraKm * exceedFeePerKm;
            }
        }

        // Total price
        double totalPrice = basePrice + insuranceFee + serviceFee + exceedFee;

        // Build response
        return BookingPriceResponse.builder()
                .rentalDays(durationDays)
                .rentalHours(Math.round(durationHours * 10) / 10.0)
                .basePrice(basePrice)
                .insuranceFee(insuranceFee)
                .serviceFee(serviceFee)
                .exceedFee(exceedFee)
                .totalPrice(totalPrice)
                .distanceKm(distanceKm)
                .allowedKm(allowedKm)
                .extraKm(extraKm)
                .areaType(req.getAreaType())
                .build();
    }

}
