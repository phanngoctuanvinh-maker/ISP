package com.carrentleproject.drivenow.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.carrentleproject.drivenow.config.JwtTokenProvider;
import com.carrentleproject.drivenow.dao.AccountDAO;
import com.carrentleproject.drivenow.dao.AdminDAO;
import com.carrentleproject.drivenow.dao.CustomerDAO;
import com.carrentleproject.drivenow.dao.DriverDAO;
import com.carrentleproject.drivenow.dto.ApiResponse;
import com.carrentleproject.drivenow.dto.AuthResponse;
import com.carrentleproject.drivenow.dto.ChangePasswordRequest;
import com.carrentleproject.drivenow.dto.ForgotPasswordRequest;
import com.carrentleproject.drivenow.dto.LoginRequest;
import com.carrentleproject.drivenow.dto.RegisterRequest;
import com.carrentleproject.drivenow.dto.ResetPasswordRequest;
import com.carrentleproject.drivenow.exception.BadRequestException;
import com.carrentleproject.drivenow.exception.UnauthorizedException;
import com.carrentleproject.drivenow.model.Account;
import com.carrentleproject.drivenow.model.Customer;
import com.carrentleproject.drivenow.model.Driver;

import jakarta.transaction.Transactional;

@Service
public class AuthService {

    @Autowired
    private AccountDAO accountDAO;

    @Autowired
    private CustomerDAO customerDAO;

    @Autowired
    private DriverDAO driverDAO;

    @Autowired
    private AdminDAO adminDAO;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtTokenProvider jwtTokenProvider;

    @Autowired
    private EmailService emailService;

    @Autowired
    private OTPService otpService;

    @Transactional
    public ApiResponse<AuthResponse> register(RegisterRequest request) {
        // Kiểm tra email (username) đã tồn tại
        if (accountDAO.existsByUsername(request.getUsername())) {
            throw new BadRequestException("Email này đã được đăng ký. Vui lòng sử dụng email khác hoặc đăng nhập.");
        }

        // Kiểm tra email đã tồn tại trong bảng Customer (double check)
        if ("customer".equals(request.getRole()) && customerDAO.existsByEmail(request.getUsername())) {
            throw new BadRequestException("Email này đã được đăng ký. Vui lòng sử dụng email khác hoặc đăng nhập.");
        }

        // Tạo Account
        Account account = new Account();
        account.setUsername(request.getUsername());
        account.setPassword(passwordEncoder.encode(request.getPassword()));
        account.setRole(request.getRole());
        account.setStatus("active");
        account = accountDAO.save(account);

        // Tạo Customer hoặc Driver
        if ("customer".equals(request.getRole())) {
            Customer customer = new Customer();
            customer.setAccount(account);
            customer.setFullName(request.getFullName());
            customer.setPhone(request.getPhone());
            customer.setEmail(request.getUsername());
            customer.setAddress(request.getAddress());
            customer.setDob(request.getDob());
            customer.setGender(request.getGender());
            customerDAO.save(customer);
        } else if ("driver".equals(request.getRole())) {
            Driver driver = new Driver();
            driver.setAccount(account);
            driver.setLicenseNumber(request.getLicenseNumber());
            driver.setYearsOfExperience(request.getYearsOfExperience());
            driver.setIdCard(request.getIdCard());
            driver.setAddress(request.getAddress());
            driver.setStatus("active");
            driverDAO.save(driver);
        }

        // Gửi email chào mừng
        try {
            emailService.sendWelcomeEmail(request.getUsername(), request.getFullName());
        } catch (Exception e) {
            // Log lỗi nhưng không throw exception
            System.err.println("Không thể gửi email chào mừng: " + e.getMessage());
        }

        // Generate JWT token
        String jwt = jwtTokenProvider.generateTokenFromUsername(account.getUsername());

        AuthResponse response = new AuthResponse(
                jwt,
                account.getAccountId(),
                account.getUsername(),
                account.getRole(),
                request.getFullName());
        response.setMessage("Đăng ký thành công");

        return ApiResponse.success("Đăng ký thành công", response);
    }

    public ApiResponse<AuthResponse> login(LoginRequest request) {
        try {
            // Authenticate
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            request.getUsername(),
                            request.getPassword()));

            SecurityContextHolder.getContext().setAuthentication(authentication);

            // Get account info - phải lấy từ authentication vì username có thể là phone
            String actualUsername = authentication.getName(); // Đây là email thực sự từ CustomUserDetailsService
            Account account = accountDAO.findByUsername(actualUsername)
                    .orElseThrow(() -> new UnauthorizedException("Tài khoản không tồn tại"));

            // Check account status (double-check for safety)
            if ("banned".equalsIgnoreCase(account.getStatus())) {
                throw new UnauthorizedException("Tài khoản của bạn đã bị khóa. Vui lòng liên hệ quản trị viên để biết thêm chi tiết.");
            }
            
            if (!"active".equalsIgnoreCase(account.getStatus())) {
                throw new UnauthorizedException("Tài khoản không khả dụng. Trạng thái: " + account.getStatus());
            }

            // Get full name
            String fullName = "";
            if ("customer".equals(account.getRole())) {
                Customer customer = customerDAO.findByAccountAccountId(account.getAccountId()).orElse(null);
                fullName = customer != null ? customer.getFullName() : "";
            } else if ("driver".equals(account.getRole())) {
                Driver driver = driverDAO.findByAccountAccountId(account.getAccountId()).orElse(null);
                fullName = driver != null ? (driver.getLicenseNumber() != null ? driver.getLicenseNumber() : "Driver") : "";
            }

            // Generate JWT token
            String jwt = jwtTokenProvider.generateToken(authentication);

            AuthResponse response = new AuthResponse(
                    jwt,
                    account.getAccountId(),
                    account.getUsername(),
                    account.getRole(),
                    fullName);

            return ApiResponse.success("Đăng nhập thành công", response);
            
        } catch (org.springframework.security.authentication.DisabledException e) {
            throw new UnauthorizedException("Tài khoản của bạn đã bị khóa. Vui lòng liên hệ quản trị viên để biết thêm chi tiết.");
        } catch (org.springframework.security.authentication.BadCredentialsException e) {
            throw new UnauthorizedException("Sai tên đăng nhập hoặc mật khẩu");
        }
    }

    @Transactional
    public ApiResponse<String> changePassword(String username, ChangePasswordRequest request) {
        Account account = accountDAO.findByUsername(username)
                .orElseThrow(() -> new BadRequestException("Tài khoản không tồn tại"));

        // Kiểm tra password cũ
        if (!passwordEncoder.matches(request.getCurrentPassword(), account.getPassword())) {
            throw new BadRequestException("Mật khẩu cũ không đúng");
        }

        // Kiểm tra password mới và confirm password
        if (!request.getNewPassword().equals(request.getConfirmPassword())) {
            throw new BadRequestException("Mật khẩu mới và xác nhận mật khẩu không khớp");
        }

        // Cập nhật password
        account.setPassword(passwordEncoder.encode(request.getNewPassword()));
        accountDAO.save(account);

        return ApiResponse.success("Đổi mật khẩu thành công", null);
    }

    public ApiResponse<String> forgotPassword(ForgotPasswordRequest request) {
        // Kiểm tra email có tồn tại không
        Account account = accountDAO.findByUsername(request.getEmail())
                .orElseThrow(() -> new BadRequestException("Email không tồn tại trong hệ thống"));

        // Tạo và gửi OTP
        otpService.generateAndSendOTP(request.getEmail());

        return ApiResponse.success("Mã OTP đã được gửi đến email của bạn", null);
    }

    @Transactional
    public ApiResponse<String> resetPassword(ResetPasswordRequest request) {
        // Kiểm tra OTP
        if (!otpService.verifyOTP(request.getEmail(), request.getOtpCode())) {
            throw new BadRequestException("Mã OTP không hợp lệ hoặc đã hết hạn");
        }

        // Kiểm tra password mới và confirm password
        if (!request.getNewPassword().equals(request.getConfirmPassword())) {
            throw new BadRequestException("Mật khẩu mới và xác nhận mật khẩu không khớp");
        }

        // Tìm account
        Account account = accountDAO.findByUsername(request.getEmail())
                .orElseThrow(() -> new BadRequestException("Email không tồn tại"));

        // Cập nhật password
        account.setPassword(passwordEncoder.encode(request.getNewPassword()));
        accountDAO.save(account);

        // Đánh dấu OTP đã sử dụng
        otpService.markOTPAsUsed(request.getEmail(), request.getOtpCode());

        return ApiResponse.success("Đặt lại mật khẩu thành công", null);
    }
}
