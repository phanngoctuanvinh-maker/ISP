package com.carrentleproject.drivenow.service;

import com.carrentleproject.drivenow.dao.AccountDAO;
import com.carrentleproject.drivenow.dao.CustomerDAO;
import com.carrentleproject.drivenow.dao.DriverDAO;
import com.carrentleproject.drivenow.dto.ApiResponse;
import com.carrentleproject.drivenow.dto.ProfileUpdateRequest;
import com.carrentleproject.drivenow.exception.BadRequestException;
import com.carrentleproject.drivenow.exception.ResourceNotFoundException;
import com.carrentleproject.drivenow.model.Account;
import com.carrentleproject.drivenow.model.Customer;
import com.carrentleproject.drivenow.model.Driver;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProfileService {

    @Autowired
    private AccountDAO accountDAO;

    @Autowired
    private CustomerDAO customerDAO;

    @Autowired
    private DriverDAO driverDAO;

    public ApiResponse<Object> getProfile(String username) {
        Account account = accountDAO.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException("Tài khoản không tồn tại"));

        if ("customer".equals(account.getRole())) {
            Customer customer = customerDAO.findByAccountAccountId(account.getAccountId())
                    .orElseThrow(() -> new ResourceNotFoundException("Thông tin khách hàng không tồn tại"));
            return ApiResponse.success("Lấy thông tin thành công", customer);
        } else if ("driver".equals(account.getRole())) {
            Driver driver = driverDAO.findByAccountAccountId(account.getAccountId())
                    .orElseThrow(() -> new ResourceNotFoundException("Thông tin tài xế không tồn tại"));
            return ApiResponse.success("Lấy thông tin thành công", driver);
        }

        return ApiResponse.success("Lấy thông tin thành công", account);
    }

    @Transactional
    public ApiResponse<Object> updateProfile(String username, ProfileUpdateRequest request) {
        Account account = accountDAO.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException("Tài khoản không tồn tại"));

        if ("customer".equals(account.getRole())) {
            Customer customer = customerDAO.findByAccountAccountId(account.getAccountId())
                    .orElseThrow(() -> new ResourceNotFoundException("Thông tin khách hàng không tồn tại"));

            if (request.getFullName() != null)
                customer.setFullName(request.getFullName());
            if (request.getPhone() != null)
                customer.setPhone(request.getPhone());
            if (request.getAddress() != null)
                customer.setAddress(request.getAddress());
            if (request.getDob() != null)
                customer.setDob(request.getDob());
            if (request.getGender() != null)
                customer.setGender(request.getGender());
            if (request.getAvatarUrl() != null)
                customer.setAvatarUrl(request.getAvatarUrl());

            customerDAO.save(customer);
            return ApiResponse.success("Cập nhật thông tin thành công", customer);

        } else if ("driver".equals(account.getRole())) {
            Driver driver = driverDAO.findByAccountAccountId(account.getAccountId())
                    .orElseThrow(() -> new ResourceNotFoundException("Thông tin tài xế không tồn tại"));

            if (request.getLicenseNumber() != null)
                driver.setLicenseNumber(request.getLicenseNumber());
            if (request.getYearsOfExperience() != null)
                driver.setYearsOfExperience(request.getYearsOfExperience());
            if (request.getIdCard() != null)
                driver.setIdCard(request.getIdCard());
            if (request.getAddress() != null)
                driver.setAddress(request.getAddress());
            if (request.getAvatarUrl() != null)
                driver.setAvatarUrl(request.getAvatarUrl());
            if (request.getBio() != null)
                driver.setBio(request.getBio());

            driverDAO.save(driver);
            return ApiResponse.success("Cập nhật thông tin thành công", driver);
        }

        throw new BadRequestException("Không thể cập nhật profile cho role này");
    }

    @Transactional
    public ApiResponse<String> deleteProfile(String username) {
        Account account = accountDAO.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException("Tài khoản không tồn tại"));

        // Soft delete - chỉ đổi status thành inactive
        account.setStatus("inactive");
        accountDAO.save(account);

        return ApiResponse.success("Xóa tài khoản thành công", null);
    }

    @Transactional
    public ApiResponse<Object> changeEmail(String username, String newEmail) {
        // Validate uniqueness
        if (accountDAO.existsByUsername(newEmail)) {
            return ApiResponse.error("Email đã được sử dụng");
        }

        Account account = accountDAO.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException("Tài khoản không tồn tại"));

        // Update account username (login) and customer email if exists
        account.setUsername(newEmail);
        accountDAO.save(account);

        if ("customer".equals(account.getRole())) {
            Customer customer = customerDAO.findByAccountAccountId(account.getAccountId())
                    .orElseThrow(() -> new ResourceNotFoundException("Thông tin khách hàng không tồn tại"));
            customer.setEmail(newEmail);
            customerDAO.save(customer);
            return ApiResponse.success("Cập nhật email thành công", customer);
        } else if ("driver".equals(account.getRole())) {
            Driver driver = driverDAO.findByAccountAccountId(account.getAccountId())
                    .orElseThrow(() -> new ResourceNotFoundException("Thông tin tài xế không tồn tại"));
            // drivers may not have email column, but update if present
            // If Driver has no email field this will be a no-op; return driver
            return ApiResponse.success("Cập nhật email thành công", driver);
        }

        return ApiResponse.success("Cập nhật email cho account thành công", account);
    }
}
