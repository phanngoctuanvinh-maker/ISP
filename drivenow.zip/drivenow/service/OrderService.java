package com.carrentleproject.drivenow.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.carrentleproject.drivenow.dao.BookingCarRepository;
import com.carrentleproject.drivenow.dao.BookingRepository;
import com.carrentleproject.drivenow.dao.CarRepository;
import com.carrentleproject.drivenow.dao.CustomerDAO;
import com.carrentleproject.drivenow.dto.OrderDTO;
import com.carrentleproject.drivenow.model.Booking;
import com.carrentleproject.drivenow.model.BookingCar;
import com.carrentleproject.drivenow.model.Car;
import com.carrentleproject.drivenow.model.Customer;

@Service
public class OrderService {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private CustomerDAO customerDAO;

    @Autowired
    private CarRepository carRepository;

    @Autowired
    private BookingCarRepository bookingCarRepository;

    /**
     * Get all orders with optional filters
     */
    public List<OrderDTO> getAllOrders(String status, Long customerId) {
        List<Booking> bookings;

        if (status != null && customerId != null) {
            bookings = bookingRepository.findByStatusAndCustomerId(status, customerId);
        } else if (status != null) {
            bookings = bookingRepository.findByStatus(status);
        } else if (customerId != null) {
            bookings = bookingRepository.findByCustomerId(customerId);
        } else {
            bookings = bookingRepository.findAll();
        }

        return bookings.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Get order by ID
     */
    public OrderDTO getOrderById(Long id) {
        Booking booking = bookingRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found with id: " + id));
        return convertToDTO(booking);
    }

    /**
     * Update order status
     */
    @Transactional
    public OrderDTO updateOrderStatus(Long id, String newStatus) {
        Booking booking = bookingRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found with id: " + id));

        // Validate status transition
        if (!isValidStatusTransition(booking.getStatus(), newStatus)) {
            throw new RuntimeException("Invalid status transition from " + booking.getStatus() + " to " + newStatus);
        }

        booking.setStatus(newStatus);

        // If status is "ongoing", update car status to "rented"
        if ("ongoing".equals(newStatus)) {
            updateCarStatus(id, "rented");
        }

        // If status is "completed" or "cancelled", update car status to "available"
        if ("completed".equals(newStatus) || "cancelled".equals(newStatus)) {
            updateCarStatus(id, "available");
        }

        booking = bookingRepository.save(booking);
        return convertToDTO(booking);
    }

    /**
     * Cancel order
     */
    @Transactional
    public OrderDTO cancelOrder(Long id, String reason) {
        Booking booking = bookingRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found with id: " + id));

        if ("completed".equals(booking.getStatus())) {
            throw new RuntimeException("Cannot cancel completed order");
        }

        booking.setStatus("cancelled");
        booking.setCancellationReason(reason);

        // Release car
        updateCarStatus(id, "available");

        booking = bookingRepository.save(booking);
        return convertToDTO(booking);
    }

    /**
     * Complete order
     */
    @Transactional
    public OrderDTO completeOrder(Long id) {
        Booking booking = bookingRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found with id: " + id));

        if (!"renting".equals(booking.getStatus())) {
            throw new RuntimeException("Only renting orders can be completed");
        }

        booking.setStatus("completed");

        // Release car
        updateCarStatus(id, "available");

        booking = bookingRepository.save(booking);
        return convertToDTO(booking);
    }

    /**
     * Convert Booking to OrderDTO with additional info
     */
    private OrderDTO convertToDTO(Booking booking) {
        OrderDTO dto = new OrderDTO(booking);

        // Get customer name
        if (booking.getCustomerId() != null) {
            Optional<Customer> customer = customerDAO.findById(booking.getCustomerId().intValue());
            customer.ifPresent(c -> dto.setCustomerName(c.getFullName()));
        }

        // Get vehicle name
        if (booking.getCarId() != null) {
            Optional<Car> car = carRepository.findById(booking.getCarId());
            car.ifPresent(c -> dto.setVehicleName(c.getBrand() + " " + c.getName()));
        }

        return dto;
    }

    /**
     * Update car status for all cars in booking
     */
    private void updateCarStatus(Long bookingId, String status) {
        List<BookingCar> bookingCars = bookingCarRepository.findByBookingId(bookingId);
        for (BookingCar bc : bookingCars) {
            Optional<Car> carOpt = carRepository.findById(bc.getCarId());
            if (carOpt.isPresent()) {
                Car car = carOpt.get();
                car.setStatus(status);
                carRepository.save(car);
            }
        }
    }

    /**
     * Validate status transition
     */
    private boolean isValidStatusTransition(String currentStatus, String newStatus) {
        if (currentStatus == null || newStatus == null)
            return false;

        switch (currentStatus) {
            case "pending":
                // Pending có thể chuyển thành: confirmed (driver accept) hoặc cancelled (driver
                // reject)
                return "confirmed".equals(newStatus) || "cancelled".equals(newStatus);
            case "confirmed":
                // Confirmed có thể chuyển thành: ongoing (driver start) hoặc cancelled
                // (customer/driver cancel)
                return "ongoing".equals(newStatus) || "cancelled".equals(newStatus);
            case "ongoing":
                // Ongoing có thể chuyển thành: completed (driver complete) hoặc cancelled
                // (emergency)
                return "completed".equals(newStatus) || "cancelled".equals(newStatus);
            case "completed":
            case "cancelled":
                return false; // Terminal states - không thể chuyển đổi nữa
            default:
                return false;
        }
    }

    /**
     * Get unassigned orders (confirmed but no driver assigned)
     * For admin to assign drivers
     */
    public List<OrderDTO> getUnassignedOrders() {
        List<Booking> bookings = bookingRepository.findAll().stream()
                .filter(b -> "confirmed".equals(b.getStatus()) &&
                        (b.getDriverId() == null || b.getDriverId() == 0))
                .collect(Collectors.toList());

        return bookings.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Assign driver to order
     */
    @Transactional
    public OrderDTO assignDriver(Long orderId, Long driverId) {
        Booking booking = bookingRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found with id: " + orderId));

        // Validate booking status
        if (!"confirmed".equals(booking.getStatus())) {
            throw new RuntimeException("Only confirmed orders can be assigned to drivers");
        }

        // Update driver assignment and change status to pending (waiting for driver
        // acceptance)
        booking.setDriverId(driverId);
        booking.setStatus("pending");
        booking.setUpdatedAt(java.time.LocalDateTime.now());

        booking = bookingRepository.save(booking);
        return convertToDTO(booking);
    }

    /**
     * Unassign driver from order
     */
    @Transactional
    public OrderDTO unassignDriver(Long orderId) {
        Booking booking = bookingRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found with id: " + orderId));

        booking.setDriverId(null);
        booking.setUpdatedAt(java.time.LocalDateTime.now());

        booking = bookingRepository.save(booking);
        return convertToDTO(booking);
    }
}
