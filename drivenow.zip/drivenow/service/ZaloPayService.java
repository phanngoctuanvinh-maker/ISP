package com.carrentleproject.drivenow.service;

import com.carrentleproject.drivenow.config.ZaloPayConfig;
import com.carrentleproject.drivenow.dao.BookingCarRepository;
import com.carrentleproject.drivenow.dao.BookingRepository;
import com.carrentleproject.drivenow.dao.CarRepository;
import com.carrentleproject.drivenow.dao.ZaloPayPaymentRepository;
import com.carrentleproject.drivenow.dto.ZaloPayRequest;
import com.carrentleproject.drivenow.model.Booking;
import com.carrentleproject.drivenow.model.BookingCar;
import com.carrentleproject.drivenow.model.Car;
import com.carrentleproject.drivenow.model.ZaloPayPayment;
import com.carrentleproject.drivenow.util.HMACUtil;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

/**
 * ZaloPay Payment Service
 * Xử lý các chức năng liên quan đến thanh toán ZaloPay
 */
@Service
public class ZaloPayService {
    
    @Autowired
    private ZaloPayConfig zaloPayConfig;
    
    @Autowired
    private ZaloPayPaymentRepository paymentRepository;
    
    @Autowired
    private BookingRepository bookingRepository;
    
    @Autowired
    private BookingCarRepository bookingCarRepository;
    
    @Autowired
    private CarRepository carRepository;
    
    private final RestTemplate restTemplate = new RestTemplate();
    
    /**
     * Tạo đơn hàng ZaloPay và lấy URL thanh toán
     */
    @Transactional
    public Map<String, Object> createOrder(ZaloPayRequest request) throws Exception {
        // Generate unique app transaction ID
        String appTransId = zaloPayConfig.getCurrentTimeString("yyMMdd") + "_" + UUID.randomUUID().toString();
        
        // Prepare embeddata (merchant info)
        Map<String, String> embedData = new HashMap<>();
        embedData.put("merchantinfo", "DriveNow Car Rental");
        if (request.getBookingId() != null) {
            embedData.put("bookingId", request.getBookingId().toString());
        }
        
        // Prepare item (product info)
        Map<String, Object>[] items = new Map[]{
            new HashMap<String, Object>() {{
                put("itemid", "rental");
                put("itemname", request.getOrderInfo() != null ? request.getOrderInfo() : "Thue xe DriveNow");
                put("itemprice", request.getAmount());
                put("itemquantity", 1);
            }}
        };
        
        // Create order parameters
        Map<String, Object> order = new HashMap<>();
        order.put("appid", zaloPayConfig.getAppId());
        order.put("apptransid", appTransId);
        order.put("apptime", System.currentTimeMillis());
        order.put("appuser", "user_" + request.getUserId());
        order.put("amount", request.getAmount());
        order.put("description", request.getOrderInfo() != null ? request.getOrderInfo() : "Thanh toan thue xe");
        order.put("bankcode", request.getBankCode() != null ? request.getBankCode() : "zalopayapp");
        order.put("item", new JSONObject(items).toString());
        order.put("embeddata", new JSONObject(embedData).toString());
        
        // Generate MAC signature
        String data = order.get("appid") + "|" + order.get("apptransid") + "|" + order.get("appuser") 
                + "|" + order.get("amount") + "|" + order.get("apptime") + "|" + order.get("embeddata") 
                + "|" + order.get("item");
        String mac = HMACUtil.HMacHexStringEncode(HMACUtil.HMACSHA256, zaloPayConfig.getKey1(), data);
        order.put("mac", mac);
        
        // Save payment record to database
        ZaloPayPayment payment = new ZaloPayPayment(
            appTransId,
            request.getUserId(),
            BigDecimal.valueOf(request.getAmount()),
            request.getOrderInfo()
        );
        if (request.getBookingId() != null) {
            payment.setBookingId(request.getBookingId().intValue());
        }
        payment.setPaymentStatus("PENDING");
        paymentRepository.save(payment);
        
        // Call ZaloPay API to create order
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        
        MultiValueMap<String, String> formData = new LinkedMultiValueMap<>();
        for (Map.Entry<String, Object> entry : order.entrySet()) {
            formData.add(entry.getKey(), entry.getValue().toString());
        }
        
        HttpEntity<MultiValueMap<String, String>> requestEntity = new HttpEntity<>(formData, headers);
        
        ResponseEntity<String> response = restTemplate.postForEntity(
            zaloPayConfig.getCreateOrderEndpoint(),
            requestEntity,
            String.class
        );
        
        // Parse response
        JSONObject result = new JSONObject(response.getBody());
        
        Map<String, Object> responseMap = new HashMap<>();
        responseMap.put("returncode", result.getInt("returncode"));
        responseMap.put("returnmessage", result.getString("returnmessage"));
        
        if (result.getInt("returncode") == 1) {
            // Success
            String orderUrl = result.getString("orderurl");
            String zpTransToken = result.getString("zptranstoken");
            
            // Update payment record
            payment.setOrderUrl(orderUrl);
            payment.setZpTransToken(zpTransToken);
            payment.setReturnCode(1);
            payment.setReturnMessage("Order created successfully");
            paymentRepository.save(payment);
            
            responseMap.put("success", true);
            responseMap.put("orderurl", orderUrl);
            responseMap.put("zptranstoken", zpTransToken);
            responseMap.put("apptransid", appTransId);
            
            System.out.println("✅ ZaloPay order created: " + appTransId);
        } else {
            // Failed
            payment.setPaymentStatus("FAILED");
            payment.setReturnCode(result.getInt("returncode"));
            payment.setReturnMessage(result.getString("returnmessage"));
            paymentRepository.save(payment);
            
            responseMap.put("success", false);
            responseMap.put("error", result.getString("returnmessage"));
            
            System.err.println("❌ ZaloPay order creation failed: " + result.getString("returnmessage"));
        }
        
        return responseMap;
    }
    
    /**
     * Xử lý callback từ ZaloPay sau khi thanh toán
     */
    @Transactional
    public Map<String, Object> handleCallback(String jsonData, String mac) {
        Map<String, Object> result = new HashMap<>();
        
        try {
            // Verify MAC signature from ZaloPay
            String calculatedMac = HMACUtil.HMacHexStringEncode(HMACUtil.HMACSHA256, zaloPayConfig.getKey2(), jsonData);
            
            if (!calculatedMac.equals(mac)) {
                System.err.println("❌ Invalid MAC from ZaloPay callback");
                System.err.println("Expected: " + calculatedMac);
                System.err.println("Received: " + mac);
                result.put("returncode", -1);
                result.put("returnmessage", "mac not equal");
                return result;
            }
            
            System.out.println("✅ MAC verification successful");
            
            // Parse callback data
            JSONObject data = new JSONObject(jsonData);
            String appTransId = data.getString("apptransid");
            Long zpTransId = data.getLong("zptransid");
            
            System.out.println("📩 ZaloPay callback received for: " + appTransId);
            
            // Find payment record
            Optional<ZaloPayPayment> paymentOpt = paymentRepository.findByAppTransId(appTransId);
            
            if (paymentOpt.isPresent()) {
                ZaloPayPayment payment = paymentOpt.get();
                payment.setZpTransId(String.valueOf(zpTransId));
                payment.setPaymentStatus("SUCCESS");
                payment.setReturnCode(1);
                payment.setReturnMessage("Payment successful");
                payment.setCallbackReceivedAt(LocalDateTime.now());
                
                // Extract additional info if available
                if (data.has("amount")) {
                    payment.setAmount(BigDecimal.valueOf(data.getLong("amount")));
                }
                if (data.has("channel")) {
                    payment.setChannel(data.getInt("channel"));
                }
                if (data.has("merchantuserid")) {
                    payment.setMerchantUserId(data.getString("merchantuserid"));
                }
                if (data.has("userfeeamount")) {
                    payment.setUserFeeAmount(BigDecimal.valueOf(data.getLong("userfeeamount")));
                }
                
                paymentRepository.save(payment);
                
                System.out.println("✅ Payment updated: " + payment.getId());
                
                // ===== CẬP NHẬT TRẠNG THÁI BOOKING VÀ XE =====
                if (payment.getBookingId() != null) {
                    updateBookingAndCarStatus(payment.getBookingId());
                }
                
                result.put("returncode", 1);
                result.put("returnmessage", "success");
            } else {
                System.err.println("❌ Payment not found: " + appTransId);
                result.put("returncode", 0); // ZaloPay will retry
                result.put("returnmessage", "Payment not found");
            }
            
        } catch (Exception e) {
            System.err.println("❌ Error processing ZaloPay callback: " + e.getMessage());
            e.printStackTrace();
            result.put("returncode", 0); // ZaloPay will retry
            result.put("returnmessage", e.getMessage());
        }
        
        return result;
    }
    
    /**
     * Cập nhật trạng thái booking và xe sau khi thanh toán thành công
     */
    private void updateBookingAndCarStatus(Integer bookingId) {
        try {
            System.out.println("🚗 Updating booking and car status for booking: " + bookingId);
            
            Optional<Booking> bookingOpt = bookingRepository.findById(bookingId.longValue());
            if (bookingOpt.isPresent()) {
                Booking booking = bookingOpt.get();
                booking.setPaymentStatus("paid");
                booking.setPaymentMethod("zalopay");
                booking.setStatus("confirmed");
                booking.setUpdatedAt(LocalDateTime.now());
                bookingRepository.save(booking);
                
                System.out.println("✅ Booking updated: " + booking.getBookingId());
                
                // Cập nhật trạng thái tất cả xe trong booking sang "rented"
                List<BookingCar> bookingCars = bookingCarRepository.findByBookingId(bookingId.longValue());
                System.out.println("🚙 Found " + bookingCars.size() + " cars to update");
                
                for (BookingCar bc : bookingCars) {
                    Optional<Car> carOpt = carRepository.findById(bc.getCarId());
                    if (carOpt.isPresent()) {
                        Car car = carOpt.get();
                        car.setStatus("rented");
                        carRepository.save(car);
                        System.out.println("✅ Car updated to rented: " + car.getId() + " - " + car.getName());
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("❌ Error updating booking/car status: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Kiểm tra trạng thái thanh toán
     */
    public Map<String, Object> queryOrderStatus(String appTransId) throws Exception {
        String data = zaloPayConfig.getAppId() + "|" + appTransId + "|" + zaloPayConfig.getKey1();
        String mac = HMACUtil.HMacHexStringEncode(HMACUtil.HMACSHA256, zaloPayConfig.getKey1(), data);
        
        String url = zaloPayConfig.getQueryEndpoint() 
                + "?appid=" + zaloPayConfig.getAppId()
                + "&apptransid=" + appTransId
                + "&mac=" + mac;
        
        ResponseEntity<String> response = restTemplate.getForEntity(url, String.class);
        JSONObject result = new JSONObject(response.getBody());
        
        Map<String, Object> responseMap = new HashMap<>();
        responseMap.put("returncode", result.getInt("returncode"));
        responseMap.put("returnmessage", result.getString("returnmessage"));
        
        if (result.has("zptransid")) {
            responseMap.put("zptransid", result.getLong("zptransid"));
        }
        if (result.has("amount")) {
            responseMap.put("amount", result.getLong("amount"));
        }
        
        return responseMap;
    }
    
    /**
     * Get payment by app transaction ID
     */
    public Optional<ZaloPayPayment> getPaymentByAppTransId(String appTransId) {
        return paymentRepository.findByAppTransId(appTransId);
    }
    
    /**
     * Get payment by booking ID
     */
    public Optional<ZaloPayPayment> getPaymentByBookingId(Integer bookingId) {
        return paymentRepository.findByBookingId(bookingId);
    }
    
    /**
     * Get payments by user ID
     */
    public List<ZaloPayPayment> getPaymentsByUserId(Long userId) {
        return paymentRepository.findByUserId(userId);
    }
}
