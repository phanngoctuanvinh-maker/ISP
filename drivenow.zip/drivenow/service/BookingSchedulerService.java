package com.carrentleproject.drivenow.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.carrentleproject.drivenow.dao.BookingRepository;
import com.carrentleproject.drivenow.model.Booking;

/**
 * Service to handle scheduled tasks for bookings
 */
@Service
public class BookingSchedulerService {

    @Autowired
    private BookingRepository bookingRepository;

    /**
     * Auto-cancel expired pending bookings
     * Runs every 5 minutes
     * Cancels bookings that are in "pending" status for more than 15 minutes
     */
    @Scheduled(cron = "0 */5 * * * *") // Chạy mỗi 5 phút
    @Transactional
    public void cancelExpiredPendingBookings() {
        try {
            // Tính thời gian timeout: 15 phút trước
            LocalDateTime timeoutThreshold = LocalDateTime.now().minusMinutes(15);
            
            System.out.println("⏰ [SCHEDULER] Checking for expired pending bookings...");
            System.out.println("📅 Timeout threshold: " + timeoutThreshold);
            
            // Tìm tất cả booking pending được tạo trước 15 phút
            List<Booking> expiredBookings = bookingRepository.findByStatusAndCreatedAtBefore("pending", timeoutThreshold);
            
            if (expiredBookings.isEmpty()) {
                System.out.println("✅ No expired pending bookings found");
                return;
            }
            
            System.out.println("🔍 Found " + expiredBookings.size() + " expired pending booking(s)");
            
            // Hủy từng booking
            int cancelledCount = 0;
            for (Booking booking : expiredBookings) {
                try {
                    booking.setStatus("cancelled");
                    booking.setCancellationReason("Auto-cancelled: Payment timeout (15 minutes)");
                    bookingRepository.save(booking);
                    
                    System.out.println("❌ Cancelled booking ID: " + booking.getBookingId() 
                        + " (Customer: " + booking.getCustomerId() 
                        + ", Created: " + booking.getCreatedAt() + ")");
                    
                    cancelledCount++;
                } catch (Exception e) {
                    System.err.println("⚠️ Error cancelling booking " + booking.getBookingId() + ": " + e.getMessage());
                }
            }
            
            System.out.println("✅ Successfully cancelled " + cancelledCount + " expired booking(s)");
            
        } catch (Exception e) {
            System.err.println("❌ Error in cancelExpiredPendingBookings scheduler: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Optional: Log scheduler status every hour
     */
    @Scheduled(cron = "0 0 * * * *") // Chạy mỗi giờ
    public void logSchedulerStatus() {
        long pendingCount = bookingRepository.findByStatus("pending").size();
        long confirmedCount = bookingRepository.findByStatus("confirmed").size();
        long cancelledCount = bookingRepository.findByStatus("cancelled").size();
        
        System.out.println("📊 [BOOKING STATS] Pending: " + pendingCount 
            + " | Confirmed: " + confirmedCount 
            + " | Cancelled: " + cancelledCount);
    }
}
