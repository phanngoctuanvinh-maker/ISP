package com.carrentleproject.drivenow.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carrentleproject.drivenow.dao.BookingRepository;
import com.carrentleproject.drivenow.dto.CustomerDTO;
import com.carrentleproject.drivenow.model.Booking;
import com.carrentleproject.drivenow.model.Customer;
import com.carrentleproject.drivenow.repository.CustomerRepository;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private BookingRepository bookingRepository;

    public List<CustomerDTO> getAllCustomers() {
        List<Customer> customers = customerRepository.findAll();
        return customers.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public CustomerDTO getCustomerById(Integer id) {
        Customer customer = customerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Customer not found with id: " + id));
        return convertToDTO(customer);
    }

    public CustomerDTO getCustomerByEmail(String email) {
        Customer customer = customerRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Customer not found with email: " + email));
        return convertToDTO(customer);
    }

    private CustomerDTO convertToDTO(Customer customer) {
        CustomerDTO dto = new CustomerDTO(customer);
        
        // Calculate rental statistics
        List<Booking> bookings = bookingRepository.findByCustomerId(customer.getCustomerId().longValue());
        dto.setRentalCount(bookings.size());
        
        // Calculate total spent (sum of all booking prices)
        double totalSpent = bookings.stream()
                .filter(booking -> booking.getTotalAmount() != null)
                .mapToDouble(booking -> booking.getTotalAmount().doubleValue())
                .sum();
        dto.setTotalSpent(totalSpent);
        
        return dto;
    }

    public void deleteCustomer(Integer id) {
        customerRepository.deleteById(id);
    }

    public CustomerDTO updateCustomer(Integer id, CustomerDTO customerDTO) {
        Customer customer = customerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Customer not found with id: " + id));
        
        customer.setFullName(customerDTO.getName());
        customer.setPhone(customerDTO.getPhone());
        customer.setEmail(customerDTO.getEmail());
        customer.setAddress(customerDTO.getAddress());
        customer.setDob(customerDTO.getDob());
        customer.setGender(customerDTO.getGender());
        
        Customer updatedCustomer = customerRepository.save(customer);
        return convertToDTO(updatedCustomer);
    }
    
    public CustomerDTO blockCustomer(Integer id) {
        Customer customer = customerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Customer not found with id: " + id));
        
        // Update customer status
        customer.setStatus("blocked");
        
        // IMPORTANT: Also update Account status to block login
        if (customer.getAccount() != null) {
            customer.getAccount().setStatus("banned");
        }
        
        Customer blockedCustomer = customerRepository.save(customer);
        return convertToDTO(blockedCustomer);
    }
    
    public CustomerDTO unblockCustomer(Integer id) {
        Customer customer = customerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Customer not found with id: " + id));
        
        // Update customer status
        customer.setStatus("active");
        
        // IMPORTANT: Also update Account status to allow login
        if (customer.getAccount() != null) {
            customer.getAccount().setStatus("active");
        }
        
        Customer unblockedCustomer = customerRepository.save(customer);
        return convertToDTO(unblockedCustomer);
    }
}
