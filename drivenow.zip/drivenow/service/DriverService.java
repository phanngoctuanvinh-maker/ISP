package com.carrentleproject.drivenow.service;

import com.carrentleproject.drivenow.dto.DriverDashboardStatsDTO;
import com.carrentleproject.drivenow.dto.DriverTripDTO;
import com.carrentleproject.drivenow.dto.DriverDTO;
import com.carrentleproject.drivenow.dto.DriverProfileDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Service
public class DriverService {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    /**
     * Lấy thông tin profile driver đầy đủ
     */
    public DriverProfileDTO getDriverProfile(Integer driverId) {
        String sql = "SELECT " +
                "d.driver_id, d.account_id, d.name, d.address, d.id_card, " +
                "d.license_number, d.years_of_experience, d.average_rating, " +
                "d.status, d.avatar_url, d.bio, " +
                "a.username " +
                "FROM driver d " +
                "INNER JOIN account a ON d.account_id = a.account_id " +
                "WHERE d.driver_id = ?";

        return jdbcTemplate.queryForObject(sql, (rs, rowNum) -> {
            DriverProfileDTO profile = new DriverProfileDTO();
            profile.setDriverId(rs.getInt("driver_id"));
            profile.setAccountId(rs.getInt("account_id"));
            profile.setName(rs.getString("name"));
            profile.setUsername(rs.getString("username"));
            profile.setEmail(rs.getString("username")); // username is email
            profile.setAddress(rs.getString("address"));
            profile.setIdCard(rs.getString("id_card"));
            profile.setLicenseNumber(rs.getString("license_number"));
            profile.setYearsOfExperience(rs.getInt("years_of_experience"));

            BigDecimal rating = rs.getBigDecimal("average_rating");
            profile.setAverageRating(rating != null ? rating.doubleValue() : 0.0);

            profile.setStatus(rs.getString("status"));
            profile.setAvatarUrl(rs.getString("avatar_url"));
            profile.setBio(rs.getString("bio"));

            return profile;
        }, driverId);
    }

    /**
     * Cập nhật thông tin profile driver
     */
    public void updateDriverProfile(Integer driverId, DriverProfileDTO profile) {
        String sql = "UPDATE driver SET " +
                "name = ?, " +
                "address = ?, " +
                "license_number = ?, " +
                "years_of_experience = ?, " +
                "bio = ?, " +
                "updated_at = GETDATE() " +
                "WHERE driver_id = ?";

        jdbcTemplate.update(sql,
                profile.getName(),
                profile.getAddress(),
                profile.getLicenseNumber(),
                profile.getYearsOfExperience(),
                profile.getBio(),
                driverId);
    }

    /**
     * Lấy thống kê dashboard cho driver
     */
    public DriverDashboardStatsDTO getDashboardStats(Integer driverId) {
        String sql = "SELECT " +
                "    (SELECT COUNT(*) FROM bookings WHERE driver_id = ? AND CAST(pickup_time AS DATE) = CAST(GETDATE() AS DATE)) AS trips_today, "
                +
                "    (SELECT ISNULL(SUM(total_price), 0) FROM bookings WHERE driver_id = ? AND CAST(pickup_time AS DATE) = CAST(GETDATE() AS DATE) AND payment_status = 'paid') AS today_earnings, "
                +
                "    (SELECT ISNULL(AVG(CAST(average_rating AS FLOAT)), 0) FROM driver WHERE driver_id = ?) AS average_rating, "
                +
                "    0 AS online_time_minutes, " +
                "    (SELECT COUNT(*) FROM bookings WHERE driver_id = ?) AS total_trips, " +
                "    (SELECT ISNULL(SUM(total_price), 0) FROM bookings WHERE driver_id = ? AND payment_status = 'paid') AS total_earnings";

        return jdbcTemplate.queryForObject(sql, (rs, rowNum) -> {
            DriverDashboardStatsDTO stats = new DriverDashboardStatsDTO();
            stats.setTripsToday(rs.getInt("trips_today"));
            stats.setTodayEarnings(rs.getDouble("today_earnings"));
            stats.setAverageRating(rs.getDouble("average_rating"));
            stats.setOnlineTimeMinutes(rs.getInt("online_time_minutes"));
            stats.setTotalTrips(rs.getInt("total_trips"));
            stats.setTotalEarnings(rs.getDouble("total_earnings"));
            return stats;
        }, driverId, driverId, driverId, driverId, driverId);
    }

    /**
     * Lấy danh sách chuyến đi gần đây
     */
    public List<DriverTripDTO> getRecentTrips(Integer driverId, Integer limit) {
        String sql = "SELECT TOP (?) " +
                "    b.booking_id, " +
                "    c.full_name AS customer_name, " +
                "    c.phone AS customer_phone, " +
                "    b.pickup_location, " +
                "    b.return_location AS dropoff_location, " +
                "    b.distance_fee AS distance, " +
                "    b.total_price AS fare, " +
                "    b.status, " +
                "    b.pickup_time AS start_time, " +
                "    b.return_time AS end_time " +
                "FROM bookings b " +
                "LEFT JOIN Customer c ON b.customer_id = c.customer_id " +
                "WHERE b.driver_id = ? " +
                "ORDER BY b.pickup_time DESC";

        return jdbcTemplate.query(sql, this::mapRowToDriverTrip, limit, driverId);
    }

    /**
     * Map ResultSet to DriverTripDTO
     */
    private DriverTripDTO mapRowToDriverTrip(ResultSet rs, int rowNum) throws SQLException {
        DriverTripDTO trip = new DriverTripDTO();
        trip.setBookingId(rs.getInt("booking_id"));
        trip.setCustomerName(rs.getString("customer_name"));
        trip.setCustomerPhone(rs.getString("customer_phone"));
        trip.setPickupLocation(rs.getString("pickup_location"));
        trip.setDropoffLocation(rs.getString("dropoff_location"));
        trip.setDistance(rs.getDouble("distance"));
        trip.setFare(rs.getDouble("fare"));
        trip.setStatus(rs.getString("status"));

        // Handle datetime
        if (rs.getTimestamp("start_time") != null) {
            trip.setStartTime(rs.getTimestamp("start_time").toLocalDateTime());
        }
        if (rs.getTimestamp("end_time") != null) {
            trip.setEndTime(rs.getTimestamp("end_time").toLocalDateTime());
        }

        return trip;
    }

    /**
     * Lấy danh sách tài xế đang rảnh (cho admin phân công)
     */
    public List<DriverDTO> getAvailableDrivers() {
        String sql = "SELECT " +
                "    d.driver_id, " +
                "    d.account_id, " +
                "    a.username AS full_name, " + // Using username as name temporarily
                "    d.id_card AS phone, " + // Using id_card as phone temporarily
                "    a.username AS email, " +
                "    d.license_number, " +
                "    d.years_of_experience, " +
                "    d.status, " +
                "    d.average_rating, " +
                "    CAST(NULL AS INT) AS current_booking_id " +
                "FROM driver d " +
                "LEFT JOIN Account a ON d.account_id = a.account_id " +
                "WHERE d.status = 'active' " +
                "ORDER BY d.average_rating DESC, d.years_of_experience DESC";

        return jdbcTemplate.query(sql, this::mapRowToDriverDTO);
    }

    /**
     * Map ResultSet to DriverDTO
     */
    private DriverDTO mapRowToDriverDTO(ResultSet rs, int rowNum) throws SQLException {
        DriverDTO driver = new DriverDTO();
        driver.setDriverId(rs.getInt("driver_id"));
        driver.setAccountId(rs.getInt("account_id"));
        driver.setFullName(rs.getString("full_name"));
        driver.setPhone(rs.getString("phone"));
        driver.setEmail(rs.getString("email"));
        driver.setLicenseNumber(rs.getString("license_number"));
        driver.setExperienceYears(rs.getInt("years_of_experience"));
        driver.setStatus(rs.getString("status"));

        if (rs.getObject("average_rating") != null) {
            driver.setAverageRating(rs.getDouble("average_rating"));
        }

        if (rs.getObject("current_booking_id") != null) {
            driver.setCurrentBookingId(rs.getInt("current_booking_id"));
        }

        return driver;
    }

    /**
     * Lấy danh sách chuyến đi đang hoạt động (Active Trips)
     * Bao gồm: pending, confirmed, ongoing
     */
    public List<DriverTripDTO> getAssignedTrips(Integer driverId) {
        String sql = "SELECT " +
                "    b.booking_id, " +
                "    c.full_name AS customer_name, " +
                "    c.phone AS customer_phone, " +
                "    b.pickup_location, " +
                "    b.return_location AS dropoff_location, " +
                "    b.distance_fee AS distance, " +
                "    b.total_price AS fare, " +
                "    b.status, " +
                "    b.pickup_time AS start_time, " +
                "    b.return_time AS end_time " +
                "FROM bookings b " +
                "LEFT JOIN Customer c ON b.customer_id = c.customer_id " +
                "WHERE b.driver_id = ? AND b.status IN (N'pending', N'confirmed', N'ongoing') " +
                "ORDER BY b.pickup_time ASC";

        return jdbcTemplate.query(sql, (rs, rowNum) -> {
            DriverTripDTO trip = new DriverTripDTO();
            trip.setBookingId(rs.getInt("booking_id"));
            trip.setCustomerName(rs.getString("customer_name"));
            trip.setCustomerPhone(rs.getString("customer_phone"));
            trip.setPickupLocation(rs.getString("pickup_location"));
            trip.setDropoffLocation(rs.getString("dropoff_location"));
            trip.setDistance(rs.getDouble("distance"));
            trip.setFare(rs.getDouble("fare"));
            trip.setStatus(rs.getString("status"));

            // Handle datetime
            if (rs.getTimestamp("start_time") != null) {
                trip.setStartTime(rs.getTimestamp("start_time").toLocalDateTime());
            }
            if (rs.getTimestamp("end_time") != null) {
                trip.setEndTime(rs.getTimestamp("end_time").toLocalDateTime());
            }

            return trip;
        }, driverId);
    }

    /**
     * Lấy thông tin driver theo ID
     */
    public DriverDTO getDriverById(Integer driverId) {
        String sql = "SELECT d.driver_id, d.account_id, d.name, d.license_number, " +
                "d.years_of_experience, d.address, d.avatar_url, d.average_rating, d.status, d.bio, " +
                "a.phone, a.email " +
                "FROM driver d " +
                "LEFT JOIN Account a ON d.account_id = a.account_id " +
                "WHERE d.driver_id = ?";

        return jdbcTemplate.queryForObject(sql, (rs, rowNum) -> {
            DriverDTO driver = new DriverDTO();
            driver.setDriverId(rs.getInt("driver_id"));
            driver.setAccountId(rs.getInt("account_id"));
            driver.setFullName(rs.getString("name"));
            driver.setLicenseNumber(rs.getString("license_number"));
            driver.setExperienceYears(rs.getInt("years_of_experience"));
            driver.setStatus(rs.getString("status"));

            // Handle nullable fields
            BigDecimal rating = rs.getBigDecimal("average_rating");
            if (rating != null) {
                driver.setAverageRating(rating.doubleValue());
            }

            driver.setPhone(rs.getString("phone"));
            driver.setEmail(rs.getString("email"));

            return driver;
        }, driverId);
    }

    /**
     * Chấp nhận chuyến đi
     * Thay đổi status từ 'pending' -> 'confirmed'
     * Driver chấp nhận nhận chuyến, nhưng chưa bắt đầu đón khách
     */
    public void acceptTrip(Integer bookingId) {
        String sql = "UPDATE bookings SET status = N'confirmed', updated_at = GETDATE() WHERE booking_id = ? AND status = N'pending'";
        int rowsAffected = jdbcTemplate.update(sql, bookingId);

        if (rowsAffected == 0) {
            throw new RuntimeException("Không thể chấp nhận chuyến đi. Booking không tồn tại hoặc đã được xử lý.");
        }
    }

    /**
     * Từ chối chuyến đi
     * Set driver_id = NULL, status = 'cancelled'
     * Chuyến đi bị driver từ chối, sẽ vào Trip History
     */
    /**
     * Từ chối/Hủy chuyến đi
     * - Pending: Từ chối và xóa driver_id
     * - Confirmed/Ongoing: Hủy và giữ driver_id
     */
    public void rejectTrip(Integer bookingId, String reason) {
        // Try to cancel as pending first (remove driver)
        String cancelPendingSql = "UPDATE bookings SET driver_id = NULL, status = N'cancelled', " +
                "cancellation_reason = ?, updated_at = GETDATE() " +
                "WHERE booking_id = ? AND status = N'pending'";
        int pendingUpdated = jdbcTemplate.update(cancelPendingSql, reason, bookingId);

        if (pendingUpdated > 0) {
            return; // Successfully cancelled pending trip
        }

        // If not pending, try confirmed/ongoing (keep driver)
        String cancelConfirmedSql = "UPDATE bookings SET status = N'cancelled', " +
                "cancellation_reason = ?, updated_at = GETDATE() " +
                "WHERE booking_id = ? AND status IN (N'confirmed', N'ongoing')";
        int confirmedUpdated = jdbcTemplate.update(cancelConfirmedSql, reason, bookingId);

        if (confirmedUpdated == 0) {
            throw new RuntimeException(
                    "Không thể hủy chuyến đi. Booking không tồn tại hoặc không ở trạng thái cho phép hủy.");
        }
    }

    /**
     * Bắt đầu chuyến đi
     * Thay đổi status từ 'confirmed' -> 'ongoing'
     * Driver đã đón khách và bắt đầu di chuyển
     */
    public void startTrip(Integer bookingId) {
        String sql = "UPDATE bookings SET status = N'ongoing', pickup_time = GETDATE(), updated_at = GETDATE() " +
                "WHERE booking_id = ? AND status = N'confirmed'";
        int rowsAffected = jdbcTemplate.update(sql, bookingId);

        if (rowsAffected == 0) {
            throw new RuntimeException("Không thể bắt đầu chuyến đi. Booking không tồn tại hoặc đã được xử lý.");
        }
    }

    /**
     * Hoàn thành chuyến đi
     * Thay đổi status từ 'ongoing' -> 'completed'
     * Chuyến đi kết thúc thành công, sẽ vào Trip History
     */
    public void completeTrip(Integer bookingId) {
        String sql = "UPDATE bookings SET status = N'completed', return_time = GETDATE(), updated_at = GETDATE() " +
                "WHERE booking_id = ? AND status = N'ongoing'";
        int rowsAffected = jdbcTemplate.update(sql, bookingId);

        if (rowsAffected == 0) {
            throw new RuntimeException("Không thể hoàn thành chuyến đi. Booking không tồn tại hoặc đã được xử lý.");
        }
    }

    /**
     * Lấy lịch sử chuyến đi (completed và cancelled)
     */
    public List<DriverTripDTO> getTripHistory(Integer driverId) {
        String sql = "SELECT " +
                "b.booking_id, " +
                "b.status, " +
                "b.pickup_time, " +
                "b.return_time, " +
                "b.total_price, " +
                "b.cancellation_reason, " +
                "b.pickup_location, " +
                "b.return_location, " +
                "c.full_name as customer_name, " +
                "c.phone as customer_phone, " +
                "0.0 as distance " +
                "FROM bookings b " +
                "INNER JOIN customer c ON b.customer_id = c.customer_id " +
                "WHERE b.driver_id = ? " +
                "AND b.status IN (N'completed', N'cancelled') " +
                "ORDER BY b.updated_at DESC";

        return jdbcTemplate.query(sql, (rs, rowNum) -> {
            DriverTripDTO dto = new DriverTripDTO();
            dto.setBookingId(rs.getInt("booking_id"));
            dto.setCustomerName(rs.getString("customer_name"));
            dto.setCustomerPhone(rs.getString("customer_phone"));
            dto.setPickupLocation(rs.getString("pickup_location"));
            dto.setDropoffLocation(rs.getString("return_location"));
            dto.setDistance(rs.getDouble("distance"));

            // Convert BigDecimal to Double
            java.math.BigDecimal totalPrice = rs.getBigDecimal("total_price");
            dto.setFare(totalPrice != null ? totalPrice.doubleValue() : 0.0);

            dto.setStatus(rs.getString("status"));
            dto.setCancellationReason(rs.getString("cancellation_reason"));

            // Convert pickup_time
            java.sql.Timestamp pickupTime = rs.getTimestamp("pickup_time");
            if (pickupTime != null) {
                dto.setStartTime(pickupTime.toLocalDateTime());
            }

            // Convert return_time
            java.sql.Timestamp returnTime = rs.getTimestamp("return_time");
            if (returnTime != null) {
                dto.setEndTime(returnTime.toLocalDateTime());
            }

            return dto;
        }, driverId);
    }
}
