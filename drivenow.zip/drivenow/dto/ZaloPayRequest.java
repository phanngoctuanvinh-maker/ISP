package com.carrentleproject.drivenow.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

/**
 * Request DTO for ZaloPay payment
 */
public class ZaloPayRequest {
    
    @NotNull(message = "User ID is required")
    private Long userId;
    
    private Long bookingId; // Optional: Link to booking
    
    @NotNull(message = "Amount is required")
    @Min(value = 1000, message = "Amount must be at least 1,000 VND")
    private Long amount; // Số tiền (VND)
    
    private String orderInfo; // Mô tả đơn hàng (optional)
    
    private String bankCode; // Bank code (optional, default: zalopayapp)
    
    // Constructors
    public ZaloPayRequest() {
    }
    
    public ZaloPayRequest(Long userId, Long amount, String orderInfo) {
        this.userId = userId;
        this.amount = amount;
        this.orderInfo = orderInfo;
    }
    
    // Getters and Setters
    public Long getUserId() {
        return userId;
    }
    
    public void setUserId(Long userId) {
        this.userId = userId;
    }
    
    public Long getBookingId() {
        return bookingId;
    }
    
    public void setBookingId(Long bookingId) {
        this.bookingId = bookingId;
    }
    
    public Long getAmount() {
        return amount;
    }
    
    public void setAmount(Long amount) {
        this.amount = amount;
    }
    
    public String getOrderInfo() {
        return orderInfo;
    }
    
    public void setOrderInfo(String orderInfo) {
        this.orderInfo = orderInfo;
    }
    
    public String getBankCode() {
        return bankCode;
    }
    
    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }
}
