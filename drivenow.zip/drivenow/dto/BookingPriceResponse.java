package com.carrentleproject.drivenow.dto;

/**
 * DTO for returning calculated booking price details
 */
public class BookingPriceResponse {
    private Integer rentalDays;
    private Double rentalHours;
    private Double basePrice;           // Giá thuê cơ bản
    private Double insuranceFee;        // Phí bảo hiểm (2% giá thuê)
    private Double serviceFee;          // Phí dịch vụ
    private Double exceedFee;           // Phí vượt giới hạn km
    private Double totalPrice;          // Tổng tiền
    private Double distanceKm;          // Quãng đường ước tính
    private Double allowedKm;           // Số km được phép
    private Double extraKm;             // Số km vượt
    private String areaType;            // Loại lộ trình

    // Constructor
    public BookingPriceResponse() {
    }

    // Builder pattern
    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private BookingPriceResponse response = new BookingPriceResponse();

        public Builder rentalDays(Integer rentalDays) {
            response.rentalDays = rentalDays;
            return this;
        }

        public Builder rentalHours(Double rentalHours) {
            response.rentalHours = rentalHours;
            return this;
        }

        public Builder basePrice(Double basePrice) {
            response.basePrice = basePrice;
            return this;
        }

        public Builder insuranceFee(Double insuranceFee) {
            response.insuranceFee = insuranceFee;
            return this;
        }

        public Builder serviceFee(Double serviceFee) {
            response.serviceFee = serviceFee;
            return this;
        }

        public Builder exceedFee(Double exceedFee) {
            response.exceedFee = exceedFee;
            return this;
        }

        public Builder totalPrice(Double totalPrice) {
            response.totalPrice = totalPrice;
            return this;
        }

        public Builder distanceKm(Double distanceKm) {
            response.distanceKm = distanceKm;
            return this;
        }

        public Builder allowedKm(Double allowedKm) {
            response.allowedKm = allowedKm;
            return this;
        }

        public Builder extraKm(Double extraKm) {
            response.extraKm = extraKm;
            return this;
        }

        public Builder areaType(String areaType) {
            response.areaType = areaType;
            return this;
        }

        public BookingPriceResponse build() {
            return response;
        }
    }

    // Getters and Setters
    public Integer getRentalDays() {
        return rentalDays;
    }

    public void setRentalDays(Integer rentalDays) {
        this.rentalDays = rentalDays;
    }

    public Double getRentalHours() {
        return rentalHours;
    }

    public void setRentalHours(Double rentalHours) {
        this.rentalHours = rentalHours;
    }

    public Double getBasePrice() {
        return basePrice;
    }

    public void setBasePrice(Double basePrice) {
        this.basePrice = basePrice;
    }

    public Double getInsuranceFee() {
        return insuranceFee;
    }

    public void setInsuranceFee(Double insuranceFee) {
        this.insuranceFee = insuranceFee;
    }

    public Double getServiceFee() {
        return serviceFee;
    }

    public void setServiceFee(Double serviceFee) {
        this.serviceFee = serviceFee;
    }

    public Double getExceedFee() {
        return exceedFee;
    }

    public void setExceedFee(Double exceedFee) {
        this.exceedFee = exceedFee;
    }

    public Double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(Double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public Double getDistanceKm() {
        return distanceKm;
    }

    public void setDistanceKm(Double distanceKm) {
        this.distanceKm = distanceKm;
    }

    public Double getAllowedKm() {
        return allowedKm;
    }

    public void setAllowedKm(Double allowedKm) {
        this.allowedKm = allowedKm;
    }

    public Double getExtraKm() {
        return extraKm;
    }

    public void setExtraKm(Double extraKm) {
        this.extraKm = extraKm;
    }

    public String getAreaType() {
        return areaType;
    }

    public void setAreaType(String areaType) {
        this.areaType = areaType;
    }
}
