package com.carrentleproject.drivenow.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.carrentleproject.drivenow.model.Promotion;
import com.fasterxml.jackson.annotation.JsonFormat;

public class PromotionDTO {
    private Long id;
    private String name;
    private String description;
    private String discountType;
    private BigDecimal discountValue;
    private Long minOrderValue;
    private Long maxDiscountAmount;
    
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss", timezone = "Asia/Ho_Chi_Minh")
    private LocalDateTime startDate;
    
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss", timezone = "Asia/Ho_Chi_Minh")
    private LocalDateTime endDate;
    
    private Integer usageLimit;
    private Integer usedCount;
    private String status;
    
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss", timezone = "Asia/Ho_Chi_Minh")
    private LocalDateTime createdAt;
    
    // Thêm trường tính toán
    private boolean isExpired;
    private boolean isActive;
    private Integer remainingUsage;

    // Constructor
    public PromotionDTO() {
    }

    public PromotionDTO(Promotion promotion) {
        this.id = promotion.getId();
        this.name = promotion.getName();
        this.description = promotion.getDescription();
        this.discountType = promotion.getDiscountType().toString();
        this.discountValue = promotion.getDiscountValue();
        this.minOrderValue = promotion.getMinOrderValue();
        this.maxDiscountAmount = promotion.getMaxDiscountAmount();
        this.startDate = promotion.getStartDate();
        this.endDate = promotion.getEndDate();
        this.usageLimit = promotion.getUsageLimit();
        this.usedCount = promotion.getUsedCount();
        this.status = promotion.getStatus();
        this.createdAt = promotion.getCreatedAt();

        // Tính toán các trường
        LocalDateTime now = LocalDateTime.now();
        this.isExpired = promotion.getEndDate().isBefore(now);
        this.isActive = "ACTIVE".equals(promotion.getStatus()) 
                       && promotion.getStartDate().isBefore(now) 
                       && promotion.getEndDate().isAfter(now);
        
        if (promotion.getUsageLimit() != null) {
            this.remainingUsage = Math.max(0, promotion.getUsageLimit() - promotion.getUsedCount());
        } else {
            this.remainingUsage = null; // Unlimited
        }
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDiscountType() {
        return discountType;
    }

    public void setDiscountType(String discountType) {
        this.discountType = discountType;
    }

    public BigDecimal getDiscountValue() {
        return discountValue;
    }

    public void setDiscountValue(BigDecimal discountValue) {
        this.discountValue = discountValue;
    }

    public Long getMinOrderValue() {
        return minOrderValue;
    }

    public void setMinOrderValue(Long minOrderValue) {
        this.minOrderValue = minOrderValue;
    }

    public Long getMaxDiscountAmount() {
        return maxDiscountAmount;
    }

    public void setMaxDiscountAmount(Long maxDiscountAmount) {
        this.maxDiscountAmount = maxDiscountAmount;
    }

    public LocalDateTime getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDateTime startDate) {
        this.startDate = startDate;
    }

    public LocalDateTime getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDateTime endDate) {
        this.endDate = endDate;
    }

    public Integer getUsageLimit() {
        return usageLimit;
    }

    public void setUsageLimit(Integer usageLimit) {
        this.usageLimit = usageLimit;
    }

    public Integer getUsedCount() {
        return usedCount;
    }

    public void setUsedCount(Integer usedCount) {
        this.usedCount = usedCount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public boolean isExpired() {
        return isExpired;
    }

    public void setExpired(boolean expired) {
        isExpired = expired;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public Integer getRemainingUsage() {
        return remainingUsage;
    }

    public void setRemainingUsage(Integer remainingUsage) {
        this.remainingUsage = remainingUsage;
    }
}
