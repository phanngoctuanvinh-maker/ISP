package com.carrentleproject.drivenow.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public class GroupBookingRequest {
    private Long customerId;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private String pickupLocation;
    private String dropoffLocation;
    private BigDecimal totalAmount;
    // Additional UI fields
    private String tripType;
    private Boolean oneWay;
    private String pickupPoint;
    private String specificPickupAddress;
    private Integer allowedKmPerDay;
    private BigDecimal exceedFeePerKm;
    private BigDecimal fuelConsumption;
    private BigDecimal insuranceFee;
    private BigDecimal transferFee;
    private String promoCode;
    private BigDecimal basePrice;
    private BigDecimal discountAmount;

    public static class CarItem {
        public Long carId;
        public BigDecimal priceAtBooking;
        public BigDecimal totalPrice;
        public LocalDateTime startDate;
        public LocalDateTime endDate;
    }

    private List<CarItem> cars;

    // getters / setters
    public Long getCustomerId() { return customerId; }
    public void setCustomerId(Long customerId) { this.customerId = customerId; }
    public LocalDateTime getStartTime() { return startTime; }
    public void setStartTime(LocalDateTime startTime) { this.startTime = startTime; }
    public LocalDateTime getEndTime() { return endTime; }
    public void setEndTime(LocalDateTime endTime) { this.endTime = endTime; }
    public String getPickupLocation() { return pickupLocation; }
    public void setPickupLocation(String pickupLocation) { this.pickupLocation = pickupLocation; }
    public String getDropoffLocation() { return dropoffLocation; }
    public void setDropoffLocation(String dropoffLocation) { this.dropoffLocation = dropoffLocation; }
    public BigDecimal getTotalAmount() { return totalAmount; }
    public void setTotalAmount(BigDecimal totalAmount) { this.totalAmount = totalAmount; }
    public List<CarItem> getCars() { return cars; }
    public void setCars(List<CarItem> cars) { this.cars = cars; }
    public String getTripType() { return tripType; }
    public void setTripType(String tripType) { this.tripType = tripType; }
    public Boolean getOneWay() { return oneWay; }
    public void setOneWay(Boolean oneWay) { this.oneWay = oneWay; }
    public String getPickupPoint() { return pickupPoint; }
    public void setPickupPoint(String pickupPoint) { this.pickupPoint = pickupPoint; }
    public String getSpecificPickupAddress() { return specificPickupAddress; }
    public void setSpecificPickupAddress(String specificPickupAddress) { this.specificPickupAddress = specificPickupAddress; }
    public Integer getAllowedKmPerDay() { return allowedKmPerDay; }
    public void setAllowedKmPerDay(Integer allowedKmPerDay) { this.allowedKmPerDay = allowedKmPerDay; }
    public BigDecimal getExceedFeePerKm() { return exceedFeePerKm; }
    public void setExceedFeePerKm(BigDecimal exceedFeePerKm) { this.exceedFeePerKm = exceedFeePerKm; }
    public BigDecimal getFuelConsumption() { return fuelConsumption; }
    public void setFuelConsumption(BigDecimal fuelConsumption) { this.fuelConsumption = fuelConsumption; }
    public BigDecimal getInsuranceFee() { return insuranceFee; }
    public void setInsuranceFee(BigDecimal insuranceFee) { this.insuranceFee = insuranceFee; }
    public BigDecimal getTransferFee() { return transferFee; }
    public void setTransferFee(BigDecimal transferFee) { this.transferFee = transferFee; }
    public String getPromoCode() { return promoCode; }
    public void setPromoCode(String promoCode) { this.promoCode = promoCode; }
    public BigDecimal getBasePrice() { return basePrice; }
    public void setBasePrice(BigDecimal basePrice) { this.basePrice = basePrice; }
    public BigDecimal getDiscountAmount() { return discountAmount; }
    public void setDiscountAmount(BigDecimal discountAmount) { this.discountAmount = discountAmount; }
}
