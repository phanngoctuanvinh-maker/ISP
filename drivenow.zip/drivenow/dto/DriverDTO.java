package com.carrentleproject.drivenow.dto;

/**
 * DTO for Driver information (used in admin panel for driver assignment)
 */
public class DriverDTO {
    private Integer driverId;
    private Integer accountId;
    private String fullName;
    private String phone;
    private String email;
    private String licenseNumber;
    private Integer experienceYears;
    private String status;
    private Double averageRating;
    private Integer currentBookingId;

    // Constructors
    public DriverDTO() {
    }

    // Getters and Setters
    public Integer getDriverId() {
        return driverId;
    }

    public void setDriverId(Integer driverId) {
        this.driverId = driverId;
    }

    public Integer getAccountId() {
        return accountId;
    }

    public void setAccountId(Integer accountId) {
        this.accountId = accountId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getLicenseNumber() {
        return licenseNumber;
    }

    public void setLicenseNumber(String licenseNumber) {
        this.licenseNumber = licenseNumber;
    }

    public Integer getExperienceYears() {
        return experienceYears;
    }

    public void setExperienceYears(Integer experienceYears) {
        this.experienceYears = experienceYears;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Double getAverageRating() {
        return averageRating;
    }

    public void setAverageRating(Double averageRating) {
        this.averageRating = averageRating;
    }

    public Integer getCurrentBookingId() {
        return currentBookingId;
    }

    public void setCurrentBookingId(Integer currentBookingId) {
        this.currentBookingId = currentBookingId;
    }
}
