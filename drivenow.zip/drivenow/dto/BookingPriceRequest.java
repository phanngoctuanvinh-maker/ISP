package com.carrentleproject.drivenow.dto;

/**
 * DTO for calculating booking price before creating actual booking
 */
public class BookingPriceRequest {
    private Long carId;
    private String startDate;       // ISO format: "2025-10-16T08:00:00"
    private String endDate;         // ISO format: "2025-10-16T10:00:00"
    private String pickupLocation;
    private String dropoffLocation;
    private String areaType;        // "local", "intercity", "oneway"
    private Double distanceKm;      // Optional: estimated distance

    // Getters and Setters
    public Long getCarId() {
        return carId;
    }

    public void setCarId(Long carId) {
        this.carId = carId;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getPickupLocation() {
        return pickupLocation;
    }

    public void setPickupLocation(String pickupLocation) {
        this.pickupLocation = pickupLocation;
    }

    public String getDropoffLocation() {
        return dropoffLocation;
    }

    public void setDropoffLocation(String dropoffLocation) {
        this.dropoffLocation = dropoffLocation;
    }

    public String getAreaType() {
        return areaType;
    }

    public void setAreaType(String areaType) {
        this.areaType = areaType;
    }

    public Double getDistanceKm() {
        return distanceKm;
    }

    public void setDistanceKm(Double distanceKm) {
        this.distanceKm = distanceKm;
    }
}
