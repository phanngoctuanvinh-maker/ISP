package com.carrentleproject.drivenow.dto;

public class DriverDashboardStatsDTO {
    private Integer tripsToday;
    private Double todayEarnings;
    private Double averageRating;
    private Integer onlineTimeMinutes;
    private Integer totalTrips;
    private Double totalEarnings;

    public DriverDashboardStatsDTO() {
    }

    public DriverDashboardStatsDTO(Integer tripsToday, Double todayEarnings, Double averageRating,
            Integer onlineTimeMinutes, Integer totalTrips, Double totalEarnings) {
        this.tripsToday = tripsToday;
        this.todayEarnings = todayEarnings;
        this.averageRating = averageRating;
        this.onlineTimeMinutes = onlineTimeMinutes;
        this.totalTrips = totalTrips;
        this.totalEarnings = totalEarnings;
    }

    public Integer getTripsToday() {
        return tripsToday;
    }

    public void setTripsToday(Integer tripsToday) {
        this.tripsToday = tripsToday;
    }

    public Double getTodayEarnings() {
        return todayEarnings;
    }

    public void setTodayEarnings(Double todayEarnings) {
        this.todayEarnings = todayEarnings;
    }

    public Double getAverageRating() {
        return averageRating;
    }

    public void setAverageRating(Double averageRating) {
        this.averageRating = averageRating;
    }

    public Integer getOnlineTimeMinutes() {
        return onlineTimeMinutes;
    }

    public void setOnlineTimeMinutes(Integer onlineTimeMinutes) {
        this.onlineTimeMinutes = onlineTimeMinutes;
    }

    public Integer getTotalTrips() {
        return totalTrips;
    }

    public void setTotalTrips(Integer totalTrips) {
        this.totalTrips = totalTrips;
    }

    public Double getTotalEarnings() {
        return totalEarnings;
    }

    public void setTotalEarnings(Double totalEarnings) {
        this.totalEarnings = totalEarnings;
    }
}
