package com.carrentleproject.drivenow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling  // Enable scheduled tasks
public class DrivenowApplication {

	public static void main(String[] args) {
		SpringApplication.run(DrivenowApplication.class, args);
	}

}
