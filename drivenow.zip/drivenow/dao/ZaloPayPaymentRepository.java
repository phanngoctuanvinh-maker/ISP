package com.carrentleproject.drivenow.dao;

import com.carrentleproject.drivenow.model.ZaloPayPayment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository for ZaloPay Payment
 */
@Repository
public interface ZaloPayPaymentRepository extends JpaRepository<ZaloPayPayment, Long> {
    
    /**
     * Find payment by app transaction ID
     */
    Optional<ZaloPayPayment> findByAppTransId(String appTransId);
    
    /**
     * Find payment by ZaloPay transaction ID
     */
    Optional<ZaloPayPayment> findByZpTransId(String zpTransId);
    
    /**
     * Find payment by booking ID
     */
    Optional<ZaloPayPayment> findByBookingId(Integer bookingId);
    
    /**
     * Find all payments by user ID
     */
    List<ZaloPayPayment> findByUserId(Long userId);
    
    /**
     * Find payments by status
     */
    List<ZaloPayPayment> findByPaymentStatus(String paymentStatus);
}
