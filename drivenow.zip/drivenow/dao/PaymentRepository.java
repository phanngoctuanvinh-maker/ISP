package com.carrentleproject.drivenow.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.carrentleproject.drivenow.model.Payment;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, Long> {
    Optional<Payment> findByOrderId(String orderId);
    List<Payment> findByUserId(Long userId);
    List<Payment> findByPaymentStatus(String paymentStatus);
    Optional<Payment> findByBookingId(Integer bookingId);
    List<Payment> findByBankCode(String bankCode);
    List<Payment> findByPaymentStatusAndBankCode(String paymentStatus, String bankCode);
}
