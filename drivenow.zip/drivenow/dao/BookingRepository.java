package com.carrentleproject.drivenow.dao;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.carrentleproject.drivenow.model.Booking;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {
    
    /**
     * Find bookings by customer ID
     */
    List<Booking> findByCustomerId(Long customerId);
    
    /**
     * Find bookings by status
     */
    List<Booking> findByStatus(String status);
    
    /**
     * Find bookings by driver ID
     */
    List<Booking> findByDriverId(Long driverId);
    
    /**
     * Find bookings by status and created before a specific time
     * Used for auto-canceling expired pending bookings
     */
    List<Booking> findByStatusAndCreatedAtBefore(String status, LocalDateTime createdAt);
    
    /**
     * Find bookings by status and customer ID
     */
    List<Booking> findByStatusAndCustomerId(String status, Long customerId);
}
