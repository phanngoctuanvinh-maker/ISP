package com.carrentleproject.drivenow.dao;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.carrentleproject.drivenow.model.BookingCar;

@Repository
public interface BookingCarRepository extends JpaRepository<BookingCar, Long> {

    /**
     * Find overlapping bookings for a specific car and time range
     * Includes bookings with status: pending, confirmed, renting, completed
     * Excludes only: cancelled bookings
     * 
     * This ensures that:
     * 1. Pending bookings (waiting for payment) are still blocking the car
     * 2. Confirmed/renting bookings are obviously blocking
     * 3. Only cancelled bookings don't block availability
     */
    @Query("SELECT bc FROM BookingCar bc, Booking b " +
	    "WHERE bc.carId = :carId AND b.bookingId = bc.bookingId " +
	    "AND b.status <> 'cancelled' AND (bc.startDate <= :end AND bc.endDate >= :start)")
    List<BookingCar> findOverlappingBookings(@Param("carId") Long carId, @Param("start") LocalDateTime start, @Param("end") LocalDateTime end);

    /**
     * Find all booking cars by booking ID
     */
    List<BookingCar> findByBookingId(Long bookingId);
    
    /**
     * Find all booking cars by car ID
     */
    List<BookingCar> findByCarId(Long carId);

}
