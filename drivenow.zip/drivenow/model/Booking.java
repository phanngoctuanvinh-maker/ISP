package com.carrentleproject.drivenow.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

@Entity
@Table(name = "bookings")
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "booking_id")  // Match database column name
    private Long bookingId;

    @Column(name = "customer_id")
    private Long customerId;

    @Column(name = "car_id")
    private Long carId;

    @Column(name = "driver_id")
    private Long driverId;

    @Column(name = "pickup_time")  // Match database column name
    private LocalDateTime startTime;

    @Column(name = "return_time")  // Match database column name
    private LocalDateTime endTime;

    @Column(name = "total_price")  // Match database column name
    private BigDecimal totalAmount;

    @Column(name = "trip_type")
    private String tripType;

    @Column(name = "one_way")
    private Boolean oneWay;

    @Column(name = "pickup_point")
    private String pickupPoint;

    @Column(name = "specific_pickup_address")
    private String specificPickupAddress;

    @Column(name = "allowed_km_per_day")
    private Integer allowedKmPerDay;

    @Column(name = "exceed_fee_per_km")
    private BigDecimal exceedFeePerKm;

    @Column(name = "fuel_consumption")
    private Double fuelConsumption;

    @Column(name = "insurance_fee")
    private BigDecimal insuranceFee;

    @Column(name = "transfer_fee")
    private BigDecimal transferFee;

    @Column(name = "promo_code")
    private String promoCode;

    @Column(name = "base_price")
    private BigDecimal basePrice;

    @Column(name = "discount_amount")
    private BigDecimal discountAmount;

    @Column(name = "discount_code")
    private String discountCode;

    @Column(name = "notes")
    private String notes;

    // Fields below are NOT present in the current DB schema (per your SELECT output).
    // Mark them @Transient so Hibernate will not include them in INSERT/UPDATE SQL.
    // If you later add these columns to the database, remove @Transient.
    @Transient
    private BigDecimal cleaningFee;

    @Transient
    private BigDecimal distanceFee;

    @Transient
    private BigDecimal driverPrice;

    @Transient
    private Double estimatedDistance;

    @Transient
    private BigDecimal fuelSurcharge;

    @Transient
    private BigDecimal seatSurcharge;

    @Transient
    private String specialRequests;

    @Transient
    private BigDecimal tollFee;

    @Transient
    private LocalDateTime originalReturnDate;

    @Column(name = "payment_method")
    private String paymentMethod;

    @Column(name = "payment_status")
    private String paymentStatus;

    @Column(name = "pickup_date", nullable = false)
    private LocalDateTime pickupDate;

    @Column(name = "return_date", nullable = false)
    private LocalDateTime returnDate;

    @Column(name = "total_days", nullable = false)
    private Integer totalDays;

    @Transient
    private Long groupBookingId;

    @Transient
    private String cancellationReason;

    @Transient
    private Integer extensionDays;

    @Transient
    private BigDecimal extensionPrice;

    @Transient
    private Boolean isExtended;

    @Column(name = "pickup_location")
    private String pickupLocation;

    @Column(name = "return_location")  // Match database column name
    private String dropoffLocation;

    @Column(name = "status")
    private String status;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    public Booking() {}

    // getters / setters
    public Long getBookingId() {
        return bookingId;
    }

    public void setBookingId(Long bookingId) {
        this.bookingId = bookingId;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public Long getCarId() {
        return carId;
    }

    public void setCarId(Long carId) {
        this.carId = carId;
    }

    public Long getDriverId() {
        return driverId;
    }

    public void setDriverId(Long driverId) {
        this.driverId = driverId;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getTripType() {
        return tripType;
    }

    public void setTripType(String tripType) {
        this.tripType = tripType;
    }

    public Boolean getOneWay() {
        return oneWay;
    }

    public void setOneWay(Boolean oneWay) {
        this.oneWay = oneWay;
    }

    public String getPickupPoint() {
        return pickupPoint;
    }

    public void setPickupPoint(String pickupPoint) {
        this.pickupPoint = pickupPoint;
    }

    public String getSpecificPickupAddress() {
        return specificPickupAddress;
    }

    public void setSpecificPickupAddress(String specificPickupAddress) {
        this.specificPickupAddress = specificPickupAddress;
    }

    public Integer getAllowedKmPerDay() {
        return allowedKmPerDay;
    }

    public void setAllowedKmPerDay(Integer allowedKmPerDay) {
        this.allowedKmPerDay = allowedKmPerDay;
    }

    public BigDecimal getExceedFeePerKm() {
        return exceedFeePerKm;
    }

    public void setExceedFeePerKm(BigDecimal exceedFeePerKm) {
        this.exceedFeePerKm = exceedFeePerKm;
    }

    public Double getFuelConsumption() {
        return fuelConsumption;
    }

    public void setFuelConsumption(Double fuelConsumption) {
        this.fuelConsumption = fuelConsumption;
    }

    public BigDecimal getInsuranceFee() {
        return insuranceFee;
    }

    public void setInsuranceFee(BigDecimal insuranceFee) {
        this.insuranceFee = insuranceFee;
    }

    public BigDecimal getTransferFee() {
        return transferFee;
    }

    public void setTransferFee(BigDecimal transferFee) {
        this.transferFee = transferFee;
    }

    public String getPromoCode() {
        return promoCode;
    }

    public void setPromoCode(String promoCode) {
        this.promoCode = promoCode;
    }

    public BigDecimal getBasePrice() {
        return basePrice;
    }

    public void setBasePrice(BigDecimal basePrice) {
        this.basePrice = basePrice;
    }

    public BigDecimal getDiscountAmount() {
        return discountAmount;
    }

    public void setDiscountAmount(BigDecimal discountAmount) {
        this.discountAmount = discountAmount;
    }

    public String getDiscountCode() {
        return discountCode;
    }

    public void setDiscountCode(String discountCode) {
        this.discountCode = discountCode;
    }

    public BigDecimal getCleaningFee() {
        return cleaningFee;
    }

    public void setCleaningFee(BigDecimal cleaningFee) {
        this.cleaningFee = cleaningFee;
    }

    public BigDecimal getDistanceFee() {
        return distanceFee;
    }

    public void setDistanceFee(BigDecimal distanceFee) {
        this.distanceFee = distanceFee;
    }

    public BigDecimal getDriverPrice() {
        return driverPrice;
    }

    public void setDriverPrice(BigDecimal driverPrice) {
        this.driverPrice = driverPrice;
    }

    public Double getEstimatedDistance() {
        return estimatedDistance;
    }

    public void setEstimatedDistance(Double estimatedDistance) {
        this.estimatedDistance = estimatedDistance;
    }

    public BigDecimal getFuelSurcharge() {
        return fuelSurcharge;
    }

    public void setFuelSurcharge(BigDecimal fuelSurcharge) {
        this.fuelSurcharge = fuelSurcharge;
    }

    public BigDecimal getSeatSurcharge() {
        return seatSurcharge;
    }

    public void setSeatSurcharge(BigDecimal seatSurcharge) {
        this.seatSurcharge = seatSurcharge;
    }

    public String getSpecialRequests() {
        return specialRequests;
    }

    public void setSpecialRequests(String specialRequests) {
        this.specialRequests = specialRequests;
    }

    public BigDecimal getTollFee() {
        return tollFee;
    }

    public void setTollFee(BigDecimal tollFee) {
        this.tollFee = tollFee;
    }

    public LocalDateTime getOriginalReturnDate() {
        return originalReturnDate;
    }

    public void setOriginalReturnDate(LocalDateTime originalReturnDate) {
        this.originalReturnDate = originalReturnDate;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public LocalDateTime getPickupDate() {
        return pickupDate;
    }

    public void setPickupDate(LocalDateTime pickupDate) {
        this.pickupDate = pickupDate;
    }

    public LocalDateTime getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(LocalDateTime returnDate) {
        this.returnDate = returnDate;
    }

    public Integer getTotalDays() {
        return totalDays;
    }

    public void setTotalDays(Integer totalDays) {
        this.totalDays = totalDays;
    }

    public Long getGroupBookingId() {
        return groupBookingId;
    }

    public void setGroupBookingId(Long groupBookingId) {
        this.groupBookingId = groupBookingId;
    }

    public String getCancellationReason() {
        return cancellationReason;
    }

    public void setCancellationReason(String cancellationReason) {
        this.cancellationReason = cancellationReason;
    }

    public Integer getExtensionDays() {
        return extensionDays;
    }

    public void setExtensionDays(Integer extensionDays) {
        this.extensionDays = extensionDays;
    }

    public BigDecimal getExtensionPrice() {
        return extensionPrice;
    }

    public void setExtensionPrice(BigDecimal extensionPrice) {
        this.extensionPrice = extensionPrice;
    }

    public Boolean getIsExtended() {
        return isExtended;
    }

    public void setIsExtended(Boolean isExtended) {
        this.isExtended = isExtended;
    }

    public String getPickupLocation() {
        return pickupLocation;
    }

    public void setPickupLocation(String pickupLocation) {
        this.pickupLocation = pickupLocation;
    }

    public String getDropoffLocation() {
        return dropoffLocation;
    }

    public void setDropoffLocation(String dropoffLocation) {
        this.dropoffLocation = dropoffLocation;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }
}
