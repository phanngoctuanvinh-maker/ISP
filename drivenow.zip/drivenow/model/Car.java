package com.carrentleproject.drivenow.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;

@Entity
@Table(name = "cars")
public class Car {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "brand", length = 50, nullable = false, columnDefinition = "NVARCHAR(50)")
    private String brand;

    @Column(name = "model", length = 50, nullable = false, columnDefinition = "NVARCHAR(50)")
    private String model;

    @Column(name = "name", length = 100, columnDefinition = "NVARCHAR(100)")
    private String name;

    @Column(name = "year")
    private Integer year;

    @Column(name = "color", length = 50, columnDefinition = "NVARCHAR(50)")
    private String color;

    @Column(name = "car_type", length = 50, columnDefinition = "NVARCHAR(50)")
    private String carType;

    @Column(name = "seat_capacity", nullable = false)
    private Integer seatCapacity;

    @Column(name = "fuel_type", length = 50, columnDefinition = "NVARCHAR(50)")
    private String fuelType;

    @Column(name = "transmission_type", length = 50, columnDefinition = "NVARCHAR(50)")
    private String transmissionType;

    @Column(name = "daily_rate", precision = 10, scale = 2)
    private BigDecimal dailyRate;

    @Column(name = "price_per_day", precision = 10, scale = 2, nullable = false)
    private BigDecimal pricePerDay;

    @Column(name = "description", columnDefinition = "NVARCHAR(MAX)")
    private String description;

    @Column(name = "mileage")
    private Integer mileage;

    @Column(name = "image_url", length = 500, columnDefinition = "NVARCHAR(500)")
    private String imageUrl;

    @Column(name = "status", length = 50, columnDefinition = "NVARCHAR(50)")
    private String status;

    @Column(name = "license_plate", length = 50, columnDefinition = "NVARCHAR(50)")
    private String licensePlate;

    @Column(name = "insurance_info", length = 500, columnDefinition = "NVARCHAR(500)")
    private String insuranceInfo;

    @Column(name = "location", length = 200, columnDefinition = "NVARCHAR(200)")
    private String location;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    // NEW FIELDS for Advanced Filter
    @Column(name = "daily_km_limit")
    private Integer dailyKmLimit; // Giới hạn km/ngày (null = không giới hạn)

    @Column(name = "exceed_fee_per_km")
    private Integer exceedFeePerKm; // Phí vượt giới hạn (VNĐ/km)

    @Column(name = "fuel_consumption", precision = 5, scale = 2)
    private BigDecimal fuelConsumption; // Mức tiêu thụ nhiên liệu (L/100km)

    // Constructors
    public Car() {
    }

    public Car(Long id, String brand, String model, String name, Integer year, String color, 
               String carType, Integer seatCapacity, String fuelType, String transmissionType, 
               BigDecimal dailyRate, BigDecimal pricePerDay, String description, Integer mileage, 
               String imageUrl, String status, String licensePlate, String insuranceInfo, 
               String location, LocalDateTime createdAt, LocalDateTime updatedAt,
               Integer dailyKmLimit, Integer exceedFeePerKm, BigDecimal fuelConsumption) {
        this.id = id;
        this.brand = brand;
        this.model = model;
        this.name = name;
        this.year = year;
        this.color = color;
        this.carType = carType;
        this.seatCapacity = seatCapacity;
        this.fuelType = fuelType;
        this.transmissionType = transmissionType;
        this.dailyRate = dailyRate;
        this.pricePerDay = pricePerDay;
        this.description = description;
        this.mileage = mileage;
        this.imageUrl = imageUrl;
        this.status = status;
        this.licensePlate = licensePlate;
        this.insuranceInfo = insuranceInfo;
        this.location = location;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.dailyKmLimit = dailyKmLimit;
        this.exceedFeePerKm = exceedFeePerKm;
        this.fuelConsumption = fuelConsumption;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getCarType() {
        return carType;
    }

    public void setCarType(String carType) {
        this.carType = carType;
    }

    public Integer getSeatCapacity() {
        return seatCapacity;
    }

    public void setSeatCapacity(Integer seatCapacity) {
        this.seatCapacity = seatCapacity;
    }

    public String getFuelType() {
        return fuelType;
    }

    public void setFuelType(String fuelType) {
        this.fuelType = fuelType;
    }

    public String getTransmissionType() {
        return transmissionType;
    }

    public void setTransmissionType(String transmissionType) {
        this.transmissionType = transmissionType;
    }

    public BigDecimal getDailyRate() {
        return dailyRate;
    }

    public void setDailyRate(BigDecimal dailyRate) {
        this.dailyRate = dailyRate;
    }

    public BigDecimal getPricePerDay() {
        return pricePerDay;
    }

    public void setPricePerDay(BigDecimal pricePerDay) {
        this.pricePerDay = pricePerDay;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getMileage() {
        return mileage;
    }

    public void setMileage(Integer mileage) {
        this.mileage = mileage;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getLicensePlate() {
        return licensePlate;
    }

    public void setLicensePlate(String licensePlate) {
        this.licensePlate = licensePlate;
    }

    public String getInsuranceInfo() {
        return insuranceInfo;
    }

    public void setInsuranceInfo(String insuranceInfo) {
        this.insuranceInfo = insuranceInfo;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    // NEW GETTERS/SETTERS for Advanced Filter
    public Integer getDailyKmLimit() {
        return dailyKmLimit;
    }

    public void setDailyKmLimit(Integer dailyKmLimit) {
        this.dailyKmLimit = dailyKmLimit;
    }

    public Integer getExceedFeePerKm() {
        return exceedFeePerKm;
    }

    public void setExceedFeePerKm(Integer exceedFeePerKm) {
        this.exceedFeePerKm = exceedFeePerKm;
    }

    public BigDecimal getFuelConsumption() {
        return fuelConsumption;
    }

    public void setFuelConsumption(BigDecimal fuelConsumption) {
        this.fuelConsumption = fuelConsumption;
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    @PrePersist
    protected void onCreate() {
        LocalDateTime now = LocalDateTime.now();
        if (createdAt == null) createdAt = now;
        updatedAt = now;
    }
}
