package com.carrentleproject.drivenow.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "booking_cars")
public class BookingCar {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "booking_car_id")
    private Long bookingCarId;

    @Column(name = "booking_id")
    private Long bookingId;

    @Column(name = "car_id")
    private Long carId;
    

    @Column(name = "start_date")
    private LocalDateTime startDate;

    @Column(name = "end_date")
    private LocalDateTime endDate;

    @Column(name = "price_at_booking")
    private BigDecimal priceAtBooking;

    @Column(name = "total_price")
    private BigDecimal totalPrice;

    @Column(name = "distance_km")
    private BigDecimal distanceKm;

    @Column(name = "allowed_km")
    private BigDecimal allowedKm;

    @Column(name = "service_fee")
    private BigDecimal serviceFee;

    @Column(name = "area_type")
    private String areaType;

    @Column(name = "extra_km")
    private BigDecimal extraKm;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    public BookingCar() {
        this.createdAt = LocalDateTime.now();
    }    public Long getBookingCarId() {
        return bookingCarId;
    }

    public void setBookingCarId(Long bookingCarId) {
        this.bookingCarId = bookingCarId;
    }

    public Long getBookingId() {
        return bookingId;
    }

    public void setBookingId(Long bookingId) {
        this.bookingId = bookingId;
    }

    public Long getCarId() {
        return carId;
    }

    public void setCarId(Long carId) {
        this.carId = carId;
    }

    public LocalDateTime getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDateTime startDate) {
        this.startDate = startDate;
    }

    public LocalDateTime getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDateTime endDate) {
        this.endDate = endDate;
    }

    public BigDecimal getPriceAtBooking() {
        return priceAtBooking;
    }

    public void setPriceAtBooking(BigDecimal priceAtBooking) {
        this.priceAtBooking = priceAtBooking;
    }

    public BigDecimal getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(BigDecimal totalPrice) {
        this.totalPrice = totalPrice;
    }

    public BigDecimal getDistanceKm() {
        return distanceKm;
    }

    public void setDistanceKm(BigDecimal distanceKm) {
        this.distanceKm = distanceKm;
    }

    public BigDecimal getAllowedKm() {
        return allowedKm;
    }

    public void setAllowedKm(BigDecimal allowedKm) {
        this.allowedKm = allowedKm;
    }

    public BigDecimal getServiceFee() {
        return serviceFee;
    }

    public void setServiceFee(BigDecimal serviceFee) {
        this.serviceFee = serviceFee;
    }

    public String getAreaType() {
        return areaType;
    }

    public void setAreaType(String areaType) {
        this.areaType = areaType;
    }

    public BigDecimal getExtraKm() {
        return extraKm;
    }

    public void setExtraKm(BigDecimal extraKm) {
        this.extraKm = extraKm;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
}
