package com.carrentleproject.drivenow.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * ZaloPay Payment Entity
 * Lưu thông tin thanh toán qua ZaloPay
 */
@Entity
@Table(name = "zalopay_payments")
public class ZaloPayPayment {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "app_trans_id", unique = true, nullable = false, length = 100)
    private String appTransId; // Mã giao dịch của ứng dụng
    
    @Column(name = "zp_trans_id", length = 100)
    private String zpTransId; // Mã giao dịch từ ZaloPay
    
    @Column(name = "user_id")
    private Long userId;
    
    @Column(name = "booking_id")
    private Integer bookingId; // Liên kết với booking
    
    @Column(name = "amount", nullable = false)
    private BigDecimal amount; // Số tiền thanh toán
    
    @Column(name = "order_info", length = 500)
    private String orderInfo; // Mô tả đơn hàng
    
    @Column(name = "order_url", length = 1000)
    private String orderUrl; // URL để mở app ZaloPay
    
    @Column(name = "zp_trans_token", length = 500)
    private String zpTransToken; // Token từ ZaloPay
    
    @Column(name = "payment_status", length = 50)
    private String paymentStatus = "PENDING"; // PENDING, SUCCESS, FAILED, REFUNDED
    
    @Column(name = "return_code")
    private Integer returnCode; // Mã trả về từ ZaloPay (1: success, 2: failed, 3: pending)
    
    @Column(name = "return_message", length = 500)
    private String returnMessage;
    
    @Column(name = "merchant_user_id", length = 255)
    private String merchantUserId; // User ID trong merchant system
    
    @Column(name = "user_fee_amount")
    private BigDecimal userFeeAmount; // Phí người dùng phải trả
    
    @Column(name = "discount_amount")
    private BigDecimal discountAmount; // Số tiền được giảm giá
    
    @Column(name = "channel")
    private Integer channel; // Kênh thanh toán
    
    @Column(name = "created_at")
    private LocalDateTime createdAt;
    
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    
    @Column(name = "callback_received_at")
    private LocalDateTime callbackReceivedAt; // Thời điểm nhận callback từ ZaloPay
    
    // Constructors
    public ZaloPayPayment() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }
    
    public ZaloPayPayment(String appTransId, Long userId, BigDecimal amount, String orderInfo) {
        this();
        this.appTransId = appTransId;
        this.userId = userId;
        this.amount = amount;
        this.orderInfo = orderInfo;
    }
    
    // Getters and Setters
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public String getAppTransId() {
        return appTransId;
    }
    
    public void setAppTransId(String appTransId) {
        this.appTransId = appTransId;
    }
    
    public String getZpTransId() {
        return zpTransId;
    }
    
    public void setZpTransId(String zpTransId) {
        this.zpTransId = zpTransId;
    }
    
    public Long getUserId() {
        return userId;
    }
    
    public void setUserId(Long userId) {
        this.userId = userId;
    }
    
    public Integer getBookingId() {
        return bookingId;
    }
    
    public void setBookingId(Integer bookingId) {
        this.bookingId = bookingId;
    }
    
    public BigDecimal getAmount() {
        return amount;
    }
    
    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }
    
    public String getOrderInfo() {
        return orderInfo;
    }
    
    public void setOrderInfo(String orderInfo) {
        this.orderInfo = orderInfo;
    }
    
    public String getOrderUrl() {
        return orderUrl;
    }
    
    public void setOrderUrl(String orderUrl) {
        this.orderUrl = orderUrl;
    }
    
    public String getZpTransToken() {
        return zpTransToken;
    }
    
    public void setZpTransToken(String zpTransToken) {
        this.zpTransToken = zpTransToken;
    }
    
    public String getPaymentStatus() {
        return paymentStatus;
    }
    
    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
        this.updatedAt = LocalDateTime.now();
    }
    
    public Integer getReturnCode() {
        return returnCode;
    }
    
    public void setReturnCode(Integer returnCode) {
        this.returnCode = returnCode;
    }
    
    public String getReturnMessage() {
        return returnMessage;
    }
    
    public void setReturnMessage(String returnMessage) {
        this.returnMessage = returnMessage;
    }
    
    public String getMerchantUserId() {
        return merchantUserId;
    }
    
    public void setMerchantUserId(String merchantUserId) {
        this.merchantUserId = merchantUserId;
    }
    
    public BigDecimal getUserFeeAmount() {
        return userFeeAmount;
    }
    
    public void setUserFeeAmount(BigDecimal userFeeAmount) {
        this.userFeeAmount = userFeeAmount;
    }
    
    public BigDecimal getDiscountAmount() {
        return discountAmount;
    }
    
    public void setDiscountAmount(BigDecimal discountAmount) {
        this.discountAmount = discountAmount;
    }
    
    public Integer getChannel() {
        return channel;
    }
    
    public void setChannel(Integer channel) {
        this.channel = channel;
    }
    
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
    
    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    public LocalDateTime getCallbackReceivedAt() {
        return callbackReceivedAt;
    }
    
    public void setCallbackReceivedAt(LocalDateTime callbackReceivedAt) {
        this.callbackReceivedAt = callbackReceivedAt;
    }
}
