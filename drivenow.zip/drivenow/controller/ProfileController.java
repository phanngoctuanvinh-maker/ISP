package com.carrentleproject.drivenow.controller;

import com.carrentleproject.drivenow.dto.ApiResponse;
import com.carrentleproject.drivenow.dto.ProfileUpdateRequest;
import com.carrentleproject.drivenow.service.ProfileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import com.carrentleproject.drivenow.dto.ChangeEmailRequest;
import com.carrentleproject.drivenow.config.JwtTokenProvider;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/profile")
public class ProfileController {

    @Autowired
    private ProfileService profileService;

    @Autowired
    private JwtTokenProvider jwtTokenProvider;

    /**
     * Lấy thông tin profile của user hiện tại (Customer, Driver, Admin)
     */
    @GetMapping("/me")
    public ResponseEntity<ApiResponse<Object>> getProfile() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        ApiResponse<Object> response = profileService.getProfile(username);
        return ResponseEntity.ok(response);
    }

    /**
     * Cập nhật thông tin profile (Customer, Driver)
     */
    @PutMapping("/update")
    @PreAuthorize("hasAnyRole('CUSTOMER', 'DRIVER')")
    public ResponseEntity<ApiResponse<Object>> updateProfile(@RequestBody ProfileUpdateRequest request) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        ApiResponse<Object> response = profileService.updateProfile(username, request);
        return ResponseEntity.ok(response);
    }

    /**
     * Xóa tài khoản (soft delete - đổi status thành inactive)
     */
    @DeleteMapping("/delete")
    public ResponseEntity<ApiResponse<String>> deleteProfile() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        ApiResponse<String> response = profileService.deleteProfile(username);
        return ResponseEntity.ok(response);
    }

    /**
     * Thay đổi email (username) của account. Trả về JWT mới (nếu thành công) và
     * thông tin cập nhật.
     */
    @PutMapping("/email")
    @PreAuthorize("hasAnyRole('CUSTOMER', 'DRIVER')")
    public ResponseEntity<ApiResponse<Object>> changeEmail(@RequestBody ChangeEmailRequest request) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        ApiResponse<Object> response = profileService.changeEmail(username, request.getEmail());
        if (!response.isSuccess()) {
            return ResponseEntity.badRequest().body(response);
        }

        // Generate new token for the new username so client can update Authorization if
        // necessary
        String newToken = jwtTokenProvider.generateTokenFromUsername(request.getEmail());
        Map<String, Object> data = new HashMap<>();
        data.put("token", newToken);
        data.put("email", request.getEmail());
        data.put("payload", response.getData());

        return ResponseEntity.ok(ApiResponse.success("Cập nhật email thành công", data));
    }
}
