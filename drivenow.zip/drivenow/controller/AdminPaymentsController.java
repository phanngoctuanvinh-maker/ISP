package com.carrentleproject.drivenow.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.carrentleproject.drivenow.dto.PaymentDTO;
import com.carrentleproject.drivenow.model.Payment;
import com.carrentleproject.drivenow.service.VNPayService;

/**
 * Admin Payments Controller - For managing all payments
 * Endpoint: /api/payments
 */
@RestController
@RequestMapping("/api/payments")
@CrossOrigin(origins = "*")
public class AdminPaymentsController {

    @Autowired
    private VNPayService vnPayService;

    /**
     * Get all payments (for admin) with customer details
     * GET /api/payments
     */
    @GetMapping
    public ResponseEntity<?> getAllPayments(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String method) {
        try {
            // Lấy tất cả payments với customer name
            List<PaymentDTO> payments = vnPayService.getAllPaymentsWithDetails();
            
            // Filter theo status nếu có
            if (status != null && !status.isEmpty()) {
                payments = payments.stream()
                        .filter(p -> status.equalsIgnoreCase(p.getStatus()))
                        .collect(java.util.stream.Collectors.toList());
            }
            
            // Filter theo method nếu có
            if (method != null && !method.isEmpty()) {
                payments = payments.stream()
                        .filter(p -> method.equalsIgnoreCase(p.getMethod()))
                        .collect(java.util.stream.Collectors.toList());
            }
            
            return ResponseEntity.ok(payments);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }

    /**
     * Get payment by ID
     * GET /api/payments/{id}
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getPaymentById(@PathVariable Long id) {
        try {
            Payment payment = vnPayService.getPaymentById(id);
            if (payment != null) {
                return ResponseEntity.ok(payment);
            } else {
                Map<String, Object> errorResponse = new HashMap<>();
                errorResponse.put("success", false);
                errorResponse.put("message", "Không tìm thấy thanh toán");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
            }
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }
}
