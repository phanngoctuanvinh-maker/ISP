package com.carrentleproject.drivenow.controller;

import com.carrentleproject.drivenow.dto.DriverDashboardStatsDTO;
import com.carrentleproject.drivenow.dto.DriverTripDTO;
import com.carrentleproject.drivenow.dto.DriverDTO;
import com.carrentleproject.drivenow.service.DriverService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/drivers")
@CrossOrigin(origins = "*")
public class DriverController {

    @Autowired
    private DriverService driverService;

    /**
     * Health check endpoint
     */
    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> healthCheck() {
        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("message", "Driver API is running");
        response.put("timestamp", System.currentTimeMillis());
        return ResponseEntity.ok(response);
    }

    /**
     * Lấy thống kê dashboard
     * GET /api/drivers/{driverId}/dashboard-stats
     */
    @GetMapping("/{driverId}/dashboard-stats")
    public ResponseEntity<Map<String, Object>> getDashboardStats(@PathVariable Integer driverId) {
        try {
            DriverDashboardStatsDTO stats = driverService.getDashboardStats(driverId);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", stats);

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Error loading dashboard stats: " + e.getMessage());
            return ResponseEntity.status(500).body(errorResponse);
        }
    }

    /**
     * Lấy danh sách chuyến đi gần đây
     * GET /api/drivers/{driverId}/recent-trips
     */
    @GetMapping("/{driverId}/recent-trips")
    public ResponseEntity<Map<String, Object>> getRecentTrips(
            @PathVariable Integer driverId,
            @RequestParam(defaultValue = "10") Integer limit) {
        try {
            List<DriverTripDTO> trips = driverService.getRecentTrips(driverId, limit);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", trips);
            response.put("count", trips.size());

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Error loading recent trips: " + e.getMessage());
            return ResponseEntity.status(500).body(errorResponse);
        }
    }

    /**
     * Lấy thông tin driver theo ID
     * GET /api/drivers/{driverId}
     */
    @GetMapping("/{driverId}")
    public ResponseEntity<Map<String, Object>> getDriverById(@PathVariable Integer driverId) {
        try {
            DriverDTO driver = driverService.getDriverById(driverId);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("driver", driver);

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Error loading driver info: " + e.getMessage());
            return ResponseEntity.status(500).body(errorResponse);
        }
    }

    /**
     * Lấy profile driver
     * GET /api/drivers/{driverId}/profile
     */
    @GetMapping("/{driverId}/profile")
    public ResponseEntity<Map<String, Object>> getDriverProfile(@PathVariable Integer driverId) {
        try {
            com.carrentleproject.drivenow.dto.DriverProfileDTO profile = driverService.getDriverProfile(driverId);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", profile);

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Lỗi khi tải thông tin: " + e.getMessage());
            return ResponseEntity.status(500).body(errorResponse);
        }
    }

    /**
     * Cập nhật profile driver
     * PUT /api/drivers/{driverId}/profile
     */
    @PutMapping("/{driverId}/profile")
    public ResponseEntity<Map<String, Object>> updateDriverProfile(
            @PathVariable Integer driverId,
            @RequestBody com.carrentleproject.drivenow.dto.DriverProfileDTO profile) {
        try {
            driverService.updateDriverProfile(driverId, profile);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Cập nhật thông tin thành công");

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Lỗi khi cập nhật: " + e.getMessage());
            return ResponseEntity.status(500).body(errorResponse);
        }
    }

    /**
     * Lấy danh sách tài xế đang rảnh (cho admin)
     * GET /api/drivers/available
     */
    @GetMapping("/available")
    public ResponseEntity<Map<String, Object>> getAvailableDrivers() {
        try {
            List<DriverDTO> drivers = driverService.getAvailableDrivers();

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("drivers", drivers);
            response.put("count", drivers.size());

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Error loading available drivers: " + e.getMessage());
            return ResponseEntity.status(500).body(errorResponse);
        }
    }

    /**
     * Lấy danh sách chuyến đi được phân công cho tài xế
     * GET /api/drivers/{driverId}/assigned-trips
     */
    @GetMapping("/{driverId}/assigned-trips")
    public ResponseEntity<Map<String, Object>> getAssignedTrips(@PathVariable Integer driverId) {
        try {
            List<DriverTripDTO> trips = driverService.getAssignedTrips(driverId);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("trips", trips);
            response.put("count", trips.size());

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Error loading assigned trips: " + e.getMessage());
            return ResponseEntity.status(500).body(errorResponse);
        }
    }

    /**
     * Chấp nhận chuyến đi (Accept Trip)
     * POST /api/drivers/trips/{bookingId}/accept
     */
    @PostMapping("/trips/{bookingId}/accept")
    public ResponseEntity<Map<String, Object>> acceptTrip(@PathVariable Integer bookingId) {
        try {
            driverService.acceptTrip(bookingId);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Đã chấp nhận chuyến đi thành công");
            response.put("bookingId", bookingId);

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Lỗi khi chấp nhận chuyến đi: " + e.getMessage());
            return ResponseEntity.status(500).body(errorResponse);
        }
    }

    /**
     * Từ chối/Hủy chuyến đi (Reject/Cancel Trip)
     * POST /api/drivers/trips/{bookingId}/reject
     * Body: { "reason": "Lý do hủy" }
     */
    @PostMapping("/trips/{bookingId}/reject")
    public ResponseEntity<Map<String, Object>> rejectTrip(
            @PathVariable Integer bookingId,
            @RequestBody(required = false) Map<String, String> requestBody) {
        try {
            String reason = (requestBody != null && requestBody.containsKey("reason"))
                    ? requestBody.get("reason")
                    : "Tài xế từ chối";

            driverService.rejectTrip(bookingId, reason);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Đã hủy chuyến đi thành công");
            response.put("bookingId", bookingId);

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Lỗi khi hủy chuyến đi: " + e.getMessage());
            return ResponseEntity.status(500).body(errorResponse);
        }
    }

    /**
     * Bắt đầu chuyến đi (Start Trip)
     * POST /api/drivers/trips/{bookingId}/start
     */
    @PostMapping("/trips/{bookingId}/start")
    public ResponseEntity<Map<String, Object>> startTrip(@PathVariable Integer bookingId) {
        try {
            driverService.startTrip(bookingId);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Đã bắt đầu chuyến đi thành công");
            response.put("bookingId", bookingId);

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Lỗi khi bắt đầu chuyến đi: " + e.getMessage());
            return ResponseEntity.status(500).body(errorResponse);
        }
    }

    /**
     * Hoàn thành chuyến đi (Complete Trip)
     * POST /api/drivers/trips/{bookingId}/complete
     */
    @PostMapping("/trips/{bookingId}/complete")
    public ResponseEntity<Map<String, Object>> completeTrip(@PathVariable Integer bookingId) {
        try {
            driverService.completeTrip(bookingId);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Đã hoàn thành chuyến đi thành công");
            response.put("bookingId", bookingId);

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Lỗi khi hoàn thành chuyến đi: " + e.getMessage());
            return ResponseEntity.status(500).body(errorResponse);
        }
    }

    /**
     * Lấy lịch sử chuyến đi (completed và cancelled)
     * GET /api/drivers/{driverId}/trip-history
     */
    @GetMapping("/{driverId}/trip-history")
    public ResponseEntity<Map<String, Object>> getTripHistory(@PathVariable Integer driverId) {
        try {
            List<DriverTripDTO> history = driverService.getTripHistory(driverId);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", history);
            response.put("count", history.size());

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Lỗi khi tải lịch sử: " + e.getMessage());
            return ResponseEntity.status(500).body(errorResponse);
        }
    }
}
