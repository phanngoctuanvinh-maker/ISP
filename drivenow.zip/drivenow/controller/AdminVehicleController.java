package com.carrentleproject.drivenow.controller;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Base64;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.carrentleproject.drivenow.dao.CarRepository;
import com.carrentleproject.drivenow.model.Car;
import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("/api/vehicles")
@CrossOrigin(origins = "*")
public class AdminVehicleController {

    @Autowired
    private CarRepository carRepository;

    private static final Logger log = LoggerFactory.getLogger(AdminVehicleController.class);
    private static final ObjectMapper MAPPER = new ObjectMapper();

    @GetMapping("")
    public ResponseEntity<List<Car>> listAll() {
        List<Car> cars = carRepository.findAll();
        return ResponseEntity.ok(cars);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Car> getById(@PathVariable Long id) {
        var opt = carRepository.findById(id);
        if (opt.isPresent()) {
            return ResponseEntity.ok(opt.get());
        }
        return ResponseEntity.notFound().build();
    }

    public static class VehicleRequest {
        public String name;
        public String brand;
        public String type; // maps to carType
    @JsonProperty("seatCapacity")
    @JsonAlias({"seats","seat_capacity","seat_capacity"})
    public Integer seatCapacity; // maps to seat_capacity
        @JsonAlias({"plateNumber","plate_number"})
        public String plateNumber; // licensePlate
        @JsonAlias({"pricePerDay","price_per_day","pricePerDay"})
        public Number pricePerDay;
        @JsonAlias({"dailyRate","daily_rate","dailyRate"})
        public Number dailyRate; // maps to dailyRate
        public String status;
        public String imageUrl;

        // additional fields from cars table
        public String model;
        public Integer year;
        public String color;
        public String description;
        public Integer mileage;
        public String insuranceInfo;
        public String location;
        public String fuelType;
        public String transmissionType;
        @JsonAlias({"dailyKmLimit","daily_km_limit","daily_km_limit"})
        public Integer dailyKmLimit;
        @JsonAlias({"exceedFeePerKm","exceed_fee_per_km","exceed_fee_per_km"})
        public Integer exceedFeePerKm;
        @JsonAlias({"fuelConsumption","fuel_consumption","fuel_consumption"})
        public Number fuelConsumption; // decimal
    }

    public static class ErrorResponse {
        public String error;
        public ErrorResponse(String error) { this.error = error; }
    }

    @PostMapping("")
    public ResponseEntity<?> createVehicle(@RequestBody VehicleRequest req) {
        try {
            // Log incoming request for debugging field binding
            try {
                log.debug("createVehicle request => {}", MAPPER.writeValueAsString(req));
            } catch (Exception _e) {
                log.debug("createVehicle - cannot serialize request");
            }
            // normalize plate if provided
            if (req.plateNumber != null) req.plateNumber = req.plateNumber.trim();

            // If license plate provided, enforce uniqueness at API level to return 409 instead of 500
            if (req.plateNumber != null && !req.plateNumber.isBlank()) {
                if (carRepository.existsByLicensePlate(req.plateNumber)) {
                    return ResponseEntity.status(HttpStatus.CONFLICT)
                            .body(new ErrorResponse("license plate already exists"));
                }
            }

            Car car = new Car();
            car.setName(req.name);
            car.setBrand(req.brand);
            car.setCarType(req.type);
            // seat capacity
            if (req.seatCapacity != null) car.setSeatCapacity(req.seatCapacity);
            // license plate
            car.setLicensePlate(req.plateNumber);
            // price fields
            if (req.pricePerDay != null) {
                car.setPricePerDay(new BigDecimal(req.pricePerDay.toString()));
            }
            if (req.dailyRate != null) {
                car.setDailyRate(new BigDecimal(req.dailyRate.toString()));
            }
            car.setStatus(req.status != null ? req.status : "available");
            car.setImageUrl(req.imageUrl);

            // optional additional fields
            if (req.model != null) car.setModel(req.model);
            if (req.year != null) car.setYear(req.year);
            if (req.color != null) car.setColor(req.color);
            if (req.description != null) car.setDescription(req.description);
            if (req.mileage != null) car.setMileage(req.mileage);
            if (req.insuranceInfo != null) car.setInsuranceInfo(req.insuranceInfo);
            if (req.location != null) car.setLocation(req.location);
            if (req.fuelType != null) car.setFuelType(req.fuelType);
            if (req.transmissionType != null) car.setTransmissionType(req.transmissionType);
            if (req.dailyKmLimit != null) car.setDailyKmLimit(req.dailyKmLimit);
            if (req.exceedFeePerKm != null) car.setExceedFeePerKm(req.exceedFeePerKm);
            if (req.fuelConsumption != null) car.setFuelConsumption(new BigDecimal(req.fuelConsumption.toString()));

            Car saved = carRepository.save(car);
            return ResponseEntity.status(HttpStatus.CREATED).body(saved);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ErrorResponse("internal server error"));
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateVehicle(@PathVariable Long id, @RequestBody VehicleRequest req) {
        try {
            try {
                log.debug("updateVehicle request => {}", MAPPER.writeValueAsString(req));
            } catch (Exception _e) {
                log.debug("updateVehicle - cannot serialize request");
            }
        } catch (Exception ignored) {}
        var opt = carRepository.findById(id);
        if (opt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        Car car = opt.get();
        if (req.name != null) car.setName(req.name);
        if (req.brand != null) car.setBrand(req.brand);
        if (req.type != null) car.setCarType(req.type);
    if (req.seatCapacity != null) car.setSeatCapacity(req.seatCapacity);
    // If plateNumber is being changed, ensure it doesn't collide with another car
    if (req.plateNumber != null) {
        String newPlate = req.plateNumber.trim();
        if (!newPlate.equals(car.getLicensePlate())) {
            if (carRepository.existsByLicensePlate(newPlate)) {
                return ResponseEntity.status(HttpStatus.CONFLICT)
                        .body(new ErrorResponse("license plate already exists"));
            }
        }
        car.setLicensePlate(newPlate);
    }
    if (req.pricePerDay != null) car.setPricePerDay(new BigDecimal(req.pricePerDay.toString()));
    if (req.dailyRate != null) car.setDailyRate(new BigDecimal(req.dailyRate.toString()));
    if (req.status != null) car.setStatus(req.status);
    if (req.imageUrl != null) car.setImageUrl(req.imageUrl);

    // additional updatable fields
    if (req.model != null) car.setModel(req.model);
    if (req.year != null) car.setYear(req.year);
    if (req.color != null) car.setColor(req.color);
    if (req.description != null) car.setDescription(req.description);
    if (req.mileage != null) car.setMileage(req.mileage);
    if (req.insuranceInfo != null) car.setInsuranceInfo(req.insuranceInfo);
    if (req.location != null) car.setLocation(req.location);
    if (req.fuelType != null) car.setFuelType(req.fuelType);
    if (req.transmissionType != null) car.setTransmissionType(req.transmissionType);
    if (req.dailyKmLimit != null) car.setDailyKmLimit(req.dailyKmLimit);
    if (req.exceedFeePerKm != null) car.setExceedFeePerKm(req.exceedFeePerKm);
    if (req.fuelConsumption != null) car.setFuelConsumption(new BigDecimal(req.fuelConsumption.toString()));

        Car updated = carRepository.save(car);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteVehicle(@PathVariable Long id) {
        var opt = carRepository.findById(id);
        if (opt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        carRepository.delete(opt.get());
        return ResponseEntity.noContent().build();
    }

    /**
     * Accept an image file, store as base64 string in DB.imageUrl (data URL).
     * This is a simple approach for demo purposes and avoids filesystem config.
     */
    @PostMapping(path = "/{id}/image", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Car> uploadImage(@PathVariable Long id, @RequestParam("image") MultipartFile image) {
        if (image == null || image.isEmpty()) {
            return ResponseEntity.badRequest().build();
        }

        var opt = carRepository.findById(id);
        if (opt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        Car car = opt.get();
        try {
            byte[] bytes = image.getBytes();
            String base64 = Base64.getEncoder().encodeToString(bytes);
            String contentType = image.getContentType() != null ? image.getContentType() : "image/jpeg";
            String dataUrl = "data:" + contentType + ";base64," + base64;
            car.setImageUrl(dataUrl);
            Car saved = carRepository.save(car);
            return ResponseEntity.ok(saved);
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
