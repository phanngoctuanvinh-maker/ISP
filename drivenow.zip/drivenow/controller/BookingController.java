package com.carrentleproject.drivenow.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.carrentleproject.drivenow.dto.BookingRequest;
import com.carrentleproject.drivenow.dto.BookingPriceRequest;
import com.carrentleproject.drivenow.dto.BookingPriceResponse;
import com.carrentleproject.drivenow.dto.GroupBookingRequest;
import com.carrentleproject.drivenow.model.Booking;
import com.carrentleproject.drivenow.service.BookingService;

import java.util.List;

@RestController
@RequestMapping("/api/bookings")
@CrossOrigin(origins = "*")
public class BookingController {

    @Autowired
    private BookingService bookingService;

    /**
     * Create a single-car booking
     * POST /api/bookings
     */
    @PostMapping("")
    public ResponseEntity<Map<String, Object>> createBooking(@RequestBody BookingRequest req) {
        try {
            Booking booking = bookingService.createBooking(req);
            Map<String, Object> resp = new HashMap<>();
            resp.put("success", true);
            resp.put("bookingId", booking.getBookingId());
            resp.put("id", booking.getBookingId()); // For frontend compatibility
            resp.put("totalPrice", booking.getTotalAmount());
            resp.put("status", booking.getStatus());
            resp.put("message", "Booking created");
            return ResponseEntity.ok(resp);
        } catch (Exception e) {
            Map<String, Object> err = new HashMap<>();
            err.put("success", false);
            err.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(err);
        }
    }

    /**
     * Create a group booking (multiple cars under one booking)
     * POST /api/bookings/group
     */
    @PostMapping("/group")
    public ResponseEntity<Map<String, Object>> createGroupBooking(@RequestBody GroupBookingRequest req) {
        try {
            Booking booking = bookingService.createGroupBooking(req);
            Map<String, Object> resp = new HashMap<>();
            resp.put("success", true);
            resp.put("bookingId", booking.getBookingId());
            resp.put("id", booking.getBookingId()); // For frontend compatibility
            resp.put("totalPrice", booking.getTotalAmount());
            resp.put("status", booking.getStatus());
            resp.put("message", "Group booking created");
            return ResponseEntity.ok(resp);
        } catch (Exception e) {
            Map<String, Object> err = new HashMap<>();
            err.put("success", false);
            err.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(err);
        }
    }

    /**
     * Get booking by ID with details
     * GET /api/bookings/{id}
     */
    @GetMapping("/{id}")
    public ResponseEntity<Map<String, Object>> getBookingById(@PathVariable Long id) {
        try {
            Booking booking = bookingService.getBookingById(id);
            Map<String, Object> resp = new HashMap<>();
            resp.put("success", true);
            resp.put("booking", booking);
            return ResponseEntity.ok(resp);
        } catch (Exception e) {
            Map<String, Object> err = new HashMap<>();
            err.put("success", false);
            err.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(err);
        }
    }

    /**
     * Get all bookings by customer ID
     * GET /api/bookings/customer/{customerId}
     */
    @GetMapping("/customer/{customerId}")
    public ResponseEntity<Map<String, Object>> getBookingsByCustomer(@PathVariable Long customerId) {
        try {
            List<Booking> bookings = bookingService.getBookingsByCustomerId(customerId);
            Map<String, Object> resp = new HashMap<>();
            resp.put("success", true);
            resp.put("bookings", bookings);
            resp.put("count", bookings.size());
            return ResponseEntity.ok(resp);
        } catch (Exception e) {
            Map<String, Object> err = new HashMap<>();
            err.put("success", false);
            err.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(err);
        }
    }

    /**
     * Get all bookings (with optional status filter)
     * GET /api/bookings?status=pending
     */
    @GetMapping("")
    public ResponseEntity<Map<String, Object>> getAllBookings(
            @RequestParam(required = false) String status) {
        try {
            List<Booking> bookings;
            if (status != null && !status.isEmpty()) {
                bookings = bookingService.getBookingsByStatus(status);
            } else {
                bookings = bookingService.getAllBookings();
            }
            Map<String, Object> resp = new HashMap<>();
            resp.put("success", true);
            resp.put("bookings", bookings);
            resp.put("count", bookings.size());
            return ResponseEntity.ok(resp);
        } catch (Exception e) {
            Map<String, Object> err = new HashMap<>();
            err.put("success", false);
            err.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(err);
        }
    }

    /**
     * Update booking status
     * PUT /api/bookings/{id}/status
     */
    @PutMapping("/{id}/status")
    public ResponseEntity<Map<String, Object>> updateBookingStatus(
            @PathVariable Long id,
            @RequestBody Map<String, String> request) {
        try {
            String newStatus = request.get("status");
            if (newStatus == null || newStatus.isEmpty()) {
                throw new IllegalArgumentException("Status is required");
            }
            Booking booking = bookingService.updateBookingStatus(id, newStatus);
            Map<String, Object> resp = new HashMap<>();
            resp.put("success", true);
            resp.put("booking", booking);
            resp.put("message", "Booking status updated successfully");
            return ResponseEntity.ok(resp);
        } catch (Exception e) {
            Map<String, Object> err = new HashMap<>();
            err.put("success", false);
            err.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(err);
        }
    }

    /**
     * Cancel booking
     * PUT /api/bookings/{id}/cancel
     */
    @PutMapping("/{id}/cancel")
    public ResponseEntity<Map<String, Object>> cancelBooking(@PathVariable Long id) {
        try {
            Booking booking = bookingService.cancelBooking(id);
            Map<String, Object> resp = new HashMap<>();
            resp.put("success", true);
            resp.put("booking", booking);
            resp.put("message", "Booking cancelled successfully");
            return ResponseEntity.ok(resp);
        } catch (Exception e) {
            Map<String, Object> err = new HashMap<>();
            err.put("success", false);
            err.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(err);
        }
    }

    /**
     * Calculate booking price (server-side calculation)
     * POST /api/bookings/calculate-price
     */
    @PostMapping("/calculate-price")
    public ResponseEntity<Map<String, Object>> calculatePrice(@RequestBody BookingPriceRequest req) {
        try {
            BookingPriceResponse priceDetails = bookingService.calculateBookingPrice(req);
            Map<String, Object> resp = new HashMap<>();
            resp.put("success", true);
            resp.put("priceDetails", priceDetails);
            return ResponseEntity.ok(resp);
        } catch (Exception e) {
            Map<String, Object> err = new HashMap<>();
            err.put("success", false);
            err.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(err);
        }
    }
    
    /**
     * Update booking payment info
     * PUT /api/bookings/{id}/payment
     */
    @PutMapping("/{id}/payment")
    public ResponseEntity<Map<String, Object>> updatePaymentInfo(
            @PathVariable Long id,
            @RequestBody Map<String, String> request) {
        try {
            String paymentMethod = request.get("paymentMethod");
            String paymentStatus = request.get("paymentStatus");
            String newStatus = request.get("status");
            
            Booking booking = bookingService.getBookingById(id);
            
            if (paymentMethod != null) {
                booking.setPaymentMethod(paymentMethod);
            }
            if (paymentStatus != null) {
                booking.setPaymentStatus(paymentStatus);
            }
            if (newStatus != null) {
                booking.setStatus(newStatus);
            }
            
            booking.setUpdatedAt(java.time.LocalDateTime.now());
            booking = bookingService.updateBookingStatus(id, booking.getStatus());
            
            Map<String, Object> resp = new HashMap<>();
            resp.put("success", true);
            resp.put("booking", booking);
            resp.put("message", "Payment info updated successfully");
            return ResponseEntity.ok(resp);
        } catch (Exception e) {
            Map<String, Object> err = new HashMap<>();
            err.put("success", false);
            err.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(err);
        }
    }
}
