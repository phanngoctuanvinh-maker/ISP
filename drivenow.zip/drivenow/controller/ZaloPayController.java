package com.carrentleproject.drivenow.controller;

import com.carrentleproject.drivenow.dto.ZaloPayRequest;
import com.carrentleproject.drivenow.model.ZaloPayPayment;
import com.carrentleproject.drivenow.service.ZaloPayService;
import jakarta.validation.Valid;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * ZaloPay Payment Controller
 * Xử lý các API liên quan đến thanh toán ZaloPay
 */
@RestController
@RequestMapping("/api/zalopay")
@CrossOrigin(origins = "*")
public class ZaloPayController {
    
    @Autowired
    private ZaloPayService zaloPayService;
    
    /**
     * API: Tạo đơn hàng ZaloPay
     * Method: POST
     * Endpoint: /api/zalopay/create
     * Body: {
     *   "userId": 1,
     *   "bookingId": 123,
     *   "amount": 100000,
     *   "orderInfo": "Thanh toan thue xe",
     *   "bankCode": "zalopayapp"
     * }
     */
    @PostMapping("/create")
    public ResponseEntity<?> createOrder(@Valid @RequestBody ZaloPayRequest request) {
        try {
            System.out.println("📝 Creating ZaloPay order for user: " + request.getUserId());
            
            Map<String, Object> result = zaloPayService.createOrder(request);
            
            if (Boolean.TRUE.equals(result.get("success"))) {
                Map<String, Object> response = new HashMap<>();
                response.put("success", true);
                response.put("message", "Tạo đơn hàng ZaloPay thành công");
                response.put("orderUrl", result.get("orderurl"));
                response.put("zpTransToken", result.get("zptranstoken"));
                response.put("appTransId", result.get("apptransid"));
                response.put("returnCode", result.get("returncode"));
                
                return ResponseEntity.ok(response);
            } else {
                Map<String, Object> errorResponse = new HashMap<>();
                errorResponse.put("success", false);
                errorResponse.put("message", "Không thể tạo đơn hàng: " + result.get("error"));
                errorResponse.put("returnCode", result.get("returncode"));
                
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
            }
            
        } catch (Exception e) {
            System.err.println("❌ Error creating ZaloPay order: " + e.getMessage());
            e.printStackTrace();
            
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Lỗi khi tạo đơn hàng: " + e.getMessage());
            
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }
    
    /**
     * API: Callback từ ZaloPay (ZaloPay server sẽ gọi API này sau khi thanh toán)
     * Method: POST
     * Endpoint: /api/zalopay/callback
     * Body: {
     *   "data": "...",
     *   "mac": "..."
     * }
     */
    @PostMapping("/callback")
    public ResponseEntity<?> handleCallback(@RequestBody String jsonStr) {
        try {
            System.out.println("📩 ZaloPay callback received");
            System.out.println("📋 Callback data: " + jsonStr);
            
            JSONObject cbData = new JSONObject(jsonStr);
            String data = cbData.getString("data");
            String mac = cbData.getString("mac");
            
            Map<String, Object> result = zaloPayService.handleCallback(data, mac);
            
            // Trả về response cho ZaloPay server
            return ResponseEntity.ok(result);
            
        } catch (Exception e) {
            System.err.println("❌ Error processing ZaloPay callback: " + e.getMessage());
            e.printStackTrace();
            
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("returncode", 0); // ZaloPay sẽ retry
            errorResponse.put("returnmessage", e.getMessage());
            
            return ResponseEntity.ok(errorResponse); // Vẫn trả về 200 OK để ZaloPay không retry liên tục
        }
    }
    
    /**
     * API: Kiểm tra trạng thái thanh toán
     * Method: GET
     * Endpoint: /api/zalopay/query/{appTransId}
     */
    @GetMapping("/query/{appTransId}")
    public ResponseEntity<?> queryOrderStatus(@PathVariable String appTransId) {
        try {
            Map<String, Object> result = zaloPayService.queryOrderStatus(appTransId);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", result);
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Lỗi khi kiểm tra trạng thái: " + e.getMessage());
            
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }
    
    /**
     * API: Lấy thông tin thanh toán theo App Transaction ID
     * Method: GET
     * Endpoint: /api/zalopay/payment/{appTransId}
     */
    @GetMapping("/payment/{appTransId}")
    public ResponseEntity<?> getPaymentByAppTransId(@PathVariable String appTransId) {
        try {
            Optional<ZaloPayPayment> payment = zaloPayService.getPaymentByAppTransId(appTransId);
            
            if (payment.isPresent()) {
                Map<String, Object> response = new HashMap<>();
                response.put("success", true);
                response.put("payment", payment.get());
                return ResponseEntity.ok(response);
            } else {
                Map<String, Object> errorResponse = new HashMap<>();
                errorResponse.put("success", false);
                errorResponse.put("message", "Không tìm thấy thanh toán");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
            }
            
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }
    
    /**
     * API: Lấy trạng thái thanh toán theo Booking ID (cho frontend polling)
     * Method: GET
     * Endpoint: /api/zalopay/booking/{bookingId}/status
     */
    @GetMapping("/booking/{bookingId}/status")
    public ResponseEntity<?> getPaymentStatusByBookingId(@PathVariable Integer bookingId) {
        try {
            System.out.println("🔍 [ZaloPay] Checking payment status for booking: " + bookingId);
            
            Optional<ZaloPayPayment> paymentOpt = zaloPayService.getPaymentByBookingId(bookingId);
            
            if (paymentOpt.isPresent()) {
                ZaloPayPayment payment = paymentOpt.get();
                System.out.println("✅ [ZaloPay] Found payment - Status: " + payment.getPaymentStatus());
                
                Map<String, Object> response = new HashMap<>();
                response.put("success", true);
                response.put("paymentStatus", payment.getPaymentStatus());
                response.put("bookingId", payment.getBookingId());
                response.put("appTransId", payment.getAppTransId());
                response.put("amount", payment.getAmount());
                response.put("zpTransId", payment.getZpTransId());
                response.put("returnCode", payment.getReturnCode());
                
                return ResponseEntity.ok(response);
            } else {
                System.out.println("⚠️ [ZaloPay] No payment found for booking: " + bookingId);
                Map<String, Object> response = new HashMap<>();
                response.put("success", true);
                response.put("paymentStatus", "PENDING"); // Chưa có payment
                response.put("bookingId", bookingId);
                
                return ResponseEntity.ok(response);
            }
            
        } catch (Exception e) {
            System.err.println("❌ [ZaloPay] Error in getPaymentStatusByBookingId: " + e.getMessage());
            e.printStackTrace();
            
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Lỗi: " + e.getMessage());
            
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }
    
    /**
     * API: Lấy danh sách thanh toán của user
     * Method: GET
     * Endpoint: /api/zalopay/user/{userId}
     */
    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getPaymentsByUserId(@PathVariable Long userId) {
        try {
            List<ZaloPayPayment> payments = zaloPayService.getPaymentsByUserId(userId);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("payments", payments);
            response.put("total", payments.size());
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Lỗi: " + e.getMessage());
            
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }
    
    /**
     * API: Test endpoint
     * Method: GET
     * Endpoint: /api/zalopay/test
     */
    @GetMapping("/test")
    public ResponseEntity<?> testZaloPay() {
        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("message", "ZaloPay API is working!");
        response.put("timestamp", System.currentTimeMillis());
        
        return ResponseEntity.ok(response);
    }
}
