package com.carrentleproject.drivenow.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.carrentleproject.drivenow.dao.CarRepository;
import com.carrentleproject.drivenow.dto.SearchCarResponse;
import com.carrentleproject.drivenow.model.Car;

@RestController
@RequestMapping("/api/long-term-cars")
@CrossOrigin(origins = "*")
public class LongTermCarController {
    @Autowired
    private CarRepository CarRepository;

    @Autowired
    private com.carrentleproject.drivenow.service.SearchCarService searchCarService;

    /**
     * API lấy xe cho thuê dài hạn theo thành phố/location và filter
     * GET /api/long-term-cars?city=Hà Nội&carType=Sedan&brand=Toyota&transmissionType=Tự động&seatCapacity=5&fuelType=Xăng
     * Các filter (carType, brand, transmissionType, seatCapacity, fuelType) là optional
     */
    @GetMapping("")
    public ResponseEntity<SearchCarResponse> getLongTermCars(
            @RequestParam String city,
            @RequestParam(required = false) String carType,
            @RequestParam(required = false) String brand,
            @RequestParam(required = false) String transmissionType,
            @RequestParam(required = false) Integer seatCapacity,
            @RequestParam(required = false) String fuelType
    ) {
        try {
            // Delegate to SearchCarService to reuse filtering logic and keep behavior consistent
            List<Car> cars = searchCarService.searchByLocation(city, carType, brand, transmissionType, seatCapacity, fuelType);
            boolean found = (cars != null && !cars.isEmpty());
            int carCount = (cars != null) ? cars.size() : 0;
            String msg = found ? ("Tìm thấy " + carCount + " xe tại " + city) : ("Không tìm thấy xe tại " + city);
            return ResponseEntity.ok(new SearchCarResponse(found, msg, cars));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new SearchCarResponse(false, "Lỗi hệ thống: " + e.getMessage(), null));
        }
    }
}
