package com.carrentleproject.drivenow.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.carrentleproject.drivenow.dto.PaymentRequest;
import com.carrentleproject.drivenow.model.Payment;
import com.carrentleproject.drivenow.service.VNPayService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/payment")
public class PaymentController {

    @Autowired
    private VNPayService vnPayService;

    /**
     * API: Tạo URL thanh toán VNPay
     * Method: POST
     * Endpoint: /api/payment/create
     * Body: {
     *   "userId": 1,
     *   "amount": 100000,
     *   "orderInfo": "Thanh toan thue xe",
     *   "bankCode": "NCB" (optional)
     * }
     */
    @PostMapping("/create")
    public ResponseEntity<?> createPayment(
            @Valid @RequestBody PaymentRequest paymentRequest,
            HttpServletRequest request) {
        try {
            String paymentUrl = vnPayService.createPaymentUrl(paymentRequest, request);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Tạo URL thanh toán thành công");
            response.put("paymentUrl", paymentUrl);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Lỗi khi tạo thanh toán: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }

    /**
     * API: Callback từ VNPay sau khi thanh toán
     * Method: GET
     * Endpoint: /api/payment/vnpay-return
     * VNPay sẽ redirect về URL này với các query params
     * Sau khi xử lý xong, redirect về frontend payment page
     */
    @GetMapping("/vnpay-return")
    public ResponseEntity<?> vnpayReturn(HttpServletRequest request) {
        try {
            // Get all request parameters
            Map<String, String> params = new HashMap<>();
            request.getParameterMap().forEach((key, values) -> {
                if (values != null && values.length > 0) {
                    params.put(key, values[0]);
                }
            });
            
            System.out.println("📩 VNPay callback received with params: " + params);
            
            Map<String, Object> result = vnPayService.handlePaymentReturn(params);
            
            System.out.println("📊 Payment processing result: " + result);
            
            // Trả về JSON response
            // Frontend sẽ polling để check payment status
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            System.err.println("❌ Error processing VNPay callback: " + e.getMessage());
            e.printStackTrace();
            
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Lỗi xử lý callback: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }

    /**
     * API: Lấy danh sách tất cả thanh toán (cho admin)
     * Method: GET
     * Endpoint: /api/payments
     */
    @GetMapping
    public ResponseEntity<?> getAllPayments(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String method) {
        try {
            List<Payment> payments = vnPayService.getAllPayments(status, method);
            
            return ResponseEntity.ok(payments);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }

    /**
     * API: Lấy thông tin thanh toán theo Order ID
     * Method: GET
     * Endpoint: /api/payment/order/{orderId}
     */
    @GetMapping("/order/{orderId}")
    public ResponseEntity<?> getPaymentByOrderId(@PathVariable String orderId) {
        try {
            Optional<Payment> payment = vnPayService.getPaymentByOrderId(orderId);
            
            if (payment.isPresent()) {
                Map<String, Object> response = new HashMap<>();
                response.put("success", true);
                response.put("payment", payment.get());
                return ResponseEntity.ok(response);
            } else {
                Map<String, Object> errorResponse = new HashMap<>();
                errorResponse.put("success", false);
                errorResponse.put("message", "Không tìm thấy đơn hàng");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
            }
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }

    /**
     * API: Lấy thông tin thanh toán theo Booking ID (Dùng để frontend polling)
     * Method: GET
     * Endpoint: /api/payment/booking/{bookingId}/status
     */
    @GetMapping("/booking/{bookingId}/status")
    public ResponseEntity<?> getPaymentStatusByBookingId(@PathVariable Integer bookingId) {
        try {
            Optional<Payment> paymentOpt = vnPayService.getPaymentByBookingId(bookingId);
            
            if (paymentOpt.isPresent()) {
                Payment payment = paymentOpt.get();
                Map<String, Object> response = new HashMap<>();
                response.put("success", true);
                response.put("paymentStatus", payment.getPaymentStatus());
                response.put("bookingId", payment.getBookingId());
                response.put("orderId", payment.getOrderId());
                response.put("amount", payment.getAmount());
                response.put("transactionNo", payment.getTransactionNo());
                response.put("vnpayResponseCode", payment.getVnpayResponseCode());
                return ResponseEntity.ok(response);
            } else {
                Map<String, Object> response = new HashMap<>();
                response.put("success", true);
                response.put("paymentStatus", "PENDING"); // Chưa có payment
                response.put("bookingId", bookingId);
                return ResponseEntity.ok(response);
            }
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }

    /**
     * API: Lấy danh sách thanh toán của user
     * Method: GET
     * Endpoint: /api/payment/user/{userId}
     */
    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getPaymentsByUserId(@PathVariable Long userId) {
        try {
            List<Payment> payments = vnPayService.getPaymentsByUserId(userId);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("payments", payments);
            response.put("total", payments.size());
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }

    /**
     * API: Test endpoint
     * Method: GET
     * Endpoint: /api/payment/test
     */
    @GetMapping("/test")
    public ResponseEntity<?> testPayment() {
        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("message", "Payment API is working!");
        response.put("timestamp", System.currentTimeMillis());
        return ResponseEntity.ok(response);
    }
}
