package com.carrentleproject.drivenow.controller;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.carrentleproject.drivenow.dao.BookingRepository;
import com.carrentleproject.drivenow.dao.CarRepository;
import com.carrentleproject.drivenow.dao.CustomerDAO;
import com.carrentleproject.drivenow.dao.PaymentRepository;
import com.carrentleproject.drivenow.model.Booking;
import com.carrentleproject.drivenow.model.Car;

/**
 * Dashboard Controller - Thống kê tổng quan hệ thống
 */
@RestController
@RequestMapping("/api/dashboard")
@CrossOrigin(origins = "*")
public class DashboardController {

    @Autowired
    private CarRepository carRepository;

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private CustomerDAO customerDAO;

    @Autowired
    private PaymentRepository paymentRepository;

    /**
     * GET /api/dashboard/stats - Lấy tất cả thống kê tổng quan
     */
    @GetMapping("/stats")
    public ResponseEntity<?> getDashboardStats() {
        try {
            Map<String, Object> stats = new HashMap<>();

            // 1. Tổng số xe
            long totalCars = carRepository.count();
            stats.put("totalCars", totalCars);

            // 2. Xe đang cho thuê (status = RENTED hoặc rented)
            List<Car> allCars = carRepository.findAll();
            long rentedCars = allCars.stream()
                    .filter(c -> "RENTED".equalsIgnoreCase(c.getStatus()) || "rented".equalsIgnoreCase(c.getStatus()))
                    .count();
            stats.put("rentedCars", rentedCars);

            // 3. Xe sẵn sàng (status = AVAILABLE)
            long availableCars = allCars.stream().filter(c -> "AVAILABLE".equals(c.getStatus())).count();
            stats.put("availableCars", availableCars);

            // 4. Tổng số đơn thuê
            long totalBookings = bookingRepository.count();
            stats.put("totalBookings", totalBookings);

            // 5. Đơn đang hoạt động (confirmed + renting)
            List<Booking> allBookings = bookingRepository.findAll();
            long activeBookings = allBookings.stream()
                    .filter(b -> "confirmed".equals(b.getStatus()) || "renting".equals(b.getStatus()))
                    .count();
            stats.put("activeBookings", activeBookings);

            // 6. Tổng doanh thu (từ các booking completed)
            List<Booking> completedBookings = bookingRepository.findByStatus("completed");
            long totalRevenue = completedBookings.stream()
                    .filter(b -> b.getTotalAmount() != null)
                    .mapToLong(b -> b.getTotalAmount().longValue())
                    .sum();
            stats.put("totalRevenue", totalRevenue);

            // 7. Doanh thu tháng này
            LocalDateTime startOfMonth = LocalDateTime.now().withDayOfMonth(1).withHour(0).withMinute(0).withSecond(0);
            long monthRevenue = completedBookings.stream()
                    .filter(b -> b.getCreatedAt() != null && b.getCreatedAt().isAfter(startOfMonth))
                    .filter(b -> b.getTotalAmount() != null)
                    .mapToLong(b -> b.getTotalAmount().longValue())
                    .sum();
            stats.put("monthRevenue", monthRevenue);

            // 8. Tổng số khách hàng
            long totalCustomers = customerDAO.count();
            stats.put("totalCustomers", totalCustomers);

            // 9. Danh sách xe đang cho thuê (với thông tin chi tiết)
            List<Car> rentingCars = allCars.stream()
                    .filter(c -> "RENTED".equalsIgnoreCase(c.getStatus()) || "rented".equalsIgnoreCase(c.getStatus()))
                    .collect(Collectors.toList());
                    
            List<Map<String, Object>> rentingCarsList = rentingCars.stream().map(car -> {
                Map<String, Object> carInfo = new HashMap<>();
                carInfo.put("id", car.getId());
                carInfo.put("model", car.getModel());
                carInfo.put("licensePlate", car.getLicensePlate());
                carInfo.put("brand", car.getBrand());
                
                // Tìm booking đang active của xe này
                Optional<Booking> activeBooking = allBookings.stream()
                        .filter(b -> b.getCarId().equals(car.getId()))
                        .filter(b -> "renting".equals(b.getStatus()))
                        .findFirst();
                
                if (activeBooking.isPresent()) {
                    Booking booking = activeBooking.get();
                    carInfo.put("customerId", booking.getCustomerId());
                    carInfo.put("startDate", booking.getStartTime());
                    carInfo.put("endDate", booking.getEndTime());
                    carInfo.put("bookingId", booking.getBookingId());
                }
                
                return carInfo;
            }).collect(Collectors.toList());
            stats.put("rentingCars", rentingCarsList);

            // 10. Thống kê theo loại xe
            Map<String, Long> carTypeStats = new HashMap<>();
            carTypeStats.put("sedan", allCars.stream().filter(c -> "Sedan".equalsIgnoreCase(c.getCarType())).count());
            carTypeStats.put("suv", allCars.stream().filter(c -> "SUV".equalsIgnoreCase(c.getCarType())).count());
            carTypeStats.put("hatchback", allCars.stream().filter(c -> "Hatchback".equalsIgnoreCase(c.getCarType())).count());
            carTypeStats.put("electric", allCars.stream().filter(c -> "Electric".equalsIgnoreCase(c.getCarType())).count());
            stats.put("carTypeStats", carTypeStats);

            // 11. Doanh thu 6 tháng gần nhất (cho biểu đồ)
            Map<String, Long> revenueChart = new LinkedHashMap<>();
            for (int i = 5; i >= 0; i--) {
                LocalDateTime monthStart = LocalDateTime.now().minusMonths(i).withDayOfMonth(1).withHour(0).withMinute(0).withSecond(0);
                LocalDateTime monthEnd = monthStart.plusMonths(1);
                
                long monthlyRevenue = completedBookings.stream()
                        .filter(b -> b.getCreatedAt() != null 
                                && b.getCreatedAt().isAfter(monthStart) 
                                && b.getCreatedAt().isBefore(monthEnd))
                        .filter(b -> b.getTotalAmount() != null)
                        .mapToLong(b -> b.getTotalAmount().longValue())
                        .sum();
                
                String monthLabel = "Tháng " + monthStart.getMonthValue();
                revenueChart.put(monthLabel, monthlyRevenue);
            }
            stats.put("revenueChart", revenueChart);

            // 12. Đơn thuê gần đây (3 đơn mới nhất)
            List<Booking> recentBookings = allBookings.stream()
                    .sorted((b1, b2) -> b2.getCreatedAt().compareTo(b1.getCreatedAt()))
                    .limit(3)
                    .collect(Collectors.toList());
            
            List<Map<String, Object>> recentBookingsList = recentBookings.stream().map(booking -> {
                Map<String, Object> bookingInfo = new HashMap<>();
                bookingInfo.put("bookingId", booking.getBookingId());
                bookingInfo.put("customerId", booking.getCustomerId());
                
                // Lấy thông tin khách hàng
                try {
                    Optional<com.carrentleproject.drivenow.model.Customer> customer = 
                        customerDAO.findById(booking.getCustomerId().intValue());
                    if (customer.isPresent()) {
                        bookingInfo.put("customerName", customer.get().getFullName());
                    } else {
                        bookingInfo.put("customerName", "N/A");
                    }
                } catch (Exception e) {
                    bookingInfo.put("customerName", "N/A");
                }
                
                // Lấy thông tin xe
                Optional<Car> carOpt = allCars.stream().filter(c -> c.getId().equals(booking.getCarId())).findFirst();
                if (carOpt.isPresent()) {
                    Car car = carOpt.get();
                    bookingInfo.put("carModel", car.getModel());
                    bookingInfo.put("carBrand", car.getBrand());
                    bookingInfo.put("licensePlate", car.getLicensePlate());
                    bookingInfo.put("vehicleName", car.getBrand() + " " + car.getModel());
                } else {
                    bookingInfo.put("vehicleName", "N/A");
                }
                
                bookingInfo.put("startDate", booking.getStartTime());
                bookingInfo.put("endDate", booking.getEndTime());
                bookingInfo.put("totalAmount", booking.getTotalAmount());
                bookingInfo.put("status", booking.getStatus());
                bookingInfo.put("createdAt", booking.getCreatedAt());
                
                return bookingInfo;
            }).collect(Collectors.toList());
            stats.put("recentBookings", recentBookingsList);

            return ResponseEntity.ok(stats);
            
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Lỗi khi lấy thống kê: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.status(500).body(errorResponse);
        }
    }

    /**
     * GET /api/dashboard/revenue - Thống kê doanh thu chi tiết
     */
    @GetMapping("/revenue")
    public ResponseEntity<?> getRevenueStats(
            @RequestParam(required = false) String period // "day", "week", "month", "year"
    ) {
        try {
            List<Booking> completedBookings = bookingRepository.findByStatus("completed");
            LocalDateTime now = LocalDateTime.now();
            LocalDateTime startDate;

            if ("day".equals(period)) {
                startDate = now.truncatedTo(ChronoUnit.DAYS);
            } else if ("week".equals(period)) {
                startDate = now.minusWeeks(1);
            } else if ("year".equals(period)) {
                startDate = now.minusYears(1);
            } else { // default month
                startDate = now.withDayOfMonth(1).withHour(0).withMinute(0).withSecond(0);
            }

            long revenue = completedBookings.stream()
                    .filter(b -> b.getCreatedAt() != null && b.getCreatedAt().isAfter(startDate))
                    .filter(b -> b.getTotalAmount() != null)
                    .mapToLong(b -> b.getTotalAmount().longValue())
                    .sum();

            Map<String, Object> response = new HashMap<>();
            response.put("period", period != null ? period : "month");
            response.put("revenue", revenue);
            response.put("startDate", startDate);
            response.put("endDate", now);

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.status(500).body(Map.of("error", e.getMessage()));
        }
    }
}
