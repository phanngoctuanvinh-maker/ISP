package com.carrentleproject.drivenow.controller;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.carrentleproject.drivenow.dto.PromotionRequest;
import com.carrentleproject.drivenow.model.Promotion;
import com.carrentleproject.drivenow.service.PromotionService;

/**
 * Admin Coupons Controller - Alias for Promotions
 * Endpoint: /api/coupons
 */
@RestController
@RequestMapping("/api/coupons")
@CrossOrigin(origins = "*")
public class AdminCouponsController {

    @Autowired
    private PromotionService promotionService;

    /**
     * Get all coupons (promotions)
     * GET /api/coupons
     */
    @GetMapping
    public ResponseEntity<?> getAllCoupons(@RequestParam(required = false) String status) {
        try {
            List<Promotion> promotions = promotionService.getAllPromotions();
            
            // Filter by status if provided
            if (status != null && !status.isEmpty()) {
                promotions = promotions.stream()
                        .filter(p -> status.equalsIgnoreCase(p.getStatus()))
                        .toList();
            }
            
            return ResponseEntity.ok(promotions);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }

    /**
     * Get coupon by ID
     * GET /api/coupons/{id}
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getCouponById(@PathVariable Long id) {
        try {
            Promotion promotion = promotionService.getPromotionById(id);
            if (promotion != null) {
                return ResponseEntity.ok(promotion);
            } else {
                Map<String, Object> errorResponse = new HashMap<>();
                errorResponse.put("success", false);
                errorResponse.put("message", "Không tìm thấy mã giảm giá");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
            }
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }

    /**
     * Create new coupon
     * POST /api/coupons
     */
    @PostMapping
    public ResponseEntity<?> createCoupon(@RequestBody Map<String, Object> requestData) {
        try {
            // Convert request data to PromotionRequest with proper date handling
            PromotionRequest request = convertToPromotionRequest(requestData);
            Promotion promotion = promotionService.createPromotion(request);
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Tạo mã giảm giá thành công");
            response.put("data", promotion);
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Lỗi: " + e.getMessage());
            e.printStackTrace(); // For debugging
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
        }
    }

    /**
     * Update coupon
     * PUT /api/coupons/{id}
     */
    @PutMapping("/{id}")
    public ResponseEntity<?> updateCoupon(@PathVariable Long id, @RequestBody Map<String, Object> requestData) {
        try {
            PromotionRequest request = convertToPromotionRequest(requestData);
            Promotion promotion = promotionService.updatePromotion(id, request);
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Cập nhật mã giảm giá thành công");
            response.put("data", promotion);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Lỗi: " + e.getMessage());
            e.printStackTrace(); // For debugging
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
        }
    }

    /**
     * Delete coupon
     * DELETE /api/coupons/{id}
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteCoupon(@PathVariable Long id) {
        try {
            promotionService.deletePromotion(id);
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Xóa mã giảm giá thành công");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
        }
    }

    /**
     * Validate coupon for an order
     * POST /api/coupons/validate
     */
    @PostMapping("/validate")
    public ResponseEntity<?> validateCoupon(@RequestBody Map<String, Object> request) {
        try {
            Long promotionId = ((Number) request.get("promotionId")).longValue();
            Long orderAmount = ((Number) request.get("orderAmount")).longValue();
            
            Promotion promotion = promotionService.getPromotionById(promotionId);
            if (promotion == null) {
                Map<String, Object> errorResponse = new HashMap<>();
                errorResponse.put("success", false);
                errorResponse.put("message", "Không tìm thấy mã giảm giá");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
            }
            
            Long discount = promotionService.calculateDiscount(promotion, orderAmount);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("isValid", discount > 0);
            response.put("discount", discount);
            response.put("finalAmount", orderAmount - discount);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
        }
    }

    /**
     * Helper method to convert Map to PromotionRequest with proper date parsing
     */
    private PromotionRequest convertToPromotionRequest(Map<String, Object> data) {
        PromotionRequest request = new PromotionRequest();
        
        request.setName((String) data.get("name"));
        request.setDescription((String) data.get("description"));
        request.setDiscountType((String) data.get("discountType"));
        
        // Handle discountValue
        Object discountValueObj = data.get("discountValue");
        if (discountValueObj instanceof Number) {
            request.setDiscountValue(new BigDecimal(discountValueObj.toString()));
        } else if (discountValueObj instanceof String) {
            request.setDiscountValue(new BigDecimal((String) discountValueObj));
        }
        
        // Handle minOrderValue
        Object minOrderValueObj = data.get("minOrderValue");
        if (minOrderValueObj instanceof Number) {
            request.setMinOrderValue(((Number) minOrderValueObj).longValue());
        } else if (minOrderValueObj instanceof String) {
            request.setMinOrderValue(Long.parseLong((String) minOrderValueObj));
        }
        
        // Handle maxDiscountAmount
        Object maxDiscountObj = data.get("maxDiscountAmount");
        if (maxDiscountObj instanceof Number) {
            request.setMaxDiscountAmount(((Number) maxDiscountObj).longValue());
        } else if (maxDiscountObj instanceof String) {
            request.setMaxDiscountAmount(Long.parseLong((String) maxDiscountObj));
        }
        
        // Handle dates - Parse from "yyyy-MM-dd" format
        String startDateStr = (String) data.get("startDate");
        if (startDateStr != null) {
            LocalDate startDate = LocalDate.parse(startDateStr, DateTimeFormatter.ISO_DATE);
            request.setStartDate(startDate.atStartOfDay()); // 00:00:00
        }
        
        String endDateStr = (String) data.get("endDate");
        if (endDateStr != null) {
            LocalDate endDate = LocalDate.parse(endDateStr, DateTimeFormatter.ISO_DATE);
            request.setEndDate(endDate.atTime(23, 59, 59)); // 23:59:59
        }
        
        // Handle usageLimit
        Object usageLimitObj = data.get("usageLimit");
        if (usageLimitObj instanceof Number) {
            request.setUsageLimit(((Number) usageLimitObj).intValue());
        } else if (usageLimitObj instanceof String) {
            request.setUsageLimit(Integer.parseInt((String) usageLimitObj));
        }
        
        request.setStatus((String) data.get("status"));
        
        // Handle createdBy
        Object createdByObj = data.get("createdBy");
        if (createdByObj instanceof Number) {
            request.setCreatedBy(((Number) createdByObj).longValue());
        }
        
        return request;
    }
}
