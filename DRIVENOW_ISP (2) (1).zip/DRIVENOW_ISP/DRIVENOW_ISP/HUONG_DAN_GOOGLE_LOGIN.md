# 🔐 HƯỚNG DẪN CẤU HÌNH GOOGLE SIGN-IN

## 📋 Tổng quan

Chức năng **Đăng nhập bằng Google** đã được implement đầy đủ. Bạn cần cấu hình Google OAuth Client ID để kích hoạt.

---

## ✅ BƯỚC 1: Tạo Google OAuth Client ID

### 1.1. Truy cập Google Cloud Console

Vào: https://console.cloud.google.com/

### 1.2. Tạo Project mới (nếu chưa có)

1. Click **Select a project** → **New Project**
2. Nhập tên project: `DriveNow` → **Create**

### 1.3. Bật Google+ API

1. Vào **APIs & Services** → **Library**
2. Tìm **"Google+ API"** hoặc **"Google Identity Services"**
3. Click **Enable**

### 1.4. Tạo OAuth 2.0 Client ID

1. Vào **APIs & Services** → **Credentials**
2. Click **+ CREATE CREDENTIALS** → **OAuth client ID**
3. Nếu lần đầu, click **CONFIGURE CONSENT SCREEN**:
   - Chọn **External** → **Create**
   - App name: `DriveNow`
   - User support email: `quyenthedinh@gmail.com`
   - Developer contact: `quyenthedinh@gmail.com`
   - Click **SAVE AND CONTINUE** (bỏ qua các bước khác)

4. Quay lại **Credentials** → **+ CREATE CREDENTIALS** → **OAuth client ID**
5. Application type: **Web application**
6. Name: `DriveNow Web Client`
7. **Authorized JavaScript origins:**
   - `http://127.0.0.1:5500`
   - `http://localhost:5500`
   - `http://127.0.0.1:8080` (nếu chạy từ backend)
8. Click **CREATE**
9. **COPY Client ID** (dạng: `123456789-abcdefg.apps.googleusercontent.com`)

---

## ✅ BƯỚC 2: Cấu hình Backend

### 2.1. Cập nhật `application.properties`

Mở: `drivenow/src/main/resources/application.properties`

Tìm và sửa dòng:

```properties
google.client.id=YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com
```

**Thay bằng Client ID vừa copy:**

```properties
google.client.id=123456789-abcdefghijklmnop.apps.googleusercontent.com
```

### 2.2. Lưu file và khởi động lại backend

```powershell
cd drivenow
.\start-backend.bat
```

---

## ✅ BƯỚC 3: Cấu hình Frontend

### 3.1. Cập nhật `login.html`

Mở: `Project1/html/login.html`

Tìm dòng (khoảng dòng 42):

```html
data-client_id="YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com"
```

**Thay bằng Client ID giống như backend:**

```html
data-client_id="123456789-abcdefghijklmnop.apps.googleusercontent.com"
```

### 3.2. Lưu file

Ctrl+S

---

## 🧪 TEST NGAY

### Bước 1: Mở trang login

```
http://127.0.0.1:5500/Project1/html/login.html
```

### Bước 2: Click nút "Sign in with Google"

- Nút Google màu xanh/trắng sẽ hiện dưới form login
- Click vào nút

### Bước 3: Chọn tài khoản Google

- Popup Google Sign-In sẽ hiện
- Chọn tài khoản Google của bạn

### Bước 4: Xác nhận quyền

- Google sẽ hỏi quyền truy cập email và profile
- Click **Allow** hoặc **Cho phép**

### Bước 5: Tự động đăng nhập

- Trang sẽ tự động:
  - Gửi Google Token về backend
  - Backend verify token
  - Tạo/Tìm account
  - Generate JWT
  - Chuyển về homepage

---

## 🎯 Cách hoạt động

### Flow đăng nhập Google:

1. **User click "Sign in with Google"** (Frontend)
2. **Google Popup hiện** → User chọn account
3. **Google trả về ID Token** (JWT chứa email, name, picture)
4. **Frontend gọi `/auth/google-login`** với ID Token
5. **Backend verify token** với Google API
6. **Backend kiểm tra email**:
   - Nếu **chưa tồn tại** → Tạo account mới + customer profile (auto-register)
   - Nếu **đã tồn tại** → Sử dụng account cũ
7. **Backend generate JWT** và trả về
8. **Frontend lưu token** → Chuyển về homepage

### Auto-register:

Khi user đăng nhập Google lần đầu:
- Email từ Google → `username` trong DB
- Full name → `full_name` trong Customer
- Password → Random UUID (user không cần biết vì login qua Google)
- Role → `customer`
- Status → `active`

---

## ⚠️ Lưu ý quan trọng

### 1. Client ID phải giống nhau

```properties
# Backend (application.properties)
google.client.id=123456789-abc.apps.googleusercontent.com

# Frontend (login.html)
data-client_id="123456789-abc.apps.googleusercontent.com"
```

### 2. Authorized Origins

Trong Google Cloud Console, phải thêm:
- `http://127.0.0.1:5500` (Live Server)
- `http://localhost:5500`

Nếu không, sẽ bị lỗi: **"Not a valid origin for the client"**

### 3. Backend phải chạy

Backend phải chạy trên `http://localhost:8080` để nhận request `/auth/google-login`

---

## 🔧 Xử lý lỗi thường gặp

### Lỗi: "Invalid client ID"

✅ Kiểm tra Client ID trong `login.html` và `application.properties` có giống nhau không

### Lỗi: "Not a valid origin"

✅ Vào Google Cloud Console → Credentials → Edit OAuth Client → Thêm `http://127.0.0.1:5500` vào Authorized JavaScript origins

### Lỗi: "Không thể xác thực Google Token"

✅ Kiểm tra Client ID trong `application.properties` có đúng không
✅ Kiểm tra backend có chạy không

### Lỗi: "Google login chưa được implement"

✅ Khởi động lại backend sau khi sửa code

---

## ✅ Checklist hoàn thành

- [ ] Đã tạo Google OAuth Client ID
- [ ] Đã cấu hình `google.client.id` trong `application.properties`
- [ ] Đã cập nhật Client ID trong `login.html`
- [ ] Đã thêm Authorized Origins (`http://127.0.0.1:5500`)
- [ ] Đã khởi động lại backend
- [ ] Đã test click "Sign in with Google" thành công
- [ ] Đã đăng nhập và chuyển về homepage

---

## 📸 Giao diện mới

Trang login giờ có:
- ✨ Form đăng nhập thông thường (email/password)
- ➕ Dòng "Hoặc" (divider)
- 🔵 Nút **"Sign in with Google"** (Google branding)
- 🔗 Link "Quên mật khẩu?"
- 🔗 Link "Đăng ký ngay"

---

**🎉 Sau khi cấu hình xong, user có thể đăng nhập bằng 2 cách:**
1. Email/Password (đăng ký thủ công)
2. Tài khoản Google (đăng nhập nhanh, auto-register)
