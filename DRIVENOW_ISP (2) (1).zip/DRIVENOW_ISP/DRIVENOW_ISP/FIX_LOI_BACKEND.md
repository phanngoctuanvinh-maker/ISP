# 🔧 FIX LỖI "UNABLE TO CONNECT TO REMOTE SERVER"

## ❌ LỖI GÌ?

Lỗi này xuất hiện khi:
```
Invoke-RestMethod : Unable to connect to the remote server
```

**Nguyên nhân:** Backend chưa chạy hoặc đã bị tắt!

---

## ✅ GIẢI PHÁP

### 🎯 Cách 1: Dùng Cửa sổ CMD mới (ĐƠN GIẢN NHẤT)

1. **Nhìn vào thanh taskbar** - Bạn sẽ thấy một cửa sổ **CMD đen** vừa mở
2. **Xem trong cửa sổ CMD** đó - sẽ thấy backend đang chạy
3. **Chờ** cho đến khi thấy dòng:
   ```
   Started DrivenowApplication in X.XXX seconds
   ```
4. **Không đóng** cửa sổ CMD đó!

### 🎯 Cách 2: Dùng file start-backend.bat

1. Mở **File Explorer**
2. Đi tới: `C:\Users\quyen\Downloads\DRIVENOW_ISP\Project1`
3. **Double-click** vào file: `start-backend.bat`
4. Chờ backend khởi động

### 🎯 Cách 3: Dùng PowerShell thủ công

Mở PowerShell và chạy từng lệnh:

```powershell
# Bước 1: Vào thư mục Project
cd C:\Users\quyen\Downloads\DRIVENOW_ISP\Project1

# Bước 2: Chạy backend
.\mvnw.cmd spring-boot:run
```

**Lưu ý:** KHÔNG đóng cửa sổ PowerShell khi backend đang chạy!

---

## 🕐 BACKEND MẤT BAO LÂU ĐỂ KHỞI ĐỘNG?

**Thời gian:** 15-30 giây

**Các bước backend thực hiện:**
1. ⏳ Compile code (5-10s)
2. ⏳ Connect database (2-5s)
3. ⏳ Load Spring beans (5-10s)
4. ⏳ Start Tomcat server (2-5s)
5. ✅ **DONE!** → Thấy "Started DrivenowApplication"

---

## 🧪 KIỂM TRA BACKEND ĐÃ CHẠY CHƯA

### Cách 1: Dùng trình duyệt

Mở trình duyệt và vào:
```
http://localhost:8080/api/promotions/test
```

**Nếu thấy JSON response** → Backend đang chạy! ✅

Ví dụ response:
```json
{
  "status": "success",
  "message": "Promotion API is working!",
  "timestamp": "2025-10-15T08:45:00"
}
```

### Cách 2: Dùng PowerShell

```powershell
Invoke-RestMethod -Uri "http://localhost:8080/api/promotions/test"
```

**Nếu thấy kết quả** → Backend OK! ✅

### Cách 3: Kiểm tra port 8080

```powershell
netstat -ano | findstr :8080
```

**Nếu có kết quả** → Port 8080 đang được dùng = Backend đang chạy! ✅

---

## ❌ NẾU VẪN LỖI

### Lỗi 1: Port 8080 đã được sử dụng

**Triệu chứng:**
```
Port 8080 was already in use
```

**Giải pháp:**
```powershell
# Tìm process đang dùng port 8080
netstat -ano | findstr :8080

# Ví dụ output:
# TCP    0.0.0.0:8080    0.0.0.0:0    LISTENING    12345

# Kill process (thay 12345 bằng PID thực tế)
taskkill /PID 12345 /F

# Chạy lại backend
cd C:\Users\quyen\Downloads\DRIVENOW_ISP\Project1
.\mvnw.cmd spring-boot:run
```

### Lỗi 2: Database không kết nối được

**Triệu chứng:**
```
Cannot connect to SQL Server
```

**Giải pháp:**
1. Mở **SQL Server Management Studio**
2. Kiểm tra SQL Server đang chạy
3. Kiểm tra database `drivenow_db` đã tạo chưa:
   ```sql
   CREATE DATABASE drivenow_db;
   ```
4. Kiểm tra username/password trong `application.properties`

### Lỗi 3: Java không tìm thấy

**Triệu chứng:**
```
'java' is not recognized
```

**Giải pháp:**
1. Kiểm tra Java đã cài chưa:
   ```powershell
   java -version
   ```
2. Nếu chưa có → Cài Java JDK 17 hoặc 21
3. Set JAVA_HOME environment variable

---

## 📝 LOGS BACKEND

Khi backend chạy, bạn sẽ thấy nhiều logs. Đây là các logs **QUAN TRỌNG**:

### ✅ Logs TỐT (Bình thường):

```
INFO  --- Tomcat initialized with port 8080
INFO  --- Starting service [Tomcat]
INFO  --- Hibernate is in classpath
INFO  --- HikariPool-1 - Starting...
INFO  --- HikariPool-1 - Start completed
INFO  --- Tomcat started on port 8080 (http)
INFO  --- Started DrivenowApplication in 6.XXX seconds ← QUAN TRỌNG!
```

### ⚠️ Logs WARNING (Có thể bỏ qua):

```
WARN  --- spring.jpa.open-in-view is enabled by default
WARN  --- Global AuthenticationManager configured...
```

→ Những warning này KHÔNG ảnh hưởng!

### ❌ Logs LỖI (Cần fix):

```
ERROR --- Application run failed
ERROR --- Cannot create connection to database
ERROR --- Port 8080 was already in use
```

→ Cần xử lý theo hướng dẫn phía trên!

---

## 🎯 SAU KHI BACKEND CHẠY THÀNH CÔNG

### Bước 1: Test API

Mở file test đã mở trước đó:
```
C:\Users\quyen\Downloads\DRIVENOW_ISP\DriveNow\html\test-module3.html
```

Hoặc mở lại:
```powershell
Start-Process "C:\Users\quyen\Downloads\DRIVENOW_ISP\DriveNow\html\test-module3.html"
```

### Bước 2: Nhấn nút Test

1. Nhấn **"Test Promotion API"**
2. Xem response → Nếu `status: success` = OK! ✅

### Bước 3: Test các chức năng

- ✅ Tạo Promotion
- ✅ Tạo Promo Code
- ✅ Validate Code
- ✅ Apply Code
- ✅ Tạo VNPay Payment

---

## 📞 TÓM TẮT

| Vấn đề | Giải pháp |
|--------|-----------|
| Backend chưa chạy | Chạy `start-backend.bat` |
| Port 8080 bị chiếm | Kill process: `taskkill /PID xxx /F` |
| Database lỗi | Check SQL Server đang chạy |
| Test API lỗi | Đảm bảo backend đã chạy xong |

---

## 🚀 CHECKLIST

Trước khi test API, hãy check:

- [ ] SQL Server đang chạy
- [ ] Database `drivenow_db` đã tạo
- [ ] Cửa sổ CMD/PowerShell chạy backend đang mở
- [ ] Thấy dòng "Started DrivenowApplication"
- [ ] Không có lỗi ERROR màu đỏ
- [ ] Test URL http://localhost:8080/api/promotions/test → có response

Nếu tất cả đều ✅ → Backend đang chạy hoàn hảo! 🎉

---

**Ghi chú:** Backend cần chạy **LIÊN TỤC** khi bạn test. Không được tắt cửa sổ chạy backend!
