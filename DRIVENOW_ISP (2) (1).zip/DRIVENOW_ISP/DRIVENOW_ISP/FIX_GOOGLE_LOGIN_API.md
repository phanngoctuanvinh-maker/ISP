# Hướng Dẫn Sửa Lỗi "api is not defined" - Google Login

## Vấn đề đã được fix:

### 1. ✅ Đã tạo file `api.js`
- File: `DriveNow/js/api.js`
- Chứa tất cả các hàm API cần thiết: login, googleLogin, register, forgotPassword, etc.

### 2. ✅ Cải thiện error handling trong `login.js`
- Thêm kiểm tra `api` object trước khi sử dụng
- Thêm logging chi tiết để debug
- Hiển thị thông báo lỗi rõ ràng hơn

### 3. ✅ Tạo file test
- File: `DriveNow/test-google-login.html`
- Để kiểm tra Google Login riêng biệt

## Cách Kiểm Tra:

### Bước 1: Khởi động Backend
```bash
cd Project1
.\start-backend.bat
```

Đảm bảo backend chạy trên: http://localhost:8080

### Bước 2: Mở file test
1. Mở file: `DriveNow/test-google-login.html` trong browser
2. Kiểm tra status có hiển thị "✅ API object loaded successfully!" không
3. Nếu có, click nút "Sign in with Google"

### Bước 3: Test đăng nhập chính thức
1. Mở file: `DriveNow/html/login.html` 
2. Click nút "Sign in with Google"
3. Kiểm tra Console (F12) xem có lỗi gì không

### Bước 4: Nếu vẫn lỗi
1. Mở Developer Tools (F12)
2. Vào tab Console
3. Kiểm tra các thông báo lỗi:
   - "API object is not defined!" → File api.js chưa load
   - "api.googleLogin is not a function!" → Hàm googleLogin bị lỗi
   - Lỗi network → Backend chưa chạy hoặc CORS

## Checklist:

- [ ] Backend đang chạy (http://localhost:8080)
- [ ] Database đã setup
- [ ] File `api.js` tồn tại trong `DriveNow/js/`
- [ ] Mở Developer Console để xem lỗi chi tiết
- [ ] Google Client ID đúng trong login.html

## Các lỗi phổ biến:

### Lỗi 1: "api is not defined"
**Nguyên nhân:** File `api.js` chưa được load
**Giải pháp:** Đã tạo file `api.js` với tất cả hàm cần thiết

### Lỗi 2: "Failed to fetch" hoặc CORS error
**Nguyên nhân:** Backend chưa chạy hoặc CORS chưa config
**Giải pháp:** 
```bash
cd Project1
.\start-backend.bat
```

### Lỗi 3: "Invalid token" từ backend
**Nguyên nhân:** Google Token không hợp lệ hoặc Google Client ID sai
**Giải pháp:** Kiểm tra Client ID trong `login.html` và `application.properties`

## API Endpoint Backend:

- POST `/api/auth/google-login`
- Request body: `{ "idToken": "google_id_token_here" }`
- Response: `{ "token": "jwt_token", "user": {...} }`

## Cấu trúc File:

```
DriveNow/
  js/
    api.js          ← MỚI TẠO - Chứa tất cả API functions
    login.js        ← ĐÃ CẬP NHẬT - Thêm error checking
  html/
    login.html      ← Đã có Google Sign-In button
  test-google-login.html  ← MỚI TẠO - Test độc lập
```

## Test Manual:

### 1. Test file api.js đã load:
Mở Console (F12) và gõ:
```javascript
console.log(api);
// Phải hiển thị object với các hàm: login, googleLogin, register, etc.
```

### 2. Test Google Login manually:
```javascript
// Lấy một Google ID Token test (từ Google Sign-In)
const testToken = "eyJhbGc..."; // Google ID Token

// Test API call
api.googleLogin(testToken)
  .then(response => console.log('Success:', response))
  .catch(error => console.error('Error:', error));
```

## Liên Hệ Debug:

Nếu vẫn còn lỗi, cung cấp thông tin sau:
1. Screenshot Console (F12)
2. Screenshot Network tab (F12)
3. Backend logs
4. Trình duyệt đang dùng (Chrome, Firefox, Edge?)

---

**Tóm tắt:** Lỗi "api is not defined" đã được fix bằng cách tạo file `api.js` chứa tất cả các hàm API cần thiết. Giờ bạn có thể test lại Google Login!
