@echo off
echo ========================================
echo DRIVENOW - MODULE 3 QUICK TEST
echo ========================================
echo.

echo [1/3] Kiem tra Backend dang chay...
curl -s http://localhost:8080/api/promotions/test >nul 2>&1
if %errorlevel% equ 0 (
    echo ✓ Backend dang chay!
    echo.
    goto :test
) else (
    echo ✗ Backend chua chay!
    echo.
    echo Vui long chay backend truoc:
    echo    cd Project1
    echo    .\start-backend.bat
    echo.
    pause
    exit /b 1
)

:test
echo [2/3] Test Promotion API...
curl -s -X GET "http://localhost:8080/api/promotions/test"
echo.
echo.

echo [3/3] Test Payment API...
echo Tao test payment...
curl -s -X POST "http://localhost:8080/api/payment/create" ^
  -H "Content-Type: application/json" ^
  -d "{\"userId\":1,\"amount\":100000,\"orderInfo\":\"Test payment\"}"
echo.
echo.

echo ========================================
echo Test hoan thanh!
echo.
echo Mo trinh duyet de test day du:
echo    DriveNow\html\test-module3.html
echo.
echo Xem huong dan:
echo    HUONG_DAN_TEST_MODULE3.md
echo ========================================
pause
