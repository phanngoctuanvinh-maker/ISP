# 🧪 TEST CASES - SEARCH CAR API
**Updated:** October 21, 2025  
**Base URL:** `http://localhost:8080/api/cars`  
**Database Structure:** `car_type` (String) + `seat_capacity` (Integer)

---

## ✅ TEST CASE 1: Get All Cars
**Endpoint:** `GET /api/cars/all`  
**Purpose:** Lấy tất cả xe trong database  

### Request:
```
GET http://localhost:8080/api/cars/all
```

### Expected Response:
```json
{
    "success": true,
    "message": "Cars retrieved successfully",
    "cars": [
        {
            "id": 1,
            "brand": "Toyota",
            "model": "Vios",
            "name": "Toyota Vios 2024",
            "year": 2024,
            "color": "Trắng",
            "carType": "Sedan",
            "seatCapacity": 4,
            "fuelType": "Gasoline",
            "transmissionType": "Automatic",
            "pricePerDay": 500000,
            "status": "Available"
        }
        // ... 29 more cars
    ],
    "totalCars": 30
}
```

### ✅ Pass Criteria:
- ✅ Status code: **200 OK**
- ✅ `success: true`
- ✅ `totalCars: 30`
- ✅ Mỗi car object có đủ fields: `carType`, `seatCapacity`

---

## ✅ TEST CASE 2: Get Cars by Seat Capacity - 4 chỗ
**Endpoint:** `GET /api/cars/by-type?seatCapacity=4`  
**Purpose:** Lấy xe 4 chỗ (Mini, Sedan, Pickup)

### Request:
```
GET http://localhost:8080/api/cars/by-type?seatCapacity=4
```

### Expected Response:
```json
{
    "success": true,
    "message": "Cars with 4 seats retrieved successfully",
    "cars": [
        {
            "id": 1,
            "name": "Toyota Vios 2024",
            "carType": "Sedan",
            "seatCapacity": 4
        },
        {
            "id": 2,
            "name": "Mazda 2 2024",
            "carType": "Mini",
            "seatCapacity": 4
        }
        // ... more 4-seater cars
    ],
    "totalCars": 8
}
```

### ✅ Pass Criteria:
- ✅ Status code: **200 OK**
- ✅ Tất cả xe đều có `seatCapacity: 4`
- ✅ Expected count: **~8 cars** (1 Mini + 6 Sedan + 1 Pickup)
- ✅ Bao gồm: Mazda 2, Toyota Vios, Honda City, Ford Ranger

---

## ✅ TEST CASE 3: Get Cars by Seat Capacity - 5 chỗ
**Endpoint:** `GET /api/cars/by-type?seatCapacity=5`  
**Purpose:** Lấy xe 5 chỗ (SUV/CUV)

### Request:
```
GET http://localhost:8080/api/cars/by-type?seatCapacity=5
```

### Expected Response:
```json
{
    "success": true,
    "message": "Cars with 5 seats retrieved successfully",
    "cars": [
        {
            "id": 8,
            "name": "Toyota Corolla Cross 2024",
            "carType": "SUV",
            "seatCapacity": 5
        },
        {
            "id": 21,
            "name": "Vinfast VF5 2024",
            "carType": "SUV",
            "seatCapacity": 5,
            "fuelType": "Electric"
        }
        // ... more 5-seater SUVs
    ],
    "totalCars": 9
}
```

### ✅ Pass Criteria:
- ✅ Status code: **200 OK**
- ✅ Tất cả xe đều có `seatCapacity: 5`
- ✅ Expected count: **~9 cars**
- ✅ Bao gồm: Toyota Corolla Cross, Honda CR-V, Mazda CX-5, Vinfast VF5, VF8

---

## ✅ TEST CASE 4: Get Cars by Seat Capacity - 7 chỗ
**Endpoint:** `GET /api/cars/by-type?seatCapacity=7`  
**Purpose:** Lấy xe 7 chỗ (SUV, MPV, Minivan)

### Request:
```
GET http://localhost:8080/api/cars/by-type?seatCapacity=7
```

### Expected Response:
```json
{
    "success": true,
    "message": "Cars with 7 seats retrieved successfully",
    "cars": [
        {
            "id": 18,
            "name": "Toyota Fortuner 2024",
            "carType": "SUV",
            "seatCapacity": 7
        },
        {
            "id": 26,
            "name": "Kia Carnival 2024",
            "carType": "Minivan",
            "seatCapacity": 7
        },
        {
            "id": 23,
            "name": "Vinfast VF9 2024",
            "carType": "SUV",
            "seatCapacity": 7,
            "fuelType": "Electric"
        }
        // ... more 7-seater cars
    ],
    "totalCars": 13
}
```

### ✅ Pass Criteria:
- ✅ Status code: **200 OK**
- ✅ Tất cả xe đều có `seatCapacity: 7`
- ✅ Expected count: **~13 cars** (10 SUV + 3 MPV + 1 Minivan)
- ✅ Bao gồm: Fortuner, Everest, Santa Fe, VF9, Carnival

---

## ✅ TEST CASE 5: Get Cars by Brand - Toyota
**Endpoint:** `GET /api/cars/by-brand?brand=Toyota`  
**Purpose:** Lấy tất cả xe Toyota

### Request:
```
GET http://localhost:8080/api/cars/by-brand?brand=Toyota
```

### Expected Response:
```json
{
    "success": true,
    "message": "Toyota cars retrieved successfully",
    "cars": [
        {
            "id": 1,
            "brand": "Toyota",
            "model": "Vios",
            "name": "Toyota Vios 2024",
            "carType": "Sedan",
            "seatCapacity": 4
        },
        {
            "id": 8,
            "brand": "Toyota",
            "model": "Corolla Cross",
            "carType": "SUV",
            "seatCapacity": 5
        },
        {
            "id": 18,
            "brand": "Toyota",
            "model": "Fortuner",
            "carType": "SUV",
            "seatCapacity": 7
        },
        {
            "id": 25,
            "brand": "Toyota",
            "model": "Innova Cross",
            "carType": "MPV",
            "seatCapacity": 7
        }
    ],
    "totalCars": 4
}
```

### ✅ Pass Criteria:
- ✅ Status code: **200 OK**
- ✅ Expected count: **4 cars**
- ✅ Tất cả xe đều có `brand: "Toyota"`
- ✅ Models: Vios, Corolla Cross, Fortuner, Innova Cross

---

## ✅ TEST CASE 6: Get Cars by Brand - Vinfast
**Endpoint:** `GET /api/cars/by-brand?brand=Vinfast`  
**Purpose:** Lấy xe Vinfast (Electric)

### Request:
```
GET http://localhost:8080/api/cars/by-brand?brand=Vinfast
```

### Expected Response:
```json
{
    "success": true,
    "message": "Vinfast cars retrieved successfully",
    "cars": [
        {
            "id": 21,
            "brand": "Vinfast",
            "model": "VF5",
            "carType": "SUV",
            "seatCapacity": 5,
            "fuelType": "Electric"
        },
        {
            "id": 22,
            "brand": "Vinfast",
            "model": "VF8",
            "carType": "SUV",
            "seatCapacity": 5,
            "fuelType": "Electric"
        },
        {
            "id": 23,
            "brand": "Vinfast",
            "model": "VF9",
            "carType": "SUV",
            "seatCapacity": 7,
            "fuelType": "Electric"
        }
    ],
    "totalCars": 3
}
```

### ✅ Pass Criteria:
- ✅ Status code: **200 OK**
- ✅ Expected count: **3 cars**
- ✅ Tất cả đều có `fuelType: "Electric"`
- ✅ Models: VF5 (5 chỗ), VF8 (5 chỗ), VF9 (7 chỗ)

---

## ✅ TEST CASE 7: Get Electric Cars
**Endpoint:** `GET /api/cars/electric`  
**Purpose:** Lấy tất cả xe điện

### Request:
```
GET http://localhost:8080/api/cars/electric
```

### Expected Response:
```json
{
    "success": true,
    "message": "Electric cars retrieved successfully",
    "cars": [
        {
            "id": 21,
            "brand": "Vinfast",
            "model": "VF5",
            "fuelType": "Electric",
            "seatCapacity": 5
        },
        {
            "id": 22,
            "brand": "Vinfast",
            "model": "VF8",
            "fuelType": "Electric",
            "seatCapacity": 5
        },
        {
            "id": 23,
            "brand": "Vinfast",
            "model": "VF9",
            "fuelType": "Electric",
            "seatCapacity": 7
        }
    ],
    "totalCars": 3
}
```

### ✅ Pass Criteria:
- ✅ Status code: **200 OK**
- ✅ Expected count: **3 cars** (Vinfast VF5, VF8, VF9)
- ✅ Tất cả đều có `fuelType: "Electric"`

---

## ✅ TEST CASE 8: Get Hybrid Cars
**Endpoint:** `GET /api/cars/hybrid`  
**Purpose:** Lấy xe Hybrid (xăng + điện)

### Request:
```
GET http://localhost:8080/api/cars/hybrid
```

### Expected Response:
```json
{
    "success": true,
    "message": "Hybrid cars retrieved successfully",
    "cars": [
        {
            "id": 30,
            "brand": "Mitsubishi",
            "model": "Outlander PHEV",
            "name": "Mitsubishi Outlander PHEV 2024",
            "fuelType": "Hybrid",
            "seatCapacity": 7,
            "carType": "SUV"
        }
    ],
    "totalCars": 1
}
```

### ✅ Pass Criteria:
- ✅ Status code: **200 OK**
- ✅ Expected count: **1 car** (Mitsubishi Outlander PHEV)
- ✅ `fuelType: "Hybrid"`

---

## ✅ TEST CASE 9: Get Cars by Transmission - Automatic
**Endpoint:** `GET /api/cars/by-transmission?type=Automatic`  
**Purpose:** Lấy xe số tự động

### Request:
```
GET http://localhost:8080/api/cars/by-transmission?type=Automatic
```

### Expected Response:
```json
{
    "success": true,
    "message": "Automatic transmission cars retrieved successfully",
    "cars": [
        // Most cars have automatic transmission
    ],
    "totalCars": 20
}
```

### ✅ Pass Criteria:
- ✅ Status code: **200 OK**
- ✅ Expected count: **~20 cars**
- ✅ Tất cả đều có `transmissionType: "Automatic"`

---

## ✅ TEST CASE 10: Get Cars by Transmission - Manual
**Endpoint:** `GET /api/cars/by-transmission?type=Manual`  
**Purpose:** Lấy xe số sàn

### Request:
```
GET http://localhost:8080/api/cars/by-transmission?type=Manual
```

### Expected Response:
```json
{
    "success": true,
    "message": "Manual transmission cars retrieved successfully",
    "cars": [
        {
            "id": 2,
            "brand": "Mazda",
            "model": "2",
            "transmissionType": "Manual",
            "seatCapacity": 4
        }
        // ... other manual cars
    ],
    "totalCars": 10
}
```

### ✅ Pass Criteria:
- ✅ Status code: **200 OK**
- ✅ Expected count: **~10 cars**
- ✅ Tất cả đều có `transmissionType: "Manual"`

---

## ✅ TEST CASE 11: Advanced Search - POST (4 chỗ)
**Endpoint:** `POST /api/cars/search`  
**Purpose:** Tìm kiếm nâng cao với multiple filters

### Request:
```json
POST http://localhost:8080/api/cars/search
Content-Type: application/json

{
    "searchType": "type",
    "seatCapacity": 4
}
```

### Expected Response:
```json
{
    "success": true,
    "message": "Search completed successfully",
    "cars": [
        {
            "id": 1,
            "name": "Toyota Vios 2024",
            "carType": "Sedan",
            "seatCapacity": 4
        }
        // ... more 4-seater cars
    ],
    "totalCars": 8,
    "searchCriteria": {
        "searchType": "type",
        "seatCapacity": 4
    }
}
```

### ✅ Pass Criteria:
- ✅ Status code: **200 OK**
- ✅ Expected count: **~8 cars**
- ✅ Tất cả đều có `seatCapacity: 4`

---

## ✅ TEST CASE 12: Advanced Search - POST (5 chỗ SUV)
**Endpoint:** `POST /api/cars/search`  
**Purpose:** Tìm xe 5 chỗ SUV

### Request:
```json
POST http://localhost:8080/api/cars/search
Content-Type: application/json

{
    "searchType": "type",
    "seatCapacity": 5,
    "carType": "SUV"
}
```

### Expected Response:
```json
{
    "success": true,
    "cars": [
        {
            "id": 8,
            "name": "Toyota Corolla Cross 2024",
            "carType": "SUV",
            "seatCapacity": 5
        },
        {
            "id": 9,
            "name": "Honda CR-V 2024",
            "carType": "SUV",
            "seatCapacity": 5
        }
        // ... more 5-seater SUVs
    ],
    "totalCars": 9
}
```

### ✅ Pass Criteria:
- ✅ Status code: **200 OK**
- ✅ Tất cả đều có `seatCapacity: 5` và `carType: "SUV"`
- ✅ Expected count: **~9 cars**

---

## ✅ TEST CASE 13: Advanced Search - POST (7 chỗ)
**Endpoint:** `POST /api/cars/search`  
**Purpose:** Tìm xe 7 chỗ (SUV + MPV + Minivan)

### Request:
```json
POST http://localhost:8080/api/cars/search
Content-Type: application/json

{
    "searchType": "type",
    "seatCapacity": 7
}
```

### Expected Response:
```json
{
    "success": true,
    "cars": [
        {
            "id": 18,
            "name": "Toyota Fortuner 2024",
            "carType": "SUV",
            "seatCapacity": 7
        },
        {
            "id": 25,
            "name": "Toyota Innova Cross 2024",
            "carType": "MPV",
            "seatCapacity": 7
        }
        // ... more 7-seater cars
    ],
    "totalCars": 13
}
```

### ✅ Pass Criteria:
- ✅ Status code: **200 OK**
- ✅ Expected count: **~13 cars**
- ✅ Tất cả đều có `seatCapacity: 7`

---

## ✅ TEST CASE 14: Advanced Search - POST (Toyota 7 chỗ)
**Endpoint:** `POST /api/cars/search`  
**Purpose:** Tìm xe Toyota 7 chỗ

### Request:
```json
POST http://localhost:8080/api/cars/search
Content-Type: application/json

{
    "searchType": "brand",
    "brand": "Toyota",
    "seatCapacity": 7
}
```

### Expected Response:
```json
{
    "success": true,
    "cars": [
        {
            "id": 18,
            "brand": "Toyota",
            "model": "Fortuner",
            "name": "Toyota Fortuner 2024",
            "seatCapacity": 7,
            "carType": "SUV"
        },
        {
            "id": 25,
            "brand": "Toyota",
            "model": "Innova Cross",
            "name": "Toyota Innova Cross 2024",
            "seatCapacity": 7,
            "carType": "MPV"
        }
    ],
    "totalCars": 2
}
```

### ✅ Pass Criteria:
- ✅ Status code: **200 OK**
- ✅ Expected count: **2 cars** (Fortuner + Innova Cross)
- ✅ `brand: "Toyota"` và `seatCapacity: 7`

---

## ✅ TEST CASE 15: Get Car by ID
**Endpoint:** `GET /api/cars/1`  
**Purpose:** Lấy chi tiết 1 xe theo ID

### Request:
```
GET http://localhost:8080/api/cars/1
```

### Expected Response:
```json
{
    "success": true,
    "message": "Car details retrieved successfully",
    "car": {
        "id": 1,
        "brand": "Toyota",
        "model": "Vios",
        "name": "Toyota Vios 2024",
        "year": 2024,
        "color": "Trắng",
        "carType": "Sedan",
        "seatCapacity": 4,
        "fuelType": "Gasoline",
        "transmissionType": "Automatic",
        "pricePerDay": 500000,
        "imageUrl": "/assets/images/toyota-vios.jpg",
        "location": "Hà Nội",
        "status": "Available",
        "description": "Toyota Vios 2024 - Sedan 4 chỗ tiết kiệm nhiên liệu"
    }
}
```

### ✅ Pass Criteria:
- ✅ Status code: **200 OK**
- ✅ Trả về đầy đủ thông tin 1 xe
- ✅ Có đủ các fields: `carType`, `seatCapacity`, `pricePerDay`

---

## ✅ TEST CASE 16: Get All Brands
**Endpoint:** `GET /api/cars/brands`  
**Purpose:** Lấy danh sách tất cả hãng xe

### Request:
```
GET http://localhost:8080/api/cars/brands
```

### Expected Response:
```json
{
    "success": true,
    "message": "All brands retrieved successfully",
    "brands": [
        "Toyota",
        "Honda",
        "Mazda",
        "Ford",
        "Kia",
        "Hyundai",
        "Vinfast",
        "Mitsubishi"
    ],
    "totalBrands": 8
}
```

### ✅ Pass Criteria:
- ✅ Status code: **200 OK**
- ✅ Expected count: **8 brands**
- ✅ Bao gồm: Toyota, Honda, Mazda, Ford, Kia, Hyundai, Vinfast, Mitsubishi

---

## ✅ TEST CASE 17: Get All Transmissions
**Endpoint:** `GET /api/cars/transmissions`  
**Purpose:** Lấy danh sách loại hộp số

### Request:
```
GET http://localhost:8080/api/cars/transmissions
```

### Expected Response:
```json
{
    "success": true,
    "message": "All transmission types retrieved successfully",
    "transmissions": [
        "Automatic",
        "Manual"
    ],
    "totalTypes": 2
}
```

### ✅ Pass Criteria:
- ✅ Status code: **200 OK**
- ✅ Expected count: **2 types**
- ✅ Bao gồm: Automatic, Manual

---

## ❌ ERROR TEST CASES

### ❌ TEST CASE 18: Invalid Seat Capacity
**Endpoint:** `GET /api/cars/by-type?seatCapacity=100`

### Expected Response:
```json
{
    "success": false,
    "message": "No cars found with 100 seats",
    "cars": [],
    "totalCars": 0
}
```

### ✅ Pass Criteria:
- ✅ Status code: **200 OK** (hoặc 404)
- ✅ `success: false`
- ✅ `totalCars: 0`

---

### ❌ TEST CASE 19: Invalid Brand
**Endpoint:** `GET /api/cars/by-brand?brand=Ferrari`

### Expected Response:
```json
{
    "success": false,
    "message": "No cars found for brand Ferrari",
    "cars": [],
    "totalCars": 0
}
```

### ✅ Pass Criteria:
- ✅ Status code: **200 OK** (hoặc 404)
- ✅ `success: false`
- ✅ Empty cars array

---

### ❌ TEST CASE 20: Invalid Car ID
**Endpoint:** `GET /api/cars/999`

### Expected Response:
```json
{
    "success": false,
    "message": "Car with ID 999 not found",
    "error": "Car not found"
}
```

### ✅ Pass Criteria:
- ✅ Status code: **404 Not Found**
- ✅ `success: false`
- ✅ Error message rõ ràng

---

## 📊 SUMMARY - EXPECTED COUNTS

| Seat Capacity | Car Type | Expected Count | Examples |
|--------------|----------|----------------|----------|
| 4 chỗ | Mini, Sedan, Pickup | ~8 cars | Mazda 2, Vios, City, Ranger |
| 5 chỗ | SUV/CUV | ~9 cars | CR-V, CX-5, VF5, VF8 |
| 7 chỗ | SUV, MPV, Minivan | ~13 cars | Fortuner, Everest, VF9, Carnival |

| Brand | Count | Models |
|-------|-------|--------|
| Toyota | 4 | Vios, Corolla Cross, Fortuner, Innova |
| Honda | 4 | City, Accord, CR-V, Pilot |
| Mazda | 4 | 2, 3, CX-5, CX-9 |
| Ford | 3 | Focus, Everest, Ranger |
| Kia | 3 | K3, Sorento, Carnival |
| Hyundai | 4 | Accent, Elantra, Tucson, Santa Fe |
| Vinfast | 3 | VF5, VF8, VF9 (all Electric) |
| Mitsubishi | 3 | Attrage, Xpander, Outlander PHEV |

| Fuel Type | Count | Note |
|-----------|-------|------|
| Gasoline | 20 | Xăng |
| Diesel | 7 | Dầu |
| Electric | 3 | Vinfast VF5, VF8, VF9 |
| Hybrid | 1 | Outlander PHEV |

| Transmission | Count |
|--------------|-------|
| Automatic | ~20 |
| Manual | ~10 |

---

## 🎯 TESTING CHECKLIST

### Pre-test:
- [ ] Server đang chạy: `http://localhost:8080`
- [ ] Database đã import: `insert_cars_NEW_STRUCTURE.sql`
- [ ] Postman collection đã import: `SearchCar_API_NEW_STRUCTURE.postman_collection.json`
- [ ] SecurityConfig đã allow `/api/cars/**` (no JWT required)

### Test Execution:
- [ ] TC01: Get All Cars (30 cars)
- [ ] TC02: Get 4 chỗ (~8 cars)
- [ ] TC03: Get 5 chỗ (~9 cars)
- [ ] TC04: Get 7 chỗ (~13 cars)
- [ ] TC05: Get Toyota (4 cars)
- [ ] TC06: Get Vinfast (3 electric cars)
- [ ] TC07: Get Electric (3 cars)
- [ ] TC08: Get Hybrid (1 car)
- [ ] TC09: Get Automatic (~20 cars)
- [ ] TC10: Get Manual (~10 cars)
- [ ] TC11-14: POST Search (various combinations)
- [ ] TC15: Get by ID
- [ ] TC16: Get All Brands (8 brands)
- [ ] TC17: Get All Transmissions (2 types)
- [ ] TC18-20: Error cases

### Verification:
- [ ] Tất cả response có `seatCapacity` field (không phải `seats`)
- [ ] Tất cả response có `carType` field (Mini, Sedan, SUV, MPV, etc.)
- [ ] Không có lỗi 403 Forbidden
- [ ] Response time < 1000ms
- [ ] Data consistent với database

---

## 🚀 QUICK TEST COMMANDS (Postman)

1. **Run All Tests:** Click "Run Collection" → chọn tất cả 17 tests
2. **View Results:** Check "Test Results" tab
3. **Expected:** 17/17 tests PASSED ✅

---

**Status:** Ready for Testing ✅  
**Database:** 30 cars loaded ✅  
**API:** All endpoints public (no auth) ✅  
**Structure:** car_type + seat_capacity ✅
