-- ========================================
-- ALTER TABLE: THÊM CÁC COLUMNS MỚI CHO ADVANCED FILTER
-- ========================================

-- Thêm column: daily_km_limit (Giới hạn km/ngày)
ALTER TABLE cars
ADD daily_km_limit INT NULL;

-- Thêm column: exceed_fee_per_km (Phí vượt giới hạn - VNĐ/km)
ALTER TABLE cars
ADD exceed_fee_per_km INT NULL;

-- Thêm column: fuel_consumption (Mức tiêu thụ nhiên liệu - L/100km)
ALTER TABLE cars
ADD fuel_consumption DECIMAL(5, 2) NULL;

GO

-- ========================================
-- UPDATE DỮ LIỆU MẪU
-- ========================================

-- Update các xe hiện tại với giá trị mẫu
UPDATE cars
SET 
    daily_km_limit = CASE 
        WHEN car_type = 'Mini' THEN 200
        WHEN car_type = 'Sedan' THEN 300
        WHEN car_type = 'SUV' AND seat_capacity = 5 THEN 350
        WHEN car_type = 'SUV' AND seat_capacity = 7 THEN NULL -- Không giới hạn
        WHEN car_type = 'MPV' THEN 400
        WHEN car_type = 'Pickup' THEN 250
        WHEN car_type = 'Minivan' THEN NULL -- Không giới hạn
        ELSE 300
    END,
    exceed_fee_per_km = CASE 
        WHEN car_type = 'Mini' THEN 3000
        WHEN car_type = 'Sedan' THEN 4000
        WHEN car_type = 'SUV' THEN 5000
        WHEN car_type = 'MPV' THEN 4500
        WHEN car_type = 'Pickup' THEN 4000
        WHEN car_type = 'Minivan' THEN 0 -- Miễn phí
        ELSE 4000
    END,
    fuel_consumption = CASE 
        WHEN fuel_type = 'Electric' THEN NULL -- Xe điện không có tiêu thụ nhiên liệu
        WHEN fuel_type = 'Hybrid' THEN 5.5
        WHEN car_type = 'Mini' THEN 5.2
        WHEN car_type = 'Sedan' THEN 6.5
        WHEN car_type = 'SUV' AND fuel_type = 'Diesel' THEN 8.5
        WHEN car_type = 'SUV' AND fuel_type = 'Gasoline' THEN 9.5
        WHEN car_type = 'MPV' THEN 7.8
        WHEN car_type = 'Pickup' THEN 10.5
        WHEN car_type = 'Minivan' THEN 11.2
        ELSE 7.0
    END
WHERE id > 0;

GO

-- ========================================
-- VERIFY
-- ========================================
SELECT 
    id,
    name,
    car_type,
    seat_capacity,
    fuel_type,
    daily_km_limit,
    exceed_fee_per_km,
    fuel_consumption
FROM cars
ORDER BY id;

-- ========================================
-- STATISTICS
-- ========================================
-- Thống kê giới hạn km/ngày
SELECT 
    CASE 
        WHEN daily_km_limit IS NULL THEN 'Không giới hạn'
        WHEN daily_km_limit < 250 THEN 'Dưới 250km'
        WHEN daily_km_limit < 350 THEN '250-350km'
        ELSE 'Trên 350km'
    END AS km_range,
    COUNT(*) as total
FROM cars
GROUP BY 
    CASE 
        WHEN daily_km_limit IS NULL THEN 'Không giới hạn'
        WHEN daily_km_limit < 250 THEN 'Dưới 250km'
        WHEN daily_km_limit < 350 THEN '250-350km'
        ELSE 'Trên 350km'
    END;

-- Thống kê phí vượt giới hạn
SELECT 
    CASE 
        WHEN exceed_fee_per_km = 0 OR exceed_fee_per_km IS NULL THEN 'Miễn phí'
        WHEN exceed_fee_per_km < 3500 THEN 'Dưới 3.5k/km'
        WHEN exceed_fee_per_km < 4500 THEN '3.5k-4.5k/km'
        ELSE 'Trên 4.5k/km'
    END AS fee_range,
    COUNT(*) as total
FROM cars
GROUP BY 
    CASE 
        WHEN exceed_fee_per_km = 0 OR exceed_fee_per_km IS NULL THEN 'Miễn phí'
        WHEN exceed_fee_per_km < 3500 THEN 'Dưới 3.5k/km'
        WHEN exceed_fee_per_km < 4500 THEN '3.5k-4.5k/km'
        ELSE 'Trên 4.5k/km'
    END;
