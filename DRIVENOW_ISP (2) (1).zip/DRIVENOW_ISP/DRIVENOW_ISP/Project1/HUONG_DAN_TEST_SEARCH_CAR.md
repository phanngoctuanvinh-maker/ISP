# 🚀 HƯỚNG DẪN TEST SEARCH CAR API

## ✅ Chuẩn bị

### 1. Import dữ liệu vào SQL Server
```sql
-- Mở SQL Server Management Studio (SSMS)
-- Kết nối tới database: drivenow_db
-- Chạy file: insert_cars_correct_structure.sql
```

### 2. Start Backend Server
```powershell
cd e:\DriveNowPorject\DRIVENOW_ISP\DRIVENOW_ISP\Project1
.\start-backend-window.bat
```

Đợi cho đến khi thấy: **Started DrivenowApplication**

---

## 📮 TEST BẰNG POSTMAN

### Bước 1: Import Postman Collection
1. Mở Postman
2. Click **Import**
3. Chọn file: `SearchCar_API_Tests.postman_collection.json`
4. Click **Import**

### Bước 2: Test các API

#### ✅ Test 1: Get All Cars
```
GET http://localhost:8080/api/cars/all
```
**Kết quả mong đợi:** Danh sách tất cả 30 xe

#### ✅ Test 2: Get Cars by Brand
```
GET http://localhost:8080/api/cars/by-brand?brand=Toyota
```
**Thử các hãng:**
- Toyota
- Honda
- Mazda
- Ford
- Kia
- Hyundai
- Vinfast
- Mitsubishi

#### ✅ Test 3: Get Cars by Seats
```
GET http://localhost:8080/api/cars/by-type?seats=7
```
**Thử các loại:**
- `seats=4` - Xe 4 chỗ mini
- `seats=5` - Xe 5 chỗ sedan/SUV
- `seats=7` - Xe 7 chỗ MPV
- `seats=16` - Xe 16 chỗ

#### ✅ Test 4: Get Electric Cars
```
GET http://localhost:8080/api/cars/electric
```
**Kết quả:** 3 xe Vinfast điện

#### ✅ Test 5: Get Hybrid Cars
```
GET http://localhost:8080/api/cars/hybrid
```
**Kết quả:** 3 xe hybrid (Toyota, Honda, Hyundai)

#### ✅ Test 6: Get Cars by Transmission
```
GET http://localhost:8080/api/cars/by-transmission?type=Số sàn
```
**Thử:**
- `type=Số sàn` - Xe số sàn
- `type=Số tự động` - Xe số tự động

#### ✅ Test 7: Advanced Search (POST)
```json
POST http://localhost:8080/api/cars/search
Content-Type: application/json

{
    "filterType": "brand",
    "brand": "Toyota",
    "transmissionType": null,
    "seats": null,
    "fuelType": null
}
```

#### ✅ Test 8: Get Car by ID
```
GET http://localhost:8080/api/cars/1
```

---

## 🌐 TEST BẰNG BROWSER

### Mở trang Search Car
```
http://localhost:5500/DRIVENOW_ISP/DriveNow/html/searchcar.html
```

### Test các chức năng:
1. ✅ **Tất cả** - Hiển thị tất cả xe
2. ✅ **Loại Xe** - Chọn 4/5/7 chỗ → Áp dụng
3. ✅ **Hãng Xe** - Chọn Toyota/Honda/... → Áp dụng
4. ✅ **Truyền động** - Chọn Số sàn/Số tự động → Áp dụng
5. ✅ **Xe Điện** - Click trực tiếp
6. ✅ **Xe Xăng & Điện** - Click trực tiếp

---

## 🔍 KIỂM TRA KẾT QUẢ

### Response Structure
```json
{
    "success": true,
    "message": "Tìm thấy 30 xe",
    "cars": [
        {
            "id": 1,
            "brand": "Toyota",
            "model": "Vios",
            "name": "Toyota Vios 2023",
            "year": 2023,
            "color": "Trắng",
            "seats": 5,
            "seatCapacity": 5,
            "fuelType": "gasoline",
            "transmissionType": "automatic",
            "pricePerDay": 500000.00,
            "description": "...",
            "imageUrl": "...",
            "status": "available",
            "licensePlate": "30A-12345",
            "location": "Hà Nội",
            "createdAt": "...",
            "updatedAt": "..."
        }
    ],
    "totalCount": 30
}
```

---

## ❌ XỬ LÝ LỖI

### Lỗi: Cannot connect to backend
```
Error: Không thể tải danh sách xe
```
**Giải pháp:**
1. Kiểm tra backend đã chạy chưa
2. Check port 8080 có bị chiếm không

### Lỗi: Không có dữ liệu
```
Message: Không tìm thấy xe phù hợp
```
**Giải pháp:**
1. Chạy lại file SQL `insert_cars_correct_structure.sql`
2. Check database đã có data chưa

### Lỗi: CORS
```
Access-Control-Allow-Origin error
```
**Giải pháp:**
- Controller đã có `@CrossOrigin(origins = "*")`
- Restart backend

---

## 📊 DANH SÁCH XE TRONG DATABASE

| Hãng | Số lượng | Loại nhiên liệu |
|------|----------|----------------|
| Toyota | 4 | Xăng, Hybrid |
| Honda | 4 | Xăng, Hybrid |
| Mazda | 3 | Xăng |
| Ford | 3 | Dầu |
| Kia | 4 | Xăng |
| Hyundai | 5 | Xăng, Hybrid |
| Vinfast | 3 | Điện |
| Mitsubishi | 3 | Xăng, Dầu |

**Tổng: 30 xe**

---

## ✅ CHECKLIST

- [ ] Database đã import xong
- [ ] Backend đã chạy (port 8080)
- [ ] Test GET /api/cars/all - Thành công
- [ ] Test GET /api/cars/electric - Thành công
- [ ] Test GET /api/cars/by-brand?brand=Toyota - Thành công
- [ ] Test POST /api/cars/search - Thành công
- [ ] Frontend hiển thị đúng dữ liệu
- [ ] Các filter hoạt động tốt

---

## 🎯 TIPS

1. **Xem log backend** để debug
2. **F12 trong browser** → Console → Xem lỗi JS
3. **Network tab** → Xem API response
4. **Postman** tốt hơn browser để test API thuần

---

Chúc bạn test thành công! 🚗✨
