@echo off
echo ========================================
echo   KHOI DONG BACKEND - DRIVENOW
echo ========================================
echo.
cd /d "%~dp0"
echo Starting Spring Boot Application...
echo.
call mvnw.cmd spring-boot:run
pause
