-- Tạo bảng cars nếu chưa có
CREATE TABLE IF NOT EXISTS cars (
    car_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    brand VARCHAR(50),
    model VARCHAR(50),
    year INT,
    color VARCHAR(30),
    seats INT,
    fuel_type VARCHAR(20),
    transmission_type VARCHAR(20),
    daily_rate DECIMAL(10,2),
    description TEXT,
    mileage INT,
    seat_capacity INT,
    image_url VARCHAR(255),
    status VARCHAR(20) DEFAULT 'available',
    rental_plate VARCHAR(20),
    insurance_info TEXT,
    extension_price DECIMAL(10,2),
    width INT,
    price_per_day DECIMAL(10,2),
    updated_at DATETIME
);

-- Xóa dữ liệu cũ nếu có
DELETE FROM cars;

-- Insert dữ liệu mẫu cho các xe

-- Toyota (Xăng)
INSERT INTO cars (brand, model, year, color, seats, fuel_type, transmission_type, daily_rate, description, mileage, seat_capacity, image_url, status, rental_plate, price_per_day) VALUES
('Toyota', 'Vios', 2023, 'Trắng', 5, 'gasoline', 'automatic', 500000, 'Toyota Vios đời mới, tiết kiệm nhiên liệu', 15000, 5, 'https://example.com/toyota-vios.jpg', 'available', '30A-12345', 500000),
('Toyota', 'Camry', 2023, 'Đen', 5, 'gasoline', 'automatic', 1200000, 'Toyota Camry sang trọng, êm ái', 10000, 5, 'https://example.com/toyota-camry.jpg', 'available', '30A-12346', 1200000),
('Toyota', 'Fortuner', 2022, 'Bạc', 7, 'diesel', 'automatic', 1500000, 'Toyota Fortuner 7 chỗ, phù hợp gia đình', 20000, 7, 'https://example.com/toyota-fortuner.jpg', 'available', '30A-12347', 1500000);

-- Honda (Xăng)
INSERT INTO cars (brand, model, year, color, seats, fuel_type, transmission_type, daily_rate, description, mileage, seat_capacity, image_url, status, rental_plate, price_per_day) VALUES
('Honda', 'City', 2023, 'Đỏ', 5, 'gasoline', 'automatic', 550000, 'Honda City thể thao, năng động', 12000, 5, 'https://example.com/honda-city.jpg', 'available', '30B-22345', 550000),
('Honda', 'Civic', 2023, 'Xanh', 5, 'gasoline', 'automatic', 900000, 'Honda Civic hiện đại, công nghệ cao', 8000, 5, 'https://example.com/honda-civic.jpg', 'available', '30B-22346', 900000),
('Honda', 'CR-V', 2022, 'Trắng', 7, 'gasoline', 'automatic', 1300000, 'Honda CR-V 7 chỗ, rộng rãi', 18000, 7, 'https://example.com/honda-crv.jpg', 'available', '30B-22347', 1300000);

-- Mazda (Xăng)
INSERT INTO cars (brand, model, year, color, seats, fuel_type, transmission_type, daily_rate, description, mileage, seat_capacity, image_url, status, rental_plate, price_per_day) VALUES
('Mazda', '3', 2023, 'Đỏ Soul', 5, 'gasoline', 'automatic', 700000, 'Mazda 3 thiết kế đẹp, vận hành ổn định', 10000, 5, 'https://example.com/mazda3.jpg', 'available', '30C-32345', 700000),
('Mazda', 'CX-5', 2023, 'Xám', 5, 'gasoline', 'automatic', 1100000, 'Mazda CX-5 sang trọng, tiện nghi', 12000, 5, 'https://example.com/mazda-cx5.jpg', 'available', '30C-32346', 1100000),
('Mazda', 'CX-8', 2022, 'Trắng', 7, 'gasoline', 'automatic', 1400000, 'Mazda CX-8 7 chỗ cao cấp', 15000, 7, 'https://example.com/mazda-cx8.jpg', 'available', '30C-32347', 1400000);

-- Ford (Xăng và Số sàn)
INSERT INTO cars (brand, model, year, color, seats, fuel_type, transmission_type, daily_rate, description, mileage, seat_capacity, image_url, status, rental_plate, price_per_day) VALUES
('Ford', 'Ranger', 2023, 'Xanh', 5, 'diesel', 'manual', 800000, 'Ford Ranger bán tải mạnh mẽ', 25000, 5, 'https://example.com/ford-ranger.jpg', 'available', '30D-42345', 800000),
('Ford', 'Everest', 2022, 'Nâu', 7, 'diesel', 'automatic', 1600000, 'Ford Everest 7 chỗ off-road', 22000, 7, 'https://example.com/ford-everest.jpg', 'available', '30D-42346', 1600000),
('Ford', 'Transit', 2021, 'Trắng', 16, 'diesel', 'manual', 1200000, 'Ford Transit 16 chỗ du lịch', 35000, 16, 'https://example.com/ford-transit.jpg', 'available', '30D-42347', 1200000);

-- Kia (Xăng)
INSERT INTO cars (brand, model, year, color, seats, fuel_type, transmission_type, daily_rate, description, mileage, seat_capacity, image_url, status, rental_plate, price_per_day) VALUES
('Kia', 'Morning', 2023, 'Vàng', 4, 'gasoline', 'automatic', 400000, 'Kia Morning nhỏ gọn, tiết kiệm', 8000, 4, 'https://example.com/kia-morning.jpg', 'available', '30E-52345', 400000),
('Kia', 'Seltos', 2023, 'Đỏ', 5, 'gasoline', 'automatic', 800000, 'Kia Seltos SUV đô thị hiện đại', 10000, 5, 'https://example.com/kia-seltos.jpg', 'available', '30E-52346', 800000),
('Kia', 'Sorento', 2022, 'Đen', 7, 'diesel', 'automatic', 1300000, 'Kia Sorento 7 chỗ sang trọng', 18000, 7, 'https://example.com/kia-sorento.jpg', 'available', '30E-52347', 1300000);

-- Hyundai (Xăng)
INSERT INTO cars (brand, model, year, color, seats, fuel_type, transmission_type, daily_rate, description, mileage, seat_capacity, image_url, status, rental_plate, price_per_day) VALUES
('Hyundai', 'Accent', 2023, 'Bạc', 5, 'gasoline', 'automatic', 500000, 'Hyundai Accent sedan hiện đại', 12000, 5, 'https://example.com/hyundai-accent.jpg', 'available', '30F-62345', 500000),
('Hyundai', 'Tucson', 2023, 'Trắng', 5, 'gasoline', 'automatic', 1000000, 'Hyundai Tucson SUV công nghệ cao', 9000, 5, 'https://example.com/hyundai-tucson.jpg', 'available', '30F-62346', 1000000),
('Hyundai', 'Santa Fe', 2022, 'Đen', 7, 'diesel', 'automatic', 1400000, 'Hyundai Santa Fe 7 chỗ cao cấp', 15000, 7, 'https://example.com/hyundai-santafe.jpg', 'available', '30F-62347', 1400000);

-- Vinfast (Điện và Hybrid)
INSERT INTO cars (brand, model, year, color, seats, fuel_type, transmission_type, daily_rate, description, mileage, seat_capacity, image_url, status, rental_plate, price_per_day) VALUES
('Vinfast', 'VF e34', 2023, 'Trắng', 5, 'electric', 'automatic', 900000, 'Vinfast VF e34 xe điện thông minh', 5000, 5, 'https://example.com/vinfast-vfe34.jpg', 'available', '30G-72345', 900000),
('Vinfast', 'VF 8', 2023, 'Xanh', 5, 'electric', 'automatic', 1500000, 'Vinfast VF 8 xe điện cao cấp', 3000, 5, 'https://example.com/vinfast-vf8.jpg', 'available', '30G-72346', 1500000),
('Vinfast', 'VF 9', 2023, 'Đen', 7, 'electric', 'automatic', 2000000, 'Vinfast VF 9 xe điện 7 chỗ', 2000, 7, 'https://example.com/vinfast-vf9.jpg', 'available', '30G-72347', 2000000);

-- Mitsubishi (Xăng và Số sàn)
INSERT INTO cars (brand, model, year, color, seats, fuel_type, transmission_type, daily_rate, description, mileage, seat_capacity, image_url, status, rental_plate, price_per_day) VALUES
('Mitsubishi', 'Attrage', 2023, 'Trắng', 5, 'gasoline', 'manual', 450000, 'Mitsubishi Attrage tiết kiệm nhiên liệu', 13000, 5, 'https://example.com/mitsubishi-attrage.jpg', 'available', '30H-82345', 450000),
('Mitsubishi', 'Xpander', 2023, 'Bạc', 7, 'gasoline', 'automatic', 800000, 'Mitsubishi Xpander MPV 7 chỗ', 11000, 7, 'https://example.com/mitsubishi-xpander.jpg', 'available', '30H-82346', 800000),
('Mitsubishi', 'Pajero Sport', 2022, 'Đen', 7, 'diesel', 'automatic', 1500000, 'Mitsubishi Pajero Sport off-road', 20000, 7, 'https://example.com/mitsubishi-pajero.jpg', 'available', '30H-82347', 1500000);

-- Thêm xe Hybrid (Xăng & Điện)
INSERT INTO cars (brand, model, year, color, seats, fuel_type, transmission_type, daily_rate, description, mileage, seat_capacity, image_url, status, rental_plate, price_per_day) VALUES
('Toyota', 'Corolla Cross Hybrid', 2023, 'Trắng Ngọc', 5, 'hybrid', 'automatic', 1100000, 'Toyota Corolla Cross Hybrid tiết kiệm nhiên liệu', 8000, 5, 'https://example.com/toyota-corolla-hybrid.jpg', 'available', '30A-12348', 1100000),
('Honda', 'Accord Hybrid', 2023, 'Bạc', 5, 'hybrid', 'automatic', 1300000, 'Honda Accord Hybrid sang trọng, tiết kiệm', 6000, 5, 'https://example.com/honda-accord-hybrid.jpg', 'available', '30B-22348', 1300000),
('Hyundai', 'Tucson Hybrid', 2023, 'Xanh', 5, 'hybrid', 'automatic', 1200000, 'Hyundai Tucson Hybrid công nghệ xanh', 7000, 5, 'https://example.com/hyundai-tucson-hybrid.jpg', 'available', '30F-62348', 1200000);

-- Thêm xe 4 chỗ Mini
INSERT INTO cars (brand, model, year, color, seats, fuel_type, transmission_type, daily_rate, description, mileage, seat_capacity, image_url, status, rental_plate, price_per_day) VALUES
('Kia', 'Morning AT', 2023, 'Đỏ', 4, 'gasoline', 'automatic', 400000, 'Kia Morning 4 chỗ mini, dễ lái', 9000, 4, 'https://example.com/kia-morning-at.jpg', 'available', '30E-52348', 400000),
('Hyundai', 'Grand i10', 2023, 'Trắng', 4, 'gasoline', 'automatic', 420000, 'Hyundai Grand i10 nhỏ gọn tiện lợi', 10000, 4, 'https://example.com/hyundai-i10.jpg', 'available', '30F-62349', 420000);

COMMIT;
