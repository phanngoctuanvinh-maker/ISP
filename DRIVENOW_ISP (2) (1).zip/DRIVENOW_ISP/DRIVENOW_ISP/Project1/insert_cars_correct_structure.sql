-- Insert dữ liệu xe cho bảng cars với cấu trúc đúng
-- Xóa dữ liệu cũ nếu có
DELETE FROM cars;

-- Toyota (Xăng)
INSERT INTO cars (brand, model, name, year, color, seats, seat_capacity, fuel_type, transmission_type, 
                  daily_rate, price_per_day, description, mileage, image_url, status, license_plate, 
                  location, insurance_info, created_at, updated_at) 
VALUES
('Toyota', 'Vios', 'Toyota Vios 2023', 2023, 'Trắng', 5, 5, 'gasoline', 'automatic', 
 500000.00, 500000.00, 'Toyota Vios đời mới, tiết kiệm nhiên liệu, phù hợp đi phố', 15000, 
 'https://example.com/toyota-vios.jpg', 'available', '30A-12345', 'Hà Nội', 
 'Bảo hiểm vật chất xe, Bảo hiểm trách nhiệm dân sự', GETDATE(), GETDATE()),

('Toyota', 'Camry', 'Toyota Camry 2023', 2023, 'Đen', 5, 5, 'gasoline', 'automatic', 
 1200000.00, 1200000.00, 'Toyota Camry sang trọng, êm ái, động cơ mạnh mẽ', 10000, 
 'https://example.com/toyota-camry.jpg', 'available', '30A-12346', 'Hà Nội', 
 'Bảo hiểm vật chất xe, Bảo hiểm trách nhiệm dân sự', GETDATE(), GETDATE()),

('Toyota', 'Fortuner', 'Toyota Fortuner 2022', 2022, 'Bạc', 7, 7, 'diesel', 'automatic', 
 1500000.00, 1500000.00, 'Toyota Fortuner 7 chỗ, phù hợp gia đình, đi du lịch xa', 20000, 
 'https://example.com/toyota-fortuner.jpg', 'available', '30A-12347', 'Hà Nội', 
 'Bảo hiểm vật chất xe, Bảo hiểm trách nhiệm dân sự', GETDATE(), GETDATE());

-- Honda (Xăng)
INSERT INTO cars (brand, model, name, year, color, seats, seat_capacity, fuel_type, transmission_type, 
                  daily_rate, price_per_day, description, mileage, image_url, status, license_plate, 
                  location, insurance_info, created_at, updated_at) 
VALUES
('Honda', 'City', 'Honda City 2023', 2023, 'Đỏ', 5, 5, 'gasoline', 'automatic', 
 550000.00, 550000.00, 'Honda City thể thao, năng động, thiết kế trẻ trung', 12000, 
 'https://example.com/honda-city.jpg', 'available', '30B-22345', 'Hà Nội', 
 'Bảo hiểm vật chất xe, Bảo hiểm trách nhiệm dân sự', GETDATE(), GETDATE()),

('Honda', 'Civic', 'Honda Civic 2023', 2023, 'Xanh', 5, 5, 'gasoline', 'automatic', 
 900000.00, 900000.00, 'Honda Civic hiện đại, công nghệ cao, động cơ turbo', 8000, 
 'https://example.com/honda-civic.jpg', 'available', '30B-22346', 'Hà Nội', 
 'Bảo hiểm vật chất xe, Bảo hiểm trách nhiệm dân sự', GETDATE(), GETDATE()),

('Honda', 'CR-V', 'Honda CR-V 2022', 2022, 'Trắng', 7, 7, 'gasoline', 'automatic', 
 1300000.00, 1300000.00, 'Honda CR-V 7 chỗ, rộng rãi, tiện nghi cao cấp', 18000, 
 'https://example.com/honda-crv.jpg', 'available', '30B-22347', 'Hà Nội', 
 'Bảo hiểm vật chất xe, Bảo hiểm trách nhiệm dân sự', GETDATE(), GETDATE());

-- Mazda (Xăng)
INSERT INTO cars (brand, model, name, year, color, seats, seat_capacity, fuel_type, transmission_type, 
                  daily_rate, price_per_day, description, mileage, image_url, status, license_plate, 
                  location, insurance_info, created_at, updated_at) 
VALUES
('Mazda', '3', 'Mazda 3 2023', 2023, 'Đỏ Soul', 5, 5, 'gasoline', 'automatic', 
 700000.00, 700000.00, 'Mazda 3 thiết kế đẹp, vận hành ổn định, tiết kiệm nhiên liệu', 10000, 
 'https://example.com/mazda3.jpg', 'available', '30C-32345', 'Hà Nội', 
 'Bảo hiểm vật chất xe, Bảo hiểm trách nhiệm dân sự', GETDATE(), GETDATE()),

('Mazda', 'CX-5', 'Mazda CX-5 2023', 2023, 'Xám', 5, 5, 'gasoline', 'automatic', 
 1100000.00, 1100000.00, 'Mazda CX-5 sang trọng, tiện nghi, công nghệ an toàn', 12000, 
 'https://example.com/mazda-cx5.jpg', 'available', '30C-32346', 'Hà Nội', 
 'Bảo hiểm vật chất xe, Bảo hiểm trách nhiệm dân sự', GETDATE(), GETDATE()),

('Mazda', 'CX-8', 'Mazda CX-8 2022', 2022, 'Trắng', 7, 7, 'gasoline', 'automatic', 
 1400000.00, 1400000.00, 'Mazda CX-8 7 chỗ cao cấp, nội thất da sang trọng', 15000, 
 'https://example.com/mazda-cx8.jpg', 'available', '30C-32347', 'Hà Nội', 
 'Bảo hiểm vật chất xe, Bảo hiểm trách nhiệm dân sự', GETDATE(), GETDATE());

-- Ford (Diesel và Số sàn)
INSERT INTO cars (brand, model, name, year, color, seats, seat_capacity, fuel_type, transmission_type, 
                  daily_rate, price_per_day, description, mileage, image_url, status, license_plate, 
                  location, insurance_info, created_at, updated_at) 
VALUES
('Ford', 'Ranger', 'Ford Ranger 2023', 2023, 'Xanh', 5, 5, 'diesel', 'manual', 
 800000.00, 800000.00, 'Ford Ranger bán tải mạnh mẽ, phù hợp địa hình khó', 25000, 
 'https://example.com/ford-ranger.jpg', 'available', '30D-42345', 'Hà Nội', 
 'Bảo hiểm vật chất xe, Bảo hiểm trách nhiệm dân sự', GETDATE(), GETDATE()),

('Ford', 'Everest', 'Ford Everest 2022', 2022, 'Nâu', 7, 7, 'diesel', 'automatic', 
 1600000.00, 1600000.00, 'Ford Everest 7 chỗ off-road, phù hợp đi phượt', 22000, 
 'https://example.com/ford-everest.jpg', 'available', '30D-42346', 'Hà Nội', 
 'Bảo hiểm vật chất xe, Bảo hiểm trách nhiệm dân sự', GETDATE(), GETDATE()),

('Ford', 'Transit', 'Ford Transit 2021', 2021, 'Trắng', 16, 16, 'diesel', 'manual', 
 1200000.00, 1200000.00, 'Ford Transit 16 chỗ du lịch, đi tour đông người', 35000, 
 'https://example.com/ford-transit.jpg', 'available', '30D-42347', 'Hà Nội', 
 'Bảo hiểm vật chất xe, Bảo hiểm trách nhiệm dân sự', GETDATE(), GETDATE());

-- Kia (Xăng)
INSERT INTO cars (brand, model, name, year, color, seats, seat_capacity, fuel_type, transmission_type, 
                  daily_rate, price_per_day, description, mileage, image_url, status, license_plate, 
                  location, insurance_info, created_at, updated_at) 
VALUES
('Kia', 'Morning', 'Kia Morning 2023', 2023, 'Vàng', 4, 4, 'gasoline', 'automatic', 
 400000.00, 400000.00, 'Kia Morning nhỏ gọn, tiết kiệm, dễ đậu xe trong phố', 8000, 
 'https://example.com/kia-morning.jpg', 'available', '30E-52345', 'Hà Nội', 
 'Bảo hiểm vật chất xe, Bảo hiểm trách nhiệm dân sự', GETDATE(), GETDATE()),

('Kia', 'Seltos', 'Kia Seltos 2023', 2023, 'Đỏ', 5, 5, 'gasoline', 'automatic', 
 800000.00, 800000.00, 'Kia Seltos SUV đô thị hiện đại, công nghệ thông minh', 10000, 
 'https://example.com/kia-seltos.jpg', 'available', '30E-52346', 'Hà Nội', 
 'Bảo hiểm vật chất xe, Bảo hiểm trách nhiệm dân sự', GETDATE(), GETDATE()),

('Kia', 'Sorento', 'Kia Sorento 2022', 2022, 'Đen', 7, 7, 'diesel', 'automatic', 
 1300000.00, 1300000.00, 'Kia Sorento 7 chỗ sang trọng, nội thất cao cấp', 18000, 
 'https://example.com/kia-sorento.jpg', 'available', '30E-52347', 'Hà Nội', 
 'Bảo hiểm vật chất xe, Bảo hiểm trách nhiệm dân sự', GETDATE(), GETDATE());

-- Hyundai (Xăng)
INSERT INTO cars (brand, model, name, year, color, seats, seat_capacity, fuel_type, transmission_type, 
                  daily_rate, price_per_day, description, mileage, image_url, status, license_plate, 
                  location, insurance_info, created_at, updated_at) 
VALUES
('Hyundai', 'Accent', 'Hyundai Accent 2023', 2023, 'Bạc', 5, 5, 'gasoline', 'automatic', 
 500000.00, 500000.00, 'Hyundai Accent sedan hiện đại, tiện nghi đầy đủ', 12000, 
 'https://example.com/hyundai-accent.jpg', 'available', '30F-62345', 'Hà Nội', 
 'Bảo hiểm vật chất xe, Bảo hiểm trách nhiệm dân sự', GETDATE(), GETDATE()),

('Hyundai', 'Tucson', 'Hyundai Tucson 2023', 2023, 'Trắng', 5, 5, 'gasoline', 'automatic', 
 1000000.00, 1000000.00, 'Hyundai Tucson SUV công nghệ cao, an toàn tối đa', 9000, 
 'https://example.com/hyundai-tucson.jpg', 'available', '30F-62346', 'Hà Nội', 
 'Bảo hiểm vật chất xe, Bảo hiểm trách nhiệm dân sự', GETDATE(), GETDATE()),

('Hyundai', 'Santa Fe', 'Hyundai Santa Fe 2022', 2022, 'Đen', 7, 7, 'diesel', 'automatic', 
 1400000.00, 1400000.00, 'Hyundai Santa Fe 7 chỗ cao cấp, nội thất sang trọng', 15000, 
 'https://example.com/hyundai-santafe.jpg', 'available', '30F-62347', 'Hà Nội', 
 'Bảo hiểm vật chất xe, Bảo hiểm trách nhiệm dân sự', GETDATE(), GETDATE());

-- Vinfast (Điện)
INSERT INTO cars (brand, model, name, year, color, seats, seat_capacity, fuel_type, transmission_type, 
                  daily_rate, price_per_day, description, mileage, image_url, status, license_plate, 
                  location, insurance_info, created_at, updated_at) 
VALUES
('Vinfast', 'VF e34', 'Vinfast VF e34 2023', 2023, 'Trắng', 5, 5, 'electric', 'automatic', 
 900000.00, 900000.00, 'Vinfast VF e34 xe điện thông minh, công nghệ Việt Nam', 5000, 
 'https://example.com/vinfast-vfe34.jpg', 'available', '30G-72345', 'Hà Nội', 
 'Bảo hiểm vật chất xe, Bảo hiểm trách nhiệm dân sự', GETDATE(), GETDATE()),

('Vinfast', 'VF 8', 'Vinfast VF 8 2023', 2023, 'Xanh', 5, 5, 'electric', 'automatic', 
 1500000.00, 1500000.00, 'Vinfast VF 8 xe điện cao cấp, tầm di chuyển xa', 3000, 
 'https://example.com/vinfast-vf8.jpg', 'available', '30G-72346', 'Hà Nội', 
 'Bảo hiểm vật chất xe, Bảo hiểm trách nhiệm dân sự', GETDATE(), GETDATE()),

('Vinfast', 'VF 9', 'Vinfast VF 9 2023', 2023, 'Đen', 7, 7, 'electric', 'automatic', 
 2000000.00, 2000000.00, 'Vinfast VF 9 xe điện 7 chỗ, sang trọng bậc nhất', 2000, 
 'https://example.com/vinfast-vf9.jpg', 'available', '30G-72347', 'Hà Nội', 
 'Bảo hiểm vật chất xe, Bảo hiểm trách nhiệm dân sự', GETDATE(), GETDATE());

-- Mitsubishi (Xăng và Số sàn)
INSERT INTO cars (brand, model, name, year, color, seats, seat_capacity, fuel_type, transmission_type, 
                  daily_rate, price_per_day, description, mileage, image_url, status, license_plate, 
                  location, insurance_info, created_at, updated_at) 
VALUES
('Mitsubishi', 'Attrage', 'Mitsubishi Attrage 2023', 2023, 'Trắng', 5, 5, 'gasoline', 'manual', 
 450000.00, 450000.00, 'Mitsubishi Attrage tiết kiệm nhiên liệu, bền bỉ', 13000, 
 'https://example.com/mitsubishi-attrage.jpg', 'available', '30H-82345', 'Hà Nội', 
 'Bảo hiểm vật chất xe, Bảo hiểm trách nhiệm dân sự', GETDATE(), GETDATE()),

('Mitsubishi', 'Xpander', 'Mitsubishi Xpander 2023', 2023, 'Bạc', 7, 7, 'gasoline', 'automatic', 
 800000.00, 800000.00, 'Mitsubishi Xpander MPV 7 chỗ, phù hợp gia đình', 11000, 
 'https://example.com/mitsubishi-xpander.jpg', 'available', '30H-82346', 'Hà Nội', 
 'Bảo hiểm vật chất xe, Bảo hiểm trách nhiệm dân sự', GETDATE(), GETDATE()),

('Mitsubishi', 'Pajero Sport', 'Mitsubishi Pajero Sport 2022', 2022, 'Đen', 7, 7, 'diesel', 'automatic', 
 1500000.00, 1500000.00, 'Mitsubishi Pajero Sport off-road, mạnh mẽ trên mọi địa hình', 20000, 
 'https://example.com/mitsubishi-pajero.jpg', 'available', '30H-82347', 'Hà Nội', 
 'Bảo hiểm vật chất xe, Bảo hiểm trách nhiệm dân sự', GETDATE(), GETDATE());

-- Xe Hybrid (Xăng & Điện)
INSERT INTO cars (brand, model, name, year, color, seats, seat_capacity, fuel_type, transmission_type, 
                  daily_rate, price_per_day, description, mileage, image_url, status, license_plate, 
                  location, insurance_info, created_at, updated_at) 
VALUES
('Toyota', 'Corolla Cross Hybrid', 'Toyota Corolla Cross Hybrid 2023', 2023, 'Trắng Ngọc', 5, 5, 'hybrid', 'automatic', 
 1100000.00, 1100000.00, 'Toyota Corolla Cross Hybrid tiết kiệm nhiên liệu tối đa', 8000, 
 'https://example.com/toyota-corolla-hybrid.jpg', 'available', '30A-12348', 'Hà Nội', 
 'Bảo hiểm vật chất xe, Bảo hiểm trách nhiệm dân sự', GETDATE(), GETDATE()),

('Honda', 'Accord Hybrid', 'Honda Accord Hybrid 2023', 2023, 'Bạc', 5, 5, 'hybrid', 'automatic', 
 1300000.00, 1300000.00, 'Honda Accord Hybrid sang trọng, tiết kiệm nhiên liệu', 6000, 
 'https://example.com/honda-accord-hybrid.jpg', 'available', '30B-22348', 'Hà Nội', 
 'Bảo hiểm vật chất xe, Bảo hiểm trách nhiệm dân sự', GETDATE(), GETDATE()),

('Hyundai', 'Tucson Hybrid', 'Hyundai Tucson Hybrid 2023', 2023, 'Xanh', 5, 5, 'hybrid', 'automatic', 
 1200000.00, 1200000.00, 'Hyundai Tucson Hybrid công nghệ xanh, thân thiện môi trường', 7000, 
 'https://example.com/hyundai-tucson-hybrid.jpg', 'available', '30F-62348', 'Hà Nội', 
 'Bảo hiểm vật chất xe, Bảo hiểm trách nhiệm dân sự', GETDATE(), GETDATE());

-- Thêm xe 4 chỗ Mini
INSERT INTO cars (brand, model, name, year, color, seats, seat_capacity, fuel_type, transmission_type, 
                  daily_rate, price_per_day, description, mileage, image_url, status, license_plate, 
                  location, insurance_info, created_at, updated_at) 
VALUES
('Kia', 'Morning AT', 'Kia Morning AT 2023', 2023, 'Đỏ', 4, 4, 'gasoline', 'automatic', 
 400000.00, 400000.00, 'Kia Morning 4 chỗ mini, dễ lái trong phố đông', 9000, 
 'https://example.com/kia-morning-at.jpg', 'available', '30E-52348', 'Hà Nội', 
 'Bảo hiểm vật chất xe, Bảo hiểm trách nhiệm dân sự', GETDATE(), GETDATE()),

('Hyundai', 'Grand i10', 'Hyundai Grand i10 2023', 2023, 'Trắng', 4, 4, 'gasoline', 'automatic', 
 420000.00, 420000.00, 'Hyundai Grand i10 nhỏ gọn tiện lợi, kinh tế', 10000, 
 'https://example.com/hyundai-i10.jpg', 'available', '30F-62349', 'Hà Nội', 
 'Bảo hiểm vật chất xe, Bảo hiểm trách nhiệm dân sự', GETDATE(), GETDATE());

-- Kiểm tra số lượng xe đã insert
SELECT COUNT(*) AS TotalCars FROM cars;
SELECT brand, COUNT(*) AS CarCount FROM cars GROUP BY brand;
