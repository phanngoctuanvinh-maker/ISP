# 🚗 DRIVENOW - HỆ THỐNG CHO THUÊ XE Ô TÔ CÓ TÀI XẾ

## 📂 CẤU TRÚC PROJECT

```
drivenow/
├── src/main/java/com/carrentleproject/drivenow/
│   ├── model/              # Entity classes (JPA)
│   │   ├── Account.java
│   │   ├── Customer.java
│   │   ├── Driver.java
│   │   ├── Admin.java
│   │   └── OTP.java
│   │
│   ├── dto/                # Data Transfer Objects
│   │   ├── LoginRequest.java
│   │   ├── RegisterRequest.java
│   │   ├── ChangePasswordRequest.java
│   │   ├── ForgotPasswordRequest.java
│   │   ├── ResetPasswordRequest.java
│   │   ├── ProfileUpdateRequest.java
│   │   ├── GoogleLoginRequest.java
│   │   ├── AuthResponse.java
│   │   └── ApiResponse.java
│   │
│   ├── dao/                # Data Access Objects (JPA Repository)
│   │   ├── AccountDAO.java
│   │   ├── CustomerDAO.java
│   │   ├── DriverDAO.java
│   │   ├── AdminDAO.java
│   │   └── OTPDAO.java
│   │
│   ├── service/            # Business Logic Layer
│   │   ├── AuthService.java
│   │   ├── ProfileService.java
│   │   ├── EmailService.java
│   │   └── OTPService.java
│   │
│   ├── controller/         # REST API Controllers
│   │   ├── LoginController.java
│   │   ├── LogoutController.java
│   │   ├── RegisterController.java
│   │   ├── LoginGGController.java
│   │   ├── ForgotPasswordController.java
│   │   ├── ChangePasswordController.java
│   │   └── ProfileController.java
│   │
│   ├── config/             # Configuration classes
│   │   ├── SecurityConfig.java
│   │   ├── JwtTokenProvider.java
│   │   ├── JwtAuthenticationFilter.java
│   │   └── CustomUserDetailsService.java
│   │
│   ├── exception/          # Custom Exceptions & Handler
│   │   ├── GlobalExceptionHandler.java
│   │   ├── ResourceNotFoundException.java
│   │   ├── BadRequestException.java
│   │   └── UnauthorizedException.java
│   │
│   └── DrivenowApplication.java
│
└── src/main/resources/
    └── application.properties
```

---

## ⚙️ CẤU HÌNH TRƯỚC KHI CHẠY

### 1️⃣ Cấu hình SQL Server
Mở file `application.properties` và cập nhật:
```properties
spring.datasource.url=jdbc:sqlserver://localhost:1433;databaseName=drivenow_db;encrypt=true;trustServerCertificate=true
spring.datasource.username=sa
spring.datasource.password=YourPassword123  # ĐỔI MẬT KHẨU CỦA BẠN Ở ĐÂY
```

### 2️⃣ Tạo Database
```sql
CREATE DATABASE drivenow_db;
```

### 3️⃣ Cấu hình Email (Gmail)
Để gửi OTP, bạn cần cấu hình Gmail:

1. Đăng nhập Gmail của bạn
2. Truy cập: https://myaccount.google.com/security
3. Bật **"2-Step Verification"**
4. Tạo **App Password**: https://myaccount.google.com/apppasswords
5. Cập nhật trong `application.properties`:

```properties
spring.mail.username=your-email@gmail.com       # Email của bạn
spring.mail.password=your-app-password          # App Password vừa tạo
```

### 4️⃣ Cấu hình Google OAuth (Tùy chọn - cho LoginGGController)
Hiện tại LoginGGController chưa implement. Nếu muốn dùng:
1. Tạo Google OAuth Client ID tại: https://console.cloud.google.com/
2. Cập nhật trong `application.properties`:
```properties
google.client.id=your-google-client-id.apps.googleusercontent.com
google.client.secret=your-google-client-secret
```

---

## 🚀 CHẠY PROJECT

### Cách 1: Dùng Maven Wrapper (Khuyến nghị)
```powershell
# Build project
.\mvnw clean install

# Run application
.\mvnw spring-boot:run
```

### Cách 2: Dùng IDE (IntelliJ IDEA / Eclipse)
1. Import project as Maven project
2. Run `DrivenowApplication.java`

Server sẽ chạy tại: **http://localhost:8080/api**

---

## 📡 API ENDPOINTS

### 🔐 AUTHENTICATION ENDPOINTS (Public - không cần token)

#### 1. Đăng ký (Register)
**POST** `/api/auth/register`
```json
{
  "username": "customer@gmail.com",
  "password": "123456",
  "role": "customer",
  "fullName": "Nguyễn Văn A",
  "phone": "0987654321",
  "address": "123 Đường ABC, TP.HCM",
  "dob": "2000-01-15",
  "gender": "male"
}
```

**Cho Driver:**
```json
{
  "username": "driver@gmail.com",
  "password": "123456",
  "role": "driver",
  "fullName": "Trần Văn B",
  "licenseNumber": "B2-123456",
  "yearsOfExperience": 5,
  "idCard": "001234567890",
  "address": "456 Đường XYZ, Hà Nội"
}
```

#### 2. Đăng nhập (Login)
**POST** `/api/auth/login`
```json
{
  "username": "customer@gmail.com",
  "password": "123456"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Đăng nhập thành công",
  "data": {
    "token": "eyJhbGciOiJIUzUxMiJ9...",
    "type": "Bearer",
    "accountId": 1,
    "username": "customer@gmail.com",
    "role": "customer",
    "fullName": "Nguyễn Văn A",
    "message": "Đăng nhập thành công"
  }
}
```

#### 3. Quên mật khẩu - Bước 1: Gửi OTP
**POST** `/api/auth/forgot-password`
```json
{
  "email": "customer@gmail.com"
}
```

#### 4. Quên mật khẩu - Bước 2: Reset password với OTP
**POST** `/api/auth/reset-password`
```json
{
  "email": "customer@gmail.com",
  "otpCode": "123456",
  "newPassword": "newpass123"
}
```

#### 5. Google Login (Chưa implement)
**POST** `/api/auth/google-login`
```json
{
  "idToken": "google-id-token-here"
}
```

---

### 🔒 AUTHENTICATED ENDPOINTS (Cần token)

**Lưu ý:** Thêm header vào mọi request:
```
Authorization: Bearer <your-jwt-token>
```

#### 6. Đăng xuất (Logout)
**POST** `/api/auth/logout`

#### 7. Đổi mật khẩu (Change Password)
**POST** `/api/profile/change-password`
```json
{
  "oldPassword": "123456",
  "newPassword": "newpass789",
  "confirmPassword": "newpass789"
}
```

#### 8. Lấy thông tin Profile
**GET** `/api/profile/me`

**Response (Customer):**
```json
{
  "success": true,
  "message": "Lấy thông tin thành công",
  "data": {
    "customerId": 1,
    "fullName": "Nguyễn Văn A",
    "phone": "0987654321",
    "email": "customer@gmail.com",
    "address": "123 Đường ABC",
    "dob": "2000-01-15",
    "gender": "male",
    "avatarUrl": null
  }
}
```

#### 9. Cập nhật Profile
**PUT** `/api/profile/update`
```json
{
  "fullName": "Nguyễn Văn A Updated",
  "phone": "0912345678",
  "address": "New Address",
  "avatarUrl": "https://example.com/avatar.jpg"
}
```

#### 10. Xóa tài khoản (Soft delete)
**DELETE** `/api/profile/delete`

---

## 🧪 TEST API VỚI POSTMAN

### 1. Đăng ký Customer
```
POST http://localhost:8080/api/auth/register
Body (JSON):
{
  "username": "test@gmail.com",
  "password": "123456",
  "role": "customer",
  "fullName": "Test User",
  "phone": "0123456789",
  "gender": "male"
}
```

### 2. Đăng nhập
```
POST http://localhost:8080/api/auth/login
Body (JSON):
{
  "username": "test@gmail.com",
  "password": "123456"
}
```

**Copy token từ response**

### 3. Lấy Profile (cần token)
```
GET http://localhost:8080/api/profile/me
Headers:
Authorization: Bearer <paste-token-here>
```

---

## 🔥 ROLES & PERMISSIONS

### Roles trong hệ thống:
- **customer**: Khách hàng thuê xe
- **driver**: Tài xế
- **admin**: Quản trị viên (tạo manual, không qua đăng ký)

### Phân quyền:
- `/api/auth/**`: Public (không cần đăng nhập)
- `/api/profile/**`: Authenticated (cần đăng nhập)
- Update profile: Chỉ CUSTOMER & DRIVER

---

## 🛠️ CÔNG NGHỆ SỬ DỤNG

- **Spring Boot 3.5.6** - Framework chính
- **Spring Security** - Authentication & Authorization
- **JWT (JSON Web Token)** - Stateless authentication
- **Spring Data JPA** - ORM
- **Hibernate** - JPA implementation
- **SQL Server** - Database
- **Spring Mail** - Gửi email OTP
- **Lombok** - Giảm boilerplate code
- **Bean Validation** - Validate input

---

## 📋 DATABASE SCHEMA

Hệ thống tự động tạo tables khi chạy (hibernate.ddl-auto=update):

- **Account** - Tài khoản (username, password, role, status)
- **Customer** - Thông tin khách hàng (1-1 với Account)
- **Driver** - Thông tin tài xế (1-1 với Account)
- **Admin** - Thông tin admin (1-1 với Account)
- **OTP** - Lưu mã OTP cho forgot password

---

## ⚠️ LƯU Ý QUAN TRỌNG

1. **JWT Secret**: Đổi `jwt.secret` trong `application.properties` khi deploy production
2. **Database Password**: Không commit password thật vào Git
3. **Email Config**: Dùng App Password, không dùng password Gmail thật
4. **OTP Expiration**: Mặc định 5 phút (300000ms)
5. **JWT Expiration**: Mặc định 24 giờ (86400000ms)

---

## 🐛 TROUBLESHOOTING

### Lỗi kết nối SQL Server:
```
Error: Connection refused
```
**Giải pháp:**
- Kiểm tra SQL Server đã chạy chưa
- Kiểm tra port 1433 có mở không
- Bật TCP/IP trong SQL Server Configuration Manager

### Lỗi gửi email:
```
Error: Authentication failed
```
**Giải pháp:**
- Kiểm tra đã bật 2-Step Verification
- Sử dụng App Password thay vì password Gmail
- Kiểm tra firewall không block port 587

### Lỗi JWT:
```
Error: JWT signature does not match
```
**Giải pháp:**
- Kiểm tra `jwt.secret` có đủ dài không (tối thiểu 256 bits)
- Xóa token cũ và đăng nhập lại

---

## 📞 LIÊN HỆ

Nếu có vấn đề, hãy kiểm tra:
1. Console log (có error gì không)
2. Database đã tạo chưa
3. Application.properties đã config đúng chưa

---

## ✅ CHECKLIST TRƯỚC KHI CHẠY

- [ ] Đã cài SQL Server
- [ ] Đã tạo database `drivenow_db`
- [ ] Đã cập nhật `spring.datasource.password`
- [ ] Đã cấu hình Gmail (nếu cần OTP)
- [ ] Đã chạy `mvnw clean install`
- [ ] Port 8080 không bị chiếm

**Chúc bạn code thành công! 🎉**
