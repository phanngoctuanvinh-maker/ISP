# 📊 TÓM TẮT THAY ĐỔI CẤU TRÚC DATABASE - CAR_TYPE & SEAT_CAPACITY

## 🔄 Thay đổi Database Schema

### Before (Cũ):
```sql
- seats INTEGER          -- Bị trùng với seat_capacity, gây nhầm lẫn
- seat_capacity INTEGER  -- Số ghế
```

### After (Mới):
```sql
- car_type VARCHAR(50)       -- Loại xe: Mini, Sedan, SUV, MPV, Pickup, Minivan
- seat_capacity INTEGER      -- Số ghế: 4, 5, 7
```

## ✅ FILES ĐÃ SỬA XONG

### 1. Backend - Java Files

#### ✅ Car.java (Model)
**Thay đổi:**
```java
// CŨ:
@Column(name = "seats", nullable = false)
private Integer seats;

// MỚI:
@Column(name = "car_type", length = 50)
private String carType;

@Column(name = "seat_capacity", nullable = false)
private Integer seatCapacity;
```

**Getters/Setters:**
- Xóa: `getSeats()`, `setSeats()`
- Thêm: `getCarType()`, `setCarType()`
- Giữ: `getSeatCapacity()`, `setSeatCapacity()`

---

#### ✅ CarRepository.java (DAO)
**Thay đổi:**
```java
// CŨ:
List<Car> findBySeats(Integer seats);

// MỚI:
List<Car> findBySeatCapacity(Integer seatCapacity);
List<Car> findByCarTypeIgnoreCase(String carType);  // Thêm mới
```

**Query Method:**
```java
// CŨ:
@Query("... AND (:seats IS NULL OR c.seats = :seats)")
List<Car> searchCars(..., @Param("seats") Integer seats);

// MỚI:
@Query("... AND (:seatCapacity IS NULL OR c.seatCapacity = :seatCapacity)")
List<Car> searchCars(..., @Param("seatCapacity") Integer seatCapacity);
```

---

#### ✅ SearchCarService.java (Service Layer)
**Thay đổi:**
```java
// CŨ:
public List<Car> searchCars(String filterType, String brand, String transmissionType, 
                            Integer seats, String fuelType)

// MỚI:
public List<Car> searchCars(String filterType, String brand, String transmissionType, 
                            Integer seatCapacity, String fuelType)
```

**Switch Case:**
```java
// CŨ:
case "type" -> {
    results = (seats != null) ? carRepository.findBySeats(seats) : new ArrayList<>();
}

// MỚI:
case "type" -> {
    results = (seatCapacity != null) ? carRepository.findBySeatCapacity(seatCapacity) : new ArrayList<>();
}
```

---

#### ✅ SearchCarController.java (REST API)
**Thay đổi:**
```java
// CŨ:
@GetMapping("/by-type")
public ResponseEntity<SearchCarResponse> getCarsByType(@RequestParam Integer seats) {
    ...
    List<Car> cars = searchCarService.searchCars("type", null, null, seats, null);
    ...
}

// MỚI:
@GetMapping("/by-type")
public ResponseEntity<SearchCarResponse> getCarsByType(@RequestParam Integer seatCapacity) {
    ...
    List<Car> cars = searchCarService.searchCars("type", null, null, seatCapacity, null);
    ...
}
```

**API Endpoint thay đổi:**
- CŨ: `GET /api/cars/by-type?seats=4`
- MỚI: `GET /api/cars/by-type?seatCapacity=4`

---

#### ✅ SearchCarRequest.java (DTO)
**Thay đổi:**
```java
// CŨ:
private Integer seats;
public Integer getSeats() { return seats; }
public void setSeats(Integer seats) { this.seats = seats; }

// MỚI:
private Integer seatCapacity;
public Integer getSeatCapacity() { return seatCapacity; }
public void setSeatCapacity(Integer seatCapacity) { this.seatCapacity = seatCapacity; }
```

---

### 2. Database - SQL Files

#### ✅ insert_cars_NEW_STRUCTURE.sql
**Cấu trúc mới:**
```sql
INSERT INTO cars (
    brand, model, name, year, color, 
    car_type,        -- MỚI: Loại xe
    seat_capacity,   -- Số ghế
    fuel_type, transmission_type, 
    daily_rate, price_per_day, description, mileage, 
    image_url, status, license_plate, insurance_info, location, 
    created_at, updated_at
) VALUES (
    'Toyota', 'Vios', 'Toyota Vios 2024', 2024, 'Trắng',
    'Sedan',    -- car_type
    4,          -- seat_capacity
    'Gasoline', 'Automatic',
    ...
);
```

**Dữ liệu mẫu (30 xe):**
- Mini: 1 xe (Mazda 2)
- Sedan: 6 xe (Vios, City, Accord, Mazda 3, Accent...)
- SUV 5 chỗ: 7 xe (Corolla Cross, CR-V, CX-5, Territory, Seltos, Tucson, VF5, VF8)
- SUV 7 chỗ: 10 xe (Fortuner, BR-V, CX-8, Everest, Sorento, Santa Fe, VF9, Outlander, Pajero)
- MPV: 3 xe (Innova, Stargazer, Xpander)
- Pickup: 1 xe (Ranger)
- Minivan: 1 xe (Carnival)

---

### 3. Frontend - JavaScript Files

#### ⚠️ searchcar.js (CẦN SỬA)
**File hiện tại:** Bị corrupt (83KB), cần xóa và tạo lại

**Cần sửa:**
1. **API Call:**
```javascript
// CŨ:
const response = await fetch(`${API_BASE_URL}/cars/by-type?seats=${seats}`);

// MỚI:
const response = await fetch(`${API_BASE_URL}/cars/by-type?seatCapacity=${seatCapacity}`);
```

2. **Variable Names:**
```javascript
// CŨ:
let seats;
switch(carType) {
    case 'mini': seats = 4; break;
    ...
}

// MỚI:
let seatCapacity;
switch(carType) {
    case 'mini': seatCapacity = 4; break;
    ...
}
```

3. **Render Function:**
```javascript
// CŨ:
const seats = car.seats || car.seatCapacity || 'N/A';

// MỚI:
const seatCapacity = car.seatCapacity || car.seat_capacity || 'N/A';
```

---

## 📊 MAPPING LOẠI XE

| UI Label | data-type | car_type | seat_capacity | API Call |
|----------|-----------|----------|---------------|----------|
| 4 Chỗ Mini | mini | Mini | 4 | `?seatCapacity=4` |
| 4 Chỗ Sedan | sedan | Sedan | 4 | `?seatCapacity=4` |
| 5 Chỗ CUV Gầm cao | cuv-5 | SUV | 5 | `?seatCapacity=5` |
| 7 Chỗ CUV Gầm cao | suv-7 | SUV | 7 | `?seatCapacity=7` |
| 7 Chỗ MPV Gầm thấp | mpv | MPV | 7 | `?seatCapacity=7` |
| Bán tải | pickup | Pickup | 4 | `?seatCapacity=4` |
| Minivan | minivan | Minivan | 7 | `?seatCapacity=7` |

---

## 🧪 TEST APIs

### 1. Test lấy tất cả xe:
```bash
GET http://localhost:8080/api/cars/all
```

### 2. Test lấy xe theo số ghế:
```bash
# Xe 4 chỗ (Mini, Sedan, Pickup):
GET http://localhost:8080/api/cars/by-type?seatCapacity=4

# Xe 5 chỗ (SUV):
GET http://localhost:8080/api/cars/by-type?seatCapacity=5

# Xe 7 chỗ (SUV, MPV, Minivan):
GET http://localhost:8080/api/cars/by-type?seatCapacity=7
```

### 3. Test lấy xe theo hãng:
```bash
GET http://localhost:8080/api/cars/by-brand?brand=Toyota
GET http://localhost:8080/api/cars/by-brand?brand=Vinfast
```

### 4. Test lấy xe điện:
```bash
GET http://localhost:8080/api/cars/electric
# Kỳ vọng: 3 xe Vinfast (VF5, VF8, VF9)
```

### 5. Test lấy xe hybrid:
```bash
GET http://localhost:8080/api/cars/hybrid
# Kỳ vọng: 1 xe (Mitsubishi Outlander PHEV)
```

### 6. Test tìm kiếm nâng cao:
```bash
POST http://localhost:8080/api/cars/search
Content-Type: application/json

{
    "filterType": "type",
    "seatCapacity": 7
}
```

---

## 🚀 CÁC BƯỚC TRIỂN KHAI

### Bước 1: Update Database ✅
```sql
-- Chạy script mới trong SQL Server:
E:\DriveNowPorject\DRIVENOW_ISP\DRIVENOW_ISP\Project1\insert_cars_NEW_STRUCTURE.sql
```

### Bước 2: Backend đã sửa xong ✅
- Car.java ✅
- CarRepository.java ✅
- SearchCarService.java ✅
- SearchCarController.java ✅
- SearchCarRequest.java ✅

### Bước 3: Start Backend ✅
```powershell
cd E:\DriveNowPorject\DRIVENOW_ISP\DRIVENOW_ISP\Project1
.\start-backend-window.bat
```

### Bước 4: Sửa Frontend ⚠️
```powershell
# Xóa file cũ bị corrupt:
Remove-Item "E:\DriveNowPorject\DRIVENOW_ISP\DRIVENOW_ISP\DriveNow\js\searchcar.js"

# Tạo file mới với code đúng (xem HUONG_DAN_SUA_SEARCHCAR_JS.md)
```

### Bước 5: Test ✅
1. Test API bằng Postman
2. Test UI trên browser
3. Test các filter: Tất cả, Loại Xe, Hãng Xe, Truyền động, Xe Điện, Xe Hybrid

---

## 📝 LƯU Ý QUAN TRỌNG

### ❌ Không dùng nữa:
- `seats` field
- `findBySeats()` method
- `GET /api/cars/by-type?seats=4`

### ✅ Dùng thay thế:
- `car_type` (String) - Loại xe
- `seat_capacity` (Integer) - Số ghế
- `findBySeatCapacity()` method
- `GET /api/cars/by-type?seatCapacity=4`

### 🔍 Ý nghĩa:
- **`car_type`**: Phân loại xe theo kiểu dáng (Mini, Sedan, SUV, MPV, Pickup, Minivan)
- **`seat_capacity`**: Số ghế ngồi thực tế (4, 5, 7, 9...)

### 💡 Ví dụ:
```
Toyota Fortuner:
- car_type: "SUV"
- seat_capacity: 7

Mazda 2:
- car_type: "Mini"
- seat_capacity: 4

Kia Carnival:
- car_type: "Minivan"
- seat_capacity: 7
```

---

## 📧 HỖ TRỢ

Nếu gặp lỗi:
1. Kiểm tra database đã update chưa
2. Kiểm tra backend build thành công không
3. Kiểm tra API endpoint đúng chưa
4. Kiểm tra frontend đã sửa đúng parameter chưa
5. Xem file hướng dẫn: `HUONG_DAN_SUA_SEARCHCAR_JS.md`

---

**Tạo ngày:** 2025-10-21  
**Trạng thái:** Backend hoàn thành ✅ | Frontend cần sửa ⚠️
