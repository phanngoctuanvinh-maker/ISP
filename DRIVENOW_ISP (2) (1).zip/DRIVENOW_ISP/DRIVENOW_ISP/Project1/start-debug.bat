@echo off
echo Starting DriveNow Backend...
echo.
echo Press Ctrl+C to stop the server
echo.
cd /d "%~dp0"
call mvnw.cmd spring-boot:run
pause
