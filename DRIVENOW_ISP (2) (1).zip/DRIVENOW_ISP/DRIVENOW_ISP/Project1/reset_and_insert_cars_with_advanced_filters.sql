-- ========================================
-- RESET & INSERT CARS DATA WITH ADVANCED FILTER COLUMNS
-- Database: drivenow_db
-- Created: October 21, 2025
-- Purpose: Xóa dữ liệu cũ và insert lại với daily_km_limit, exceed_fee_per_km, fuel_consumption
-- ========================================

USE drivenow_db;
GO

-- ========================================
-- BƯỚC 1: XÓA TẤT CẢ DỮ LIỆU CŨ
-- ========================================
PRINT '========================================';
PRINT 'STEP 1: Deleting old car data...';
PRINT '========================================';

DELETE FROM [dbo].[cars];
GO

-- Reset IDENTITY counter về 1
DBCC CHECKIDENT ('[dbo].[cars]', RESEED, 0);
GO

PRINT '✅ All old data deleted!';
PRINT '';

-- ========================================
-- BƯỚC 2: INSERT DỮ LIỆU MỚI (30 CARS)
-- ========================================
PRINT '========================================';
PRINT 'STEP 2: Inserting new car data...';
PRINT '========================================';

SET IDENTITY_INSERT [dbo].[cars] ON;
GO

-- ========================================
-- MINI (4 chỗ) - 1 car
-- ========================================
INSERT INTO [dbo].[cars] (
    [id], [brand], [color], [daily_rate], [description], [fuel_type], [license_plate], 
    [mileage], [model], [name], [seat_capacity], [status], [transmission_type], [year], 
    [created_at], [image_url], [insurance_info], [location], [price_per_day], [updated_at], 
    [car_type], [daily_km_limit], [exceed_fee_per_km], [fuel_consumption]
) VALUES
(1, 'Mazda', 'Đỏ', 400000, 'Xe nhỏ gọn, dễ lái, tiết kiệm nhiên liệu', 'Gasoline', '30A-12345', 5000, '2', 'Mazda 2 2024', 4, 'Available', 'Manual', 2024, GETDATE(), 'https://example.com/mazda-2.jpg', 'Bảo hiểm đầy đủ', 'Hà Nội', 400000, GETDATE(), 'Mini', 300, 3000, 5.5);

-- ========================================
-- SEDAN (4 chỗ) - 6 cars
-- ========================================
INSERT INTO [dbo].[cars] (
    [id], [brand], [color], [daily_rate], [description], [fuel_type], [license_plate], 
    [mileage], [model], [name], [seat_capacity], [status], [transmission_type], [year], 
    [created_at], [image_url], [insurance_info], [location], [price_per_day], [updated_at], 
    [car_type], [daily_km_limit], [exceed_fee_per_km], [fuel_consumption]
) VALUES
(2, 'Toyota', 'Trắng', 450000, 'Xe sedan nhỏ nhắn, phù hợp đi phố', 'Gasoline', '30A-23456', 15000, 'Vios', 'Toyota Vios 2024', 4, 'Available', 'Automatic', 2024, GETDATE(), 'https://example.com/toyota-vios.jpg', 'Bảo hiểm đầy đủ', 'Hà Nội', 450000, GETDATE(), 'Sedan', 250, 3500, 6.0),
(3, 'Honda', 'Bạc', 480000, 'Sedan sang trọng, tiết kiệm nhiên liệu', 'Gasoline', '30A-34567', 12000, 'City', 'Honda City 2024', 4, 'Available', 'Automatic', 2024, GETDATE(), 'https://example.com/honda-city.jpg', 'Bảo hiểm đầy đủ', 'Hà Nội', 480000, GETDATE(), 'Sedan', 300, 3000, 5.8),
(4, 'Honda', 'Đen', 750000, 'Sedan cao cấp, động cơ mạnh mẽ', 'Gasoline', '30A-45678', 8000, 'Accord', 'Honda Accord 2024', 4, 'Available', 'Automatic', 2024, GETDATE(), 'https://example.com/honda-accord.jpg', 'Bảo hiểm đầy đủ', 'Hà Nội', 750000, GETDATE(), 'Sedan', NULL, 0, 7.5),
(5, 'Mazda', 'Xanh', 520000, 'Sedan thể thao, thiết kế đẹp mắt', 'Gasoline', '30A-56789', 10000, '3', 'Mazda 3 2024', 4, 'Available', 'Automatic', 2024, GETDATE(), 'https://example.com/mazda-3.jpg', 'Bảo hiểm đầy đủ', 'Hà Nội', 520000, GETDATE(), 'Sedan', 250, 4000, 6.2),
(6, 'Hyundai', 'Trắng', 420000, 'Sedan giá rẻ, phù hợp sinh viên', 'Gasoline', '30A-67890', 18000, 'Accent', 'Hyundai Accent 2024', 4, 'Available', 'Manual', 2024, GETDATE(), 'https://example.com/hyundai-accent.jpg', 'Bảo hiểm đầy đủ', 'Hà Nội', 420000, GETDATE(), 'Sedan', 200, 3500, 5.5),
(7, 'Hyundai', 'Xám', 680000, 'Sedan cao cấp, nội thất sang trọng', 'Gasoline', '30A-78901', 9000, 'Elantra', 'Hyundai Elantra 2024', 4, 'Available', 'Automatic', 2024, GETDATE(), 'https://example.com/hyundai-elantra.jpg', 'Bảo hiểm đầy đủ', 'Hà Nội', 680000, GETDATE(), 'Sedan', 350, 3000, 6.8);

-- ========================================
-- SUV/CUV (5 chỗ) - 9 cars
-- ========================================
INSERT INTO [dbo].[cars] (
    [id], [brand], [color], [daily_rate], [description], [fuel_type], [license_plate], 
    [mileage], [model], [name], [seat_capacity], [status], [transmission_type], [year], 
    [created_at], [image_url], [insurance_info], [location], [price_per_day], [updated_at], 
    [car_type], [daily_km_limit], [exceed_fee_per_km], [fuel_consumption]
) VALUES
(8, 'Toyota', 'Đen', 650000, 'SUV 5 chỗ, năng động, gầm cao', 'Gasoline', '30A-23456', 8000, 'Corolla Cross', 'Toyota Corolla Cross 2024', 5, 'Available', 'Automatic', 2024, GETDATE(), 'https://example.com/toyota-cross.jpg', 'Bảo hiểm đầy đủ', 'Hà Nội', 650000, GETDATE(), 'SUV', 300, 3500, 7.0),
(9, 'Honda', 'Trắng', 850000, 'SUV 5 chỗ, rộng rãi, tiện nghi', 'Gasoline', '30A-34567', 6000, 'CR-V', 'Honda CR-V 2024', 5, 'Available', 'Automatic', 2024, GETDATE(), 'https://example.com/honda-crv.jpg', 'Bảo hiểm đầy đủ', 'Hà Nội', 850000, GETDATE(), 'SUV', NULL, 0, 8.2),
(10, 'Mazda', 'Đỏ', 780000, 'SUV 5 chỗ, thiết kế thể thao', 'Gasoline', '30A-45678', 7000, 'CX-5', 'Mazda CX-5 2024', 5, 'Available', 'Automatic', 2024, GETDATE(), 'https://example.com/mazda-cx5.jpg', 'Bảo hiểm đầy đủ', 'Hà Nội', 780000, GETDATE(), 'SUV', 350, 3000, 7.8),
(11, 'Hyundai', 'Xanh', 720000, 'SUV 5 chỗ, giá tốt, tiện nghi', 'Gasoline', '30A-56789', 9000, 'Tucson', 'Hyundai Tucson 2024', 5, 'Available', 'Automatic', 2024, GETDATE(), 'https://example.com/hyundai-tucson.jpg', 'Bảo hiểm đầy đủ', 'Hà Nội', 720000, GETDATE(), 'SUV', 300, 3500, 7.5),
(12, 'Kia', 'Trắng', 680000, 'SUV 5 chỗ, thiết kế hiện đại', 'Gasoline', '30A-67890', 8500, 'Seltos', 'Kia Seltos 2024', 5, 'Available', 'Automatic', 2024, GETDATE(), 'https://example.com/kia-seltos.jpg', 'Bảo hiểm đầy đủ', 'Hà Nội', 680000, GETDATE(), 'SUV', 250, 4000, 7.2),
(13, 'Ford', 'Xám', 950000, 'SUV 5 chỗ, mạnh mẽ, off-road tốt', 'Diesel', '30A-78901', 5000, 'Territory', 'Ford Territory 2024', 5, 'Available', 'Automatic', 2024, GETDATE(), 'https://example.com/ford-territory.jpg', 'Bảo hiểm đầy đủ', 'Hà Nội', 950000, GETDATE(), 'SUV', NULL, 0, 8.5),
(14, 'Mitsubishi', 'Trắng', 620000, 'SUV 5 chỗ, tiết kiệm nhiên liệu', 'Gasoline', '30A-89012', 11000, 'Outlander', 'Mitsubishi Outlander 2024', 5, 'Available', 'Automatic', 2024, GETDATE(), 'https://example.com/mitsubishi-outlander.jpg', 'Bảo hiểm đầy đủ', 'Hà Nội', 620000, GETDATE(), 'SUV', 300, 3000, 7.0),
(15, 'Vinfast', 'Xanh', 750000, 'SUV 5 chỗ, xe điện, thân thiện môi trường', 'Electric', '30A-90123', 3000, 'VF5', 'Vinfast VF5 2024', 5, 'Available', 'Automatic', 2024, GETDATE(), 'https://example.com/vinfast-vf5.jpg', 'Bảo hiểm đầy đủ', 'Hà Nội', 750000, GETDATE(), 'SUV', NULL, 0, 0.0),
(16, 'Vinfast', 'Đen', 950000, 'SUV 5 chỗ, xe điện cao cấp', 'Electric', '30A-01234', 2000, 'VF8', 'Vinfast VF8 2024', 5, 'Available', 'Automatic', 2024, GETDATE(), 'https://example.com/vinfast-vf8.jpg', 'Bảo hiểm đầy đủ', 'Hà Nội', 950000, GETDATE(), 'SUV', NULL, 0, 0.0);

-- ========================================
-- SUV (7 chỗ) - 10 cars
-- ========================================
INSERT INTO [dbo].[cars] (
    [id], [brand], [color], [daily_rate], [description], [fuel_type], [license_plate], 
    [mileage], [model], [name], [seat_capacity], [status], [transmission_type], [year], 
    [created_at], [image_url], [insurance_info], [location], [price_per_day], [updated_at], 
    [car_type], [daily_km_limit], [exceed_fee_per_km], [fuel_consumption]
) VALUES
(17, 'Toyota', 'Trắng', 900000, 'SUV 7 chỗ, cao cấp, mạnh mẽ', 'Diesel', '30A-34567', 12000, 'Fortuner', 'Toyota Fortuner 2024', 7, 'Available', 'Automatic', 2024, GETDATE(), 'https://example.com/toyota-fortuner.jpg', 'Bảo hiểm đầy đủ', 'Hà Nội', 900000, GETDATE(), 'SUV', 400, 3000, 9.5),
(18, 'Ford', 'Đen', 950000, 'SUV 7 chỗ, off-road tốt, động cơ diesel', 'Diesel', '30A-45678', 10000, 'Everest', 'Ford Everest 2024', 7, 'Available', 'Automatic', 2024, GETDATE(), 'https://example.com/ford-everest.jpg', 'Bảo hiểm đầy đủ', 'Hà Nội', 950000, GETDATE(), 'SUV', NULL, 0, 10.0),
(19, 'Hyundai', 'Xám', 880000, 'SUV 7 chỗ, rộng rãi, tiện nghi', 'Diesel', '30A-56789', 9000, 'Santa Fe', 'Hyundai Santa Fe 2024', 7, 'Available', 'Automatic', 2024, GETDATE(), 'https://example.com/hyundai-santafe.jpg', 'Bảo hiểm đầy đủ', 'Hà Nội', 880000, GETDATE(), 'SUV', 350, 3500, 9.0),
(20, 'Kia', 'Trắng', 850000, 'SUV 7 chỗ, thiết kế sang trọng', 'Diesel', '30A-67890', 11000, 'Sorento', 'Kia Sorento 2024', 7, 'Available', 'Automatic', 2024, GETDATE(), 'https://example.com/kia-sorento.jpg', 'Bảo hiểm đầy đủ', 'Hà Nội', 850000, GETDATE(), 'SUV', 300, 4000, 8.8),
(21, 'Mazda', 'Đỏ', 920000, 'SUV 7 chỗ, cao cấp, thể thao', 'Diesel', '30A-78901', 8000, 'CX-9', 'Mazda CX-9 2024', 7, 'Available', 'Automatic', 2024, GETDATE(), 'https://example.com/mazda-cx9.jpg', 'Bảo hiểm đầy đủ', 'Hà Nội', 920000, GETDATE(), 'SUV', NULL, 0, 9.5),
(22, 'Honda', 'Xanh', 1050000, 'SUV 7 chỗ, cao cấp nhất phân khúc', 'Gasoline', '30A-89012', 5000, 'Pilot', 'Honda Pilot 2024', 7, 'Available', 'Automatic', 2024, GETDATE(), 'https://example.com/honda-pilot.jpg', 'Bảo hiểm đầy đủ', 'Hà Nội', 1050000, GETDATE(), 'SUV', NULL, 0, 11.0),
(23, 'Vinfast', 'Đen', 1200000, 'SUV 7 chỗ, xe điện cao cấp', 'Electric', '30A-90123', 2500, 'VF9', 'Vinfast VF9 2024', 7, 'Available', 'Automatic', 2024, GETDATE(), 'https://example.com/vinfast-vf9.jpg', 'Bảo hiểm đầy đủ', 'Hà Nội', 1200000, GETDATE(), 'SUV', NULL, 0, 0.0),
(24, 'Mitsubishi', 'Trắng', 780000, 'SUV 7 chỗ, giá tốt, bền bỉ', 'Diesel', '30A-01234', 13000, 'Pajero Sport', 'Mitsubishi Pajero Sport 2024', 7, 'Available', 'Manual', 2024, GETDATE(), 'https://example.com/mitsubishi-pajero.jpg', 'Bảo hiểm đầy đủ', 'Hà Nội', 780000, GETDATE(), 'SUV', 300, 3500, 9.0),
(25, 'Ford', 'Xám', 820000, 'SUV 7 chỗ, thiết kế Mỹ, mạnh mẽ', 'Gasoline', '30A-12345', 9500, 'Explorer', 'Ford Explorer 2024', 7, 'Available', 'Automatic', 2024, GETDATE(), 'https://example.com/ford-explorer.jpg', 'Bảo hiểm đầy đủ', 'Hà Nội', 820000, GETDATE(), 'SUV', 350, 3000, 10.5),
(26, 'Kia', 'Trắng', 870000, 'SUV 7 chỗ, nội thất cao cấp', 'Diesel', '30A-23456', 7500, 'Telluride', 'Kia Telluride 2024', 7, 'Available', 'Automatic', 2024, GETDATE(), 'https://example.com/kia-telluride.jpg', 'Bảo hiểm đầy đủ', 'Hà Nội', 870000, GETDATE(), 'SUV', NULL, 0, 9.2);

-- ========================================
-- MPV (7 chỗ) - 3 cars
-- ========================================
INSERT INTO [dbo].[cars] (
    [id], [brand], [color], [daily_rate], [description], [fuel_type], [license_plate], 
    [mileage], [model], [name], [seat_capacity], [status], [transmission_type], [year], 
    [created_at], [image_url], [insurance_info], [location], [price_per_day], [updated_at], 
    [car_type], [daily_km_limit], [exceed_fee_per_km], [fuel_consumption]
) VALUES
(27, 'Toyota', 'Xám', 550000, 'MPV 7 chỗ, phù hợp gia đình, rộng rãi', 'Gasoline', '30A-45678', 20000, 'Innova', 'Toyota Innova 2024', 7, 'Available', 'Manual', 2024, GETDATE(), 'https://example.com/toyota-innova.jpg', 'Bảo hiểm đầy đủ', 'Hà Nội', 550000, GETDATE(), 'MPV', 250, 3500, 8.0),
(28, 'Mitsubishi', 'Bạc', 480000, 'MPV 7 chỗ, giá rẻ, tiện nghi', 'Gasoline', '30A-56789', 15000, 'Xpander', 'Mitsubishi Xpander 2024', 7, 'Available', 'Automatic', 2024, GETDATE(), 'https://example.com/mitsubishi-xpander.jpg', 'Bảo hiểm đầy đủ', 'Hà Nội', 480000, GETDATE(), 'MPV', 200, 4000, 7.5),
(29, 'Suzuki', 'Trắng', 420000, 'MPV 7 chỗ, nhỏ gọn, tiết kiệm', 'Gasoline', '30A-67890', 18000, 'Ertiga', 'Suzuki Ertiga 2024', 7, 'Available', 'Manual', 2024, GETDATE(), 'https://example.com/suzuki-ertiga.jpg', 'Bảo hiểm đầy đủ', 'Hà Nội', 420000, GETDATE(), 'MPV', 200, 3500, 6.8);

-- ========================================
-- MINIVAN (7 chỗ) - 1 car (Hybrid)
-- ========================================
INSERT INTO [dbo].[cars] (
    [id], [brand], [color], [daily_rate], [description], [fuel_type], [license_plate], 
    [mileage], [model], [name], [seat_capacity], [status], [transmission_type], [year], 
    [created_at], [image_url], [insurance_info], [location], [price_per_day], [updated_at], 
    [car_type], [daily_km_limit], [exceed_fee_per_km], [fuel_consumption]
) VALUES
(30, 'Kia', 'Đen', 980000, 'Minivan 7 chỗ, sang trọng, rộng rãi nhất', 'Hybrid', '30A-78901', 4000, 'Carnival', 'Kia Carnival 2024', 7, 'Available', 'Automatic', 2024, GETDATE(), 'https://example.com/kia-carnival.jpg', 'Bảo hiểm đầy đủ', 'Hà Nội', 980000, GETDATE(), 'Minivan', NULL, 0, 6.5);

SET IDENTITY_INSERT [dbo].[cars] OFF;
GO

-- ========================================
-- BƯỚC 3: VERIFY DỮ LIỆU
-- ========================================
PRINT '';
PRINT '========================================';
PRINT 'STEP 3: Verifying inserted data...';
PRINT '========================================';

-- Đếm tổng số xe
SELECT 
    COUNT(*) as [Total Cars],
    'Expected: 30 cars' as [Note]
FROM [dbo].[cars];

-- Đếm theo seat_capacity
SELECT 
    [seat_capacity] as [Seats],
    COUNT(*) as [Count],
    CASE 
        WHEN [seat_capacity] = 4 THEN 'Expected: 7 cars'
        WHEN [seat_capacity] = 5 THEN 'Expected: 9 cars'
        WHEN [seat_capacity] = 7 THEN 'Expected: 14 cars'
    END as [Note]
FROM [dbo].[cars]
GROUP BY [seat_capacity]
ORDER BY [seat_capacity];

-- Đếm theo car_type
SELECT 
    [car_type] as [Type],
    COUNT(*) as [Count]
FROM [dbo].[cars]
GROUP BY [car_type]
ORDER BY [car_type];

-- Đếm theo fuel_type
SELECT 
    [fuel_type] as [Fuel],
    COUNT(*) as [Count]
FROM [dbo].[cars]
GROUP BY [fuel_type]
ORDER BY [fuel_type];

-- Kiểm tra advanced filter columns
SELECT 
    COUNT(*) as [Total],
    SUM(CASE WHEN [daily_km_limit] IS NULL THEN 1 ELSE 0 END) as [Unlimited KM],
    SUM(CASE WHEN [exceed_fee_per_km] = 0 THEN 1 ELSE 0 END) as [Free Fee],
    AVG(CAST([fuel_consumption] as FLOAT)) as [Avg Fuel Consumption],
    'All 30 cars should have advanced filter data' as [Note]
FROM [dbo].[cars];

-- Hiển thị 5 xe đầu tiên
PRINT '';
PRINT '========================================';
PRINT 'First 5 cars preview:';
PRINT '========================================';

SELECT TOP 5
    [id],
    [brand],
    [model],
    [name],
    [seat_capacity],
    [car_type],
    [price_per_day],
    [daily_km_limit],
    [exceed_fee_per_km],
    [fuel_consumption]
FROM [dbo].[cars]
ORDER BY [id];

PRINT '';
PRINT '========================================';
PRINT '✅ COMPLETED SUCCESSFULLY!';
PRINT '========================================';
PRINT 'Total: 30 cars inserted';
PRINT 'All advanced filter columns populated';
PRINT 'Ready to test Advanced Filter API!';
PRINT '========================================';
GO
