USE drivenow_db;
GO

PRINT 'Bat dau them du lieu mau Module 3...';
GO

-- Them Promotions
INSERT INTO promotions (name, description, discount_type, discount_value, min_order_value, max_discount_amount, start_date, end_date, usage_limit, used_count, status, created_at, updated_at)
VALUES 
(N'Chao mung khach hang moi', N'Giam 50,000 VND cho khach hang dang ky lan dau tien', N'FIXED_AMOUNT', 50000, 200000, NULL, '2024-01-01', '2025-12-31', 500, 0, N'ACTIVE', GETDATE(), GETDATE()),
(N'Summer Sale 2025', N'Giam 20% cho tat ca don hang trong mua he - Toi da 200k', N'PERCENTAGE', 20, 300000, 200000, '2025-06-01', '2025-08-31', 100, 0, N'ACTIVE', GETDATE(), GETDATE()),
(N'Weekend Special', N'Uu dai cuoi tuan - Giam 15% cho don tu 250k', N'PERCENTAGE', 15, 250000, 150000, '2024-01-01', '2025-12-31', 200, 0, N'ACTIVE', GETDATE(), GETDATE()),
(N'Flash Sale Thang 10', N'Flash Sale dac biet - Giam ngay 100,000 VND', N'FIXED_AMOUNT', 100000, 500000, NULL, '2025-10-01', '2025-10-31', 50, 0, N'ACTIVE', GETDATE(), GETDATE()),
(N'VIP Member Exclusive', N'Uu dai dac biet cho thanh vien VIP - Giam 25%', N'PERCENTAGE', 25, 400000, 300000, '2024-01-01', '2025-12-31', 30, 0, N'ACTIVE', GETDATE(), GETDATE()),
(N'Giam 200k Don Lon', N'Don hang tu 1 trieu - Giam ngay 200,000 VND', N'FIXED_AMOUNT', 200000, 1000000, NULL, '2024-01-01', '2025-12-31', 20, 0, N'ACTIVE', GETDATE(), GETDATE());

PRINT 'Da them 6 Promotions';
GO

-- Lay promotion_id va them promo codes
DECLARE @promo1 BIGINT, @promo2 BIGINT, @promo3 BIGINT, @promo4 BIGINT, @promo5 BIGINT, @promo6 BIGINT;

SELECT @promo1 = promotion_id FROM promotions WHERE name = N'Chao mung khach hang moi' AND created_at >= DATEADD(MINUTE, -1, GETDATE());
SELECT @promo2 = promotion_id FROM promotions WHERE name = N'Summer Sale 2025' AND created_at >= DATEADD(MINUTE, -1, GETDATE());
SELECT @promo3 = promotion_id FROM promotions WHERE name = N'Weekend Special' AND created_at >= DATEADD(MINUTE, -1, GETDATE());
SELECT @promo4 = promotion_id FROM promotions WHERE name = N'Flash Sale Thang 10' AND created_at >= DATEADD(MINUTE, -1, GETDATE());
SELECT @promo5 = promotion_id FROM promotions WHERE name = N'VIP Member Exclusive' AND created_at >= DATEADD(MINUTE, -1, GETDATE());
SELECT @promo6 = promotion_id FROM promotions WHERE name = N'Giam 200k Don Lon' AND created_at >= DATEADD(MINUTE, -1, GETDATE());

INSERT INTO promo_codes (promotion_id, code, single_use, max_uses, used_count, min_order_value, created_at, expires_at)
VALUES 
(@promo1, N'NEWUSER', 0, 500, 0, 200000, GETDATE(), '2025-12-31 23:59:59'),
(@promo2, N'SUMMER2025', 0, 100, 0, 300000, GETDATE(), '2025-08-31 23:59:59'),
(@promo3, N'WEEKEND20', 0, 200, 0, 250000, GETDATE(), '2025-12-31 23:59:59'),
(@promo4, N'FLASH100K', 0, 50, 0, 500000, GETDATE(), '2025-10-31 23:59:59'),
(@promo5, N'VIP30', 0, 30, 0, 400000, GETDATE(), '2025-12-31 23:59:59'),
(@promo6, N'SAVE200K', 0, 20, 0, 1000000, GETDATE(), '2025-12-31 23:59:59');

PRINT 'Da them 6 Promo Codes';
GO

-- Hien thi ket qua
PRINT '';
PRINT '========================================';
PRINT 'DANH SACH PROMOTIONS VUA THEM:';
SELECT TOP 10 promotion_id AS ID, name AS Ten, discount_type AS Loai, discount_value AS GiaTri, status AS TrangThai
FROM promotions WHERE created_at >= DATEADD(MINUTE, -2, GETDATE()) ORDER BY promotion_id DESC;

PRINT '';
PRINT 'DANH SACH PROMO CODES VUA THEM:';
SELECT TOP 10 pc.promo_code_id AS ID, pc.code AS MaCode, p.name AS KhuyenMai, p.discount_value AS GiaTri
FROM promo_codes pc
INNER JOIN promotions p ON pc.promotion_id = p.promotion_id
WHERE pc.created_at >= DATEADD(MINUTE, -2, GETDATE()) ORDER BY pc.promo_code_id DESC;

PRINT '';
PRINT 'CAC MA GIAM GIA BAN CO THE TEST:';
PRINT '1. NEWUSER      - Giam 50k (don tu 200k)';
PRINT '2. SUMMER2025   - Giam 20% (don tu 300k, toi da 200k)';
PRINT '3. WEEKEND20    - Giam 15% (don tu 250k, toi da 150k)';
PRINT '4. FLASH100K    - Giam 100k (don tu 500k)';
PRINT '5. VIP30        - Giam 25% (don tu 400k, toi da 300k)';
PRINT '6. SAVE200K     - Giam 200k (don tu 1 trieu)';
PRINT '';
PRINT 'HOAN THANH! Du lieu da san sang test.';
GO
