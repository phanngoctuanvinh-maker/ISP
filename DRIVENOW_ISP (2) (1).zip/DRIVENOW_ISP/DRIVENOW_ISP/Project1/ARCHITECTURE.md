# 🏗️ KIẾN TRÚC HỆ THỐNG DRIVENOW

## 📐 LAYERED ARCHITECTURE

```
┌─────────────────────────────────────────────────────────────┐
│                      CLIENT LAYER                            │
│         (Web Browser, Mobile App, Postman, etc.)             │
└─────────────────────────────────────────────────────────────┘
                            ↓ HTTP/HTTPS
┌─────────────────────────────────────────────────────────────┐
│                    CONTROLLER LAYER                          │
│  ┌──────────────────┐  ┌──────────────────┐                 │
│  │ LoginController  │  │ RegisterController│                 │
│  └──────────────────┘  └──────────────────┘                 │
│  ┌──────────────────┐  ┌──────────────────┐                 │
│  │LogoutController  │  │ ProfileController │                 │
│  └──────────────────┘  └──────────────────┘                 │
│  ┌──────────────────┐  ┌──────────────────┐                 │
│  │ForgotPassword    │  │ChangePassword    │                 │
│  │Controller        │  │Controller        │                 │
│  └──────────────────┘  └──────────────────┘                 │
│  ┌──────────────────┐                                        │
│  │LoginGGController │                                        │
│  └──────────────────┘                                        │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│                     SERVICE LAYER                            │
│  ┌──────────────────┐  ┌──────────────────┐                 │
│  │   AuthService    │  │ ProfileService   │                 │
│  │                  │  │                  │                 │
│  │ - register()     │  │ - getProfile()   │                 │
│  │ - login()        │  │ - updateProfile()│                 │
│  │ - changePassword│  │ - deleteProfile()│                 │
│  │ - forgotPassword│  │                  │                 │
│  │ - resetPassword │  │                  │                 │
│  └──────────────────┘  └──────────────────┘                 │
│  ┌──────────────────┐  ┌──────────────────┐                 │
│  │   EmailService   │  │   OTPService     │                 │
│  │                  │  │                  │                 │
│  │ - sendOTP()      │  │ - generateOTP()  │                 │
│  │ - sendWelcome()  │  │ - verifyOTP()    │                 │
│  └──────────────────┘  └──────────────────┘                 │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│                      DAO LAYER                               │
│  ┌──────────────────┐  ┌──────────────────┐                 │
│  │   AccountDAO     │  │   CustomerDAO    │                 │
│  └──────────────────┘  └──────────────────┘                 │
│  ┌──────────────────┐  ┌──────────────────┐                 │
│  │   DriverDAO      │  │    AdminDAO      │                 │
│  └──────────────────┘  └──────────────────┘                 │
│  ┌──────────────────┐                                        │
│  │     OTPDAO       │                                        │
│  └──────────────────┘                                        │
└─────────────────────────────────────────────────────────────┘
                            ↓ JPA/Hibernate
┌─────────────────────────────────────────────────────────────┐
│                     MODEL LAYER                              │
│  ┌──────────────────┐  ┌──────────────────┐                 │
│  │     Account      │  │    Customer      │                 │
│  │                  │  │                  │                 │
│  │ - accountId      │←─┤ - customerId    │                 │
│  │ - username       │  │ - fullName       │                 │
│  │ - password       │  │ - email          │                 │
│  │ - role           │  │ - phone          │                 │
│  │ - status         │  │ - address        │                 │
│  └──────────────────┘  └──────────────────┘                 │
│  ┌──────────────────┐  ┌──────────────────┐                 │
│  │     Driver       │  │      Admin       │                 │
│  │                  │  │                  │                 │
│  │ - driverId       │←─┤ - adminId       │                 │
│  │ - licenseNumber  │  │ - role           │                 │
│  │ - yearsOfExp     │  │                  │                 │
│  └──────────────────┘  └──────────────────┘                 │
│  ┌──────────────────┐                                        │
│  │       OTP        │                                        │
│  │                  │                                        │
│  │ - otpId          │                                        │
│  │ - email          │                                        │
│  │ - otpCode        │                                        │
│  │ - expirationTime │                                        │
│  └──────────────────┘                                        │
└─────────────────────────────────────────────────────────────┘
                            ↓ JDBC
┌─────────────────────────────────────────────────────────────┐
│                   SQL SERVER DATABASE                        │
│                      (drivenow_db)                           │
└─────────────────────────────────────────────────────────────┘
```

---

## 🔐 SECURITY FLOW

```
┌──────────────┐
│   Client     │
│  (Browser)   │
└──────┬───────┘
       │ 1. POST /auth/login
       │    {username, password}
       ↓
┌─────────────────────────────────┐
│    LoginController              │
└──────┬──────────────────────────┘
       │ 2. Call authService.login()
       ↓
┌─────────────────────────────────┐
│      AuthService                │
│                                 │
│  3. authenticationManager       │
│     .authenticate()             │
└──────┬──────────────────────────┘
       │
       ↓
┌─────────────────────────────────┐
│  CustomUserDetailsService       │
│                                 │
│  4. loadUserByUsername()        │
│     → Query AccountDAO          │
└──────┬──────────────────────────┘
       │ 5. Return UserDetails
       ↓
┌─────────────────────────────────┐
│      AuthService                │
│                                 │
│  6. jwtTokenProvider            │
│     .generateToken()            │
└──────┬──────────────────────────┘
       │ 7. Return JWT Token
       ↓
┌──────────────┐
│   Client     │  Lưu token vào:
│              │  - LocalStorage
│              │  - Cookie
│              │  - Memory
└──────────────┘
```

---

## 🔄 REQUEST FLOW (Authenticated)

```
┌──────────────┐
│   Client     │
└──────┬───────┘
       │ GET /profile/me
       │ Header: Authorization: Bearer <token>
       ↓
┌─────────────────────────────────┐
│  JwtAuthenticationFilter        │
│                                 │
│  1. Extract token from header   │
│  2. Validate token              │
│  3. Get username from token     │
└──────┬──────────────────────────┘
       │
       ↓
┌─────────────────────────────────┐
│  CustomUserDetailsService       │
│                                 │
│  4. Load user details           │
└──────┬──────────────────────────┘
       │
       ↓
┌─────────────────────────────────┐
│  SecurityContextHolder          │
│                                 │
│  5. Set authentication          │
└──────┬──────────────────────────┘
       │ 6. Continue filter chain
       ↓
┌─────────────────────────────────┐
│     ProfileController           │
│                                 │
│  7. Process request             │
└──────┬──────────────────────────┘
       │ 8. Call ProfileService
       ↓
┌─────────────────────────────────┐
│      ProfileService             │
│                                 │
│  9. Query DAO → Get data        │
└──────┬──────────────────────────┘
       │ 10. Return data
       ↓
┌──────────────┐
│   Client     │  Receive JSON response
└──────────────┘
```

---

## 📧 OTP FLOW (Forgot Password)

```
┌──────────────┐
│   Client     │
└──────┬───────┘
       │ 1. POST /auth/forgot-password
       │    {email}
       ↓
┌─────────────────────────────────┐
│  ForgotPasswordController       │
└──────┬──────────────────────────┘
       │ 2. authService.forgotPassword()
       ↓
┌─────────────────────────────────┐
│      AuthService                │
│                                 │
│  3. Check email exists          │
│     in AccountDAO               │
└──────┬──────────────────────────┘
       │ 4. Generate OTP
       ↓
┌─────────────────────────────────┐
│       OTPService                │
│                                 │
│  5. Generate 6-digit code       │
│  6. Save to OTPDAO              │
│     (expiration: 5 min)         │
└──────┬──────────────────────────┘
       │ 7. Send OTP
       ↓
┌─────────────────────────────────┐
│      EmailService               │
│                                 │
│  8. Send email via SMTP         │
│     (Gmail)                     │
└──────┬──────────────────────────┘
       │ 9. Success response
       ↓
┌──────────────┐
│   Client     │  "OTP đã gửi đến email"
└──────┬───────┘
       │
       │ User nhận email → Nhập OTP
       │
       │ 10. POST /auth/reset-password
       │     {email, otpCode, newPassword}
       ↓
┌─────────────────────────────────┐
│  ForgotPasswordController       │
└──────┬──────────────────────────┘
       │ 11. authService.resetPassword()
       ↓
┌─────────────────────────────────┐
│      AuthService                │
│                                 │
│  12. otpService.verifyOTP()     │
└──────┬──────────────────────────┘
       │ 13. If valid
       ↓
┌─────────────────────────────────┐
│      AuthService                │
│                                 │
│  14. Update password (encrypt)  │
│  15. Mark OTP as used           │
└──────┬──────────────────────────┘
       │ 16. Success
       ↓
┌──────────────┐
│   Client     │  "Đặt lại mật khẩu thành công"
└──────────────┘
```

---

## 🗄️ DATABASE RELATIONSHIPS

```
┌─────────────────┐
│     Account     │
│                 │
│  PK: account_id │
│      username   │
│      password   │
│      role       │
│      status     │
└────────┬────────┘
         │
         │ 1:1
    ┌────┴────┬────────────┬─────────────┐
    │         │            │             │
    ↓         ↓            ↓             ↓
┌─────────┐┌─────────┐┌─────────┐   ┌─────────┐
│Customer ││ Driver  ││  Admin  │   │   OTP   │
│         ││         ││         │   │(separate)│
│FK:      ││FK:      ││FK:      │   │         │
│account_id││account_id││account_id│   │ email   │
└─────────┘└─────────┘└─────────┘   │ otpCode │
                                    └─────────┘
```

---

## 🛡️ SECURITY COMPONENTS

```
┌─────────────────────────────────────────────┐
│           SecurityConfig                    │
│                                             │
│  - Configure HTTP Security                  │
│  - CORS configuration                       │
│  - JWT filter chain                         │
│  - Password encoder (BCrypt)                │
│  - AuthenticationManager                    │
└──────────────┬──────────────────────────────┘
               │
       ┌───────┴────────┬──────────────────┐
       │                │                  │
       ↓                ↓                  ↓
┌─────────────┐ ┌──────────────┐ ┌─────────────────┐
│JwtToken     │ │JwtAuth       │ │CustomUserDetails│
│Provider     │ │Filter        │ │Service          │
│             │ │              │ │                 │
│- generate   │ │- validate    │ │- loadUserBy     │
│- validate   │ │- extract     │ │  Username       │
│- getUsername│ │- authenticate│ │                 │
└─────────────┘ └──────────────┘ └─────────────────┘
```

---

## 📦 PACKAGE STRUCTURE

```
com.carrentleproject.drivenow
│
├── config/                 # Configuration classes
│   ├── SecurityConfig
│   ├── JwtTokenProvider
│   ├── JwtAuthenticationFilter
│   └── CustomUserDetailsService
│
├── controller/             # REST Controllers
│   ├── LoginController
│   ├── LogoutController
│   ├── RegisterController
│   ├── LoginGGController
│   ├── ForgotPasswordController
│   ├── ChangePasswordController
│   └── ProfileController
│
├── service/               # Business Logic
│   ├── AuthService
│   ├── ProfileService
│   ├── EmailService
│   └── OTPService
│
├── dao/                   # Data Access Objects
│   ├── AccountDAO
│   ├── CustomerDAO
│   ├── DriverDAO
│   ├── AdminDAO
│   └── OTPDAO
│
├── model/                 # JPA Entities
│   ├── Account
│   ├── Customer
│   ├── Driver
│   ├── Admin
│   └── OTP
│
├── dto/                   # Data Transfer Objects
│   ├── LoginRequest
│   ├── RegisterRequest
│   ├── ChangePasswordRequest
│   ├── ForgotPasswordRequest
│   ├── ResetPasswordRequest
│   ├── ProfileUpdateRequest
│   ├── GoogleLoginRequest
│   ├── AuthResponse
│   └── ApiResponse
│
├── exception/             # Exception Handling
│   ├── GlobalExceptionHandler
│   ├── ResourceNotFoundException
│   ├── BadRequestException
│   └── UnauthorizedException
│
└── DrivenowApplication    # Main Application Class
```

---

## 🔄 DATA FLOW

```
Request → Controller → Service → DAO → Database
                ↓         ↓       ↓
              DTO   Business   Entity
                    Logic
                      ↓
                  Validation
                  Exception
                  Handling
```

---

**Kiến trúc này đảm bảo:**
- ✅ Separation of Concerns
- ✅ Loose Coupling
- ✅ High Cohesion
- ✅ Easy Testing
- ✅ Scalability
- ✅ Maintainability
