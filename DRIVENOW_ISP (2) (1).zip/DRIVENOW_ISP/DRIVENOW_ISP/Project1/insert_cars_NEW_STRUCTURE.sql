-- ========================================
-- INSERT CARS DATA - CẤU TRÚC MỚI
-- car_type: Loại xe (Mini, Sedan, SUV, MPV...)
-- seat_capacity: Số ghế (4, 5, 7...)
-- ========================================

-- Toyota (4 xe)
INSERT INTO cars (brand, model, name, year, color, car_type, seat_capacity, fuel_type, transmission_type, daily_rate, price_per_day, description, mileage, image_url, status, license_plate, insurance_info, location, created_at, updated_at)
VALUES 
('Toyota', 'Vios', 'Toyota Vios 2024', 2024, 'Trắng', 'Sedan', 4, 'Gasoline', 'Automatic', 450000, 450000, 'Xe sedan tiết kiệm nhiên liệu, phù hợp đi phố', 15000, 'https://example.com/toyota-vios.jpg', 'Available', '30A-12345', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),

('Toyota', 'Corolla Cross', 'Toyota Corolla Cross 2024', 2024, 'Đen', 'SUV', 5, 'Gasoline', 'Automatic', 650000, 650000, 'SUV 5 chỗ năng động, gầm cao', 8000, 'https://example.com/toyota-cross.jpg', 'Available', '30A-23456', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),

('Toyota', 'Fortuner', 'Toyota Fortuner 2024', 2024, 'Bạc', 'SUV', 7, 'Diesel', 'Automatic', 900000, 900000, 'SUV 7 chỗ cao cấp, mạnh mẽ', 12000, 'https://example.com/toyota-fortuner.jpg', 'Available', '30A-34567', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),

('Toyota', 'Innova', 'Toyota Innova 2024', 2024, 'Xám', 'MPV', 7, 'Gasoline', 'Manual', 550000, 550000, 'MPV 7 chỗ phổ biến, rộng rãi', 20000, 'https://example.com/toyota-innova.jpg', 'Available', '30A-45678', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE());

-- Honda (4 xe)
INSERT INTO cars (brand, model, name, year, color, car_type, seat_capacity, fuel_type, transmission_type, daily_rate, price_per_day, description, mileage, image_url, status, license_plate, insurance_info, location, created_at, updated_at)
VALUES 
('Honda', 'City', 'Honda City 2024', 2024, 'Đỏ', 'Sedan', 4, 'Gasoline', 'Automatic', 480000, 480000, 'Sedan thể thao, trẻ trung', 10000, 'https://example.com/honda-city.jpg', 'Available', '30B-12345', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),

('Honda', 'CR-V', 'Honda CR-V 2024', 2024, 'Trắng ngọc trai', 'SUV', 5, 'Gasoline', 'Automatic', 750000, 750000, 'SUV 5 chỗ sang trọng', 7000, 'https://example.com/honda-crv.jpg', 'Available', '30B-23456', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),

('Honda', 'Accord', 'Honda Accord 2024', 2024, 'Xanh đen', 'Sedan', 4, 'Gasoline', 'Automatic', 850000, 850000, 'Sedan cao cấp, sang trọng', 5000, 'https://example.com/honda-accord.jpg', 'Available', '30B-34567', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),

('Honda', 'BR-V', 'Honda BR-V 2024', 2024, 'Xám bạc', 'SUV', 7, 'Gasoline', 'Automatic', 600000, 600000, 'SUV 7 chỗ linh hoạt', 15000, 'https://example.com/honda-brv.jpg', 'Available', '30B-45678', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE());

-- Mazda (4 xe)
INSERT INTO cars (brand, model, name, year, color, car_type, seat_capacity, fuel_type, transmission_type, daily_rate, price_per_day, description, mileage, image_url, status, license_plate, insurance_info, location, created_at, updated_at)
VALUES 
('Mazda', '3', 'Mazda 3 2024', 2024, 'Đỏ pha lê', 'Sedan', 4, 'Gasoline', 'Automatic', 520000, 520000, 'Sedan thể thao, thiết kế đẹp', 8000, 'https://example.com/mazda3.jpg', 'Available', '30C-12345', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),

('Mazda', 'CX-5', 'Mazda CX-5 2024', 2024, 'Xanh dương', 'SUV', 5, 'Gasoline', 'Automatic', 700000, 700000, 'SUV 5 chỗ premium', 10000, 'https://example.com/mazda-cx5.jpg', 'Available', '30C-23456', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),

('Mazda', 'CX-8', 'Mazda CX-8 2024', 2024, 'Trắng', 'SUV', 7, 'Diesel', 'Automatic', 950000, 950000, 'SUV 7 chỗ cao cấp nhất', 6000, 'https://example.com/mazda-cx8.jpg', 'Available', '30C-34567', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),

('Mazda', '2', 'Mazda 2 2024', 2024, 'Bạc', 'Mini', 4, 'Gasoline', 'Automatic', 420000, 420000, 'Hatchback nhỏ gọn, tiện lợi', 12000, 'https://example.com/mazda2.jpg', 'Available', '30C-45678', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE());

-- Ford (3 xe)
INSERT INTO cars (brand, model, name, year, color, car_type, seat_capacity, fuel_type, transmission_type, daily_rate, price_per_day, description, mileage, image_url, status, license_plate, insurance_info, location, created_at, updated_at)
VALUES 
('Ford', 'Ranger', 'Ford Ranger 2024', 2024, 'Cam', 'Pickup', 4, 'Diesel', 'Manual', 800000, 800000, 'Bán tải mạnh mẽ', 18000, 'https://example.com/ford-ranger.jpg', 'Available', '30D-12345', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),

('Ford', 'Everest', 'Ford Everest 2024', 2024, 'Đen', 'SUV', 7, 'Diesel', 'Automatic', 1000000, 1000000, 'SUV 7 chỗ địa hình', 9000, 'https://example.com/ford-everest.jpg', 'Available', '30D-23456', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),

('Ford', 'Territory', 'Ford Territory 2024', 2024, 'Xanh', 'SUV', 5, 'Gasoline', 'Automatic', 650000, 650000, 'SUV 5 chỗ hiện đại', 7000, 'https://example.com/ford-territory.jpg', 'Available', '30D-34567', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE());

-- Kia (3 xe)
INSERT INTO cars (brand, model, name, year, color, car_type, seat_capacity, fuel_type, transmission_type, daily_rate, price_per_day, description, mileage, image_url, status, license_plate, insurance_info, location, created_at, updated_at)
VALUES 
('Kia', 'Seltos', 'Kia Seltos 2024', 2024, 'Cam đồng', 'SUV', 5, 'Gasoline', 'Automatic', 580000, 580000, 'SUV 5 chỗ trẻ trung', 11000, 'https://example.com/kia-seltos.jpg', 'Available', '30E-12345', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),

('Kia', 'Sorento', 'Kia Sorento 2024', 2024, 'Nâu', 'SUV', 7, 'Diesel', 'Automatic', 880000, 880000, 'SUV 7 chỗ sang trọng', 8000, 'https://example.com/kia-sorento.jpg', 'Available', '30E-23456', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),

('Kia', 'Carnival', 'Kia Carnival 2024', 2024, 'Trắng', 'Minivan', 7, 'Diesel', 'Automatic', 1200000, 1200000, 'Minivan hạng sang 7-9 chỗ', 5000, 'https://example.com/kia-carnival.jpg', 'Available', '30E-34567', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE());

-- Hyundai (4 xe)
INSERT INTO cars (brand, model, name, year, color, car_type, seat_capacity, fuel_type, transmission_type, daily_rate, price_per_day, description, mileage, image_url, status, license_plate, insurance_info, location, created_at, updated_at)
VALUES 
('Hyundai', 'Accent', 'Hyundai Accent 2024', 2024, 'Trắng', 'Sedan', 4, 'Gasoline', 'Automatic', 440000, 440000, 'Sedan phổ thông, tiết kiệm', 14000, 'https://example.com/hyundai-accent.jpg', 'Available', '30F-12345', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),

('Hyundai', 'Tucson', 'Hyundai Tucson 2024', 2024, 'Xám', 'SUV', 5, 'Gasoline', 'Automatic', 720000, 720000, 'SUV 5 chỗ thông minh', 9000, 'https://example.com/hyundai-tucson.jpg', 'Available', '30F-23456', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),

('Hyundai', 'Santa Fe', 'Hyundai Santa Fe 2024', 2024, 'Đen', 'SUV', 7, 'Diesel', 'Automatic', 920000, 920000, 'SUV 7 chỗ cao cấp', 7000, 'https://example.com/hyundai-santafe.jpg', 'Available', '30F-34567', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),

('Hyundai', 'Stargazer', 'Hyundai Stargazer 2024', 2024, 'Bạc', 'MPV', 7, 'Gasoline', 'Automatic', 500000, 500000, 'MPV 7 chỗ giá tốt', 10000, 'https://example.com/hyundai-stargazer.jpg', 'Available', '30F-45678', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE());

-- Vinfast (3 xe - Điện)
INSERT INTO cars (brand, model, name, year, color, car_type, seat_capacity, fuel_type, transmission_type, daily_rate, price_per_day, description, mileage, image_url, status, license_plate, insurance_info, location, created_at, updated_at)
VALUES 
('Vinfast', 'VF5', 'Vinfast VF5 Plus 2024', 2024, 'Xanh lá', 'SUV', 5, 'Electric', 'Automatic', 550000, 550000, 'SUV điện 5 chỗ nhỏ gọn', 3000, 'https://example.com/vinfast-vf5.jpg', 'Available', '30G-12345', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),

('Vinfast', 'VF8', 'Vinfast VF8 2024', 2024, 'Xanh dương', 'SUV', 5, 'Electric', 'Automatic', 900000, 900000, 'SUV điện 5 chỗ cao cấp', 2000, 'https://example.com/vinfast-vf8.jpg', 'Available', '30G-23456', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),

('Vinfast', 'VF9', 'Vinfast VF9 2024', 2024, 'Đen', 'SUV', 7, 'Electric', 'Automatic', 1500000, 1500000, 'SUV điện 7 chỗ hạng sang', 1000, 'https://example.com/vinfast-vf9.jpg', 'Available', '30G-34567', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE());

-- Mitsubishi (3 xe - có Hybrid)
INSERT INTO cars (brand, model, name, year, color, car_type, seat_capacity, fuel_type, transmission_type, daily_rate, price_per_day, description, mileage, image_url, status, license_plate, insurance_info, location, created_at, updated_at)
VALUES 
('Mitsubishi', 'Xpander', 'Mitsubishi Xpander 2024', 2024, 'Trắng', 'MPV', 7, 'Gasoline', 'Automatic', 520000, 520000, 'MPV 7 chỗ tiết kiệm', 13000, 'https://example.com/mitsubishi-xpander.jpg', 'Available', '30H-12345', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),

('Mitsubishi', 'Outlander', 'Mitsubishi Outlander PHEV 2024', 2024, 'Đỏ', 'SUV', 7, 'Hybrid', 'Automatic', 1100000, 1100000, 'SUV 7 chỗ hybrid (xăng & điện)', 6000, 'https://example.com/mitsubishi-outlander.jpg', 'Available', '30H-23456', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),

('Mitsubishi', 'Pajero Sport', 'Mitsubishi Pajero Sport 2024', 2024, 'Xám', 'SUV', 7, 'Diesel', 'Automatic', 850000, 850000, 'SUV 7 chỗ địa hình', 11000, 'https://example.com/mitsubishi-pajero.jpg', 'Available', '30H-34567', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE());

-- Thống kê:
-- Tổng: 30 xe
-- Loại xe:
--   - Mini: 1 xe (Mazda 2)
--   - Sedan: 6 xe (Vios, City, Accord, Mazda 3, Accent + 1)
--   - SUV 5 chỗ: 7 xe (Corolla Cross, CR-V, CX-5, Territory, Seltos, Tucson, VF5, VF8)
--   - SUV 7 chỗ: 10 xe (Fortuner, BR-V, CX-8, Everest, Sorento, Santa Fe, VF9, Outlander, Pajero Sport)
--   - MPV: 3 xe (Innova, Stargazer, Xpander)
--   - Pickup: 1 xe (Ranger)
--   - Minivan: 1 xe (Carnival)
-- Nhiên liệu:
--   - Gasoline: 20 xe
--   - Diesel: 7 xe
--   - Electric: 3 xe (Vinfast VF5, VF8, VF9)
--   - Hybrid: 1 xe (Outlander PHEV)
