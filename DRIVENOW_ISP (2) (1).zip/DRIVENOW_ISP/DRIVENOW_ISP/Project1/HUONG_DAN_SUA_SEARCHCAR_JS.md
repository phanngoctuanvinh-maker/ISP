# 📝 HƯỚNG DẪN SỬA SEARCHCAR.JS - CẤU TRÚC MỚI

## 🔄 Thay đổi Database

Bạn đã thay đổi database structure:
- ✅ **`seats`** (cũ) → **`car_type`** (mới) - Lưu loại xe (Mini, Sedan, SUV, MPV...)
- ✅ **`seat_capacity`** - Số ghế ngồi (4, 5, 7...)

## 📋 Cần sửa trong searchcar.js

### 1. Đổi tên function và parameter:

```javascript
// CŨ:
async function filterCarsByType(carType) {
    ...
    const response = await fetch(`${API_BASE_URL}/cars/by-type?seats=${seats}`);
    ...
}

// MỚI:
async function filterCarsByType(carType) {
    ...
    const response = await fetch(`${API_BASE_URL}/cars/by-type?seatCapacity=${seatCapacity}`);
    ...
}
```

### 2. Sửa mapping loại xe → số ghế:

```javascript
// Trong function filterCarsByType(carType):

let seatCapacity;  // ĐỔI TÊN từ seats sang seatCapacity
switch(carType) {
    case 'mini':        // 4 Chỗ Mini
    case 'sedan':       // 4 Chỗ Sedan
    case 'pickup':      // Bán tải
        seatCapacity = 4;
        break;
    case 'cuv-5':       // 5 Chỗ CUV Gầm cao
        seatCapacity = 5;
        break;
    case 'suv-7':       // 7 Chỗ CUV Gầm cao
    case 'mpv':         // 7 Chỗ MPV Gầm thấp
    case 'minivan':     // Minivan
        seatCapacity = 7;
        break;
    default:
        console.error('❌ Unknown car type:', carType);
        return;
}

console.log(`➡️ Fetching cars with ${seatCapacity} seats...`);
const response = await fetch(`${API_BASE_URL}/cars/by-type?seatCapacity=${seatCapacity}`);
```

### 3. Sửa render car card:

```javascript
// CŨ:
const seats = car.seats || car.seatCapacity || car.seat_capacity || 'N/A';

// MỚI:
const seatCapacity = car.seatCapacity || car.seat_capacity || 'N/A';

// Trong HTML:
'<span>' + seatCapacity + ' chỗ</span>'
```

## 📊 Mapping đầy đủ:

| Modal UI | data-type | seatCapacity | API Call |
|----------|-----------|--------------|----------|
| 4 Chỗ Mini | mini | 4 | `/api/cars/by-type?seatCapacity=4` |
| 4 Chỗ Sedan | sedan | 4 | `/api/cars/by-type?seatCapacity=4` |
| 5 Chỗ CUV Gầm cao | cuv-5 | 5 | `/api/cars/by-type?seatCapacity=5` |
| 7 Chỗ CUV Gầm cao | suv-7 | 7 | `/api/cars/by-type?seatCapacity=7` |
| 7 Chỗ MPV Gầm thấp | mpv | 7 | `/api/cars/by-type?seatCapacity=7` |
| Bán tải | pickup | 4 | `/api/cars/by-type?seatCapacity=4` |
| Minivan | minivan | 7 | `/api/cars/by-type?seatCapacity=7` |

## ✅ Backend đã sửa xong:

- ✅ Car.java - Đổi `seats` thành `carType`, giữ `seatCapacity`
- ✅ CarRepository.java - Đổi `findBySeats()` thành `findBySeatCapacity()`
- ✅ SearchCarService.java - Đổi parameter `seats` thành `seatCapacity`
- ✅ SearchCarController.java - API endpoint dùng `seatCapacity`
- ✅ SearchCarRequest.java - Đổi `seats` thành `seatCapacity`

## 📦 File SQL mới:

Đã tạo file `insert_cars_NEW_STRUCTURE.sql` với 30 xe có:
- `car_type`: Mini, Sedan, SUV, MPV, Pickup, Minivan
- `seat_capacity`: 4, 5, 7

## 🧪 Test API:

```bash
# Test lấy xe 4 chỗ:
GET http://localhost:8080/api/cars/by-type?seatCapacity=4

# Test lấy xe 5 chỗ:
GET http://localhost:8080/api/cars/by-type?seatCapacity=5

# Test lấy xe 7 chỗ:
GET http://localhost:8080/api/cars/by-type?seatCapacity=7
```

## 🚀 Các bước tiếp theo:

1. ✅ Chạy SQL script mới: `insert_cars_NEW_STRUCTURE.sql`
2. ✅ Start backend: `.\start-backend-window.bat`
3. ⚠️ Sửa searchcar.js theo hướng dẫn trên
4. ✅ Test trên Postman
5. ✅ Test trên UI

## 📝 Code searchcar.js cần sửa:

Nếu file searchcar.js bị lỗi, **XÓA file cũ** và tạo lại với code đúng như đã hướng dẫn ở trên.

**LƯU Ý:** Do file searchcar.js hiện tại bị duplicate nhiều lần (83KB), bạn nên:
1. Xóa file: `Remove-Item "e:\DriveNowPorject\DRIVENOW_ISP\DRIVENOW_ISP\DriveNow\js\searchcar.js"`
2. Tạo file mới với code sạch
3. Đảm bảo dùng `seatCapacity` thay vì `seats` ở mọi chỗ
