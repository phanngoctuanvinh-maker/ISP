# 🧪 HƯỚNG DẪN TEST API - CẤU TRÚC MỚI (seatCapacity)

## 📦 File Postman Collection
**File:** `SearchCar_API_NEW_STRUCTURE.postman_collection.json`

## 🚀 CHUẨN BỊ

### Bước 1: Chạy SQL Script
```sql
-- Trong SQL Server Management Studio, chạy file:
insert_cars_NEW_STRUCTURE.sql

-- Kiểm tra dữ liệu:
SELECT COUNT(*) FROM cars;  -- Expect: 30
SELECT DISTINCT car_type FROM cars;  -- Expect: Mini, Sedan, SUV, MPV, Pickup, Minivan
SELECT DISTINCT seat_capacity FROM cars;  -- Expect: 4, 5, 7
```

### Bước 2: Start Backend
```powershell
cd E:\DriveNowPorject\DRIVENOW_ISP\DRIVENOW_ISP\Project1
.\start-backend-window.bat
```

Đợi thấy log: `Started DriveNowApplication`

### Bước 3: Import vào Postman
1. Mở Postman
2. Click **Import** (góc trên bên trái)
3. Chọn file: `SearchCar_API_NEW_STRUCTURE.postman_collection.json`
4. Click **Import**

## ✅ TEST CASES

### Test 1: Get All Cars ⭐
```
GET http://localhost:8080/api/cars/all
```
**Expect:** 
- `success: true`
- `cars: 30 items`
- Response time < 500ms

---

### Test 2: Get Cars by Seat Capacity - 4 chỗ 🚗
```
GET http://localhost:8080/api/cars/by-type?seatCapacity=4
```
**Expect:** 
- `success: true`
- `~8 cars`: Vios, City, Accord, Mazda 3, Mazda 2, Accent, Ranger
- Tất cả có `seatCapacity: 4`

**Verification:**
```json
{
    "success": true,
    "message": "Tìm thấy 8 xe 4 chỗ",
    "cars": [
        {
            "id": 1,
            "brand": "Toyota",
            "model": "Vios",
            "carType": "Sedan",
            "seatCapacity": 4,
            ...
        }
    ]
}
```

---

### Test 3: Get Cars by Seat Capacity - 5 chỗ 🚙
```
GET http://localhost:8080/api/cars/by-type?seatCapacity=5
```
**Expect:** 
- `success: true`
- `~9 cars`: Corolla Cross, CR-V, CX-5, Territory, Seltos, Tucson, VF5, VF8
- Tất cả có `seatCapacity: 5`
- Tất cả là `carType: "SUV"`

---

### Test 4: Get Cars by Seat Capacity - 7 chỗ 🚐
```
GET http://localhost:8080/api/cars/by-type?seatCapacity=7
```
**Expect:** 
- `success: true`
- `~13 cars`: Fortuner, Innova, BR-V, CX-8, Everest, Sorento, Carnival, Santa Fe, Stargazer, VF9, Xpander, Outlander, Pajero
- Tất cả có `seatCapacity: 7`
- Mix của `carType: "SUV", "MPV", "Minivan"`

---

### Test 5: Get Cars by Brand - Toyota 🔴
```
GET http://localhost:8080/api/cars/by-brand?brand=Toyota
```
**Expect:** 
- `success: true`
- `4 cars`: Vios, Corolla Cross, Fortuner, Innova
- Tất cả có `brand: "Toyota"`

---

### Test 6: Get Cars by Brand - Vinfast ⚡
```
GET http://localhost:8080/api/cars/by-brand?brand=Vinfast
```
**Expect:** 
- `success: true`
- `3 cars`: VF5, VF8, VF9
- Tất cả có `fuelType: "Electric"`

---

### Test 7: Get Electric Cars ⚡⚡⚡
```
GET http://localhost:8080/api/cars/electric
```
**Expect:** 
- `success: true`
- `3 cars`: Vinfast VF5, VF8, VF9
- Tất cả có `fuelType: "Electric"`

**Critical Check:**
```json
{
    "cars": [
        { "brand": "Vinfast", "model": "VF5", "fuelType": "Electric", "seatCapacity": 5 },
        { "brand": "Vinfast", "model": "VF8", "fuelType": "Electric", "seatCapacity": 5 },
        { "brand": "Vinfast", "model": "VF9", "fuelType": "Electric", "seatCapacity": 7 }
    ]
}
```

---

### Test 8: Get Hybrid Cars 🔋⛽
```
GET http://localhost:8080/api/cars/hybrid
```
**Expect:** 
- `success: true`
- `1 car`: Mitsubishi Outlander PHEV
- `fuelType: "Hybrid"`

---

### Test 9: Get Cars by Transmission - Automatic ⚙️
```
GET http://localhost:8080/api/cars/by-transmission?type=Automatic
```
**Expect:** 
- `success: true`
- `~28 cars`
- Tất cả có `transmissionType: "Automatic"`

---

### Test 10: Get Cars by Transmission - Manual 🎮
```
GET http://localhost:8080/api/cars/by-transmission?type=Manual
```
**Expect:** 
- `success: true`
- `~2 cars`: Innova, Ranger
- Tất cả có `transmissionType: "Manual"`

---

### Test 11: Search Cars - POST (4 chỗ) 📮
```
POST http://localhost:8080/api/cars/search
Content-Type: application/json

{
    "filterType": "type",
    "seatCapacity": 4
}
```
**Expect:** 
- Same as Test 2
- `~8 cars` với `seatCapacity: 4`

---

### Test 12: Search Cars - POST (5 chỗ SUV) 📮
```
POST http://localhost:8080/api/cars/search
Content-Type: application/json

{
    "filterType": "type",
    "seatCapacity": 5
}
```
**Expect:** 
- Same as Test 3
- `~9 cars` với `seatCapacity: 5`

---

### Test 13: Search Cars - POST (7 chỗ) 📮
```
POST http://localhost:8080/api/cars/search
Content-Type: application/json

{
    "filterType": "type",
    "seatCapacity": 7
}
```
**Expect:** 
- Same as Test 4
- `~13 cars` với `seatCapacity: 7`

---

### Test 14: Search Cars - Advanced (Toyota + Automatic) 🔍
```
POST http://localhost:8080/api/cars/search
Content-Type: application/json

{
    "filterType": "advanced",
    "brand": "Toyota",
    "transmissionType": "Automatic"
}
```
**Expect:** 
- `success: true`
- `3 cars`: Vios, Corolla Cross, Fortuner
- Không có Innova (vì là Manual)

---

### Test 15: Get Car by ID 🆔
```
GET http://localhost:8080/api/cars/1
```
**Expect:** 
- `success: true`
- 1 car detail với full thông tin
- Có đầy đủ fields: `id`, `brand`, `model`, `carType`, `seatCapacity`, etc.

---

### Test 16: Get All Brands 🏷️
```
GET http://localhost:8080/api/cars/brands
```
**Expect:** 
- `success: true`
- `8 brands`: Toyota, Honda, Mazda, Ford, Kia, Hyundai, Vinfast, Mitsubishi

---

### Test 17: Get All Transmissions ⚙️
```
GET http://localhost:8080/api/cars/transmissions
```
**Expect:** 
- `success: true`
- `2 types`: Automatic, Manual

---

## 🔥 TEST CRITICAL SCENARIOS

### Scenario 1: Mapping Loại Xe → Số Ghế
**Test:** Click "4 Chỗ Mini" trong UI
**Expected API call:** `GET /api/cars/by-type?seatCapacity=4`
**Expected Result:** Trả về xe 4 chỗ (bao gồm Mini, Sedan, Pickup)

### Scenario 2: Electric Cars
**Test:** Click "Xe Điện" trong UI
**Expected API call:** `GET /api/cars/electric`
**Expected Result:** Chỉ trả về 3 xe Vinfast (VF5, VF8, VF9)

### Scenario 3: Hybrid Cars
**Test:** Click "Xe Xăng & Điện" trong UI
**Expected API call:** `GET /api/cars/hybrid`
**Expected Result:** Chỉ trả về 1 xe (Mitsubishi Outlander PHEV)

### Scenario 4: Multiple Filters
**Test:** Filter Toyota + Automatic + 7 chỗ
**API Call:**
```json
POST /api/cars/search
{
    "brand": "Toyota",
    "transmissionType": "Automatic",
    "seatCapacity": 7
}
```
**Expected Result:** 1 car (Toyota Fortuner)

---

## ❌ ERROR SCENARIOS

### Test Error 1: Invalid Seat Capacity
```
GET http://localhost:8080/api/cars/by-type?seatCapacity=99
```
**Expect:** 
- `success: false` hoặc empty array
- `message: "Không tìm thấy xe 99 chỗ"`

### Test Error 2: Invalid Brand
```
GET http://localhost:8080/api/cars/by-brand?brand=Ferrari
```
**Expect:** 
- `success: false` hoặc empty array
- `message: "Không tìm thấy xe Ferrari"`

### Test Error 3: Missing Parameter
```
GET http://localhost:8080/api/cars/by-type
```
**Expect:** 
- HTTP 400 Bad Request

---

## 📊 SUMMARY TABLE

| Test # | Endpoint | Method | Parameter | Expected Count |
|--------|----------|--------|-----------|----------------|
| 1 | /all | GET | - | 30 |
| 2 | /by-type | GET | seatCapacity=4 | ~8 |
| 3 | /by-type | GET | seatCapacity=5 | ~9 |
| 4 | /by-type | GET | seatCapacity=7 | ~13 |
| 5 | /by-brand | GET | brand=Toyota | 4 |
| 6 | /by-brand | GET | brand=Vinfast | 3 |
| 7 | /electric | GET | - | 3 |
| 8 | /hybrid | GET | - | 1 |
| 9 | /by-transmission | GET | type=Automatic | ~28 |
| 10 | /by-transmission | GET | type=Manual | ~2 |

---

## ✅ VALIDATION CHECKLIST

- [ ] Tất cả API trả về JSON format đúng
- [ ] Field `seatCapacity` xuất hiện trong response
- [ ] Field `carType` xuất hiện trong response
- [ ] Không có field `seats` trong response (đã xóa)
- [ ] Response time < 1 second cho mỗi request
- [ ] HTTP status code đúng (200 OK, 404 Not Found, 400 Bad Request)
- [ ] Success flag (`success: true/false`) đúng
- [ ] Message field rõ ràng và có ý nghĩa
- [ ] Data count khớp với expected count

---

## 🐛 TROUBLESHOOTING

### Issue 1: "Connection refused"
**Solution:** Backend chưa start. Chạy `.\start-backend-window.bat`

### Issue 2: "Empty array" cho tất cả requests
**Solution:** Database chưa có dữ liệu. Chạy `insert_cars_NEW_STRUCTURE.sql`

### Issue 3: "seats cannot be resolved"
**Solution:** Code chưa cập nhật đúng. Kiểm tra lại Car.java, CarRepository.java

### Issue 4: Response có cả `seats` và `seatCapacity`
**Solution:** Database còn column `seats` cũ. Drop và recreate table

---

**Created:** 2025-10-21  
**Author:** DriveNow Team  
**Version:** 2.0 (NEW STRUCTURE)
