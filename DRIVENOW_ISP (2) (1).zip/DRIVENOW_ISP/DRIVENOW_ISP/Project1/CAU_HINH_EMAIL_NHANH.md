# ⚡ HƯỚNG DẪN CẤU HÌNH EMAIL NHANH

## ❌ Lỗi hiện tại: "Authentication failed"

Backend đang cố gửi OTP qua email nhưng **chưa có thông tin đăng nhập Gmail thật**.

---

## ✅ Giải pháp (3 bước - 2 phút)

### Bước 1: Tạo App Password Gmail

1. Vào: https://myaccount.google.com/security
2. Bật **"2-Step Verification"** (nếu chưa)
3. Tìm **"App passwords"** → Tạo mật khẩu cho app **Mail**
4. Copy mật khẩu 16 ký tự (VD: `abcd efgh ijkl mnop`)

### Bước 2: Cập nhật file `application.properties`

Mở: `drivenow/src/main/resources/application.properties`

Tìm và sửa 2 dòng:

```properties
spring.mail.username=email-cua-ban@gmail.com
spring.mail.password=abcdefghijklmnop
```

**Ví dụ thực tế:**
```properties
spring.mail.username=quyenthedinh@gmail.com
spring.mail.password=xyzw abcd efgh ijkl
```

### Bước 3: Khởi động lại backend

```powershell
cd drivenow
.\start-backend.bat
```

---

## 🧪 Test ngay trên web

1. Mở: http://127.0.0.1:5500/Project1/html/forgotpassword.html
2. Nhập email: `quyenthedinh@gmail.com`
3. Click "Gửi yêu cầu"
4. Kiểm tra email → Nhận mã OTP 6 số
5. Nhập OTP và mật khẩu mới để hoàn tất

---

## 📌 Lưu ý

- Email phải **đã đăng ký** trong hệ thống trước
- Mã OTP hết hiệu lực sau **5 phút**
- App Password khác với mật khẩu Gmail thông thường

---

**Xong! Sau khi cấu hình xong, tất cả tính năng gửi email (OTP, Welcome email) sẽ hoạt động.**
