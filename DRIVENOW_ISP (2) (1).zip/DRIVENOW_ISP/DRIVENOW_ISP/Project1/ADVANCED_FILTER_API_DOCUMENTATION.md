# 🚀 ADVANCED FILTER API - HƯỚNG DẪN SỬ DỤNG

**Endpoint:** `POST http://localhost:8080/api/cars/advanced-filter`  
**Content-Type:** `application/json`

---

## 📋 CẤU TRÚC REQUEST

```json
{
  "sortBy": "price_low",
  "minPrice": 350000,
  "maxPrice": 3000000,
  "transmissionType": "Automatic",
  "minDailyKmLimit": 50,
  "maxDailyKmLimit": 500,
  "minExceedFee": 0,
  "maxExceedFee": 5000,
  "maxDistance": 50,
  "userLocation": "Hà Nội",
  "minSeatCapacity": 3,
  "maxSeatCapacity": 9,
  "minYear": 2008,
  "maxYear": 2024,
  "fuelType": "Gasoline",
  "minFuelConsumption": 1.0,
  "maxFuelConsumption": 30.0,
  "features": ["Bluetooth", "Camera 360"],
  "page": 0,
  "size": 10
}
```

---

## 🎯 CHI TIẾT CÁC THAM SỐ

### 1. **Sắp xếp (sortBy)**
- `"optimal"` - Tối ưu (mặc định)
- `"distance"` - Khoảng cách gần nhất  
- `"price_low"` - Giá thấp nhất
- `"price_high"` - Giá cao nhất
- `"rating"` - Đánh giá tốt nhất

### 2. **Mức giá (minPrice, maxPrice)**
- **Đơn vị:** VNĐ
- **Range:** 0 - 10,000,000
- **Logic:**
  - `null` = Bất kỳ
  - `minPrice: 350000` = Trên 350k
  - `maxPrice: 3000000` = Dưới 3 triệu

### 3. **Truyền động (transmissionType)**
- `null` = Tất cả
- `"Automatic"` = Số tự động
- `"Manual"` = Số sàn

### 4. **Giới hạn km/ngày (minDailyKmLimit, maxDailyKmLimit)** ⚠️
- **Đơn vị:** km/ngày
- **Range:** 0 - 500+
- **Logic đặc biệt:**
  - `null` = **Bất kỳ**
  - `minDailyKmLimit: 50` = Trên 50km/ngày
  - `minDailyKmLimit >= 500` = **KHÔNG GIỚI HẠN** (chỉ lấy xe có `daily_km_limit = null`)

**Ví dụ:**
```json
{
  "minDailyKmLimit": null,  // Bất kỳ (tất cả xe)
  "maxDailyKmLimit": null
}
```

```json
{
  "minDailyKmLimit": 50,    // Trên 50km/ngày
  "maxDailyKmLimit": null
}
```

```json
{
  "minDailyKmLimit": 500,   // Không giới hạn (chỉ xe có daily_km_limit = null)
  "maxDailyKmLimit": null
}
```

### 5. **Phí vượt giới hạn (minExceedFee, maxExceedFee)** ⚠️
- **Đơn vị:** VNĐ/km
- **Range:** 0 - 5,000+
- **Logic đặc biệt:**
  - `null` = Bất kỳ
  - `minExceedFee: 0, maxExceedFee: 0` = **MIỄN PHÍ** (chỉ lấy xe có `exceed_fee_per_km = 0 hoặc null`)
  - `maxExceedFee: 5000` = Từ dưới 5k/km
  - `maxExceedFee >= 5000` = **BẤT KỲ** (không quan tâm phí vượt)

**⚠️ LƯU Ý:** Phí vượt giới hạn chỉ hiển thị khi user đã chọn giới hạn km (không phải "Bất kỳ")

### 6. **Khoảng cách (maxDistance, userLocation)**
- **Đơn vị:** km
- **Range:** 1 - 50 km
- **Cần:** `userLocation` (TP HCM, Hà Nội, etc.)
- **Logic:**
  - `null` = Bất kỳ
  - `maxDistance: 1` = 1km trở lại
  - `maxDistance: 50` = 50km trở lại

### 7. **Số chỗ (minSeatCapacity, maxSeatCapacity)**
- **Range:** 3 - 9+
- **Logic:**
  - `null` = Bất kỳ
  - `minSeatCapacity: 3` = Trên 3 chỗ
  - `maxSeatCapacity: 9` = Trên 9 chỗ

### 8. **Năm sản xuất (minYear, maxYear)**
- **Range:** 2008 - 2024+
- **Logic:**
  - `null` = Bất kỳ
  - `minYear: 2008` = Trên 2008
  - `maxYear: 2024` = Trên 2024

### 9. **Nhiên liệu (fuelType)**
- `null` = Tất cả
- `"Gasoline"` = Xăng
- `"Diesel"` = Dầu diesel
- `"Electric"` = Điện
- `"Hybrid"` = Xăng & điện

### 10. **Mức tiêu thụ nhiên liệu (minFuelConsumption, maxFuelConsumption)**
- **Đơn vị:** L/100km
- **Range:** 1.0 - 30.0
- **Logic:**
  - `null` = Bất kỳ
  - `minFuelConsumption: 1.0` = Từ dưới 1L/100km
  - `maxFuelConsumption: 30.0` = Từ dưới 30L/100km

### 11. **Tính năng (features)**
- **Type:** Array of strings
- **Ví dụ:** `["Bản đồ", "Bluetooth", "Camera 360", "Camera cập lề", "Camera hành trình", "Cảm biến lốp", "Cảm biến va chạm", "Cảnh báo tốc độ", "Cửa sổ trời", "Định vị GPS", "Ghế trẻ em", "Khe cắm USB", "Lốp dự phòng", "Màn hình DVD"]`

### 12. **Phân trang (page, size)**
- `page`: Trang hiện tại (0-based)
- `size`: Số lượng kết quả mỗi trang
- **Ví dụ:** `page: 0, size: 10` = 10 kết quả đầu tiên

---

## 📤 CẤU TRÚC RESPONSE

```json
{
  "success": true,
  "message": "Lọc thành công",
  "cars": [
    {
      "id": 1,
      "brand": "Toyota",
      "model": "Vios",
      "name": "Toyota Vios 2024",
      "year": 2024,
      "color": "Trắng",
      "carType": "Sedan",
      "seatCapacity": 4,
      "fuelType": "Gasoline",
      "transmissionType": "Automatic",
      "pricePerDay": 450000,
      "dailyKmLimit": 300,
      "exceedFeePerKm": 4000,
      "fuelConsumption": 6.5,
      "imageUrl": "...",
      "location": "Hà Nội",
      "status": "Available"
    }
  ],
  "totalCars": 10,
  "filterCriteria": {
    "sortBy": "price_low",
    "minPrice": 350000,
    ...
  }
}
```

---

## 🧪 TEST CASES

### TC1: Lọc theo giá (350k - 1 triệu)
```json
{
  "minPrice": 350000,
  "maxPrice": 1000000,
  "sortBy": "price_low"
}
```

### TC2: Xe số tự động, 5-7 chỗ, không giới hạn km
```json
{
  "transmissionType": "Automatic",
  "minSeatCapacity": 5,
  "maxSeatCapacity": 7,
  "minDailyKmLimit": 500
}
```

### TC3: Xe điện, miễn phí vượt giới hạn
```json
{
  "fuelType": "Electric",
  "minExceedFee": 0,
  "maxExceedFee": 0
}
```

### TC4: Xe tiết kiệm nhiên liệu (dưới 8L/100km)
```json
{
  "minFuelConsumption": 1.0,
  "maxFuelConsumption": 8.0,
  "sortBy": "price_low"
}
```

### TC5: Xe mới (2024), giá cao nhất
```json
{
  "minYear": 2024,
  "sortBy": "price_high"
}
```

---

## 🔧 SETUP DATABASE

**Bước 1:** Chạy file SQL để thêm columns mới:
```sql
-- File: add_advanced_filter_columns.sql
```

**Bước 2:** Verify columns đã được tạo:
```sql
SELECT 
    id,
    name,
    daily_km_limit,
    exceed_fee_per_km,
    fuel_consumption
FROM cars;
```

---

## 🚨 LƯU Ý QUAN TRỌNG

1. **Giới hạn km/ngày:**
   - `daily_km_limit = NULL` nghĩa là **KHÔNG GIỚI HẠN**
   - User kéo slider max (500+) để tìm xe không giới hạn

2. **Phí vượt giới hạn:**
   - Chỉ hiển thị khi user đã chọn giới hạn km (không phải "Bất kỳ")
   - `exceed_fee_per_km = 0 hoặc NULL` = **MIỄN PHÍ**

3. **Sự khác biệt "Bất kỳ" vs "Không giới hạn":**
   - **Bất kỳ** (user không kéo slider): Trả về TẤT CẢ xe (có giới hạn + không giới hạn)
   - **Không giới hạn** (user kéo slider max): Chỉ trả về xe có `daily_km_limit = NULL`

4. **Xe điện:**
   - `fuel_consumption = NULL` (không áp dụng)

5. **Location filter:**
   - Cần implement logic tính khoảng cách dựa trên `userLocation` và `car.location`

---

## 📊 DATABASE SCHEMA

```sql
ALTER TABLE cars
ADD daily_km_limit INT NULL;

ALTER TABLE cars
ADD exceed_fee_per_km INT NULL;

ALTER TABLE cars
ADD fuel_consumption DECIMAL(5, 2) NULL;
```

---

**Status:** ✅ Backend Ready  
**Endpoint:** `POST /api/cars/advanced-filter`  
**Next Step:** Implement Frontend UI
