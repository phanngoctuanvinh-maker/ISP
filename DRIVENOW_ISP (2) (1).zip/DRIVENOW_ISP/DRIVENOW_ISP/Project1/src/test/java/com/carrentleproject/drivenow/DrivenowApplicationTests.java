package com.carrentleproject.drivenow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DrivenowApplicationTests {

	@Test
	void contextLoads() {
	}

}
