package com.carrentleproject.drivenow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DrivenowApplication {

	public static void main(String[] args) {
		SpringApplication.run(DrivenowApplication.class, args);
	}

}
