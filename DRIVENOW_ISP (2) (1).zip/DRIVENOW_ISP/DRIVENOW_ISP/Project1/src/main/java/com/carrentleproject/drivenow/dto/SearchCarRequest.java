package com.carrentleproject.drivenow.dto;

public class SearchCarRequest {
    private String filterType; // "all", "type", "brand", "transmission", "electric", "hybrid"
    private String brand; // Toyota, Honda, Mazda, Ford, Kia, Hyundai, Vinfast, Mitsubishi
    private String transmissionType; // "Tất cả", "Số sàn", "Số tự động"
    private Integer seatCapacity; // 4, 5, 7 (số chỗ ngồi)
    private String fuelType; // "electric", "hybrid", "gasoline", etc.

    public SearchCarRequest() {
    }

    public SearchCarRequest(String filterType, String brand, String transmissionType, Integer seatCapacity, String fuelType) {
        this.filterType = filterType;
        this.brand = brand;
        this.transmissionType = transmissionType;
        this.seatCapacity = seatCapacity;
        this.fuelType = fuelType;
    }

    // Getters and Setters
    public String getFilterType() {
        return filterType;
    }

    public void setFilterType(String filterType) {
        this.filterType = filterType;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getTransmissionType() {
        return transmissionType;
    }

    public void setTransmissionType(String transmissionType) {
        this.transmissionType = transmissionType;
    }

    public Integer getSeatCapacity() {
        return seatCapacity;
    }

    public void setSeatCapacity(Integer seatCapacity) {
        this.seatCapacity = seatCapacity;
    }

    public String getFuelType() {
        return fuelType;
    }

    public void setFuelType(String fuelType) {
        this.fuelType = fuelType;
    }
}
