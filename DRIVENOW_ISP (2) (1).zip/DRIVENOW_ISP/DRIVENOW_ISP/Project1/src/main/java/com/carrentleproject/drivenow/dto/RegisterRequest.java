package com.carrentleproject.drivenow.dto;

import jakarta.validation.constraints.*;

import java.time.LocalDate;

public class RegisterRequest {

    @NotBlank(message = "Username không được để trống")
    @Email(message = "Username phải là email hợp lệ")
    private String username; // email

    @NotBlank(message = "Password không được để trống")
    @Size(min = 6, message = "Password phải có ít nhất 6 ký tự")
    private String password;

    @NotBlank(message = "Role không được để trống")
    @Pattern(regexp = "customer|driver", message = "Role phải là 'customer' hoặc 'driver'")
    private String role; // customer, driver (admin không đăng ký public)

    @NotBlank(message = "Full name không được để trống")
    private String fullName;

    @Pattern(regexp = "^[0-9]{10,11}$", message = "Phone phải là số và có 10-11 chữ số")
    private String phone;

    private String address;

    private LocalDate dob; // Date of birth

    @Pattern(regexp = "male|female|other", message = "Gender phải là 'male', 'female' hoặc 'other'")
    private String gender;

    // Cho Driver
    private String licenseNumber;
    private Integer yearsOfExperience;
    private String idCard;

    public RegisterRequest() {
    }

    public RegisterRequest(String username, String password, String role, String fullName, String phone,
            String address, LocalDate dob, String gender, String licenseNumber,
            Integer yearsOfExperience, String idCard) {
        this.username = username;
        this.password = password;
        this.role = role;
        this.fullName = fullName;
        this.phone = phone;
        this.address = address;
        this.dob = dob;
        this.gender = gender;
        this.licenseNumber = licenseNumber;
        this.yearsOfExperience = yearsOfExperience;
        this.idCard = idCard;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public LocalDate getDob() {
        return dob;
    }

    public void setDob(LocalDate dob) {
        this.dob = dob;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getLicenseNumber() {
        return licenseNumber;
    }

    public void setLicenseNumber(String licenseNumber) {
        this.licenseNumber = licenseNumber;
    }

    public Integer getYearsOfExperience() {
        return yearsOfExperience;
    }

    public void setYearsOfExperience(Integer yearsOfExperience) {
        this.yearsOfExperience = yearsOfExperience;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }
}
