package com.carrentleproject.drivenow.dto;

import java.time.LocalDate;

public class ProfileUpdateRequest {

    private String fullName;
    private String phone;
    private String address;
    private LocalDate dob;
    private String gender;
    private String avatarUrl;

    // Cho Driver
    private String licenseNumber;
    private Integer yearsOfExperience;
    private String idCard;
    private String bio;

    public ProfileUpdateRequest() {
    }

    public ProfileUpdateRequest(String fullName, String phone, String address, LocalDate dob, String gender,
            String avatarUrl, String licenseNumber, Integer yearsOfExperience,
            String idCard, String bio) {
        this.fullName = fullName;
        this.phone = phone;
        this.address = address;
        this.dob = dob;
        this.gender = gender;
        this.avatarUrl = avatarUrl;
        this.licenseNumber = licenseNumber;
        this.yearsOfExperience = yearsOfExperience;
        this.idCard = idCard;
        this.bio = bio;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public LocalDate getDob() {
        return dob;
    }

    public void setDob(LocalDate dob) {
        this.dob = dob;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAvatarUrl() {
        return avatarUrl;
    }

    public void setAvatarUrl(String avatarUrl) {
        this.avatarUrl = avatarUrl;
    }

    public String getLicenseNumber() {
        return licenseNumber;
    }

    public void setLicenseNumber(String licenseNumber) {
        this.licenseNumber = licenseNumber;
    }

    public Integer getYearsOfExperience() {
        return yearsOfExperience;
    }

    public void setYearsOfExperience(Integer yearsOfExperience) {
        this.yearsOfExperience = yearsOfExperience;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }
}
