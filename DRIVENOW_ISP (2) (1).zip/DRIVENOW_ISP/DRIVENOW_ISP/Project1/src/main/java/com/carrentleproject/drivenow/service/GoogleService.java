package com.carrentleproject.drivenow.service;

import com.carrentleproject.drivenow.exception.BadRequestException;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.gson.GsonFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Collections;

@Service
public class GoogleService {

    @Value("${google.client.id}")
    private String googleClientId;

    /**
     * Verify Google ID Token và trả về thông tin user
     * 
     * @param idToken Google ID Token từ frontend
     * @return GoogleIdToken.Payload chứa email, name, picture
     * @throws BadRequestException nếu token không hợp lệ
     */
    public GoogleIdToken.Payload verifyGoogleToken(String idToken) {
        try {
            GoogleIdTokenVerifier verifier = new GoogleIdTokenVerifier.Builder(
                    new NetHttpTransport(),
                    GsonFactory.getDefaultInstance())
                    .setAudience(Collections.singletonList(googleClientId))
                    .build();

            GoogleIdToken googleIdToken = verifier.verify(idToken);

            if (googleIdToken == null) {
                throw new BadRequestException("Google ID Token không hợp lệ");
            }

            return googleIdToken.getPayload();

        } catch (Exception e) {
            throw new BadRequestException("Không thể xác thực Google Token: " + e.getMessage());
        }
    }

    /**
     * Extract email from Google payload
     */
    public String getEmailFromPayload(GoogleIdToken.Payload payload) {
        return payload.getEmail();
    }

    /**
     * Extract full name from Google payload
     */
    public String getNameFromPayload(GoogleIdToken.Payload payload) {
        return (String) payload.get("name");
    }

    /**
     * Extract profile picture URL from Google payload
     */
    public String getPictureFromPayload(GoogleIdToken.Payload payload) {
        return (String) payload.get("picture");
    }
}
