package com.carrentleproject.drivenow.service;

import com.carrentleproject.drivenow.dao.LoyaltyPointsRepository;
import com.carrentleproject.drivenow.dao.LoyaltyHistoryRepository;
import com.carrentleproject.drivenow.model.LoyaltyPoints;
import com.carrentleproject.drivenow.model.LoyaltyHistory;
import com.carrentleproject.drivenow.dto.LoyaltyRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
public class LoyaltyService {

    @Autowired
    private LoyaltyPointsRepository loyaltyPointsRepository;

    @Autowired
    private LoyaltyHistoryRepository loyaltyHistoryRepository;

    // Quy tắc tích điểm: 100,000 VND = 1 point
    private static final Long POINTS_RATE = 100000L;
    
    // Quy tắc đổi điểm: 1 point = 10,000 VND
    private static final Long REDEEM_RATE = 10000L;
    
    // Số điểm tối thiểu để đổi
    private static final Integer MIN_REDEEM_POINTS = 10;

    // Lấy thông tin điểm của user
    public Map<String, Object> getUserPoints(Long userId) {
        LoyaltyPoints loyalty = loyaltyPointsRepository.findByUserId(userId)
            .orElseGet(() -> {
                LoyaltyPoints newLoyalty = new LoyaltyPoints(userId);
                return loyaltyPointsRepository.save(newLoyalty);
            });

        Map<String, Object> result = new HashMap<>();
        result.put("userId", loyalty.getUserId());
        result.put("points", loyalty.getPoints());
        result.put("lifetimePoints", loyalty.getLifetimePoints());
        result.put("tier", loyalty.getTier());
        result.put("lastUpdated", loyalty.getLastUpdated());
        
        return result;
    }

    // Thêm điểm (Earn points)
    @Transactional
    public Map<String, Object> addPoints(Long userId, Long orderValue, String description) {
        // Tính số điểm được tích
        int pointsEarned = (int)(orderValue / POINTS_RATE);
        
        if (pointsEarned < 1) {
            throw new RuntimeException("Giá trị đơn hàng chưa đủ để tích điểm (tối thiểu " + POINTS_RATE + " VND)");
        }

        // Lấy hoặc tạo loyalty record
        LoyaltyPoints loyalty = loyaltyPointsRepository.findByUserId(userId)
            .orElseGet(() -> new LoyaltyPoints(userId));

        // Cập nhật điểm
        loyalty.setPoints(loyalty.getPoints() + pointsEarned);
        loyalty.setLifetimePoints(loyalty.getLifetimePoints() + pointsEarned);
        loyaltyPointsRepository.save(loyalty);

        // Lưu lịch sử
        LoyaltyHistory history = new LoyaltyHistory(
            userId,
            "EARN",
            pointsEarned,
            orderValue,
            description != null ? description : "Tích điểm từ đơn hàng " + orderValue + " VND"
        );
        loyaltyHistoryRepository.save(history);

        Map<String, Object> result = new HashMap<>();
        result.put("pointsEarned", pointsEarned);
        result.put("currentPoints", loyalty.getPoints());
        result.put("lifetimePoints", loyalty.getLifetimePoints());
        result.put("tier", loyalty.getTier());
        
        return result;
    }

    // Đổi điểm (Redeem points)
    @Transactional
    public Map<String, Object> redeemPoints(Long userId, Integer pointsToRedeem, String description) {
        // Validate điểm tối thiểu
        if (pointsToRedeem < MIN_REDEEM_POINTS) {
            throw new RuntimeException("Số điểm đổi tối thiểu là " + MIN_REDEEM_POINTS + " điểm");
        }

        // Lấy loyalty record
        LoyaltyPoints loyalty = loyaltyPointsRepository.findByUserId(userId)
            .orElseThrow(() -> new RuntimeException("User chưa có điểm thưởng"));

        // Kiểm tra đủ điểm không
        if (loyalty.getPoints() < pointsToRedeem) {
            throw new RuntimeException("Số điểm không đủ. Bạn có " + loyalty.getPoints() + " điểm");
        }

        // Tính giá trị chiết khấu
        Long discountValue = pointsToRedeem * REDEEM_RATE;

        // Trừ điểm
        loyalty.setPoints(loyalty.getPoints() - pointsToRedeem);
        loyaltyPointsRepository.save(loyalty);

        // Lưu lịch sử
        LoyaltyHistory history = new LoyaltyHistory(
            userId,
            "REDEEM",
            pointsToRedeem,
            discountValue,
            description != null ? description : "Đổi " + pointsToRedeem + " điểm lấy " + discountValue + " VND"
        );
        loyaltyHistoryRepository.save(history);

        Map<String, Object> result = new HashMap<>();
        result.put("pointsRedeemed", pointsToRedeem);
        result.put("discountValue", discountValue);
        result.put("remainingPoints", loyalty.getPoints());
        result.put("tier", loyalty.getTier());
        
        return result;
    }

    // Lấy lịch sử tích điểm
    public List<LoyaltyHistory> getUserHistory(Long userId) {
        return loyaltyHistoryRepository.findByUserIdOrderByCreatedAtDesc(userId);
    }

    // Tính số điểm từ giá trị đơn hàng
    public Map<String, Object> calculatePoints(Long orderValue) {
        int points = (int)(orderValue / POINTS_RATE);
        
        Map<String, Object> result = new HashMap<>();
        result.put("orderValue", orderValue);
        result.put("pointsEarned", points);
        result.put("rate", POINTS_RATE + " VND = 1 điểm");
        
        return result;
    }

    // Tính giá trị chiết khấu từ số điểm
    public Map<String, Object> calculateDiscount(Integer points) {
        if (points < MIN_REDEEM_POINTS) {
            throw new RuntimeException("Số điểm tối thiểu để đổi là " + MIN_REDEEM_POINTS + " điểm");
        }
        
        Long discountValue = points * REDEEM_RATE;
        
        Map<String, Object> result = new HashMap<>();
        result.put("points", points);
        result.put("discountValue", discountValue);
        result.put("rate", "1 điểm = " + REDEEM_RATE + " VND");
        
        return result;
    }

    // Xử lý loyalty request
    @Transactional
    public Map<String, Object> processLoyaltyRequest(LoyaltyRequest request) {
        if ("EARN".equals(request.getTransactionType())) {
            if (request.getOrderValue() == null) {
                throw new RuntimeException("Giá trị đơn hàng không được để trống khi tích điểm");
            }
            return addPoints(request.getUserId(), request.getOrderValue(), request.getDescription());
        } else if ("REDEEM".equals(request.getTransactionType())) {
            return redeemPoints(request.getUserId(), request.getPoints(), request.getDescription());
        } else {
            throw new RuntimeException("Loại giao dịch không hợp lệ");
        }
    }
}
