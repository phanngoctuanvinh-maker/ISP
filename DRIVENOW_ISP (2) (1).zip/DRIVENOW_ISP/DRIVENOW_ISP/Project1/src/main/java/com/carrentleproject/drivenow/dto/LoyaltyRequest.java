package com.carrentleproject.drivenow.dto;

import jakarta.validation.constraints.*;

public class LoyaltyRequest {

    @NotNull(message = "User ID không được để trống")
    private Long userId;

    @NotNull(message = "Số điểm không được để trống")
    @Min(value = 1, message = "Số điểm phải lớn hơn 0")
    private Integer points;

    private Long orderValue;

    @NotBlank(message = "Loại giao dịch không được để trống")
    private String transactionType; // EARN hoặc REDEEM

    private String description;

    // Getters and Setters
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public Integer getPoints() { return points; }
    public void setPoints(Integer points) { this.points = points; }

    public Long getOrderValue() { return orderValue; }
    public void setOrderValue(Long orderValue) { this.orderValue = orderValue; }

    public String getTransactionType() { return transactionType; }
    public void setTransactionType(String transactionType) { this.transactionType = transactionType; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
}
