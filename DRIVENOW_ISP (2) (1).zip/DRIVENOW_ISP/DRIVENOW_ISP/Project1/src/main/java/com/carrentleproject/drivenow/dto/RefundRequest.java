package com.carrentleproject.drivenow.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;

public class RefundRequest {

    @NotNull(message = "Deposit ID is required")
    private Long depositId;

    @NotNull(message = "Refund amount is required")
    @Min(value = 0, message = "Refund amount must be positive")
    private BigDecimal refundAmount;

    private BigDecimal penaltyAmount = BigDecimal.ZERO;

    private String reason;

    // Constructors
    public RefundRequest() {
    }

    public RefundRequest(Long depositId, BigDecimal refundAmount) {
        this.depositId = depositId;
        this.refundAmount = refundAmount;
    }

    // Getters and Setters
    public Long getDepositId() {
        return depositId;
    }

    public void setDepositId(Long depositId) {
        this.depositId = depositId;
    }

    public BigDecimal getRefundAmount() {
        return refundAmount;
    }

    public void setRefundAmount(BigDecimal refundAmount) {
        this.refundAmount = refundAmount;
    }

    public BigDecimal getPenaltyAmount() {
        return penaltyAmount;
    }

    public void setPenaltyAmount(BigDecimal penaltyAmount) {
        this.penaltyAmount = penaltyAmount;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }
}
