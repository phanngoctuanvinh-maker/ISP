package com.carrentleproject.drivenow.dao;

import com.carrentleproject.drivenow.model.LoyaltyPoints;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface LoyaltyPointsRepository extends JpaRepository<LoyaltyPoints, Long> {

    // Tìm loyalty points theo user ID
    Optional<LoyaltyPoints> findByUserId(Long userId);

    // Tìm top users theo lifetime points
    @Query("SELECT lp FROM LoyaltyPoints lp ORDER BY lp.lifetimePoints DESC")
    List<LoyaltyPoints> findTopUsersByLifetimePoints();

    // Tìm users có điểm trong khoảng
    @Query("SELECT lp FROM LoyaltyPoints lp WHERE lp.points >= :minPoints AND lp.points <= :maxPoints")
    List<LoyaltyPoints> findUsersByPointsRange(@Param("minPoints") Integer minPoints, @Param("maxPoints") Integer maxPoints);

    // Đếm số users theo tier
    @Query("SELECT COUNT(lp) FROM LoyaltyPoints lp WHERE lp.lifetimePoints >= :minPoints AND lp.lifetimePoints < :maxPoints")
    Long countUsersByTier(@Param("minPoints") Integer minPoints, @Param("maxPoints") Integer maxPoints);
}
