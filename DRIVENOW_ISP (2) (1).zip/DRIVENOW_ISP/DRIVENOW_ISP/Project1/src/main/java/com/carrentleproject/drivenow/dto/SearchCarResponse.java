package com.carrentleproject.drivenow.dto;

import java.util.List;

import com.carrentleproject.drivenow.model.Car;

public class SearchCarResponse {
    private boolean success;
    private String message;
    private List<Car> cars;
    private int totalCount;

    public SearchCarResponse() {
    }

    public SearchCarResponse(boolean success, String message, List<Car> cars) {
        this.success = success;
        this.message = message;
        this.cars = cars;
        this.totalCount = cars != null ? cars.size() : 0;
    }

    // Getters and Setters
    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<Car> getCars() {
        return cars;
    }

    public void setCars(List<Car> cars) {
        this.cars = cars;
        this.totalCount = cars != null ? cars.size() : 0;
    }

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }
}
