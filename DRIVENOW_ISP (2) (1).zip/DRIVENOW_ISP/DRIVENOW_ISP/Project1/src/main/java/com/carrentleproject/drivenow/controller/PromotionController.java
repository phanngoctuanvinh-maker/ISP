package com.carrentleproject.drivenow.controller;

import com.carrentleproject.drivenow.dto.ApplyPromoRequest;
import com.carrentleproject.drivenow.dto.PromoCodeRequest;
import com.carrentleproject.drivenow.dto.PromotionRequest;
import com.carrentleproject.drivenow.model.PromoCode;
import com.carrentleproject.drivenow.model.Promotion;
import com.carrentleproject.drivenow.service.PromotionService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/promotions")
public class PromotionController {

    @Autowired
    private PromotionService promotionService;

    // 1. Health check
    @GetMapping("/test")
    public ResponseEntity<Map<String, Object>> test() {
        Map<String, Object> response = new HashMap<>();
        response.put("status", "success");
        response.put("message", "Promotion API is working!");
        response.put("timestamp", LocalDateTime.now());
        return ResponseEntity.ok(response);
    }

    // 2. Tạo promotion mới
    @PostMapping
    public ResponseEntity<Map<String, Object>> createPromotion(@Valid @RequestBody PromotionRequest request) {
        Map<String, Object> response = new HashMap<>();
        try {
            Promotion promotion = promotionService.createPromotion(request);
            response.put("status", "success");
            response.put("message", "Tạo promotion thành công");
            response.put("data", promotion);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    // 3. Lấy tất cả promotions
    @GetMapping
    public ResponseEntity<Map<String, Object>> getAllPromotions() {
        Map<String, Object> response = new HashMap<>();
        List<Promotion> promotions = promotionService.getAllPromotions();
        response.put("status", "success");
        response.put("data", promotions);
        response.put("count", promotions.size());
        return ResponseEntity.ok(response);
    }

    // 4. Xem chi tiết promotion
    @GetMapping("/{id}")
    public ResponseEntity<Map<String, Object>> getPromotionById(@PathVariable Long id) {
        Map<String, Object> response = new HashMap<>();
        try {
            Promotion promotion = promotionService.getPromotionById(id);
            response.put("status", "success");
            response.put("data", promotion);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    // 5. Cập nhật promotion
    @PutMapping("/{id}")
    public ResponseEntity<Map<String, Object>> updatePromotion(@PathVariable Long id,
            @Valid @RequestBody PromotionRequest request) {
        Map<String, Object> response = new HashMap<>();
        try {
            Promotion promotion = promotionService.updatePromotion(id, request);
            response.put("status", "success");
            response.put("message", "Cập nhật promotion thành công");
            response.put("data", promotion);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    // 6. Xóa promotion
    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, Object>> deletePromotion(@PathVariable Long id) {
        Map<String, Object> response = new HashMap<>();
        try {
            promotionService.deletePromotion(id);
            response.put("status", "success");
            response.put("message", "Xóa promotion thành công");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    // 7. Validate promo code
    @PostMapping("/validate-code")
    public ResponseEntity<Map<String, Object>> validateCode(@Valid @RequestBody ApplyPromoRequest request) {
        Map<String, Object> response = new HashMap<>();
        try {
            Map<String, Object> validation = promotionService.validatePromoCode(
                    request.getPromoCode(),
                    request.getUserId(),
                    request.getOrderValue());
            response.put("status", "success");
            response.put("message", "Mã khuyến mãi hợp lệ");
            response.put("data", validation);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    // 8. Áp dụng giảm giá
    @PostMapping("/apply")
    public ResponseEntity<Map<String, Object>> applyPromo(@Valid @RequestBody ApplyPromoRequest request) {
        Map<String, Object> response = new HashMap<>();
        try {
            Map<String, Object> result = promotionService.applyPromoCode(request);
            response.put("status", "success");
            response.put("message", "Áp dụng mã khuyến mãi thành công");
            response.put("data", result);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    // 9. Lấy promotions đang active
    @GetMapping("/active")
    public ResponseEntity<Map<String, Object>> getActivePromotions() {
        Map<String, Object> response = new HashMap<>();
        List<Promotion> promotions = promotionService.getActivePromotions();
        response.put("status", "success");
        response.put("data", promotions);
        response.put("count", promotions.size());
        return ResponseEntity.ok(response);
    }

    // 10. Tìm promotion theo code
    @GetMapping("/code/{code}")
    public ResponseEntity<Map<String, Object>> getByCode(@PathVariable String code) {
        Map<String, Object> response = new HashMap<>();
        try {
            PromoCode promoCode = promotionService.getPromoCodeByCode(code);
            Promotion promotion = promotionService.getPromotionById(promoCode.getPromotionId());

            Map<String, Object> data = new HashMap<>();
            data.put("promoCode", promoCode);
            data.put("promotion", promotion);

            response.put("status", "success");
            response.put("data", data);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    // 11. Tạo promo code mới
    @PostMapping("/codes")
    public ResponseEntity<Map<String, Object>> createPromoCode(@Valid @RequestBody PromoCodeRequest request) {
        Map<String, Object> response = new HashMap<>();
        try {
            PromoCode promoCode = promotionService.createPromoCode(request);
            response.put("status", "success");
            response.put("message", "Tạo mã khuyến mãi thành công");
            response.put("data", promoCode);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }
}
