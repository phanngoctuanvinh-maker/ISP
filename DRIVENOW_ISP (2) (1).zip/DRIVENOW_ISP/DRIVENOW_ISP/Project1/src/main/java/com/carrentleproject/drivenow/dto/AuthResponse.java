package com.carrentleproject.drivenow.dto;

public class AuthResponse {

    private String token;
    private String type = "Bearer";
    private Integer accountId;
    private String username;
    private String role;
    private String fullName;
    private String message;

    public AuthResponse() {
    }

    public AuthResponse(String token, String type, Integer accountId, String username, String role, String fullName,
            String message) {
        this.token = token;
        this.type = type;
        this.accountId = accountId;
        this.username = username;
        this.role = role;
        this.fullName = fullName;
        this.message = message;
    }

    public AuthResponse(String token, Integer accountId, String username, String role, String fullName) {
        this.token = token;
        this.accountId = accountId;
        this.username = username;
        this.role = role;
        this.fullName = fullName;
        this.message = "Đăng nhập thành công";
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getAccountId() {
        return accountId;
    }

    public void setAccountId(Integer accountId) {
        this.accountId = accountId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
