package com.carrentleproject.drivenow.controller;

import com.carrentleproject.drivenow.service.PromotionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Controller xử lý các API liên quan đến Promo Codes (Mã giảm giá)
 */
@RestController
@RequestMapping("/api/promo-codes")
public class PromoCodeController {

    @Autowired
    private PromotionService promotionService;

    /**
     * API validate promo code và tính discount
     * GET /api/promo-codes/validate/{code}?orderValue=500000
     */
    @GetMapping("/validate/{code}")
    public ResponseEntity<Map<String, Object>> validatePromoCode(
            @PathVariable String code,
            @RequestParam(required = true) Long orderValue) {
        try {
            // Gọi service để validate promo code
            Map<String, Object> validation = promotionService.validatePromoCode(
                    code,
                    null, // userId - có thể null nếu không yêu cầu
                    orderValue);

            // Kiểm tra kết quả
            Boolean isValid = (Boolean) validation.get("valid");

            if (isValid) {
                // Tạo response đơn giản không chứa full entity
                Map<String, Object> response = new HashMap<>();
                response.put("valid", true);
                response.put("code", code);
                response.put("message", "Promo code hợp lệ");

                return ResponseEntity.ok(Map.of(
                        "success", true,
                        "message", "Promo code hợp lệ",
                        "data", response));
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of(
                        "success", false,
                        "message", validation.get("message")));
            }

        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of(
                    "success", false,
                    "message", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(
                    "success", false,
                    "message", "Lỗi hệ thống: " + e.getMessage()));
        }
    }

    /**
     * API test PromoCodeController
     * GET /api/promo-codes/test
     */
    @GetMapping("/test")
    public ResponseEntity<String> testPromoCodeController() {
        return ResponseEntity.ok("PromoCode API is working!");
    }
}
