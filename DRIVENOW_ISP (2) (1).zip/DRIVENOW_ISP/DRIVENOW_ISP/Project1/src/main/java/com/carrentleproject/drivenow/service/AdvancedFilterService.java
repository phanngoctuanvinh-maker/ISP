package com.carrentleproject.drivenow.service;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carrentleproject.drivenow.dao.CarRepository;
import com.carrentleproject.drivenow.dto.AdvancedFilterRequest;
import com.carrentleproject.drivenow.model.Car;

@Service
public class AdvancedFilterService {

    @Autowired
    private CarRepository carRepository;

    /**
     * Apply advanced filter với tất cả các tiêu chí
     */
    public List<Car> applyAdvancedFilter(AdvancedFilterRequest request) {
        // Bước 1: Lấy tất cả xe
        List<Car> cars = carRepository.findAll();

        // Bước 2: Apply filters
        cars = filterByPrice(cars, request.getMinPrice(), request.getMaxPrice());
        cars = filterByTransmission(cars, request.getTransmissionType());
        cars = filterByDailyKmLimit(cars, request.getMinDailyKmLimit(), request.getMaxDailyKmLimit());
        cars = filterByExceedFee(cars, request.getMinExceedFee(), request.getMaxExceedFee());
        cars = filterBySeatCapacity(cars, request.getMinSeatCapacity(), request.getMaxSeatCapacity());
        cars = filterByYear(cars, request.getMinYear(), request.getMaxYear());
        cars = filterByFuelType(cars, request.getFuelType());
        cars = filterByFuelConsumption(cars, request.getMinFuelConsumption(), request.getMaxFuelConsumption());
        // TODO: filterByDistance(cars, request.getMaxDistance(), request.getUserLocation());
        // TODO: filterByFeatures(cars, request.getFeatures());

        // Bước 3: Apply sorting
        cars = applySorting(cars, request.getSortBy());

        // Bước 4: Apply pagination
        if (request.getPage() != null && request.getSize() != null) {
            int start = request.getPage() * request.getSize();
            int end = Math.min(start + request.getSize(), cars.size());
            if (start < cars.size()) {
                return cars.subList(start, end);
            }
        }

        return cars;
    }

    /**
     * Filter theo mức giá
     */
    private List<Car> filterByPrice(List<Car> cars, BigDecimal minPrice, BigDecimal maxPrice) {
        return cars.stream()
                .filter(car -> {
                    BigDecimal price = car.getPricePerDay();
                    if (price == null) return false;
                    
                    boolean passMin = (minPrice == null || price.compareTo(minPrice) >= 0);
                    boolean passMax = (maxPrice == null || price.compareTo(maxPrice) <= 0);
                    
                    return passMin && passMax;
                })
                .collect(Collectors.toList());
    }

    /**
     * Filter theo truyền động
     */
    private List<Car> filterByTransmission(List<Car> cars, String transmissionType) {
        if (transmissionType == null || transmissionType.isEmpty()) {
            return cars; // Tất cả
        }
        
        return cars.stream()
                .filter(car -> transmissionType.equalsIgnoreCase(car.getTransmissionType()))
                .collect(Collectors.toList());
    }

    /**
     * Filter theo giới hạn km/ngày
     * Logic đặc biệt:
     * - minDailyKmLimit = null: Bất kỳ
     * - minDailyKmLimit >= 500: Chỉ lấy xe KHÔNG giới hạn (daily_km_limit = null)
     */
    private List<Car> filterByDailyKmLimit(List<Car> cars, Integer minDailyKmLimit, Integer maxDailyKmLimit) {
        return cars.stream()
                .filter(car -> {
                    Integer limit = car.getDailyKmLimit();
                    
                    // Trường hợp đặc biệt: Tìm xe "Không giới hạn"
                    if (minDailyKmLimit != null && minDailyKmLimit >= 500) {
                        return limit == null; // Chỉ lấy xe không giới hạn
                    }
                    
                    // Trường hợp bình thường
                    if (minDailyKmLimit == null && maxDailyKmLimit == null) {
                        return true; // Bất kỳ
                    }
                    
                    if (limit == null) {
                        return true; // Xe không giới hạn luôn pass filter
                    }
                    
                    boolean passMin = (minDailyKmLimit == null || limit >= minDailyKmLimit);
                    boolean passMax = (maxDailyKmLimit == null || limit <= maxDailyKmLimit);
                    
                    return passMin && passMax;
                })
                .collect(Collectors.toList());
    }

    /**
     * Filter theo phí vượt giới hạn
     * Logic đặc biệt:
     * - minExceedFee = 0: Chỉ lấy xe MIỄN PHÍ (exceed_fee_per_km = 0 hoặc null)
     * - maxExceedFee >= 5000: Bất kỳ phí vượt
     */
    private List<Car> filterByExceedFee(List<Car> cars, Integer minExceedFee, Integer maxExceedFee) {
        return cars.stream()
                .filter(car -> {
                    Integer fee = car.getExceedFeePerKm();
                    
                    // Trường hợp "Miễn phí"
                    if (minExceedFee != null && minExceedFee == 0 && maxExceedFee != null && maxExceedFee == 0) {
                        return fee == null || fee == 0;
                    }
                    
                    // Trường hợp "Bất kỳ"
                    if (maxExceedFee != null && maxExceedFee >= 5000) {
                        return true; // Không quan tâm phí vượt
                    }
                    
                    if (minExceedFee == null && maxExceedFee == null) {
                        return true; // Bất kỳ
                    }
                    
                    if (fee == null) {
                        fee = 0; // Coi như miễn phí
                    }
                    
                    boolean passMin = (minExceedFee == null || fee >= minExceedFee);
                    boolean passMax = (maxExceedFee == null || fee <= maxExceedFee);
                    
                    return passMin && passMax;
                })
                .collect(Collectors.toList());
    }

    /**
     * Filter theo số chỗ
     */
    private List<Car> filterBySeatCapacity(List<Car> cars, Integer minSeatCapacity, Integer maxSeatCapacity) {
        return cars.stream()
                .filter(car -> {
                    Integer seats = car.getSeatCapacity();
                    if (seats == null) return false;
                    
                    boolean passMin = (minSeatCapacity == null || seats >= minSeatCapacity);
                    boolean passMax = (maxSeatCapacity == null || seats <= maxSeatCapacity);
                    
                    return passMin && passMax;
                })
                .collect(Collectors.toList());
    }

    /**
     * Filter theo năm sản xuất
     */
    private List<Car> filterByYear(List<Car> cars, Integer minYear, Integer maxYear) {
        return cars.stream()
                .filter(car -> {
                    Integer year = car.getYear();
                    if (year == null) return false;
                    
                    boolean passMin = (minYear == null || year >= minYear);
                    boolean passMax = (maxYear == null || year <= maxYear);
                    
                    return passMin && passMax;
                })
                .collect(Collectors.toList());
    }

    /**
     * Filter theo nhiên liệu
     */
    private List<Car> filterByFuelType(List<Car> cars, String fuelType) {
        if (fuelType == null || fuelType.isEmpty()) {
            return cars; // Tất cả
        }
        
        return cars.stream()
                .filter(car -> fuelType.equalsIgnoreCase(car.getFuelType()))
                .collect(Collectors.toList());
    }

    /**
     * Filter theo mức tiêu thụ nhiên liệu
     */
    private List<Car> filterByFuelConsumption(List<Car> cars, BigDecimal minFuelConsumption, BigDecimal maxFuelConsumption) {
        return cars.stream()
                .filter(car -> {
                    BigDecimal consumption = car.getFuelConsumption();
                    if (consumption == null) return true; // Không có data thì pass
                    
                    boolean passMin = (minFuelConsumption == null || consumption.compareTo(minFuelConsumption) >= 0);
                    boolean passMax = (maxFuelConsumption == null || consumption.compareTo(maxFuelConsumption) <= 0);
                    
                    return passMin && passMax;
                })
                .collect(Collectors.toList());
    }

    /**
     * Apply sorting
     */
    private List<Car> applySorting(List<Car> cars, String sortBy) {
        if (sortBy == null || sortBy.isEmpty() || "optimal".equalsIgnoreCase(sortBy)) {
            return cars; // Tối ưu (default order)
        }
        
        switch (sortBy.toLowerCase()) {
            case "price_low":
                // Giá thấp nhất
                return cars.stream()
                        .sorted(Comparator.comparing(Car::getPricePerDay, Comparator.nullsLast(Comparator.naturalOrder())))
                        .collect(Collectors.toList());
                
            case "price_high":
                // Giá cao nhất
                return cars.stream()
                        .sorted(Comparator.comparing(Car::getPricePerDay, Comparator.nullsFirst(Comparator.reverseOrder())))
                        .collect(Collectors.toList());
                
            case "distance":
                // Khoảng cách gần nhất (TODO: cần location từ user)
                return cars;
                
            case "rating":
                // Đánh giá tốt nhất (TODO: cần rating field)
                return cars;
                
            default:
                return cars;
        }
    }
}
