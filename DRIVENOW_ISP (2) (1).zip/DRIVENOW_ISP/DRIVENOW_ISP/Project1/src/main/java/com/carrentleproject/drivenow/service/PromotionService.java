package com.carrentleproject.drivenow.service;

import com.carrentleproject.drivenow.dao.PromotionRepository;
import com.carrentleproject.drivenow.dao.PromoCodeRepository;
import com.carrentleproject.drivenow.model.Promotion;
import com.carrentleproject.drivenow.model.PromoCode;
import com.carrentleproject.drivenow.dto.PromotionRequest;
import com.carrentleproject.drivenow.dto.PromoCodeRequest;
import com.carrentleproject.drivenow.dto.ApplyPromoRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;

@Service
public class PromotionService {

    @Autowired
    private PromotionRepository promotionRepository;

    @Autowired
    private PromoCodeRepository promoCodeRepository;

    // Tạo promotion mới
    @Transactional
    public Promotion createPromotion(PromotionRequest request) {
        Promotion promotion = new Promotion();
        promotion.setName(request.getName());
        promotion.setDescription(request.getDescription());
        promotion.setDiscountType(Promotion.DiscountType.valueOf(request.getDiscountType()));
        promotion.setDiscountValue(request.getDiscountValue());
        promotion.setMinOrderValue(request.getMinOrderValue());
        promotion.setMaxDiscountAmount(request.getMaxDiscountAmount());
        promotion.setStartDate(request.getStartDate());
        promotion.setEndDate(request.getEndDate());
        promotion.setUsageLimit(request.getUsageLimit());
        promotion.setStatus(request.getStatus() != null ? request.getStatus() : "ACTIVE");
        promotion.setCreatedBy(request.getCreatedBy());

        return promotionRepository.save(promotion);
    }

    // Cập nhật promotion
    @Transactional
    public Promotion updatePromotion(Long id, PromotionRequest request) {
        Promotion promotion = promotionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Promotion không tồn tại"));

        promotion.setName(request.getName());
        promotion.setDescription(request.getDescription());
        promotion.setDiscountType(Promotion.DiscountType.valueOf(request.getDiscountType()));
        promotion.setDiscountValue(request.getDiscountValue());
        promotion.setMinOrderValue(request.getMinOrderValue());
        promotion.setMaxDiscountAmount(request.getMaxDiscountAmount());
        promotion.setStartDate(request.getStartDate());
        promotion.setEndDate(request.getEndDate());
        promotion.setUsageLimit(request.getUsageLimit());
        if (request.getStatus() != null) {
            promotion.setStatus(request.getStatus());
        }

        return promotionRepository.save(promotion);
    }

    // Tạo promo code
    @Transactional
    public PromoCode createPromoCode(PromoCodeRequest request) {
        // Validate promotion exists
        if (!promotionRepository.existsById(request.getPromotionId())) {
            throw new RuntimeException("Promotion không tồn tại");
        }

        // Check code đã tồn tại chưa
        if (promoCodeRepository.findByCode(request.getCode()).isPresent()) {
            throw new RuntimeException("Mã code đã tồn tại");
        }

        PromoCode promoCode = new PromoCode();
        promoCode.setPromotionId(request.getPromotionId());
        promoCode.setCode(request.getCode().toUpperCase());
        promoCode.setSingleUse(request.getSingleUse());
        promoCode.setMaxUses(request.getMaxUses());
        promoCode.setUserRestriction(request.getUserRestriction());
        promoCode.setMinOrderValue(request.getMinOrderValue());
        promoCode.setExpiresAt(request.getExpiresAt());

        return promoCodeRepository.save(promoCode);
    }

    // Validate promo code
    public Map<String, Object> validatePromoCode(String code, Long userId, Long orderValue) {
        Map<String, Object> result = new HashMap<>();

        // Tìm promo code
        PromoCode promoCode = promoCodeRepository.findByCode(code.toUpperCase())
                .orElseThrow(() -> new RuntimeException("Mã khuyến mãi không tồn tại"));

        // Tìm promotion
        Promotion promotion = promotionRepository.findById(promoCode.getPromotionId())
                .orElseThrow(() -> new RuntimeException("Promotion không tồn tại"));

        LocalDateTime now = LocalDateTime.now();

        // Validate thời gian promotion
        if (now.isBefore(promotion.getStartDate()) || now.isAfter(promotion.getEndDate())) {
            throw new RuntimeException("Promotion đã hết hạn hoặc chưa bắt đầu");
        }

        // Validate thời gian promo code
        if (promoCode.getExpiresAt() != null && now.isAfter(promoCode.getExpiresAt())) {
            throw new RuntimeException("Mã khuyến mãi đã hết hạn");
        }

        // Validate usage limit
        if (promotion.getUsageLimit() != null &&
                promotion.getUsedCount() >= promotion.getUsageLimit()) {
            throw new RuntimeException("Promotion đã hết lượt sử dụng");
        }

        // Validate promo code uses
        if (promoCode.getMaxUses() != null &&
                promoCode.getUsedCount() >= promoCode.getMaxUses()) {
            throw new RuntimeException("Mã khuyến mãi đã hết lượt sử dụng");
        }

        // Validate user restriction
        if (promoCode.getUserRestriction() != null &&
                !promoCode.getUserRestriction().equals(userId)) {
            throw new RuntimeException("Mã khuyến mãi này không dành cho bạn");
        }

        // Validate min order value (promotion)
        if (promotion.getMinOrderValue() != null &&
                orderValue < promotion.getMinOrderValue()) {
            throw new RuntimeException("Giá trị đơn hàng phải từ " + promotion.getMinOrderValue() + " VND trở lên");
        }

        // Validate min order value (promo code)
        if (promoCode.getMinOrderValue() != null &&
                orderValue < promoCode.getMinOrderValue()) {
            throw new RuntimeException("Giá trị đơn hàng phải từ " + promoCode.getMinOrderValue() + " VND trở lên");
        }

        // Validate status
        if (!"ACTIVE".equals(promotion.getStatus())) {
            throw new RuntimeException("Promotion không còn hoạt động");
        }

        result.put("valid", true);
        result.put("promotion", promotion);
        result.put("promoCode", promoCode);
        return result;
    }

    // Áp dụng promo code và tính giảm giá
    @Transactional
    public Map<String, Object> applyPromoCode(ApplyPromoRequest request) {
        // Validate promo code
        Map<String, Object> validation = validatePromoCode(
                request.getPromoCode(),
                request.getUserId(),
                request.getOrderValue());

        Promotion promotion = (Promotion) validation.get("promotion");
        PromoCode promoCode = (PromoCode) validation.get("promoCode");

        // Tính giảm giá
        Long discountAmount = calculateDiscount(promotion, request.getOrderValue());
        Long finalAmount = request.getOrderValue() - discountAmount;

        // Tăng used count
        promotion.setUsedCount(promotion.getUsedCount() + 1);
        promotionRepository.save(promotion);

        promoCode.setUsedCount(promoCode.getUsedCount() + 1);
        promoCodeRepository.save(promoCode);

        // Kết quả
        Map<String, Object> result = new HashMap<>();
        result.put("originalAmount", request.getOrderValue());
        result.put("discountAmount", discountAmount);
        result.put("finalAmount", finalAmount);
        result.put("promotionName", promotion.getName());
        result.put("promoCode", promoCode.getCode());

        return result;
    }

    // Tính giảm giá
    public Long calculateDiscount(Promotion promotion, Long orderValue) {
        Long discount = 0L;

        if (promotion.getDiscountType() == Promotion.DiscountType.PERCENTAGE) {
            // Giảm theo phần trăm
            double discountPercent = promotion.getDiscountValue().doubleValue();
            discount = (long) (orderValue * discountPercent / 100);

            // Áp dụng max discount
            if (promotion.getMaxDiscountAmount() != null) {
                discount = Math.min(discount, promotion.getMaxDiscountAmount());
            }
        } else {
            // Giảm số tiền cố định
            discount = promotion.getDiscountValue().longValue();
        }

        return discount;
    }

    // Get all promotions
    public List<Promotion> getAllPromotions() {
        return promotionRepository.findAll();
    }

    // Get active promotions
    public List<Promotion> getActivePromotions() {
        return promotionRepository.findActivePromotions(LocalDateTime.now());
    }

    // Get promotion by ID
    public Promotion getPromotionById(Long id) {
        return promotionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Promotion không tồn tại"));
    }

    // Get promo code by code
    public PromoCode getPromoCodeByCode(String code) {
        return promoCodeRepository.findByCode(code.toUpperCase())
                .orElseThrow(() -> new RuntimeException("Mã khuyến mãi không tồn tại"));
    }

    // Delete promotion
    @Transactional
    public void deletePromotion(Long id) {
        if (!promotionRepository.existsById(id)) {
            throw new RuntimeException("Promotion không tồn tại");
        }
        promotionRepository.deleteById(id);
    }
}
