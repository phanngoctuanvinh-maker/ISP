package com.carrentleproject.drivenow.controller;

import com.carrentleproject.drivenow.dto.ApiResponse;
import com.carrentleproject.drivenow.dto.ProfileUpdateRequest;
import com.carrentleproject.drivenow.service.ProfileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/profile")
public class ProfileController {

    @Autowired
    private ProfileService profileService;

    /**
     * Lấy thông tin profile của user hiện tại (Customer, Driver, Admin)
     */
    @GetMapping("/me")
    public ResponseEntity<ApiResponse<Object>> getProfile() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        ApiResponse<Object> response = profileService.getProfile(username);
        return ResponseEntity.ok(response);
    }

    /**
     * Cập nhật thông tin profile (Customer, Driver)
     */
    @PutMapping("/update")
    @PreAuthorize("hasAnyRole('CUSTOMER', 'DRIVER')")
    public ResponseEntity<ApiResponse<Object>> updateProfile(@RequestBody ProfileUpdateRequest request) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        ApiResponse<Object> response = profileService.updateProfile(username, request);
        return ResponseEntity.ok(response);
    }

    /**
     * Xóa tài khoản (soft delete - đổi status thành inactive)
     */
    @DeleteMapping("/delete")
    public ResponseEntity<ApiResponse<String>> deleteProfile() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        ApiResponse<String> response = profileService.deleteProfile(username);
        return ResponseEntity.ok(response);
    }
}
