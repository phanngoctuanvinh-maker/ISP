package com.carrentleproject.drivenow.controller;

import com.carrentleproject.drivenow.dao.CustomerDAO;
import com.carrentleproject.drivenow.dto.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/validation")
public class ValidationController {

    @Autowired
    private CustomerDAO customerDAO;

    /**
     * Kiểm tra email đã tồn tại chưa
     */
    @GetMapping("/check-email")
    public ResponseEntity<ApiResponse<Boolean>> checkEmailExists(@RequestParam String email) {
        boolean exists = customerDAO.existsByEmail(email);
        String message = exists ? "Email đã được sử dụng" : "Email khả dụng";
        return ResponseEntity.ok(ApiResponse.success(message, exists));
    }

    /**
     * Kiểm tra số điện thoại đã tồn tại chưa
     */
    @GetMapping("/check-phone")
    public ResponseEntity<ApiResponse<Boolean>> checkPhoneExists(@RequestParam String phone) {
        boolean exists = customerDAO.existsByPhone(phone);
        String message = exists ? "Số điện thoại đã được sử dụng" : "Số điện thoại khả dụng";
        return ResponseEntity.ok(ApiResponse.success(message, exists));
    }
}
