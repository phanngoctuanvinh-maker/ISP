package com.carrentleproject.drivenow.controller;

import com.carrentleproject.drivenow.dto.ApiResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class LogoutController {

    /**
     * Logout endpoint
     * Với JWT, việc logout chủ yếu được xử lý ở client side bằng cách xóa token
     * Server chỉ cần clear SecurityContext
     */
    @PostMapping("/logout")
    public ResponseEntity<ApiResponse<String>> logout() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        if (auth != null) {
            SecurityContextHolder.getContext().setAuthentication(null);
        }

        return ResponseEntity.ok(ApiResponse.success("Đăng xuất thành công", null));
    }
}
