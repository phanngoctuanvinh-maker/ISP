package com.carrentleproject.drivenow.service;

import com.carrentleproject.drivenow.dao.DepositRepository;
import com.carrentleproject.drivenow.dao.TransactionRepository;
import com.carrentleproject.drivenow.dto.DepositRequest;
import com.carrentleproject.drivenow.dto.RefundRequest;
import com.carrentleproject.drivenow.model.Deposit;
import com.carrentleproject.drivenow.model.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
public class DepositService {

    @Autowired
    private DepositRepository depositRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    /**
     * Tạo tiền cọc mới
     */
    @Transactional
    public Deposit createDeposit(DepositRequest request) {
        // Kiểm tra booking đã có deposit chưa
        depositRepository.findByBookingId(request.getBookingId()).ifPresent(d -> {
            throw new RuntimeException("Booking already has a deposit");
        });

        // Tạo deposit
        Deposit deposit = new Deposit();
        deposit.setDepositCode("DEP-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        deposit.setBookingId(request.getBookingId());
        deposit.setUserId(request.getUserId());
        deposit.setDepositAmount(request.getDepositAmount());
        deposit.setPaymentMethod(request.getPaymentMethod());
        deposit.setNotes(request.getNotes());
        deposit.setDepositStatus(Deposit.DepositStatus.PENDING);

        // Lưu deposit
        deposit = depositRepository.save(deposit);

        // Tạo transaction tương ứng
        Transaction transaction = new Transaction();
        transaction.setTransactionCode("TXN-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        transaction.setBookingId(request.getBookingId());
        transaction.setUserId(request.getUserId());
        transaction.setTransactionType(Transaction.TransactionType.DEPOSIT);
        transaction.setAmount(request.getDepositAmount());
        transaction.setPaymentMethod(request.getPaymentMethod());
        transaction.setStatus(Transaction.TransactionStatus.PENDING);
        transaction.setDescription("Deposit for booking #" + request.getBookingId());
        
        transaction = transactionRepository.save(transaction);

        // Cập nhật transaction_id cho deposit
        deposit.setTransactionId(transaction.getId());
        deposit = depositRepository.save(deposit);

        return deposit;
    }

    /**
     * Xác nhận đã thanh toán tiền cọc
     */
    @Transactional
    public Deposit confirmDepositPayment(Long depositId, String referenceCode) {
        Deposit deposit = depositRepository.findById(depositId)
                .orElseThrow(() -> new RuntimeException("Deposit not found"));

        if (deposit.getDepositStatus() != Deposit.DepositStatus.PENDING) {
            throw new RuntimeException("Deposit is not in PENDING status");
        }

        // Cập nhật deposit
        deposit.setDepositStatus(Deposit.DepositStatus.PAID);

        // Cập nhật transaction
        if (deposit.getTransactionId() != null) {
            Transaction transaction = transactionRepository.findById(deposit.getTransactionId())
                    .orElseThrow(() -> new RuntimeException("Transaction not found"));
            transaction.setStatus(Transaction.TransactionStatus.COMPLETED);
            transaction.setCompletedAt(LocalDateTime.now());
            transaction.setReferenceCode(referenceCode);
            transactionRepository.save(transaction);
        }

        return depositRepository.save(deposit);
    }

    /**
     * Hoàn tiền cọc
     */
    @Transactional
    public Deposit refundDeposit(RefundRequest request) {
        Deposit deposit = depositRepository.findById(request.getDepositId())
                .orElseThrow(() -> new RuntimeException("Deposit not found"));

        if (deposit.getDepositStatus() != Deposit.DepositStatus.PAID) {
            throw new RuntimeException("Deposit must be PAID to refund");
        }

        BigDecimal refundAmount = request.getRefundAmount();
        BigDecimal penaltyAmount = request.getPenaltyAmount() != null ? 
                                   request.getPenaltyAmount() : BigDecimal.ZERO;

        // Kiểm tra số tiền hoàn
        if (refundAmount.add(penaltyAmount).compareTo(deposit.getDepositAmount()) > 0) {
            throw new RuntimeException("Refund + Penalty cannot exceed deposit amount");
        }

        // Cập nhật deposit
        deposit.setRefundAmount(refundAmount);
        deposit.setPenaltyAmount(penaltyAmount);
        deposit.setRefundDate(LocalDateTime.now());

        if (refundAmount.compareTo(deposit.getDepositAmount()) == 0) {
            deposit.setDepositStatus(Deposit.DepositStatus.REFUNDED);
        } else if (refundAmount.compareTo(BigDecimal.ZERO) > 0) {
            deposit.setDepositStatus(Deposit.DepositStatus.PARTIALLY_REFUNDED);
        } else {
            deposit.setDepositStatus(Deposit.DepositStatus.FORFEITED);
        }

        deposit = depositRepository.save(deposit);

        // Tạo transaction hoàn tiền
        if (refundAmount.compareTo(BigDecimal.ZERO) > 0) {
            Transaction refundTxn = new Transaction();
            refundTxn.setTransactionCode("TXN-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
            refundTxn.setBookingId(deposit.getBookingId());
            refundTxn.setUserId(deposit.getUserId());
            refundTxn.setTransactionType(Transaction.TransactionType.REFUND);
            refundTxn.setAmount(refundAmount);
            refundTxn.setPaymentMethod(deposit.getPaymentMethod());
            refundTxn.setStatus(Transaction.TransactionStatus.COMPLETED);
            refundTxn.setCompletedAt(LocalDateTime.now());
            refundTxn.setDescription("Refund deposit for booking #" + deposit.getBookingId() + 
                                    (request.getReason() != null ? ": " + request.getReason() : ""));
            transactionRepository.save(refundTxn);
        }

        // Tạo transaction phạt (nếu có)
        if (penaltyAmount.compareTo(BigDecimal.ZERO) > 0) {
            Transaction penaltyTxn = new Transaction();
            penaltyTxn.setTransactionCode("TXN-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
            penaltyTxn.setBookingId(deposit.getBookingId());
            penaltyTxn.setUserId(deposit.getUserId());
            penaltyTxn.setTransactionType(Transaction.TransactionType.PENALTY);
            penaltyTxn.setAmount(penaltyAmount);
            penaltyTxn.setPaymentMethod(deposit.getPaymentMethod());
            penaltyTxn.setStatus(Transaction.TransactionStatus.COMPLETED);
            penaltyTxn.setCompletedAt(LocalDateTime.now());
            penaltyTxn.setDescription("Penalty for booking #" + deposit.getBookingId() + 
                                    (request.getReason() != null ? ": " + request.getReason() : ""));
            transactionRepository.save(penaltyTxn);
        }

        return deposit;
    }

    /**
     * Lấy thông tin deposit theo ID
     */
    public Deposit getDepositById(Long id) {
        return depositRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Deposit not found with id: " + id));
    }

    /**
     * Lấy deposit theo booking ID
     */
    public Deposit getDepositByBookingId(Long bookingId) {
        return depositRepository.findByBookingId(bookingId)
                .orElseThrow(() -> new RuntimeException("Deposit not found for booking: " + bookingId));
    }

    /**
     * Lấy danh sách deposit của user
     */
    public List<Deposit> getDepositsByUserId(Long userId) {
        return depositRepository.findByUserId(userId);
    }

    /**
     * Lấy danh sách deposit theo status
     */
    public List<Deposit> getDepositsByStatus(Deposit.DepositStatus status) {
        return depositRepository.findByDepositStatus(status);
    }
}
