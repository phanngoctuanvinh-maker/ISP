package com.carrentleproject.drivenow.dao;

import com.carrentleproject.drivenow.model.LoyaltyHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface LoyaltyHistoryRepository extends JpaRepository<LoyaltyHistory, Long> {

    // Tìm lịch sử theo user ID
    List<LoyaltyHistory> findByUserIdOrderByCreatedAtDesc(Long userId);

    // Tìm lịch sử theo user và loại transaction
    List<LoyaltyHistory> findByUserIdAndTransactionTypeOrderByCreatedAtDesc(Long userId, String transactionType);

    // Tìm lịch sử trong khoảng thời gian
    @Query("SELECT lh FROM LoyaltyHistory lh WHERE lh.userId = :userId AND lh.createdAt BETWEEN :startDate AND :endDate ORDER BY lh.createdAt DESC")
    List<LoyaltyHistory> findByUserIdAndDateRange(
        @Param("userId") Long userId,
        @Param("startDate") LocalDateTime startDate,
        @Param("endDate") LocalDateTime endDate
    );

    // Tổng điểm earned của user
    @Query("SELECT SUM(lh.points) FROM LoyaltyHistory lh WHERE lh.userId = :userId AND lh.transactionType = 'EARN'")
    Integer sumEarnedPointsByUserId(@Param("userId") Long userId);

    // Tổng điểm redeemed của user
    @Query("SELECT SUM(lh.points) FROM LoyaltyHistory lh WHERE lh.userId = :userId AND lh.transactionType = 'REDEEM'")
    Integer sumRedeemedPointsByUserId(@Param("userId") Long userId);
}
