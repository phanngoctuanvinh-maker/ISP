package com.carrentleproject.drivenow.dao;

import com.carrentleproject.drivenow.model.Deposit;
import com.carrentleproject.drivenow.model.Deposit.DepositStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DepositRepository extends JpaRepository<Deposit, Long> {

    Optional<Deposit> findByDepositCode(String depositCode);

    Optional<Deposit> findByBookingId(Long bookingId);

    List<Deposit> findByUserId(Long userId);

    List<Deposit> findByDepositStatus(DepositStatus depositStatus);

    List<Deposit> findByUserIdAndDepositStatus(Long userId, DepositStatus depositStatus);

    @Query("SELECT d FROM Deposit d WHERE d.depositStatus = 'PAID' AND d.bookingId IN :bookingIds")
    List<Deposit> findPaidDepositsByBookingIds(@Param("bookingIds") List<Long> bookingIds);
}
