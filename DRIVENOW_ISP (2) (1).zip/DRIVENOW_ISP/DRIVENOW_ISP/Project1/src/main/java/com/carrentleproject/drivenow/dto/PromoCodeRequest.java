package com.carrentleproject.drivenow.dto;

import jakarta.validation.constraints.*;
import java.time.LocalDateTime;

public class PromoCodeRequest {

    @NotNull(message = "Promotion ID không được để trống")
    private Long promotionId;

    @NotBlank(message = "Mã code không được để trống")
    @Size(min = 3, max = 50, message = "Mã code phải từ 3-50 ký tự")
    private String code;

    private Boolean singleUse = false;

    @Min(value = 1, message = "Số lần sử dụng tối đa phải lớn hơn 0")
    private Integer maxUses;

    private Long userRestriction;

    @Min(value = 0, message = "Giá trị đơn tối thiểu không được âm")
    private Long minOrderValue;

    private LocalDateTime expiresAt;

    // Getters and Setters
    public Long getPromotionId() { return promotionId; }
    public void setPromotionId(Long promotionId) { this.promotionId = promotionId; }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }

    public Boolean getSingleUse() { return singleUse; }
    public void setSingleUse(Boolean singleUse) { this.singleUse = singleUse; }

    public Integer getMaxUses() { return maxUses; }
    public void setMaxUses(Integer maxUses) { this.maxUses = maxUses; }

    public Long getUserRestriction() { return userRestriction; }
    public void setUserRestriction(Long userRestriction) { this.userRestriction = userRestriction; }

    public Long getMinOrderValue() { return minOrderValue; }
    public void setMinOrderValue(Long minOrderValue) { this.minOrderValue = minOrderValue; }

    public LocalDateTime getExpiresAt() { return expiresAt; }
    public void setExpiresAt(LocalDateTime expiresAt) { this.expiresAt = expiresAt; }
}
