package com.carrentleproject.drivenow.dto;

import java.math.BigDecimal;
import java.util.List;

/**
 * DTO cho Advanced Filter Request
 * Chứa tất cả các filter parameters từ frontend
 */
public class AdvancedFilterRequest {
    
    // Sắp xếp
    private String sortBy; // "optimal", "distance", "price_low", "price_high", "rating"
    
    // Mức giá (VNĐ)
    private BigDecimal minPrice;
    private BigDecimal maxPrice;
    
    // Truyền động
    private String transmissionType; // "Automatic", "Manual", null = tất cả
    
    // Giới hạn km/ngày
    private Integer minDailyKmLimit; // null = bất kỳ, 500+ = không giới hạn
    private Integer maxDailyKmLimit;
    
    // Phí vượt giới hạn (VNĐ/km)
    private Integer minExceedFee; // 0 = miễn phí, null = bất kỳ
    private Integer maxExceedFee; // 5000+ = bất kỳ
    
    // Khoảng cách (km) - cần location từ user
    private Integer maxDistance; // 1-50 km
    private String userLocation; // "TP Hồ Chí Minh", "Hà Nội", etc.
    
    // Số chỗ
    private Integer minSeatCapacity; // 3-9+
    private Integer maxSeatCapacity;
    
    // Năm sản xuất
    private Integer minYear; // 2008-2024+
    private Integer maxYear;
    
    // Nhiên liệu
    private String fuelType; // "Gasoline", "Diesel", "Electric", "Hybrid", null = tất cả
    
    // Mức tiêu thụ nhiên liệu (L/100km)
    private BigDecimal minFuelConsumption;
    private BigDecimal maxFuelConsumption; // 1-30 L/100km
    
    // Tính năng
    private List<String> features; // ["Bluetooth", "Camera 360", "GPS", ...]
    
    // Pagination
    private Integer page; // 0-based
    private Integer size; // số lượng kết quả mỗi trang
    
    // Constructors
    public AdvancedFilterRequest() {
    }

    // Getters and Setters
    public String getSortBy() {
        return sortBy;
    }

    public void setSortBy(String sortBy) {
        this.sortBy = sortBy;
    }

    public BigDecimal getMinPrice() {
        return minPrice;
    }

    public void setMinPrice(BigDecimal minPrice) {
        this.minPrice = minPrice;
    }

    public BigDecimal getMaxPrice() {
        return maxPrice;
    }

    public void setMaxPrice(BigDecimal maxPrice) {
        this.maxPrice = maxPrice;
    }

    public String getTransmissionType() {
        return transmissionType;
    }

    public void setTransmissionType(String transmissionType) {
        this.transmissionType = transmissionType;
    }

    public Integer getMinDailyKmLimit() {
        return minDailyKmLimit;
    }

    public void setMinDailyKmLimit(Integer minDailyKmLimit) {
        this.minDailyKmLimit = minDailyKmLimit;
    }

    public Integer getMaxDailyKmLimit() {
        return maxDailyKmLimit;
    }

    public void setMaxDailyKmLimit(Integer maxDailyKmLimit) {
        this.maxDailyKmLimit = maxDailyKmLimit;
    }

    public Integer getMinExceedFee() {
        return minExceedFee;
    }

    public void setMinExceedFee(Integer minExceedFee) {
        this.minExceedFee = minExceedFee;
    }

    public Integer getMaxExceedFee() {
        return maxExceedFee;
    }

    public void setMaxExceedFee(Integer maxExceedFee) {
        this.maxExceedFee = maxExceedFee;
    }

    public Integer getMaxDistance() {
        return maxDistance;
    }

    public void setMaxDistance(Integer maxDistance) {
        this.maxDistance = maxDistance;
    }

    public String getUserLocation() {
        return userLocation;
    }

    public void setUserLocation(String userLocation) {
        this.userLocation = userLocation;
    }

    public Integer getMinSeatCapacity() {
        return minSeatCapacity;
    }

    public void setMinSeatCapacity(Integer minSeatCapacity) {
        this.minSeatCapacity = minSeatCapacity;
    }

    public Integer getMaxSeatCapacity() {
        return maxSeatCapacity;
    }

    public void setMaxSeatCapacity(Integer maxSeatCapacity) {
        this.maxSeatCapacity = maxSeatCapacity;
    }

    public Integer getMinYear() {
        return minYear;
    }

    public void setMinYear(Integer minYear) {
        this.minYear = minYear;
    }

    public Integer getMaxYear() {
        return maxYear;
    }

    public void setMaxYear(Integer maxYear) {
        this.maxYear = maxYear;
    }

    public String getFuelType() {
        return fuelType;
    }

    public void setFuelType(String fuelType) {
        this.fuelType = fuelType;
    }

    public BigDecimal getMinFuelConsumption() {
        return minFuelConsumption;
    }

    public void setMinFuelConsumption(BigDecimal minFuelConsumption) {
        this.minFuelConsumption = minFuelConsumption;
    }

    public BigDecimal getMaxFuelConsumption() {
        return maxFuelConsumption;
    }

    public void setMaxFuelConsumption(BigDecimal maxFuelConsumption) {
        this.maxFuelConsumption = maxFuelConsumption;
    }

    public List<String> getFeatures() {
        return features;
    }

    public void setFeatures(List<String> features) {
        this.features = features;
    }

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public Integer getSize() {
        return size;
    }

    public void setSize(Integer size) {
        this.size = size;
    }
}
