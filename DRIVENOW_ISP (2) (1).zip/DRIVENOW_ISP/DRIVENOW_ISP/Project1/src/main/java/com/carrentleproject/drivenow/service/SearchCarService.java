package com.carrentleproject.drivenow.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carrentleproject.drivenow.dao.CarRepository;
import com.carrentleproject.drivenow.model.Car;

@Service
public class SearchCarService {

    @Autowired
    private CarRepository carRepository;

    /**
     * Tìm kiếm xe theo các tiêu chí
     */
    public List<Car> searchCars(String filterType, String brand, String transmissionType, 
                                Integer seatCapacity, String fuelType) {
        
        if (filterType == null || filterType.isEmpty()) {
            filterType = "all";
        }

        List<Car> results;

        switch (filterType.toLowerCase()) {
            case "all" -> {
                // Hiển thị tất cả xe
                results = carRepository.findAll();
            }
            case "type" -> {
                // Tìm theo số chỗ ngồi (seat_capacity)
                results = (seatCapacity != null) ? carRepository.findBySeatCapacity(seatCapacity) : new ArrayList<>();
            }
            case "brand" -> {
                // Tìm theo hãng xe
                results = (brand != null && !brand.isEmpty()) ? carRepository.findByBrandIgnoreCase(brand) : new ArrayList<>();
            }
            case "transmission" -> {
                // Tìm theo loại truyền động
                if (transmissionType != null && !transmissionType.isEmpty()) {
                    // Xử lý trường hợp "Tất cả"
                    if (transmissionType.equalsIgnoreCase("Tất cả")) {
                        results = carRepository.findAll();
                    } else {
                        // Mapping từ tiếng Việt sang tiếng Anh nếu cần
                        String mappedTransmission = mapTransmissionType(transmissionType);
                        results = carRepository.findByTransmissionTypeIgnoreCase(mappedTransmission);
                    }
                } else {
                    results = new ArrayList<>();
                }
            }
            case "electric" -> {
                // Tìm xe điện
                results = carRepository.findElectricCars();
            }
            case "hybrid" -> {
                // Tìm xe xăng & điện (hybrid)
                results = carRepository.findHybridCars();
            }
            default -> {
                // Tìm kiếm nâng cao với nhiều điều kiện
                results = carRepository.searchCars(brand, transmissionType, fuelType, seatCapacity);
            }
        }

        return results;
    }

    /**
     * Lấy tất cả xe
     */
    public List<Car> getAllCars() {
        return carRepository.findAll();
    }

    /**
     * Lấy danh sách hãng xe có trong database
     */
    public List<String> getAvailableBrands() {
        List<String> brands = new ArrayList<>();
        brands.add("Toyota");
        brands.add("Honda");
        brands.add("Mazda");
        brands.add("Ford");
        brands.add("Kia");
        brands.add("Hyundai");
        brands.add("Vinfast");
        brands.add("Mitsubishi");
        return brands;
    }

    /**
     * Lấy danh sách loại truyền động
     */
    public List<String> getTransmissionTypes() {
        List<String> types = new ArrayList<>();
        types.add("Tất cả");
        types.add("Số sàn");
        types.add("Số tự động");
        return types;
    }

    /**
     * Map transmission type từ tiếng Việt sang tiếng Anh
     */
    private String mapTransmissionType(String vietnameseType) {
        if (vietnameseType == null) return null;
        
        return switch (vietnameseType.toLowerCase()) {
            case "số sàn" -> "manual";
            case "số tự động" -> "automatic";
            default -> vietnameseType;
        };
    }

    /**
     * Lấy thông tin chi tiết xe theo ID
     */
    public Car getCarById(Long carId) {
        return carRepository.findById(carId).orElse(null);
    }
}
