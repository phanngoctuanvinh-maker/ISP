package com.carrentleproject.drivenow.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender;

    @Value("${spring.mail.username}")
    private String fromEmail;

    public void sendOTPEmail(String toEmail, String otpCode) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom(fromEmail);
        message.setTo(toEmail);
        message.setSubject("DriveNow - Mã OTP đặt lại mật khẩu");
        message.setText("Mã OTP của bạn là: " + otpCode + "\n\n" +
                "Mã này có hiệu lực trong 5 phút.\n" +
                "Nếu bạn không yêu cầu đặt lại mật khẩu, vui lòng bỏ qua email này.");

        mailSender.send(message);
    }

    public void sendWelcomeEmail(String toEmail, String fullName) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom(fromEmail);
        message.setTo(toEmail);
        message.setSubject("Chào mừng bạn đến với DriveNow!");
        message.setText("Xin chào " + fullName + ",\n\n" +
                "Chào mừng bạn đến với hệ thống cho thuê xe DriveNow!\n" +
                "Tài khoản của bạn đã được tạo thành công.\n\n" +
                "Trân trọng,\n" +
                "Đội ngũ DriveNow");

        mailSender.send(message);
    }
}
