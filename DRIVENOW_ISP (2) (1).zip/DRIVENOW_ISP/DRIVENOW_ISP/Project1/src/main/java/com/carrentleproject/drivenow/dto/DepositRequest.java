package com.carrentleproject.drivenow.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;

public class DepositRequest {

    @NotNull(message = "Booking ID is required")
    private Long bookingId;

    @NotNull(message = "User ID is required")
    private Long userId;

    @NotNull(message = "Deposit amount is required")
    @Min(value = 0, message = "Deposit amount must be positive")
    private BigDecimal depositAmount;

    @NotNull(message = "Payment method is required")
    private String paymentMethod; // VNPAY, CASH, BANK_TRANSFER, CREDIT_CARD

    private String notes;

    // Constructors
    public DepositRequest() {
    }

    public DepositRequest(Long bookingId, Long userId, BigDecimal depositAmount, String paymentMethod) {
        this.bookingId = bookingId;
        this.userId = userId;
        this.depositAmount = depositAmount;
        this.paymentMethod = paymentMethod;
    }

    // Getters and Setters
    public Long getBookingId() {
        return bookingId;
    }

    public void setBookingId(Long bookingId) {
        this.bookingId = bookingId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public BigDecimal getDepositAmount() {
        return depositAmount;
    }

    public void setDepositAmount(BigDecimal depositAmount) {
        this.depositAmount = depositAmount;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }
}
