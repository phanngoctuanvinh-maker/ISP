package com.carrentleproject.drivenow.controller;

import com.carrentleproject.drivenow.dto.PaymentRequest;
import com.carrentleproject.drivenow.service.VNPayService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/vnpay")
public class VNPayController {

    @Autowired
    private VNPayService vnPayService;

    /**
     * Test endpoint - Kiểm tra VNPay service hoạt động
     */
    @GetMapping("/test")
    public ResponseEntity<Map<String, Object>> test() {
        Map<String, Object> response = new HashMap<>();
        response.put("status", "success");
        response.put("message", "VNPay API is working!");
        response.put("timestamp", LocalDateTime.now());
        return ResponseEntity.ok(response);
    }

    /**
     * Tạo URL thanh toán VNPay
     * POST /api/vnpay/create-payment
     */
    @PostMapping("/create-payment")
    public ResponseEntity<Map<String, Object>> createPayment(
            @RequestBody PaymentRequest paymentRequest,
            HttpServletRequest request) {
        try {
            String paymentUrl = vnPayService.createPaymentUrl(paymentRequest, request);

            Map<String, Object> response = new HashMap<>();
            response.put("status", "success");
            response.put("message", "Payment URL created successfully");
            response.put("paymentUrl", paymentUrl);
            response.put("timestamp", LocalDateTime.now());

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("status", "error");
            errorResponse.put("message", e.getMessage());
            errorResponse.put("timestamp", LocalDateTime.now());

            return ResponseEntity.badRequest().body(errorResponse);
        }
    }

    /**
     * Xử lý callback từ VNPay (return URL)
     * GET /api/vnpay/callback
     */
    @GetMapping("/callback")
    public ResponseEntity<Map<String, Object>> handleCallback(HttpServletRequest request) {
        try {
            // Chuyển request parameters thành Map
            Map<String, String> params = new HashMap<>();
            request.getParameterMap().forEach((key, value) -> {
                params.put(key, value[0]);
            });

            Map<String, Object> result = vnPayService.handlePaymentReturn(params);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("status", "error");
            errorResponse.put("message", e.getMessage());
            errorResponse.put("timestamp", LocalDateTime.now());

            return ResponseEntity.badRequest().body(errorResponse);
        }
    }

    /**
     * Lấy thông tin giao dịch theo orderId
     * GET /api/vnpay/payment/{orderId}
     */
    @GetMapping("/payment/{orderId}")
    public ResponseEntity<Map<String, Object>> getPaymentByOrderId(@PathVariable String orderId) {
        try {
            var payment = vnPayService.getPaymentByOrderId(orderId);

            Map<String, Object> response = new HashMap<>();
            if (payment.isPresent()) {
                response.put("status", "success");
                response.put("data", payment.get());
            } else {
                response.put("status", "error");
                response.put("message", "Payment not found");
            }
            response.put("timestamp", LocalDateTime.now());

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("status", "error");
            errorResponse.put("message", e.getMessage());
            errorResponse.put("timestamp", LocalDateTime.now());

            return ResponseEntity.badRequest().body(errorResponse);
        }
    }

    /**
     * Lấy danh sách giao dịch theo userId
     * GET /api/vnpay/payments/user/{userId}
     */
    @GetMapping("/payments/user/{userId}")
    public ResponseEntity<Map<String, Object>> getPaymentsByUserId(@PathVariable Long userId) {
        try {
            var payments = vnPayService.getPaymentsByUserId(userId);

            Map<String, Object> response = new HashMap<>();
            response.put("status", "success");
            response.put("data", payments);
            response.put("count", payments.size());
            response.put("timestamp", LocalDateTime.now());

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("status", "error");
            errorResponse.put("message", e.getMessage());
            errorResponse.put("timestamp", LocalDateTime.now());

            return ResponseEntity.badRequest().body(errorResponse);
        }
    }
}
