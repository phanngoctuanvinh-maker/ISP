package com.carrentleproject.drivenow.dao;

import com.carrentleproject.drivenow.model.OTP;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.Optional;

@Repository
public interface OTPDAO extends JpaRepository<OTP, Integer> {

    Optional<OTP> findByEmailAndOtpCodeAndIsUsedFalseAndExpirationTimeAfter(
            String email, String otpCode, LocalDateTime currentTime);

    void deleteByEmailAndExpirationTimeBefore(String email, LocalDateTime currentTime);
}
