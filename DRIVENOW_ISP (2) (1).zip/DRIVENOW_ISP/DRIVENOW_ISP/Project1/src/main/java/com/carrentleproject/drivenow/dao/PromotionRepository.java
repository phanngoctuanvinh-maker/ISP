package com.carrentleproject.drivenow.dao;

import com.carrentleproject.drivenow.model.Promotion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface PromotionRepository extends JpaRepository<Promotion, Long> {

    // Tìm promotion theo tên
    Optional<Promotion> findByName(String name);

    // Tìm tất cả promotions đang active
    @Query("SELECT p FROM Promotion p WHERE p.status = 'ACTIVE' AND p.startDate <= :now AND p.endDate >= :now")
    List<Promotion> findActivePromotions(@Param("now") LocalDateTime now);

    // Tìm promotions theo status
    List<Promotion> findByStatus(String status);

    // Tìm promotions theo discount type
    List<Promotion> findByDiscountType(Promotion.DiscountType discountType);

    // Tìm promotions còn hạn sử dụng
    @Query("SELECT p FROM Promotion p WHERE p.endDate >= :now ORDER BY p.createdAt DESC")
    List<Promotion> findValidPromotions(@Param("now") LocalDateTime now);

    // Tìm promotions được tạo bởi user
    List<Promotion> findByCreatedBy(Long createdBy);
}