package com.carrentleproject.drivenow.dao;

import com.carrentleproject.drivenow.model.PromoCode;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface PromoCodeRepository extends JpaRepository<PromoCode, Long> {

    // Tìm promo code theo code string
    Optional<PromoCode> findByCode(String code);

    // Tìm tất cả codes của một promotion
    List<PromoCode> findByPromotionId(Long promotionId);

    // Tìm codes còn hạn sử dụng
    @Query("SELECT pc FROM PromoCode pc WHERE pc.expiresAt >= :now OR pc.expiresAt IS NULL")
    List<PromoCode> findValidCodes(@Param("now") LocalDateTime now);

    // Tìm codes của user cụ thể
    Optional<PromoCode> findByCodeAndUserRestriction(String code, Long userId);

    // Check code tồn tại và còn hạn
    @Query("SELECT pc FROM PromoCode pc WHERE pc.code = :code AND (pc.expiresAt >= :now OR pc.expiresAt IS NULL)")
    Optional<PromoCode> findValidCodeByCode(@Param("code") String code, @Param("now") LocalDateTime now);
}
