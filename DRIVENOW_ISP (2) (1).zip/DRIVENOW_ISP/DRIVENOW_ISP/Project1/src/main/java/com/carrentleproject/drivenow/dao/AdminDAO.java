package com.carrentleproject.drivenow.dao;

import com.carrentleproject.drivenow.model.Admin;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface AdminDAO extends JpaRepository<Admin, Integer> {

    Optional<Admin> findByAccountAccountId(Integer accountId);
}
