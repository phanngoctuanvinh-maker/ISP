package com.carrentleproject.drivenow.controller;

import com.carrentleproject.drivenow.dto.DepositRequest;
import com.carrentleproject.drivenow.dto.RefundRequest;
import com.carrentleproject.drivenow.model.Deposit;
import com.carrentleproject.drivenow.service.DepositService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/deposits")
public class DepositController {

    @Autowired
    private DepositService depositService;

    /**
     * Test API
     */
    @GetMapping("/test")
    public ResponseEntity<Map<String, Object>> test() {
        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("message", "Deposit Management API is working!");
        response.put("timestamp", System.currentTimeMillis());
        return ResponseEntity.ok(response);
    }

    /**
     * Tạo tiền cọc mới
     * POST /api/deposits
     */
    @PostMapping
    public ResponseEntity<Map<String, Object>> createDeposit(@Valid @RequestBody DepositRequest request) {
        try {
            Deposit deposit = depositService.createDeposit(request);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Deposit created successfully");
            response.put("deposit", deposit);
            
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (RuntimeException e) {
            Map<String, Object> error = new HashMap<>();
            error.put("success", false);
            error.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    /**
     * Xác nhận đã thanh toán tiền cọc
     * PUT /api/deposits/{id}/confirm
     */
    @PutMapping("/{id}/confirm")
    public ResponseEntity<Map<String, Object>> confirmDeposit(
            @PathVariable Long id,
            @RequestParam(required = false) String referenceCode) {
        try {
            Deposit deposit = depositService.confirmDepositPayment(id, referenceCode);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Deposit payment confirmed");
            response.put("deposit", deposit);
            
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, Object> error = new HashMap<>();
            error.put("success", false);
            error.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    /**
     * Hoàn tiền cọc
     * POST /api/deposits/refund
     */
    @PostMapping("/refund")
    public ResponseEntity<Map<String, Object>> refundDeposit(@Valid @RequestBody RefundRequest request) {
        try {
            Deposit deposit = depositService.refundDeposit(request);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Deposit refunded successfully");
            response.put("deposit", deposit);
            
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, Object> error = new HashMap<>();
            error.put("success", false);
            error.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    /**
     * Lấy thông tin deposit theo ID
     * GET /api/deposits/{id}
     */
    @GetMapping("/{id}")
    public ResponseEntity<Map<String, Object>> getDeposit(@PathVariable Long id) {
        try {
            Deposit deposit = depositService.getDepositById(id);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("deposit", deposit);
            
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, Object> error = new HashMap<>();
            error.put("success", false);
            error.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
        }
    }

    /**
     * Lấy deposit theo booking ID
     * GET /api/deposits/booking/{bookingId}
     */
    @GetMapping("/booking/{bookingId}")
    public ResponseEntity<Map<String, Object>> getDepositByBooking(@PathVariable Long bookingId) {
        try {
            Deposit deposit = depositService.getDepositByBookingId(bookingId);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("deposit", deposit);
            
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, Object> error = new HashMap<>();
            error.put("success", false);
            error.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
        }
    }

    /**
     * Lấy danh sách deposit của user
     * GET /api/deposits/user/{userId}
     */
    @GetMapping("/user/{userId}")
    public ResponseEntity<Map<String, Object>> getDepositsByUser(@PathVariable Long userId) {
        List<Deposit> deposits = depositService.getDepositsByUserId(userId);
        
        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("count", deposits.size());
        response.put("deposits", deposits);
        
        return ResponseEntity.ok(response);
    }

    /**
     * Lấy danh sách deposit theo status
     * GET /api/deposits/status/{status}
     */
    @GetMapping("/status/{status}")
    public ResponseEntity<Map<String, Object>> getDepositsByStatus(@PathVariable String status) {
        try {
            Deposit.DepositStatus depositStatus = Deposit.DepositStatus.valueOf(status.toUpperCase());
            List<Deposit> deposits = depositService.getDepositsByStatus(depositStatus);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("status", status.toUpperCase());
            response.put("count", deposits.size());
            response.put("deposits", deposits);
            
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            Map<String, Object> error = new HashMap<>();
            error.put("success", false);
            error.put("message", "Invalid status. Valid values: PENDING, PAID, REFUNDED, PARTIALLY_REFUNDED, FORFEITED");
            return ResponseEntity.badRequest().body(error);
        }
    }
}
