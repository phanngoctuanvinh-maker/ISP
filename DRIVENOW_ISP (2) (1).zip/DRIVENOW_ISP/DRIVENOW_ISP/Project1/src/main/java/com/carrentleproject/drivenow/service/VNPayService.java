package com.carrentleproject.drivenow.service;

import com.carrentleproject.drivenow.config.VNPayConfig;
import com.carrentleproject.drivenow.dao.PaymentRepository;
import com.carrentleproject.drivenow.dto.PaymentRequest;
import com.carrentleproject.drivenow.model.Payment;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class VNPayService {

    @Autowired
    private VNPayConfig vnPayConfig;

    @Autowired
    private PaymentRepository paymentRepository;

    /**
     * Tạo URL thanh toán VNPay
     */
    public String createPaymentUrl(PaymentRequest paymentRequest, HttpServletRequest request) throws UnsupportedEncodingException {
        // Tạo order ID unique
        String orderIdPrefix = "ORDER" + vnPayConfig.getRandomNumber(8);
        
        // Lưu payment vào database với trạng thái PENDING
        Payment payment = new Payment(
            orderIdPrefix,
            paymentRequest.getUserId(),
            BigDecimal.valueOf(paymentRequest.getAmount()),
            paymentRequest.getOrderInfo() != null ? paymentRequest.getOrderInfo() : "Thanh toan don hang"
        );
        payment.setBankCode(paymentRequest.getBankCode());
        paymentRepository.save(payment);

        // Tạo các tham số cho VNPay
        Map<String, String> vnpParams = new HashMap<>();
        vnpParams.put("vnp_Version", vnPayConfig.getVnpVersion());
        vnpParams.put("vnp_Command", vnPayConfig.getVnpCommand());
        vnpParams.put("vnp_TmnCode", vnPayConfig.getVnpTmnCode());
        vnpParams.put("vnp_Amount", String.valueOf(paymentRequest.getAmount() * 100)); // VNPay yêu cầu nhân 100
        vnpParams.put("vnp_CurrCode", "VND");
        
        if (paymentRequest.getBankCode() != null && !paymentRequest.getBankCode().isEmpty()) {
            vnpParams.put("vnp_BankCode", paymentRequest.getBankCode());
        }
        
        vnpParams.put("vnp_TxnRef", orderIdPrefix);
        vnpParams.put("vnp_OrderInfo", paymentRequest.getOrderInfo() != null ? paymentRequest.getOrderInfo() : "Thanh toan don hang");
        vnpParams.put("vnp_OrderType", vnPayConfig.getVnpOrderType());
        vnpParams.put("vnp_Locale", "vn");
        vnpParams.put("vnp_ReturnUrl", vnPayConfig.getVnpReturnUrl());
        vnpParams.put("vnp_IpAddr", vnPayConfig.getIpAddress(request));

        // Thời gian tạo và hết hạn
        Calendar cld = Calendar.getInstance(TimeZone.getTimeZone("Etc/GMT+7"));
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
        String vnpCreateDate = formatter.format(cld.getTime());
        vnpParams.put("vnp_CreateDate", vnpCreateDate);
        
        cld.add(Calendar.MINUTE, 15); // Payment expires in 15 minutes
        String vnpExpireDate = formatter.format(cld.getTime());
        vnpParams.put("vnp_ExpireDate", vnpExpireDate);

        // Sắp xếp params và tạo query string
        List<String> fieldNames = new ArrayList<>(vnpParams.keySet());
        Collections.sort(fieldNames);
        StringBuilder hashData = new StringBuilder();
        StringBuilder query = new StringBuilder();
        
        Iterator<String> itr = fieldNames.iterator();
        while (itr.hasNext()) {
            String fieldName = itr.next();
            String fieldValue = vnpParams.get(fieldName);
            if ((fieldValue != null) && (fieldValue.length() > 0)) {
                // Build hash data
                hashData.append(fieldName);
                hashData.append('=');
                hashData.append(URLEncoder.encode(fieldValue, StandardCharsets.US_ASCII.toString()));
                
                // Build query
                query.append(URLEncoder.encode(fieldName, StandardCharsets.US_ASCII.toString()));
                query.append('=');
                query.append(URLEncoder.encode(fieldValue, StandardCharsets.US_ASCII.toString()));
                
                if (itr.hasNext()) {
                    query.append('&');
                    hashData.append('&');
                }
            }
        }
        
        String queryUrl = query.toString();
        String vnpSecureHash = vnPayConfig.hmacSHA512(vnPayConfig.getVnpSecretKey(), hashData.toString());
        queryUrl += "&vnp_SecureHash=" + vnpSecureHash;
        
        return vnPayConfig.getVnpUrl() + "?" + queryUrl;
    }

    /**
     * Xử lý callback từ VNPay
     */
    public Map<String, Object> handlePaymentReturn(Map<String, String> params) {
        Map<String, Object> result = new HashMap<>();
        
        String vnpSecureHash = params.get("vnp_SecureHash");
        params.remove("vnp_SecureHashType");
        params.remove("vnp_SecureHash");
        
        // Tạo hash để verify
        String signValue = vnPayConfig.hashAllFields(params);
        
        if (signValue.equals(vnpSecureHash)) {
            String orderId = params.get("vnp_TxnRef");
            String responseCode = params.get("vnp_ResponseCode");
            String transactionNo = params.get("vnp_TransactionNo");
            String bankCode = params.get("vnp_BankCode");
            
            // Tìm payment trong database
            Optional<Payment> paymentOpt = paymentRepository.findByOrderId(orderId);
            
            if (paymentOpt.isPresent()) {
                Payment payment = paymentOpt.get();
                payment.setVnpayResponseCode(responseCode);
                payment.setTransactionNo(transactionNo);
                payment.setBankCode(bankCode);
                
                if ("00".equals(responseCode)) {
                    payment.setPaymentStatus("SUCCESS");
                    result.put("success", true);
                    result.put("message", "Thanh toán thành công");
                } else {
                    payment.setPaymentStatus("FAILED");
                    result.put("success", false);
                    result.put("message", "Thanh toán thất bại. Mã lỗi: " + responseCode);
                }
                
                paymentRepository.save(payment);
                result.put("payment", convertToPaymentResponse(payment));
            } else {
                result.put("success", false);
                result.put("message", "Không tìm thấy đơn hàng");
            }
        } else {
            result.put("success", false);
            result.put("message", "Chữ ký không hợp lệ");
        }
        
        return result;
    }

    /**
     * Lấy thông tin payment theo order ID
     */
    public Optional<Payment> getPaymentByOrderId(String orderId) {
        return paymentRepository.findByOrderId(orderId);
    }

    /**
     * Lấy danh sách payment của user
     */
    public List<Payment> getPaymentsByUserId(Long userId) {
        return paymentRepository.findByUserId(userId);
    }

    /**
     * Convert Payment entity to response DTO
     */
    private Map<String, Object> convertToPaymentResponse(Payment payment) {
        Map<String, Object> response = new HashMap<>();
        response.put("id", payment.getId());
        response.put("orderId", payment.getOrderId());
        response.put("userId", payment.getUserId());
        response.put("amount", payment.getAmount());
        response.put("orderInfo", payment.getOrderInfo());
        response.put("transactionNo", payment.getTransactionNo());
        response.put("bankCode", payment.getBankCode());
        response.put("paymentStatus", payment.getPaymentStatus());
        response.put("vnpayResponseCode", payment.getVnpayResponseCode());
        response.put("createdAt", payment.getCreatedAt());
        response.put("updatedAt", payment.getUpdatedAt());
        return response;
    }
}
