package com.carrentleproject.drivenow.dto;

import jakarta.validation.constraints.*;

public class ApplyPromoRequest {

    @NotBlank(message = "Mã promo không được để trống")
    private String promoCode;

    @NotNull(message = "User ID không được để trống")
    private Long userId;

    @NotNull(message = "Giá trị đơn hàng không được để trống")
    @Min(value = 1, message = "Giá trị đơn hàng phải lớn hơn 0")
    private Long orderValue;

    // Getters and Setters
    public String getPromoCode() { return promoCode; }
    public void setPromoCode(String promoCode) { this.promoCode = promoCode; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public Long getOrderValue() { return orderValue; }
    public void setOrderValue(Long orderValue) { this.orderValue = orderValue; }
}
