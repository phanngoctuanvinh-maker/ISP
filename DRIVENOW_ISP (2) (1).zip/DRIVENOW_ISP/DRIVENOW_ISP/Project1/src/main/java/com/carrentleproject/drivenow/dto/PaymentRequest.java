package com.carrentleproject.drivenow.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public class PaymentRequest {

    @NotNull(message = "User ID không được để trống")
    private Long userId;

    @NotNull(message = "Số tiền không được để trống")
    @Min(value = 10000, message = "Số tiền tối thiểu là 10,000 VNĐ")
    private Long amount;

    private String orderInfo;

    private String bankCode;

    // Thêm các fields mới cho Module 3
    private String orderType; // CAR_RENTAL, DEPOSIT, etc.
    private String language; // vn hoặc en
    private Long bookingId;
    private Long promoCodeId;
    private Long promotionId;

    // Constructors
    public PaymentRequest() {
    }

    public PaymentRequest(Long userId, Long amount, String orderInfo, String bankCode) {
        this.userId = userId;
        this.amount = amount;
        this.orderInfo = orderInfo;
        this.bankCode = bankCode;
    }

    // Getters and Setters
    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getAmount() {
        return amount;
    }

    public void setAmount(Long amount) {
        this.amount = amount;
    }

    public String getOrderInfo() {
        return orderInfo;
    }

    public void setOrderInfo(String orderInfo) {
        this.orderInfo = orderInfo;
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    // Getters/Setters cho Module 3
    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public Long getBookingId() {
        return bookingId;
    }

    public void setBookingId(Long bookingId) {
        this.bookingId = bookingId;
    }

    public Long getPromoCodeId() {
        return promoCodeId;
    }

    public void setPromoCodeId(Long promoCodeId) {
        this.promoCodeId = promoCodeId;
    }

    public Long getPromotionId() {
        return promotionId;
    }

    public void setPromotionId(Long promotionId) {
        this.promotionId = promotionId;
    }
}
