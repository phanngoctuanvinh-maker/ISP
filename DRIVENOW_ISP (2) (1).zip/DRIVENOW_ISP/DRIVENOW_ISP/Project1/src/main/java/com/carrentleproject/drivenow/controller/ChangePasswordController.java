package com.carrentleproject.drivenow.controller;

import com.carrentleproject.drivenow.dto.ApiResponse;
import com.carrentleproject.drivenow.dto.ChangePasswordRequest;
import com.carrentleproject.drivenow.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/profile")
public class ChangePasswordController {

    @Autowired
    private AuthService authService;

    @PostMapping("/change-password")
    public ResponseEntity<ApiResponse<String>> changePassword(@Valid @RequestBody ChangePasswordRequest request) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        ApiResponse<String> response = authService.changePassword(username, request);
        return ResponseEntity.ok(response);
    }
}
