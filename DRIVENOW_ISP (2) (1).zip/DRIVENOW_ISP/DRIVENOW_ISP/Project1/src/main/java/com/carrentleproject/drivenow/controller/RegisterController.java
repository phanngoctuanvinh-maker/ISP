package com.carrentleproject.drivenow.controller;

import com.carrentleproject.drivenow.dto.ApiResponse;
import com.carrentleproject.drivenow.dto.AuthResponse;
import com.carrentleproject.drivenow.dto.RegisterRequest;
import com.carrentleproject.drivenow.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class RegisterController {

    @Autowired
    private AuthService authService;

    @PostMapping("/register")
    public ResponseEntity<ApiResponse<AuthResponse>> register(@Valid @RequestBody RegisterRequest request) {
        ApiResponse<AuthResponse> response = authService.register(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }
}
