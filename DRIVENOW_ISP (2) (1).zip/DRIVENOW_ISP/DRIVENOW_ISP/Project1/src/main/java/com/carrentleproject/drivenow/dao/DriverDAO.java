package com.carrentleproject.drivenow.dao;

import com.carrentleproject.drivenow.model.Driver;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface DriverDAO extends JpaRepository<Driver, Integer> {

    Optional<Driver> findByAccountAccountId(Integer accountId);

    Optional<Driver> findByLicenseNumber(String licenseNumber);

    Optional<Driver> findByIdCard(String idCard);

    boolean existsByLicenseNumber(String licenseNumber);

    boolean existsByIdCard(String idCard);
}
