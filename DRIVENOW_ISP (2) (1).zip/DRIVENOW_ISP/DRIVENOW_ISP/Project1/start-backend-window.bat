@echo off
echo ========================================
echo   KHOI DONG BACKEND - DRIVENOW
echo   (Cua so rieng - KHONG DONG!)
echo ========================================
echo.
echo QUAN TRONG: De yen cua so nay, KHONG nhan phim!
echo Backend dang chay tren port 8080
echo.
cd /d "%~dp0"
start "DriveNow Backend - Port 8080" cmd /k "mvnw.cmd spring-boot:run"
echo.
echo Backend dang khoi dong trong cua so rieng!
echo Ban co the dong cua so nay.
timeout /t 3
exit
