# 📦 MODULE 3 - DOCUMENTATION
# Hệ thống Thanh toán, Khuyến mãi và Quản lý Giao dịch

## 📋 Tổng quan Module 3

Module 3 bao gồm 3 chức năng chính:
1. **VNPay Payment Integration** - Thanh toán online qua VNPay
2. **Promotion & Voucher Management** - Quản lý khuyến mãi và mã giảm giá
3. **Transaction Management** - Quản lý giao dịch

---

## 🏗️ Cấu trúc Module

```
Project1/src/main/java/com/carrentleproject/drivenow/
├── controller/
│   ├── PaymentController.java          # API thanh toán VNPay
│   └── PromotionController.java        # API quản lý promotion/voucher
├── service/
│   ├── VNPayService.java               # Logic xử lý VNPay
│   └── PromotionService.java           # Logic xử lý promotion
├── model/
│   ├── Payment.java                    # Entity thanh toán
│   ├── Promotion.java                  # Entity khuyến mãi
│   ├── PromoCode.java                  # Entity mã giảm giá
│   └── Transaction.java                # Entity giao dịch
├── dao/
│   ├── PaymentRepository.java          # Repository thanh toán
│   ├── PromotionRepository.java        # Repository promotion
│   ├── PromoCodeRepository.java        # Repository promo code
│   └── TransactionRepository.java      # Repository transaction
├── dto/
│   ├── PaymentRequest.java             # DTO request payment
│   ├── PaymentResponse.java            # DTO response payment
│   ├── PromotionRequest.java           # DTO request promotion
│   ├── PromoCodeRequest.java           # DTO request promo code
│   └── ApplyPromoRequest.java          # DTO áp dụng mã giảm giá
└── config/
    └── VNPayConfig.java                # Config VNPay
```

---

## 💳 1. VNPAY PAYMENT INTEGRATION

### Mô tả
Tích hợp cổng thanh toán VNPay để xử lý thanh toán online.

### Database Table: `vnpay_payments`
```sql
CREATE TABLE vnpay_payments (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    order_id VARCHAR(50) UNIQUE NOT NULL,
    user_id BIGINT NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    order_info NVARCHAR(255),
    transaction_no VARCHAR(50),
    bank_code VARCHAR(20),
    payment_status VARCHAR(20) NOT NULL,    -- PENDING, SUCCESS, FAILED
    vnpay_response_code VARCHAR(10),
    created_at DATETIME NOT NULL,
    updated_at DATETIME
);
```

### API Endpoints

#### 1. Tạo URL thanh toán VNPay
```
POST /api/payment/create
```

**Request Body:**
```json
{
  "userId": 1,
  "amount": 100000,
  "orderInfo": "Thanh toan thue xe",
  "bankCode": "NCB"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Tạo URL thanh toán thành công",
  "paymentUrl": "https://sandbox.vnpayment.vn/paymentv2/vpcpay.html?..."
}
```

#### 2. Callback từ VNPay
```
GET /api/payment/vnpay-return
```

**Query Params:** (Tự động từ VNPay)
- vnp_TxnRef
- vnp_Amount
- vnp_ResponseCode
- vnp_TransactionNo
- vnp_BankCode
- vnp_SecureHash
- ...

**Response:**
```json
{
  "success": true,
  "message": "Thanh toán thành công",
  "payment": {
    "id": 1,
    "orderId": "ORDER12345678",
    "userId": 1,
    "amount": 100000,
    "paymentStatus": "SUCCESS",
    ...
  }
}
```

#### 3. Lấy thông tin thanh toán theo Order ID
```
GET /api/payment/order/{orderId}
```

**Response:**
```json
{
  "success": true,
  "payment": {
    "id": 1,
    "orderId": "ORDER12345678",
    "userId": 1,
    "amount": 100000,
    "paymentStatus": "SUCCESS",
    "transactionNo": "14012345",
    "bankCode": "NCB",
    "createdAt": "2025-10-15T10:30:00",
    "updatedAt": "2025-10-15T10:31:00"
  }
}
```

#### 4. Lấy danh sách thanh toán của User
```
GET /api/payment/user/{userId}
```

**Response:**
```json
{
  "success": true,
  "payments": [
    {
      "id": 1,
      "orderId": "ORDER12345678",
      "amount": 100000,
      "paymentStatus": "SUCCESS",
      ...
    }
  ],
  "count": 1
}
```

### VNPay Configuration

File: `application.properties`
```properties
# VNPay Sandbox
vnpay.url=https://sandbox.vnpayment.vn/paymentv2/vpcpay.html
vnpay.return-url=http://localhost:8080/api/payment/vnpay-return
vnpay.tmn-code=YOUR_TMN_CODE
vnpay.secret-key=YOUR_SECRET_KEY
vnpay.api-url=https://sandbox.vnpayment.vn/merchant_webapi/api/transaction
vnpay.version=2.1.0
vnpay.command=pay
vnpay.order-type=other
```

**Lưu ý:** Để test VNPay Sandbox, cần đăng ký tài khoản tại: https://sandbox.vnpayment.vn/

---

## 🎁 2. PROMOTION & VOUCHER MANAGEMENT

### Mô tả
Quản lý các chương trình khuyến mãi và mã giảm giá.

### Database Tables

#### Table: `promotions`
```sql
CREATE TABLE promotions (
    promotion_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    name NVARCHAR(200) NOT NULL,
    description NVARCHAR(MAX),
    discount_type VARCHAR(20) NOT NULL,    -- PERCENTAGE, FIXED_AMOUNT
    discount_value DECIMAL(10,2) NOT NULL,
    min_order_value BIGINT,
    max_discount_amount BIGINT,
    start_date DATETIME NOT NULL,
    end_date DATETIME NOT NULL,
    usage_limit INT,
    used_count INT DEFAULT 0,
    status VARCHAR(20) DEFAULT 'ACTIVE',   -- ACTIVE, INACTIVE, EXPIRED
    created_by BIGINT,
    created_at DATETIME NOT NULL,
    updated_at DATETIME
);
```

#### Table: `promo_codes`
```sql
CREATE TABLE promo_codes (
    promo_code_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    promotion_id BIGINT NOT NULL,
    code VARCHAR(50) UNIQUE NOT NULL,
    single_use BOOLEAN DEFAULT FALSE,
    max_uses INT,
    used_count INT DEFAULT 0,
    user_restriction BIGINT,                -- Giới hạn cho user cụ thể
    min_order_value BIGINT,
    created_at DATETIME NOT NULL,
    expires_at DATETIME,
    FOREIGN KEY (promotion_id) REFERENCES promotions(promotion_id)
);
```

### API Endpoints

#### 1. Health Check
```
GET /api/promotions/test
```

**Response:**
```json
{
  "status": "success",
  "message": "Promotion API is working!",
  "timestamp": "2025-10-15T10:30:00"
}
```

#### 2. Tạo Promotion mới
```
POST /api/promotions
```

**Request Body:**
```json
{
  "name": "Giảm giá mùa hè 2025",
  "description": "Giảm 20% cho tất cả đơn hàng",
  "discountType": "PERCENTAGE",
  "discountValue": 20,
  "minOrderValue": 100000,
  "maxDiscountAmount": 50000,
  "startDate": "2025-06-01T00:00:00",
  "endDate": "2025-08-31T23:59:59",
  "usageLimit": 1000,
  "status": "ACTIVE",
  "createdBy": 1
}
```

**Response:**
```json
{
  "status": "success",
  "message": "Tạo promotion thành công",
  "data": {
    "id": 1,
    "name": "Giảm giá mùa hè 2025",
    "discountType": "PERCENTAGE",
    "discountValue": 20,
    ...
  }
}
```

#### 3. Lấy tất cả Promotions
```
GET /api/promotions
```

**Response:**
```json
{
  "status": "success",
  "data": [
    {
      "id": 1,
      "name": "Giảm giá mùa hè 2025",
      "discountType": "PERCENTAGE",
      "discountValue": 20,
      "status": "ACTIVE",
      ...
    }
  ],
  "count": 1
}
```

#### 4. Lấy Promotions đang Active
```
GET /api/promotions/active
```

**Response:**
```json
{
  "status": "success",
  "data": [
    {
      "id": 1,
      "name": "Giảm giá mùa hè 2025",
      "status": "ACTIVE",
      ...
    }
  ],
  "count": 1
}
```

#### 5. Xem chi tiết Promotion
```
GET /api/promotions/{id}
```

**Response:**
```json
{
  "status": "success",
  "data": {
    "id": 1,
    "name": "Giảm giá mùa hè 2025",
    "description": "Giảm 20% cho tất cả đơn hàng",
    "discountType": "PERCENTAGE",
    "discountValue": 20,
    "minOrderValue": 100000,
    "maxDiscountAmount": 50000,
    "startDate": "2025-06-01T00:00:00",
    "endDate": "2025-08-31T23:59:59",
    "usageLimit": 1000,
    "usedCount": 25,
    "status": "ACTIVE",
    "createdAt": "2025-05-01T10:00:00",
    "updatedAt": "2025-05-01T10:00:00"
  }
}
```

#### 6. Cập nhật Promotion
```
PUT /api/promotions/{id}
```

**Request Body:** (Giống như Create)

#### 7. Xóa Promotion
```
DELETE /api/promotions/{id}
```

**Response:**
```json
{
  "status": "success",
  "message": "Xóa promotion thành công"
}
```

#### 8. Tạo Promo Code
```
POST /api/promotions/codes
```

**Request Body:**
```json
{
  "promotionId": 1,
  "code": "SUMMER2025",
  "singleUse": false,
  "maxUses": 100,
  "userRestriction": null,
  "minOrderValue": 50000,
  "expiresAt": "2025-08-31T23:59:59"
}
```

**Response:**
```json
{
  "status": "success",
  "message": "Tạo mã khuyến mãi thành công",
  "data": {
    "id": 1,
    "promotionId": 1,
    "code": "SUMMER2025",
    "maxUses": 100,
    "usedCount": 0,
    ...
  }
}
```

#### 9. Validate Promo Code
```
POST /api/promotions/validate-code
```

**Request Body:**
```json
{
  "promoCode": "SUMMER2025",
  "userId": 1,
  "orderValue": 200000
}
```

**Response (Valid):**
```json
{
  "status": "success",
  "message": "Mã khuyến mãi hợp lệ",
  "data": {
    "valid": true,
    "promotion": { ... },
    "promoCode": { ... }
  }
}
```

**Response (Invalid):**
```json
{
  "status": "error",
  "message": "Mã khuyến mãi đã hết hạn"
}
```

#### 10. Áp dụng Promo Code
```
POST /api/promotions/apply
```

**Request Body:**
```json
{
  "promoCode": "SUMMER2025",
  "userId": 1,
  "orderValue": 200000
}
```

**Response:**
```json
{
  "status": "success",
  "message": "Áp dụng mã khuyến mãi thành công",
  "data": {
    "originalAmount": 200000,
    "discountAmount": 40000,
    "finalAmount": 160000,
    "promotionName": "Giảm giá mùa hè 2025",
    "promoCode": "SUMMER2025"
  }
}
```

#### 11. Tìm Promotion theo Code
```
GET /api/promotions/code/{code}
```

**Response:**
```json
{
  "status": "success",
  "data": {
    "promoCode": { ... },
    "promotion": { ... }
  }
}
```

---

## 💰 3. TRANSACTION MANAGEMENT

### Mô tả
Quản lý các giao dịch tài chính trong hệ thống.

### Database Table: `transaction_management`
```sql
CREATE TABLE transaction_management (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    transaction_code VARCHAR(50) UNIQUE NOT NULL,
    booking_id BIGINT,
    user_id BIGINT NOT NULL,
    transaction_type VARCHAR(20) NOT NULL,  -- DEPOSIT, PAYMENT, REFUND, PENALTY
    amount DECIMAL(15,2) NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    status VARCHAR(20) NOT NULL,            -- PENDING, COMPLETED, FAILED, REFUNDED, CANCELLED
    description NVARCHAR(500),
    reference_code VARCHAR(100),
    created_at DATETIME NOT NULL,
    updated_at DATETIME,
    completed_at DATETIME
);
```

### Transaction Types
- **DEPOSIT**: Tiền cọc
- **PAYMENT**: Thanh toán
- **REFUND**: Hoàn tiền
- **PENALTY**: Phạt

### Transaction Status
- **PENDING**: Đang chờ
- **COMPLETED**: Hoàn thành
- **FAILED**: Thất bại
- **REFUNDED**: Đã hoàn
- **CANCELLED**: Hủy

---

## 🐛 BUG FIXES

### 1. Thiếu PromotionRepository
**Vấn đề:** File `PromotionRepository.java` không tồn tại

**Fix:** Đã tạo file `PromotionRepository.java` với đầy đủ các query methods

### 2. Thiếu cấu hình VNPay
**Vấn đề:** `application.properties` thiếu cấu hình VNPay

**Fix:** Đã thêm cấu hình VNPay vào `application.properties`

### 3. Unused variables
**Vấn đề:** Một số biến không sử dụng trong `LoginGGController.java` và `AuthService.java`

**Lưu ý:** Cần xem xét xóa hoặc sử dụng các biến này.

---

## 🧪 TESTING

### Test với Postman

#### 1. Test Promotion APIs

**Create Promotion:**
```
POST http://localhost:8080/api/promotions
Body: (JSON như mô tả ở trên)
```

**Get All Promotions:**
```
GET http://localhost:8080/api/promotions
```

**Validate Promo Code:**
```
POST http://localhost:8080/api/promotions/validate-code
Body: {
  "promoCode": "SUMMER2025",
  "userId": 1,
  "orderValue": 200000
}
```

#### 2. Test Payment APIs

**Create Payment:**
```
POST http://localhost:8080/api/payment/create
Body: {
  "userId": 1,
  "amount": 100000,
  "orderInfo": "Test payment",
  "bankCode": "NCB"
}
```

**Get Payment:**
```
GET http://localhost:8080/api/payment/order/ORDER12345678
```

### Test với HTML Page

Đã tạo file test: `DriveNow/html/test-module3.html`

**Cách sử dụng:**
1. Mở file `test-module3.html` trong trình duyệt
2. Đảm bảo backend đang chạy ở `http://localhost:8080`
3. Nhấn các nút test để kiểm tra từng API

---

## 🚀 DEPLOYMENT CHECKLIST

- [ ] Cập nhật database schema (chạy migrations)
- [ ] Cấu hình VNPay credentials (TMN Code & Secret Key)
- [ ] Test toàn bộ APIs với Postman
- [ ] Test tích hợp với Frontend
- [ ] Kiểm tra xử lý exceptions
- [ ] Kiểm tra validation
- [ ] Test performance với dữ liệu lớn
- [ ] Setup logging cho transactions
- [ ] Backup database trước khi deploy

---

## 📞 SUPPORT

Nếu gặp vấn đề:
1. Kiểm tra logs trong console
2. Kiểm tra database connection
3. Kiểm tra VNPay configuration
4. Xem file `HELP.md` trong project

---

## 📝 CHANGELOG

### Version 1.0.0 (2025-10-15)
- ✅ Tích hợp VNPay Payment Gateway
- ✅ Thêm quản lý Promotion & Voucher
- ✅ Thêm quản lý Transaction
- ✅ Tạo Repository cho Promotion
- ✅ Cập nhật cấu hình VNPay
- ✅ Tạo test page HTML

---

**Made with ❤️ for DriveNow Project**
