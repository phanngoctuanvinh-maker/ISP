# Script test toàn bộ 17 API endpoints
# Đợi server khởi động
Write-Host "Đang đợi server khởi động..." -ForegroundColor Yellow
Start-Sleep -Seconds 15

$baseUrl = "http://localhost:8080/api/cars"
$testResults = @()

# Hàm test API
function Test-API {
    param(
        [string]$Name,
        [string]$Url,
        [string]$Method = "GET",
        [object]$Body = $null
    )
    
    Write-Host "`n========================================" -ForegroundColor Cyan
    Write-Host "TEST: $Name" -ForegroundColor Cyan
    Write-Host "URL: $Url" -ForegroundColor Gray
    
    try {
        $params = @{
            Uri = $Url
            Method = $Method
            ContentType = "application/json"
            ErrorAction = "Stop"
        }
        
        if ($Body) {
            $params.Body = ($Body | ConvertTo-Json)
        }
        
        $response = Invoke-RestMethod @params
        
        Write-Host "✓ PASS - Status: 200 OK" -ForegroundColor Green
        
        if ($response.success) {
            Write-Host "  Response: success = true" -ForegroundColor Green
            if ($response.cars) {
                Write-Host "  Total Cars: $($response.cars.Count)" -ForegroundColor Green
            } elseif ($response.car) {
                Write-Host "  Car Found: $($response.car.brand) $($response.car.model)" -ForegroundColor Green
            } elseif ($response.brands) {
                Write-Host "  Total Brands: $($response.brands.Count)" -ForegroundColor Green
            } elseif ($response.transmissions) {
                Write-Host "  Total Transmissions: $($response.transmissions.Count)" -ForegroundColor Green
            }
        }
        
        $testResults += [PSCustomObject]@{
            Test = $Name
            Status = "PASS"
            Details = "200 OK"
        }
        
    } catch {
        Write-Host "✗ FAIL - Error: $($_.Exception.Message)" -ForegroundColor Red
        $testResults += [PSCustomObject]@{
            Test = $Name
            Status = "FAIL"
            Details = $_.Exception.Message
        }
    }
}

# 1. GET All Cars
Test-API -Name "1. Get All Cars" -Url "$baseUrl/all"

# 2. GET Cars by Seat Capacity - 4 chỗ
Test-API -Name "2. Get Cars by Seat Capacity - 4 chỗ" -Url "$baseUrl/by-type?seatCapacity=4"

# 3. GET Cars by Seat Capacity - 5 chỗ
Test-API -Name "3. Get Cars by Seat Capacity - 5 chỗ" -Url "$baseUrl/by-type?seatCapacity=5"

# 4. GET Cars by Seat Capacity - 7 chỗ
Test-API -Name "4. Get Cars by Seat Capacity - 7 chỗ" -Url "$baseUrl/by-type?seatCapacity=7"

# 5. GET Cars by Brand - Toyota
Test-API -Name "5. Get Cars by Brand - Toyota" -Url "$baseUrl/by-brand?brand=Toyota"

# 6. GET Cars by Brand - Vinfast
Test-API -Name "6. Get Cars by Brand - Vinfast" -Url "$baseUrl/by-brand?brand=Vinfast"

# 7. GET Electric Cars
Test-API -Name "7. Get Electric Cars" -Url "$baseUrl/electric"

# 8. GET Hybrid Cars
Test-API -Name "8. Get Hybrid Cars" -Url "$baseUrl/hybrid"

# 9. GET Cars by Transmission - Automatic
Test-API -Name "9. Get Cars by Transmission - Auto" -Url "$baseUrl/by-transmission?transmission=Automatic"

# 10. GET Cars by Transmission - Manual
Test-API -Name "10. Get Cars by Transmission - Manual" -Url "$baseUrl/by-transmission?transmission=Manual"

# 11. POST Search Cars - 4 chỗ
Test-API -Name "11. Search Cars - POST (4 chỗ)" -Url "$baseUrl/search" -Method "POST" -Body @{
    seatCapacity = 4
}

# 12. POST Search Cars - 5 chỗ SUV
Test-API -Name "12. Search Cars - POST (5 chỗ SUV)" -Url "$baseUrl/search" -Method "POST" -Body @{
    seatCapacity = 5
    carType = "SUV"
}

# 13. POST Search Cars - 7 chỗ
Test-API -Name "13. Search Cars - POST (7 chỗ)" -Url "$baseUrl/search" -Method "POST" -Body @{
    seatCapacity = 7
}

# 14. POST Search Cars - Toyota + Automatic
Test-API -Name "14. Search Cars - POST (Toyota + Auto)" -Url "$baseUrl/search" -Method "POST" -Body @{
    brand = "Toyota"
    transmission = "Automatic"
}

# 15. GET Car by ID (test với car_id = 1)
Test-API -Name "15. Get Car by ID" -Url "$baseUrl/1"

# 16. GET All Brands
Test-API -Name "16. Get All Brands" -Url "$baseUrl/brands"

# 17. GET All Transmissions
Test-API -Name "17. Get All Transmissions" -Url "$baseUrl/transmissions"

# Tổng kết kết quả
Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "TỔNG KẾT KẾT QUẢ TEST" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan

$passCount = ($testResults | Where-Object {$_.Status -eq "PASS"}).Count
$failCount = ($testResults | Where-Object {$_.Status -eq "FAIL"}).Count

Write-Host "`nTổng số test: $($testResults.Count)" -ForegroundColor White
Write-Host "Passed: $passCount" -ForegroundColor Green
Write-Host "Failed: $failCount" -ForegroundColor Red

Write-Host "`nChi tiết:" -ForegroundColor Yellow
$testResults | Format-Table -AutoSize

if ($failCount -eq 0) {
    Write-Host "`n🎉 TẤT CẢ CÁC TEST ĐỀU THÀNH CÔNG!" -ForegroundColor Green
} else {
    Write-Host "`n⚠️ CÓ $failCount TEST BỊ LỖI, VUI LÒNG KIỂM TRA!" -ForegroundColor Red
}
