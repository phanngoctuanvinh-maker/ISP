# 🚀 HƯỚNG DẪN TEST NHANH - POSTMAN

## ✅ Bước 1: Import Collection vào Postman

1. Mở **Postman**
2. Click **Import** (góc trên bên trái)
3. Chọn file: `DriveNow_Car_Search_API.postman_collection.json`
4. Click **Import**
5. Collection "DriveNow Car Search API" sẽ xuất hiện bên trái

## ✅ Bước 2: Đảm bảo Server đang chạy

- Server phải chạy tại: `http://localhost:8080`
- Nếu chưa chạy, chạy file: `Project1/start-backend-window.bat`

## ✅ Bước 3: Test các API

### 🔥 TEST NHANH - 5 API QUAN TRỌNG:

#### 1️⃣ **Lấy tất cả xe**
- Chọn request: `1. Lấy tất cả xe`
- Click **Send**
- ✅ Kỳ vọng: Trả về ~30 xe

#### 2️⃣ **Lấy xe điện**
- Chọn request: `2. Lấy xe điện`
- Click **Send**
- ✅ Kỳ vọng: Trả về 3 xe Vinfast (VF e34, VF 8, VF 9)

#### 3️⃣ **Lấy xe hybrid**
- Chọn request: `3. Lấy xe hybrid (xăng & điện)`
- Click **Send**
- ✅ Kỳ vọng: Trả về 3 xe hybrid (Toyota, Honda, Hyundai)

#### 4️⃣ **Lấy xe 7 chỗ**
- Chọn request: `6. Lấy xe 7 chỗ`
- Click **Send**
- ✅ Kỳ vọng: Trả về các xe 7 chỗ (Fortuner, CR-V, CX-8, Everest, Sorento...)

#### 5️⃣ **Lấy xe Toyota**
- Chọn request: `7. Lấy xe Toyota`
- Click **Send**
- ✅ Kỳ vọng: Trả về 4 xe Toyota (Vios, Camry, Fortuner, Corolla Cross Hybrid)

---

## 📋 CHECKLIST TEST ĐẦY ĐỦ

Test theo thứ tự từ 1 → 16:

### ✅ GET Endpoints (11 API):
- [ ] 1. Lấy tất cả xe
- [ ] 2. Lấy xe điện
- [ ] 3. Lấy xe hybrid
- [ ] 4. Lấy xe 4 chỗ
- [ ] 5. Lấy xe 5 chỗ
- [ ] 6. Lấy xe 7 chỗ
- [ ] 7. Lấy xe Toyota
- [ ] 8. Lấy xe Honda
- [ ] 9. Lấy xe Vinfast
- [ ] 10. Lấy xe số sàn
- [ ] 11. Lấy xe số tự động
- [ ] 14. Lấy chi tiết xe ID=1
- [ ] 15. Lấy danh sách hãng xe
- [ ] 16. Lấy danh sách loại truyền động

### ✅ POST Endpoints (2 API):
- [ ] 12. Tìm kiếm nâng cao - Toyota 5 chỗ
- [ ] 13. Tìm kiếm - Xe 7 chỗ

---

## 🎯 KẾT QUẢ MẪU

### Response thành công:
```json
{
    "success": true,
    "message": "Tìm thấy 3 xe",
    "cars": [
        {
            "carId": 1,
            "brand": "Toyota",
            "model": "Vios",
            "year": 2023,
            "seats": 5,
            "fuelType": "gasoline",
            "transmissionType": "automatic",
            "pricePerDay": 500000,
            ...
        }
    ],
    "totalCount": 3
}
```

### Response không tìm thấy:
```json
{
    "success": false,
    "message": "Không tìm thấy xe phù hợp",
    "cars": [],
    "totalCount": 0
}
```

---

## ⚡ TEST NHANH BẰNG CURL (Terminal)

Nếu bạn muốn test nhanh bằng command line:

```powershell
# Test lấy tất cả xe
curl http://localhost:8080/api/cars/all

# Test lấy xe điện
curl http://localhost:8080/api/cars/electric

# Test lấy xe Toyota
curl "http://localhost:8080/api/cars/by-brand?brand=Toyota"

# Test tìm kiếm POST
curl -X POST http://localhost:8080/api/cars/search -H "Content-Type: application/json" -d "{\"filterType\":\"type\",\"seats\":7}"
```

---

## 🐛 XỬ LÝ LỖI

### Lỗi: "Unable to connect"
➡️ **Nguyên nhân:** Server chưa chạy
➡️ **Giải pháp:** Chạy `start-backend-window.bat`

### Lỗi: "404 Not Found"
➡️ **Nguyên nhân:** Sai đường dẫn API
➡️ **Giải pháp:** Kiểm tra URL, phải có `/api/cars`

### Lỗi: "500 Internal Server Error"
➡️ **Nguyên nhân:** Lỗi backend hoặc database
➡️ **Giải pháp:** 
1. Kiểm tra console backend
2. Đảm bảo đã chạy file SQL insert dữ liệu
3. Kiểm tra kết nối database

### Response rỗng (cars: [])
➡️ **Nguyên nhân:** Chưa có dữ liệu trong database
➡️ **Giải pháp:** Chạy file `insert_cars_data.sql`

---

## 📊 THỐNG KÊ DỮ LIỆU

Sau khi insert dữ liệu mẫu, bạn sẽ có:

- **Tổng số xe:** ~30 xe
- **Xe điện:** 3 xe (Vinfast)
- **Xe hybrid:** 3 xe (Toyota, Honda, Hyundai)
- **Xe xăng:** ~24 xe
- **Xe 4 chỗ:** 3 xe
- **Xe 5 chỗ:** ~15 xe
- **Xe 7 chỗ:** ~9 xe
- **Xe số sàn:** 3 xe
- **Xe số tự động:** ~27 xe

**Hãng xe:**
- Toyota: 4 xe
- Honda: 4 xe
- Mazda: 3 xe
- Ford: 3 xe
- Kia: 4 xe
- Hyundai: 4 xe
- Vinfast: 3 xe
- Mitsubishi: 3 xe

---

## ✨ TIPS

1. **Sử dụng Postman Tests**
   - Viết tests tự động kiểm tra response
   - Ví dụ: `pm.expect(response.success).to.be.true`

2. **Sử dụng Variables**
   - Tạo biến `baseUrl` = `http://localhost:8080/api/cars`
   - Thay đổi một lần, áp dụng cho tất cả request

3. **Lưu Response**
   - Click **Save Response** để so sánh sau này
   - Hữu ích khi debug

4. **Test nhiều trường hợp**
   - Test với dữ liệu có
   - Test với dữ liệu không có
   - Test với tham số sai

---

## 🎉 KẾT LUẬN

Sau khi test xong:
✅ Backend hoạt động tốt
✅ Tất cả API trả về đúng dữ liệu
✅ Xử lý lỗi hợp lý
✅ Sẵn sàng tích hợp frontend

**Happy Testing! 🚀**
