# 🚀 HƯỚNG DẪN CHẠY VÀ TEST MODULE 3

## 📌 Tổng quan
Module 3 bao gồm:
- ✅ VNPay Payment Integration
- ✅ Promotion & Voucher Management  
- ✅ Transaction Management

---

## 🔧 Chuẩn bị

### 1. Cài đặt Database

Mở SQL Server Management Studio và chạy:

```sql
-- Tạo database (nếu chưa có)
CREATE DATABASE drivenow_db;
GO

USE drivenow_db;
GO
```

**Lưu ý:** Spring Boot JPA sẽ tự động tạo các tables khi chạy ứng dụng.

### 2. Cấu hình VNPay

Mở file `Project1/src/main/resources/application.properties` và cập nhật:

```properties
# VNPay Sandbox credentials
vnpay.tmn-code=YOUR_TMN_CODE_HERE
vnpay.secret-key=YOUR_SECRET_KEY_HERE
```

**Cách lấy credentials:**
1. Truy cập: https://sandbox.vnpayment.vn/
2. Đăng ký tài khoản merchant
3. Lấy TMN Code và Secret Key từ dashboard

**Hoặc dùng test credentials có sẵn:**
- TMN Code: `0FMOMRK9` (đã có trong file)
- Secret Key: `O7YW3HX0MTQ1EXWGC3PJGJ8UH8CGIWHC` (đã có trong file)

---

## ▶️ Chạy Backend

### Cách 1: Dùng batch file (Khuyến nghị)

```powershell
cd C:\Users\quyen\Downloads\DRIVENOW_ISP\Project1
.\start-backend.bat
```

### Cách 2: Dùng Maven

```powershell
cd C:\Users\quyen\Downloads\DRIVENOW_ISP\Project1
.\mvnw.cmd spring-boot:run
```

### Cách 3: Trong IDE (Eclipse/IntelliJ)

1. Mở project `Project1`
2. Tìm file `DrivenowApplication.java`
3. Click chuột phải → Run As → Java Application

**Kiểm tra backend đang chạy:**
```
http://localhost:8080
```

Nếu thấy trang Whitelabel Error Page là OK!

---

## 🧪 Test APIs

### Option 1: Test với Postman

#### 1. Test Promotion APIs

**Health Check:**
```
GET http://localhost:8080/api/promotions/test
```

**Tạo Promotion:**
```
POST http://localhost:8080/api/promotions
Content-Type: application/json

{
  "name": "Giảm giá tháng 10",
  "description": "Giảm 20% cho tất cả đơn hàng",
  "discountType": "PERCENTAGE",
  "discountValue": 20,
  "minOrderValue": 100000,
  "maxDiscountAmount": 50000,
  "startDate": "2025-10-01T00:00:00",
  "endDate": "2025-10-31T23:59:59",
  "usageLimit": 1000,
  "status": "ACTIVE",
  "createdBy": 1
}
```

**Tạo Promo Code:**
```
POST http://localhost:8080/api/promotions/codes
Content-Type: application/json

{
  "promotionId": 1,
  "code": "OCTOBER2025",
  "singleUse": false,
  "maxUses": 100,
  "minOrderValue": 50000,
  "expiresAt": "2025-10-31T23:59:59"
}
```

**Validate Promo Code:**
```
POST http://localhost:8080/api/promotions/validate-code
Content-Type: application/json

{
  "promoCode": "OCTOBER2025",
  "userId": 1,
  "orderValue": 200000
}
```

**Áp dụng Promo Code:**
```
POST http://localhost:8080/api/promotions/apply
Content-Type: application/json

{
  "promoCode": "OCTOBER2025",
  "userId": 1,
  "orderValue": 200000
}
```

#### 2. Test Payment APIs

**Tạo Payment:**
```
POST http://localhost:8080/api/payment/create
Content-Type: application/json

{
  "userId": 1,
  "amount": 100000,
  "orderInfo": "Thanh toan thue xe",
  "bankCode": "NCB"
}
```

Response sẽ có `paymentUrl` → Copy và mở trong browser để test thanh toán.

**Lấy thông tin Payment:**
```
GET http://localhost:8080/api/payment/order/ORDER12345678
```

**Lấy lịch sử thanh toán:**
```
GET http://localhost:8080/api/payment/user/1
```

---

### Option 2: Test với HTML Test Page

1. Mở file test:
```
C:\Users\quyen\Downloads\DRIVENOW_ISP\DriveNow\html\test-module3.html
```

2. Đảm bảo backend đang chạy

3. Mở file trong trình duyệt (Chrome/Edge)

4. Test từng chức năng:
   - ✅ Test Promotion API
   - ✅ Tạo Promotion
   - ✅ Tạo Promo Code
   - ✅ Validate Code
   - ✅ Áp dụng Code
   - ✅ Tạo VNPay Payment
   - ✅ Tra cứu thanh toán

---

## 🌐 Tích hợp với Frontend

### Bước 1: Thêm JS file vào HTML

```html
<script src="../js/payment-promo-integration.js"></script>
```

### Bước 2: Sử dụng các hàm

**Ví dụ: Tạo thanh toán VNPay**
```javascript
// Lấy thông tin từ form
const userId = 1;
const amount = 200000;
const orderInfo = "Thanh toan thue xe Toyota Vios - 3 ngay";

// Tạo thanh toán
createVNPayPayment(userId, amount, orderInfo)
    .then(response => {
        console.log('Payment created:', response);
        // Tự động redirect đến VNPay
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Có lỗi xảy ra!');
    });
```

**Ví dụ: Áp dụng mã giảm giá**
```javascript
// Setup form nhập mã khuyến mãi
setupPromoCodeForm('promoForm', userId, orderValue, (discountInfo) => {
    // Callback khi áp dụng thành công
    console.log('Discount:', discountInfo);
    
    // Cập nhật UI
    updateOrderSummary(discountInfo);
    
    // discountInfo = {
    //   originalAmount: 200000,
    //   discountAmount: 40000,
    //   finalAmount: 160000,
    //   promotionName: "Giảm giá tháng 10",
    //   promoCode: "OCTOBER2025"
    // }
});
```

**Ví dụ: Hiển thị danh sách khuyến mãi**
```javascript
// Lấy và hiển thị promotions
getActivePromotions()
    .then(promotions => {
        displayPromotions(promotions, 'promotionsContainer');
    })
    .catch(error => {
        console.error('Error:', error);
    });
```

### Bước 3: Thêm HTML markup

**Form nhập mã khuyến mãi:**
```html
<form id="promoForm">
    <div class="promo-input-group">
        <input 
            type="text" 
            name="promoCode" 
            placeholder="Nhập mã khuyến mãi"
            class="form-control"
        >
        <button type="submit" class="btn btn-primary">
            Áp dụng
        </button>
    </div>
</form>

<!-- Hiển thị kết quả -->
<div class="order-summary">
    <div class="row">
        <span>Giá gốc:</span>
        <span id="originalAmount">200,000 VND</span>
    </div>
    <div class="row" style="display: none;">
        <span>Giảm giá:</span>
        <span id="discountAmount" class="text-success">0 VND</span>
    </div>
    <div class="row total">
        <span>Tổng cộng:</span>
        <span id="finalAmount">200,000 VND</span>
    </div>
    <div id="appliedPromoName" style="display: none;" class="text-success"></div>
</div>
```

**Container hiển thị promotions:**
```html
<div id="promotionsContainer" class="promotions-list">
    <!-- Promotions sẽ được render động bằng JS -->
</div>
```

**Nút thanh toán VNPay:**
```html
<div id="vnpayButtonContainer"></div>

<script>
    // Tạo nút VNPay động
    createVNPayButton('vnpayButtonContainer', userId, amount, orderInfo);
</script>
```

---

## 🔍 Debug & Troubleshooting

### Backend không chạy được

**Lỗi: Port 8080 đã được sử dụng**
```
Error: Port 8080 is already in use
```

**Giải pháp:**
```powershell
# Tìm process đang dùng port 8080
netstat -ano | findstr :8080

# Kill process (thay PID bằng số tìm được)
taskkill /PID <PID> /F
```

### Database connection failed

**Kiểm tra:**
1. SQL Server đang chạy?
2. Username/password trong `application.properties` đúng?
3. Database `drivenow_db` đã tạo?

**Chạy lại script:**
```sql
CREATE DATABASE drivenow_db;
GO
```

### VNPay payment không hoạt động

**Kiểm tra:**
1. TMN Code và Secret Key đã cấu hình đúng?
2. Internet connection OK?
3. Return URL accessible?

**Test với sandbox credentials:**
```properties
vnpay.tmn-code=0FMOMRK9
vnpay.secret-key=O7YW3HX0MTQ1EXWGC3PJGJ8UH8CGIWHC
```

### CORS Error từ Frontend

**Lỗi:**
```
Access to fetch at 'http://localhost:8080/api/...' from origin 'null' 
has been blocked by CORS policy
```

**Giải pháp:** Backend đã có CORS config, nhưng nếu vẫn lỗi:
1. Dùng Live Server extension trong VSCode
2. Hoặc serve file qua http server:
```powershell
# Install http-server globally
npm install -g http-server

# Chạy trong thư mục DriveNow
cd C:\Users\quyen\Downloads\DRIVENOW_ISP\DriveNow
http-server -p 3000
```

Sau đó mở: `http://localhost:3000/html/test-module3.html`

---

## ✅ Checklist Test

- [ ] Backend chạy thành công (port 8080)
- [ ] Database connected
- [ ] Promotion API test pass
- [ ] Có thể tạo promotion mới
- [ ] Có thể tạo promo code
- [ ] Validate promo code hoạt động
- [ ] Áp dụng promo code tính toán đúng
- [ ] VNPay payment URL được tạo
- [ ] Có thể tra cứu payment
- [ ] Frontend integration hoạt động
- [ ] CORS không có lỗi

---

## 📊 Test Data Mẫu

### Promotion 1: Giảm theo phần trăm
```json
{
  "name": "Giảm 20% mùa thu",
  "discountType": "PERCENTAGE",
  "discountValue": 20,
  "minOrderValue": 100000,
  "maxDiscountAmount": 50000,
  "startDate": "2025-10-01T00:00:00",
  "endDate": "2025-10-31T23:59:59",
  "usageLimit": 500
}
```

### Promotion 2: Giảm cố định
```json
{
  "name": "Giảm 50k cho khách mới",
  "discountType": "FIXED_AMOUNT",
  "discountValue": 50000,
  "minOrderValue": 200000,
  "startDate": "2025-10-01T00:00:00",
  "endDate": "2025-12-31T23:59:59",
  "usageLimit": 1000
}
```

### Promo Codes
```
OCTOBER2025    - Dùng với Promotion 1
NEWCUSTOMER    - Dùng với Promotion 2
FALL20         - Giảm 20%
SAVE50K        - Giảm 50k
```

---

## 🎯 Kịch bản Test End-to-End

### Scenario 1: Thuê xe có khuyến mãi + thanh toán VNPay

1. **User chọn xe và ngày thuê**
   - Xe: Toyota Vios
   - Số ngày: 3
   - Giá gốc: 1,500,000 VND

2. **User nhập mã khuyến mãi**
   - Code: `OCTOBER2025`
   - Validate → OK
   - Apply → Giảm 20% = 300,000 VND
   - Giá sau giảm: 1,200,000 VND

3. **User chọn thanh toán VNPay**
   - Click "Thanh toán"
   - Backend tạo payment URL
   - Redirect đến VNPay
   - User thanh toán trên VNPay
   - VNPay callback về backend
   - Backend cập nhật payment status
   - Redirect về trang xác nhận

4. **Kiểm tra kết quả**
   - Payment status = SUCCESS
   - Promotion used_count tăng lên
   - PromoCode used_count tăng lên

---

## 📞 Support

Nếu gặp vấn đề:
1. Check console logs (F12)
2. Check backend logs
3. Xem file `MODULE3_DOCUMENTATION.md`
4. Test với Postman trước

---

**Good luck! 🚀**
