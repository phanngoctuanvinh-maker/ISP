# 🚀 HƯỚNG DẪN TEST CHỨC NĂNG QUÊN MẬT KHẨU TRÊN WEB

## 📋 Tổng quan

Chức năng "Quên mật khẩu" giờ đã hoàn chỉnh với 2 bước:
1. **Gửi OTP về email** (`forgotpassword.html`)
2. **Nhập OTP và đặt lại mật khẩu** (`resetpassword.html`)

---

## ⚠️ QUAN TRỌNG: Cấu hình email trước khi test

Lỗi bạn gặp: **"Authentication failed"** vì backend chưa cấu hình Gmail.

### ✅ Cách fix (2 phút):

Xem file: `drivenow/CAU_HINH_EMAIL_NHANH.md`

**Tóm tắt:**
1. Tạo App Password từ Gmail: https://myaccount.google.com/security
2. Sửa trong `drivenow/src/main/resources/application.properties`:
   ```properties
   spring.mail.username=quyenthedinh@gmail.com
   spring.mail.password=your-16-digit-app-password
   ```
3. Khởi động lại backend: `.\start-backend.bat`

---

## 🧪 Cách test trên web (sau khi cấu hình email)

### Bước 1: Gửi yêu cầu quên mật khẩu

1. Mở trình duyệt: http://127.0.0.1:5500/Project1/html/forgotpassword.html
2. Nhập email đã đăng ký (VD: `quyenthedinh@gmail.com`)
3. Click **"Gửi yêu cầu"**
4. Chờ thông báo: ✅ **"Đã gửi mã OTP về email. Đang chuyển hướng..."**
5. Trang sẽ tự động chuyển sang `resetpassword.html`

### Bước 2: Kiểm tra email

1. Mở Gmail của bạn
2. Tìm email từ `spring.mail.username` với subject: **"DriveNow - Mã OTP đặt lại mật khẩu"**
3. Lấy mã OTP 6 số (VD: `123456`)

### Bước 3: Đặt lại mật khẩu

1. Trên trang `resetpassword.html`:
   - Email đã tự động điền
   - Nhập **Mã OTP**: `123456`
   - Nhập **Mật khẩu mới**: `MatKhauMoi123`
   - Nhập **Xác nhận mật khẩu**: `MatKhauMoi123`
2. Click **"Đặt lại mật khẩu"**
3. Thông báo thành công: ✅ **"Đặt lại mật khẩu thành công!"**
4. Trang tự động chuyển về `login.html` sau 2 giây

### Bước 4: Đăng nhập với mật khẩu mới

1. Trên trang login: http://127.0.0.1:5500/Project1/html/login.html
2. Nhập:
   - Email: `quyenthedinh@gmail.com`
   - Password: `MatKhauMoi123`
3. Click **"Đăng nhập"** → Thành công!

---

## 🎯 Test các trường hợp lỗi

### 1. Email chưa đăng ký
- Nhập email random: `khongcotontai@gmail.com`
- Kết quả: ❌ **"Email này chưa được đăng ký trong hệ thống"**

### 2. OTP sai
- Nhập OTP: `999999`
- Kết quả: ❌ **"Mã OTP không hợp lệ hoặc đã hết hạn"**

### 3. OTP hết hạn
- Chờ **6 phút** sau khi nhận OTP
- Nhập OTP cũ
- Kết quả: ❌ **"Mã OTP không hợp lệ hoặc đã hết hạn"**

### 4. Mật khẩu xác nhận không khớp
- Mật khẩu mới: `123456`
- Xác nhận: `654321`
- Kết quả: ❌ **"Mật khẩu xác nhận không khớp!"**

### 5. Email chưa cấu hình (lỗi hiện tại của bạn)
- Kết quả: ⚠️ **"Hệ thống email chưa được cấu hình. Vui lòng liên hệ quản trị viên."**

---

## 🔄 Gửi lại OTP

Nếu OTP hết hạn hoặc chưa nhận được email:
1. Trên trang `resetpassword.html`, click **"🔄 Gửi lại mã OTP"**
2. Quay lại trang `forgotpassword.html`
3. Nhập email và gửi lại

---

## 📁 Các file đã tạo/sửa

### Frontend (Project1):
- ✅ `html/resetpassword.html` - Trang nhập OTP và mật khẩu mới
- ✅ `css/resetpassword.css` - Giao diện đẹp, responsive
- ✅ `js/resetpassword.js` - Xử lý form reset password
- ✅ `js/api.js` - Thêm method `resetPassword()`
- ✅ `js/forgotpassword.js` - Tự động chuyển hướng + hiển thị lỗi rõ ràng

### Backend (drivenow):
- ✅ `CAU_HINH_EMAIL_NHANH.md` - Hướng dẫn cấu hình Gmail
- ✅ Code backend đã sẵn sàng (OTPService, EmailService, AuthService)

---

## ✅ Checklist hoàn thành

- [ ] Đã cấu hình `spring.mail.username` và `spring.mail.password`
- [ ] Đã khởi động lại backend
- [ ] Đã test gửi OTP thành công
- [ ] Đã nhận email OTP
- [ ] Đã reset password thành công
- [ ] Đã đăng nhập với mật khẩu mới

---

## 🎨 Giao diện mới

Trang `resetpassword.html` có:
- ✨ Thiết kế đẹp, gradient tím
- 📱 Responsive (hoạt động tốt trên mobile)
- 🎯 Validation đầy đủ (OTP 6 số, mật khẩu min 6 ký tự)
- 💡 Hướng dẫn rõ ràng cho người dùng
- ⏱️ Auto redirect sau khi thành công

---

**Giờ bạn có thể test toàn bộ flow quên mật khẩu ngay trên web, không cần Postman!** 🎉
