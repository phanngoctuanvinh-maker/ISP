@echo off
chcp 65001 >nul
echo ================================
echo TEST GOOGLE LOGIN - DRIVENOW
echo ================================
echo.

echo [1/3] Kiểm tra file api.js...
if exist "DriveNow\js\api.js" (
    echo ✓ File api.js đã tồn tại
) else (
    echo ✗ CẢNH BÁO: File api.js KHÔNG tồn tại!
    pause
    exit /b 1
)

echo.
echo [2/3] Kiểm tra Backend đang chạy...
curl -s http://localhost:8080/api/auth/login > nul 2>&1
if %errorlevel% equ 0 (
    echo ✓ Backend đang chạy trên port 8080
) else (
    echo ✗ CẢNH BÁO: Backend CHƯA chạy!
    echo.
    echo Bạn có muốn khởi động backend không? (Y/N)
    set /p choice=
    if /i "%choice%"=="Y" (
        echo Đang khởi động backend...
        start cmd /k "cd Project1 && .\start-backend.bat"
        timeout /t 10 /nobreak
    )
)

echo.
echo [3/3] Mở test page...
start "" "DriveNow\test-google-login.html"

echo.
echo ================================
echo HƯỚNG DẪN TEST:
echo ================================
echo 1. Trang test đã được mở trong browser
echo 2. Kiểm tra status hiển thị "API object loaded successfully"
echo 3. Click nút "Sign in with Google"
echo 4. Nếu thành công, mở login.html để test chính thức
echo.
echo Nếu có lỗi, mở Developer Console (F12) để xem chi tiết
echo.

pause
