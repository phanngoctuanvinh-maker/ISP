# 🚗 HƯỚNG DẪN TÍCH HỢP MODULE 3 - DRIVENOW

## 📋 Tổng quan

Module 3 bao gồm 3 chức năng chính:
1. **VNPay Payment** - Thanh toán qua cổng VNPay
2. **Promotion Management** - Quản lý khuyến mãi
3. **Promo Code** - Mã giảm giá

---

## 🎯 Luồng sử dụng trong trang `booking-with-payment.html`

### **Bước 1: Chọn xe** 🚙
1. Nhấn vào xe bạn muốn thuê (khung sẽ chuyển màu xanh khi chọn)
2. Chọn **Ngày nhận xe** và **Ngày trả xe**
3. Hệ thống tự động tính **Số ngày thuê**
4. Nhấn **"Tiếp tục"**

### **Bước 2: Áp dụng khuyến mãi** 🎁
Có 2 cách áp dụng giảm giá:

#### Cách 1: Sử dụng Mã giảm giá (Promo Code)
1. Nhập mã vào ô **"Nhập mã giảm giá..."**
2. Nhấn **"Áp dụng"**
3. Nếu hợp lệ → Giảm giá được áp dụng ngay

**Mã giảm giá mẫu có sẵn**:
- `SUMMER2024` - Giảm 15%
- `NEWUSER` - Giảm 100,000 VNĐ
- `WEEKEND20` - Giảm 20% (chỉ cuối tuần)

#### Cách 2: Chọn Khuyến mãi (Promotion)
1. Xem danh sách khuyến mãi đang hoạt động
2. Nhấn **"Chọn"** trên khuyến mãi bạn muốn
3. Giảm giá được áp dụng tự động

**Lưu ý**: Chỉ được áp dụng **1 trong 2** (Promo Code HOẶC Promotion)

4. Nhấn **"Thanh toán"** để tiếp tục

### **Bước 3: Thanh toán** 💳
1. Kiểm tra lại **Chi tiết thanh toán**
2. Thêm **Ghi chú** nếu cần (tùy chọn)
3. Nhấn **"Thanh toán ngay"**
4. Hệ thống chuyển hướng đến **VNPay** để thanh toán

---

## 🔧 Kiểm tra Backend đang chạy

Trước khi test, hãy đảm bảo backend đang chạy:

```powershell
# Kiểm tra port 8080
netstat -ano | findstr ":8080"

# Nếu không chạy, vào thư mục Project1 và chạy:
cd C:\Users\quyen\Downloads\DRIVENOW_ISP\Project1
.\start-debug.bat
```

---

## 📡 Các API được sử dụng

### 1. **Promotion APIs**
```javascript
// Lấy danh sách khuyến mãi đang hoạt động
GET /api/promotions/active

// Lấy chi tiết 1 khuyến mãi
GET /api/promotions/{id}
```

### 2. **Promo Code APIs**
```javascript
// Xác thực mã giảm giá
GET /api/promo-codes/validate/{code}?orderValue={amount}
```

### 3. **VNPay APIs**
```javascript
// Tạo URL thanh toán
POST /api/vnpay/create-payment
Body: {
    "amount": 500000,
    "orderInfo": "Thuê xe Toyota Vios - 1 ngày",
    "orderType": "CAR_RENTAL",
    "language": "vn",
    "userId": 1,
    "promoCodeId": 1,      // Tùy chọn
    "promotionId": null     // Tùy chọn
}

// Xử lý callback từ VNPay
GET /api/vnpay/callback?vnp_ResponseCode=00&...

// Lấy thông tin giao dịch
GET /api/vnpay/payment/{orderId}

// Lấy lịch sử giao dịch theo user
GET /api/vnpay/payments/user/{userId}
```

---

## 🧪 Test từng chức năng

### Test 1: Khuyến mãi (Promotions)
```javascript
// Mở Console (F12) và chạy:
fetch('http://localhost:8080/api/promotions/active')
  .then(r => r.json())
  .then(data => console.log(data))
```

**Kết quả mong đợi**:
```json
{
    "status": "success",
    "data": [
        {
            "id": 2,
            "name": "Summer Sale 2024",
            "discountType": "PERCENTAGE",
            "discountValue": 20,
            "startDate": "2024-06-01",
            "endDate": "2024-08-31"
        }
    ]
}
```

### Test 2: Mã giảm giá (Promo Code)
```javascript
// Test với mã SUMMER2024
fetch('http://localhost:8080/api/promo-codes/validate/SUMMER2024?orderValue=500000')
  .then(r => r.json())
  .then(data => console.log(data))
```

**Kết quả mong đợi**:
```json
{
    "status": "success",
    "valid": true,
    "message": "Mã giảm giá hợp lệ",
    "data": {
        "code": "SUMMER2024",
        "discountType": "PERCENTAGE",
        "discountValue": 15
    }
}
```

### Test 3: Tạo thanh toán VNPay
```javascript
// Test tạo URL thanh toán
fetch('http://localhost:8080/api/vnpay/create-payment', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
        amount: 500000,
        orderInfo: "Test thanh toán",
        orderType: "CAR_RENTAL",
        language: "vn",
        userId: 1
    })
})
.then(r => r.json())
.then(data => console.log(data))
```

**Kết quả mong đợi**:
```json
{
    "status": "success",
    "message": "Payment URL created successfully",
    "paymentUrl": "https://sandbox.vnpayment.vn/paymentv2/vpcpay.html?..."
}
```

---

## 🎨 Tùy chỉnh giao diện

File `booking-with-payment.html` đã tích hợp:
- ✅ Bootstrap 5.3.2
- ✅ Font Awesome 6.4.0
- ✅ Gradient đẹp mắt
- ✅ Responsive design
- ✅ Animation mượt mà
- ✅ Step-by-step indicator

Bạn có thể thay đổi màu sắc tại phần `<style>`:
```css
/* Đổi màu chính từ tím sang xanh */
background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
/* Thành */
background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
```

---

## ⚠️ Lưu ý quan trọng

### 1. **CORS Configuration**
- ✅ **GIỮ NGUYÊN** `CorsConfig.java` - Không xóa!
- ❌ **KHÔNG DÙNG** `@CrossOrigin(origins = "*")` trong controller
- Lý do: Gây conflict khi có `allowCredentials=true`

### 2. **VNPay Sandbox**
- URL: `https://sandbox.vnpayment.vn`
- TMN Code: `0FMOMRK9`
- Secret Key: Đã cấu hình trong `application.properties`

### 3. **Dữ liệu test**
Backend cần có dữ liệu mẫu trong database:
- Promotions (bảng `promotion`)
- Promo Codes (bảng `promo_code`)
- Users (bảng `customer`)

---

## 🐛 Troubleshooting

### Lỗi: "CORS policy: No 'Access-Control-Allow-Origin'"
**Nguyên nhân**: Backend không chạy hoặc CorsConfig bị xóa

**Giải pháp**:
```powershell
# Kiểm tra backend
netstat -ano | findstr ":8080"

# Nếu không thấy, khởi động lại
cd C:\Users\quyen\Downloads\DRIVENOW_ISP\Project1
.\start-debug.bat
```

### Lỗi: "500 Internal Server Error"
**Nguyên nhân**: Lỗi trong controller hoặc service

**Giải pháp**:
1. Xem log trong CMD window (backend terminal)
2. Tìm dòng màu đỏ với stack trace
3. Kiểm tra xem thiếu dependency nào không

### Lỗi: "Không có khuyến mãi nào"
**Nguyên nhân**: Database chưa có dữ liệu

**Giải pháp**:
```sql
-- Chạy script này trong SQL Server
INSERT INTO promotion (name, description, discount_type, discount_value, start_date, end_date, status)
VALUES 
('Summer Sale 2024', 'Giảm 20% cho tất cả đơn hàng', 'PERCENTAGE', 20, '2024-06-01', '2024-08-31', 'ACTIVE'),
('New User Discount', 'Giảm 100k cho khách hàng mới', 'FIXED_AMOUNT', 100000, '2024-01-01', '2024-12-31', 'ACTIVE');

INSERT INTO promo_code (code, discount_type, discount_value, min_order_value, max_usage, current_usage, start_date, end_date, status)
VALUES
('SUMMER2024', 'PERCENTAGE', 15, 200000, 100, 0, '2024-06-01', '2024-08-31', 'ACTIVE'),
('NEWUSER', 'FIXED_AMOUNT', 100000, 300000, 50, 0, '2024-01-01', '2024-12-31', 'ACTIVE');
```

---

## 🚀 Bước tiếp theo

1. **Hoàn thiện luồng booking**:
   - Lưu thông tin booking vào database
   - Gửi email xác nhận
   - Cập nhật trạng thái xe

2. **Tích hợp với trang khác**:
   - Login/Register → Lấy userId thực tế
   - Profile → Xem lịch sử giao dịch
   - Homepage → Hiển thị khuyến mãi hot

3. **Bảo mật**:
   - Thêm JWT authentication
   - Validate dữ liệu phía server
   - Mã hóa thông tin nhạy cảm

---

## 📞 Hỗ trợ

Nếu gặp vấn đề, hãy kiểm tra:
1. ✅ Backend đang chạy (port 8080)
2. ✅ Database có dữ liệu mẫu
3. ✅ CorsConfig.java chưa bị xóa
4. ✅ Mở file HTML bằng trình duyệt (không phải text editor)

---

**🎉 Chúc bạn test thành công!**
