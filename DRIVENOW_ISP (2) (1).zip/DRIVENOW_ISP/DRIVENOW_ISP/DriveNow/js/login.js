document.addEventListener('DOMContentLoaded', function() {
    // Xử lý chuyển hướng sang trang đăng ký khi click 'Đăng ký ngay'
    const switchToRegister = document.querySelector('.switch-to-register');
    if (switchToRegister) {
        switchToRegister.addEventListener('click', function(e) {
            e.preventDefault();
            window.location.href = 'register.html';
        });
    }
    const loginForm = document.querySelector('.login-form');
    
    if (loginForm) {
        loginForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            const oldError = this.querySelector('.error-message');
            if (oldError) oldError.remove();
            const username = this.querySelector('input[type="text"]').value.trim();
            const password = this.querySelector('input[type="password"]').value;
            if (!username || !password) {
                showError(this, 'Vui lòng nhập đầy đủ thông tin!');
                return;
            }
            const submitBtn = this.querySelector('.btn-submit');
            submitBtn.disabled = true;
            submitBtn.textContent = 'Đang đăng nhập...';
            try {
                const response = await api.login(username, password);
                if (response.success && response.data) {
                    // Lưu token và user info đã được api.js xử lý
                    let role = response.data.role || '';
                    role = role.toUpperCase();
                    // Chuyển hướng toàn trang nếu đăng nhập từ modal/iframe
                    function redirectTo(url) {
                        if (window.parent && window.parent !== window) {
                            window.parent.location.href = url;
                        } else {
                            window.location.href = url;
                        }
                    }
                    if (role === 'ADMIN' || role === 'admin') {
                        redirectTo('../Admin/html/admin.html');
                    } else if (role === 'CUSTOMER' || role === 'USER' || role === 'customer' || role === 'user') {
                        redirectTo('homepage.html');
                    } else if (role === 'DRIVE' || role === 'DRIVER' || role === 'drive' || role === 'driver') {
                        redirectTo('drive.html');
                    } else {
                        redirectTo('homepage.html');
                    }
                } else {
                        // Nếu backend trả về lỗi xác thực, hiển thị thông báo cụ thể
                        // Luôn hiển thị thông báo tiếng Việt cho mọi lỗi đăng nhập
                        showError(this, 'Sai tài khoản hoặc mật khẩu!');
                }
            } catch (error) {
                    // Luôn hiển thị thông báo tiếng Việt cho mọi lỗi đăng nhập
                    showError(this, 'Sai tài khoản hoặc mật khẩu!');
            } finally {
                submitBtn.disabled = false;
                submitBtn.textContent = 'Đăng Nhập';
            }
        });
    }
    
    function showError(form, message) {
        const submitBtn = form.querySelector('.btn-submit');
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-message';
        errorDiv.innerHTML = `<i class="fas fa-exclamation-circle"></i> ${message}`;
        form.insertBefore(errorDiv, submitBtn);
    }

    // Xử lý nút xem mật khẩu
    const togglePassword = document.querySelector('.toggle-password');
    if (togglePassword) {
        togglePassword.addEventListener('click', function() {
            const input = this.previousElementSibling;
            const icon = this.querySelector('i');
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            }
        });
    }

    // Forgot password UI & logic
    const forgotBtn = document.getElementById('forgotPasswordBtn');
    const forgotSection = document.getElementById('forgotPasswordSection');
    const forgotForm = document.getElementById('forgotPasswordForm');
    const forgotMsg = document.getElementById('forgotPasswordMessage');

    if (forgotBtn && forgotSection && forgotForm) {
        forgotBtn.addEventListener('click', function(e) {
            e.preventDefault();
            forgotSection.style.display = forgotSection.style.display === 'none' ? 'block' : 'none';
        });

        forgotForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            forgotMsg.textContent = '';
            const email = document.getElementById('forgotEmail').value.trim();
            if (!email) {
                forgotMsg.textContent = 'Vui lòng nhập email.';
                forgotMsg.style.color = 'red';
                return;
            }
            try {
                await api.forgotPassword(email);
                forgotMsg.textContent = 'Đã gửi yêu cầu lấy lại mật khẩu. Vui lòng kiểm tra email.';
                forgotMsg.style.color = 'green';
                forgotForm.reset();
            } catch (err) {
                forgotMsg.textContent = err.message || 'Không gửi được yêu cầu.';
                forgotMsg.style.color = 'red';
            }
        });
    }
});

/**
 * Google Login Callback
 * Được gọi tự động khi user đăng nhập Google thành công
 */
async function handleGoogleLogin(response) {
    try {
        // Kiểm tra xem api object đã được load chưa
        if (typeof api === 'undefined') {
            console.error('API object is not defined!');
            alert('Lỗi hệ thống: API không được load. Vui lòng tải lại trang!');
            return;
        }

        if (typeof api.googleLogin !== 'function') {
            console.error('api.googleLogin is not a function!');
            alert('Lỗi hệ thống: API Google Login không khả dụng!');
            return;
        }

        // response.credential chứa Google ID Token
        const idToken = response.credential;
        console.log('Google ID Token received:', idToken.substring(0, 50) + '...');
        
        // Gọi backend API để verify và login
        const apiResponse = await api.googleLogin(idToken);
        console.log('API Response:', apiResponse);
        
        if (apiResponse.success) {
            // Đăng nhập thành công - Chuyển về homepage
            console.log('Login successful, redirecting to homepage...');
            
            // Hiển thị thông báo thành công (tùy chọn)
            // alert('Đăng nhập thành công! Chào mừng bạn đến với DriveNow.');
            
            if (window.parent && window.parent !== window) {
                window.parent.location.reload();
            } else {
                window.location.href = 'homepage.html';
            }
        } else {
            // Đăng nhập thất bại - Hiển thị lỗi
            console.error('Login failed:', apiResponse.message);
            alert('Đăng nhập thất bại: ' + (apiResponse.message || 'Lỗi không xác định'));
        }
    } catch (error) {
        console.error('Google Login Error:', error);
        alert('Đăng nhập Google thất bại: ' + (error.message || 'Vui lòng thử lại'));
    }
}

// Export hàm để Google Sign-In có thể gọi
window.handleGoogleLogin = handleGoogleLogin;

