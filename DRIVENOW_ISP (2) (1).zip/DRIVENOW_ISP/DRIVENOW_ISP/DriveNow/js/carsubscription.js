// Mapping from short codes to full city names
const cityMapping = {
    'hn': 'Hà Nội',
    'hcm': 'Hồ Chí Minh',
    'dn': 'Đà Nẵng',
    'hp': 'Hải Phòng',
    'ct': 'Cần Thơ',
    'bd': 'Bình Dương',
    'dn2': 'Đồng Nai',
    'kh': 'Khánh Hòa',
    'lc': 'Lâm Đồng',
    'vt': 'Vũng Tàu'
};

// Get city name from URL parameters or localStorage
function getCityName() {
    // Try to get from URL parameters first
    const urlParams = new URLSearchParams(window.location.search);
    let cityName = urlParams.get('city');
    
    // If not in URL, try localStorage
    if (!cityName) {
        cityName = localStorage.getItem('selectedCity');
    }
    
    // Decode URI component to get full city name
    if (cityName) {
        cityName = decodeURIComponent(cityName);
        
        // Check if it's a short code and convert to full name
        const lowerCityName = cityName.toLowerCase();
        if (cityMapping[lowerCityName]) {
            cityName = cityMapping[lowerCityName];
        }
    }
    
    // Default city if nothing is found
    return cityName || 'Chọn thành phố';
}

// Update city name in the page
function updateCityDisplay() {
    const cityName = getCityName();
    const cityDisplayElement = document.querySelector('.city-name');
    
    if (cityDisplayElement) {
        cityDisplayElement.textContent = cityName;
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    updateCityDisplay();

    // Handle car type selection
    document.querySelectorAll('.car-type-item').forEach(item => {
        item.addEventListener('click', () => {
            document.querySelectorAll('.car-type-item').forEach(i => i.classList.remove('active'));
            item.classList.add('active');
        });
    });

    // Handle brand selection
    document.querySelectorAll('.brand-card-item').forEach(item => {
        item.addEventListener('click', () => {
            document.querySelectorAll('.brand-card-item').forEach(i => i.classList.remove('active'));
            item.classList.add('active');
        });
    });
});

// Lấy tên thành phố từ URL hoặc localStorage
const urlParams = new URLSearchParams(window.location.search);
const cityFromUrl = urlParams.get('city');
const cityFromStorage = localStorage.getItem('selectedCity');
    
// Mapping tên thành phố đầy đủ (hỗ trợ cả chữ hoa và chữ thường)
const cityFullNames = {
    'Hà Nội': 'Hà Nội',
    'hà nội': 'Hà Nội',
    'HN': 'Hà Nội',
    'hn': 'Hà Nội',
    'Hồ Chí Minh': 'Hồ Chí Minh',
    'hồ chí minh': 'Hồ Chí Minh',
    'HCM': 'Hồ Chí Minh',
    'hcm': 'Hồ Chí Minh',
    'Đà Nẵng': 'Đà Nẵng',
    'đà nẵng': 'Đà Nẵng',
    'DN': 'Đà Nẵng',
    'dn': 'Đà Nẵng',
};

// Lấy tên thành phố (ưu tiên từ URL, sau đó localStorage)
let cityCode = cityFromUrl || cityFromStorage;
let cityName = 'Chọn thành phố';
    
// Nếu có cityCode, tìm trong mapping
if (cityCode) {
    // Thử tìm trực tiếp
    if (cityFullNames[cityCode]) {
        cityName = cityFullNames[cityCode];
    } 
    // Thử tìm với chữ thường
    else if (cityFullNames[cityCode.toLowerCase()]) {
        cityName = cityFullNames[cityCode.toLowerCase()];
    }
    // Nếu không tìm thấy, giữ nguyên cityCode
    else {
        cityName = cityCode;
    }
}

// Hiển thị tên thành phố
const cityNameElement = document.getElementById('cityName');
if (cityNameElement) {
    cityNameElement.textContent = cityName;
}

// Lưu tên đầy đủ vào localStorage để sử dụng sau
if (cityCode) {
    localStorage.setItem('selectedCity', cityCode);
    localStorage.setItem('selectedCityFullName', cityName);
}

// Xử lý nút back
const backBtn = document.querySelector('.back-btn');
if (backBtn) {
    backBtn.addEventListener('click', function() {
        window.history.back();
    });
}

// Xử lý filter buttons
const filterBtns = document.querySelectorAll('.filter-btn');
    
filterBtns.forEach(btn => {
    btn.addEventListener('click', function() {
        // Remove active class from all buttons
        filterBtns.forEach(b => b.classList.remove('active'));
        
        // Add active class to clicked button
        this.classList.add('active');
        
        // Lấy filter type
        const filterType = this.textContent.trim();
        console.log('Filter selected:', filterType);
        
        // TODO: Thêm logic lọc xe theo filter type
        filterCars(filterType);
    });
});

// Function to filter cars
function filterCars(filterType) {
    // TODO: Implement filter logic based on filterType
    // Ví dụ: filter theo 'Loại Xe', 'Hãng Xe', 'Truyền động'
    console.log('Filtering cars by:', filterType);
}

// Load cars for the selected city
async function loadCarsForCity(cityName) {
    console.log('Loading cars for city:', cityName);
    const carGrid = document.querySelector('.cars-grid');
    if (!carGrid) return;

    carGrid.innerHTML = '<p>Đang tải danh sách xe...</p>'; // Loading message

    try {
        const response = await api.getSubscriptionCars(cityName);
        if (response.success && response.data.length > 0) {
            displayCars(response.data);
        } else {
            carGrid.innerHTML = '<p>Không tìm thấy xe nào cho khu vực này.</p>';
        }
    } catch (error) {
        carGrid.innerHTML = `<p class="error">Lỗi khi tải danh sách xe: ${error.message}</p>`;
    }
}

// Function to display cars
function displayCars(cars) {
    const carGrid = document.querySelector('.cars-grid');
    if (!carGrid) return;

    carGrid.innerHTML = ''; // Clear loading message

    cars.forEach(car => {
        const carItem = document.createElement('div');
        carItem.className = 'car-item';
        carItem.innerHTML = `
            <div class="car-img-placeholder" style="background-image: url('${car.imageUrl || '../assets/inmage/default-car.png'}')"></div>
            <div class="car-details">
                <h3 class="car-name">${car.brand} ${car.model}</h3>
                <p class="car-specs">${car.year} - ${car.transmission}</p>
                <div class="car-price">
                    <span class="price-amount">${new Intl.NumberFormat('vi-VN').format(car.pricePerMonth)}</span>
                    <span class="price-unit">đ/tháng</span>
                </div>
                <button class="btn-view-details">Xem chi tiết</button>
            </div>
        `;
        carGrid.appendChild(carItem);
    });
}
