
let isOrderDetailsShown = false;
let timeLeft = 900;
let timerInterval;
let bookingData = {
    customerName: '',
    customerPhone: '',
    hasVAT: false,
    companyName: '',
    companyAddress: '',
    taxCode: '',
    companyEmail: ''
};

function handleConfirm() {
    const name = document.getElementById('customerName').value.trim();
    const phone = document.getElementById('customerPhone').value.trim();

    if (!name || !phone) {
        alert('Vui lòng điền đầy đủ thông tin!');
        return;
    }

    // Lưu thông tin vào bookingData
    bookingData.customerName = name;
    bookingData.customerPhone = phone;
    bookingData.hasVAT = document.getElementById('vatCheckbox').checked;

    if (bookingData.hasVAT) {
        const vatInputs = document.querySelectorAll('#vatForm input');
        bookingData.companyName = vatInputs[0].value.trim();
        bookingData.companyAddress = vatInputs[1].value.trim();
        bookingData.taxCode = vatInputs[2].value.trim();
        bookingData.companyEmail = vatInputs[3].value.trim();
    }

    goToPayment();
}

function showOrderDetails() {
    const orderDetails = document.getElementById('orderDetails');
    const confirmBtn = document.getElementById('confirmBtn');
    const terms = document.getElementById('terms');

    orderDetails.style.display = 'block';
    confirmBtn.textContent = 'Xác nhận';
    terms.style.display = 'block';
    isOrderDetailsShown = true;

    setTimeout(() => {
        orderDetails.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }, 300);
}

function goToPayment() {
    // Kiểm tra có dữ liệu không
    if (!bookingData.customerName || !bookingData.customerPhone) {
        alert('Vui lòng điền thông tin trước!');
        return;
    }

    // Chuyển màn hình
    document.getElementById('bookingScreen').classList.remove('active');
    document.getElementById('paymentScreen').classList.add('active');

    // Cập nhật thông tin khách hàng
    document.getElementById('paymentCustomerName').textContent = bookingData.customerName;
    document.getElementById('paymentCustomerPhone').textContent = bookingData.customerPhone;

    // Hiển thị thông tin VAT nếu có
    updateVATInfo();

    // Bắt đầu đếm ngược
    startTimer();
    window.scrollTo(0, 0);
}

function updateVATInfo() {
    const vatInfoSection = document.getElementById('vatInfoSection');

    if (bookingData.hasVAT && bookingData.companyName) {
        vatInfoSection.style.display = 'block';
        document.getElementById('paymentCompanyName').textContent = bookingData.companyName || '-';
        document.getElementById('paymentCompanyAddress').textContent = bookingData.companyAddress || '-';
        document.getElementById('paymentTaxCode').textContent = bookingData.taxCode || '-';
        document.getElementById('paymentCompanyEmail').textContent = bookingData.companyEmail || '-';
    } else {
        vatInfoSection.style.display = 'none';
    }
}

function goToBooking() {
    if (timerInterval) {
        clearInterval(timerInterval);
    }

    // Reset thời gian
    timeLeft = 900;

    document.getElementById('paymentScreen').classList.remove('active');
    document.getElementById('bookingScreen').classList.add('active');
    window.scrollTo(0, 0);
}

function startTimer() {
    const timeDisplay = document.getElementById('timeDisplay');

    timerInterval = setInterval(() => {
        const minutes = Math.floor(timeLeft / 60);
        const seconds = timeLeft % 60;
        timeDisplay.textContent = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;

        timeLeft--;

        if (timeLeft < 0) {
            clearInterval(timerInterval);
            alert('Hết thời gian giữ xe! Vui lòng đặt lại.');
            goToBooking();
            resetForm();
        }
    }, 1000);
}

function resetForm() {
    document.getElementById('customerName').value = '';
    document.getElementById('customerPhone').value = '';
    document.getElementById('vatCheckbox').checked = false;
    document.getElementById('vatForm').classList.remove('active');

    // Reset bookingData
    bookingData = {
        customerName: '',
        customerPhone: '',
        hasVAT: false,
        companyName: '',
        companyAddress: '',
        taxCode: '',
        companyEmail: ''
    };

    timeLeft = 900;
}

function toggleVATForm() {
    const checkbox = document.getElementById('vatCheckbox');
    const vatForm = document.getElementById('vatForm');

    if (checkbox.checked) {
        vatForm.classList.add('active');
    } else {
        vatForm.classList.remove('active');
    }
}

function updateProgress(currentStep, isPaymentSuccess = false) {
  const steps = document.querySelectorAll('.progress-step');
  
  steps.forEach((step, index) => {
    // Bỏ hết class trước
    step.classList.remove('active');

    // Nếu là bước cuối (thanh toán)
    if (index === steps.length - 1) {
      if (isPaymentSuccess) step.classList.add('active'); // Chỉ xanh khi thanh toán thành công
    } 
    // Còn lại, chỉ tích xanh khi đã qua bước đó
    else if (index < currentStep) {
      step.classList.add('active');
    }
  });
}

