// ====================================================================
// MODULE 3 - PAYMENT & PROMOTION INTEGRATION
// File: payment-promo-integration.js
// Tích hợp các API thanh toán và khuyến mãi vào frontend
// ====================================================================

const API_BASE_URL = 'http://localhost:8080';

// ====================================================================
// 1. PAYMENT FUNCTIONS
// ====================================================================

/**
 * Tạo thanh toán VNPay
 * @param {number} userId - ID người dùng
 * @param {number} amount - Số tiền thanh toán
 * @param {string} orderInfo - Thông tin đơn hàng
 * @param {string} bankCode - Mã ngân hàng (optional)
 * @returns {Promise} - Promise chứa payment URL
 */
async function createVNPayPayment(userId, amount, orderInfo, bankCode = '') {
    try {
        const response = await fetch(`${API_BASE_URL}/api/payment/create`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                userId: userId,
                amount: amount,
                orderInfo: orderInfo,
                bankCode: bankCode
            })
        });

        const data = await response.json();
        
        if (data.success) {
            // Redirect đến trang thanh toán VNPay
            window.location.href = data.paymentUrl;
        } else {
            throw new Error(data.message || 'Lỗi tạo thanh toán');
        }
        
        return data;
    } catch (error) {
        console.error('Error creating VNPay payment:', error);
        throw error;
    }
}

/**
 * Lấy thông tin thanh toán theo Order ID
 * @param {string} orderId - Mã đơn hàng
 * @returns {Promise} - Promise chứa thông tin payment
 */
async function getPaymentByOrderId(orderId) {
    try {
        const response = await fetch(`${API_BASE_URL}/api/payment/order/${orderId}`);
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error getting payment:', error);
        throw error;
    }
}

/**
 * Lấy lịch sử thanh toán của user
 * @param {number} userId - ID người dùng
 * @returns {Promise} - Promise chứa danh sách payments
 */
async function getUserPayments(userId) {
    try {
        const response = await fetch(`${API_BASE_URL}/api/payment/user/${userId}`);
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error getting user payments:', error);
        throw error;
    }
}

/**
 * Xử lý callback từ VNPay (gọi khi redirect về từ VNPay)
 */
function handleVNPayReturn() {
    const urlParams = new URLSearchParams(window.location.search);
    const responseCode = urlParams.get('vnp_ResponseCode');
    const orderId = urlParams.get('vnp_TxnRef');
    
    if (responseCode === '00') {
        // Thanh toán thành công
        showSuccessMessage('Thanh toán thành công!');
        // Có thể redirect về trang đơn hàng
        setTimeout(() => {
            window.location.href = `/order-detail.html?orderId=${orderId}`;
        }, 2000);
    } else {
        // Thanh toán thất bại
        showErrorMessage('Thanh toán thất bại. Vui lòng thử lại!');
    }
}

// ====================================================================
// 2. PROMOTION & VOUCHER FUNCTIONS
// ====================================================================

/**
 * Lấy danh sách promotions đang active
 * @returns {Promise} - Promise chứa danh sách promotions
 */
async function getActivePromotions() {
    try {
        const response = await fetch(`${API_BASE_URL}/api/promotions/active`);
        const data = await response.json();
        return data.data || [];
    } catch (error) {
        console.error('Error getting active promotions:', error);
        throw error;
    }
}

/**
 * Validate mã khuyến mãi
 * @param {string} promoCode - Mã khuyến mãi
 * @param {number} userId - ID người dùng
 * @param {number} orderValue - Giá trị đơn hàng
 * @returns {Promise} - Promise chứa kết quả validate
 */
async function validatePromoCode(promoCode, userId, orderValue) {
    try {
        const response = await fetch(`${API_BASE_URL}/api/promotions/validate-code`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                promoCode: promoCode,
                userId: userId,
                orderValue: orderValue
            })
        });

        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error validating promo code:', error);
        throw error;
    }
}

/**
 * Áp dụng mã khuyến mãi và tính giảm giá
 * @param {string} promoCode - Mã khuyến mãi
 * @param {number} userId - ID người dùng
 * @param {number} orderValue - Giá trị đơn hàng
 * @returns {Promise} - Promise chứa thông tin giảm giá
 */
async function applyPromoCode(promoCode, userId, orderValue) {
    try {
        const response = await fetch(`${API_BASE_URL}/api/promotions/apply`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                promoCode: promoCode,
                userId: userId,
                orderValue: orderValue
            })
        });

        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error applying promo code:', error);
        throw error;
    }
}

/**
 * Tìm promotion theo code
 * @param {string} code - Mã code
 * @returns {Promise} - Promise chứa thông tin promotion
 */
async function getPromotionByCode(code) {
    try {
        const response = await fetch(`${API_BASE_URL}/api/promotions/code/${code}`);
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error getting promotion by code:', error);
        throw error;
    }
}

// ====================================================================
// 3. UI HELPER FUNCTIONS
// ====================================================================

/**
 * Hiển thị danh sách promotions trên trang
 * @param {Array} promotions - Danh sách promotions
 * @param {string} containerId - ID của container để hiển thị
 */
function displayPromotions(promotions, containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;

    container.innerHTML = '';
    
    promotions.forEach(promo => {
        const promoCard = `
            <div class="promo-card">
                <h4>${promo.name}</h4>
                <p>${promo.description || ''}</p>
                <div class="promo-details">
                    <span class="discount">
                        ${promo.discountType === 'PERCENTAGE' 
                            ? `Giảm ${promo.discountValue}%` 
                            : `Giảm ${formatMoney(promo.discountValue)} VND`}
                    </span>
                    <span class="min-order">
                        Đơn tối thiểu: ${formatMoney(promo.minOrderValue)} VND
                    </span>
                </div>
                <p class="promo-date">
                    Từ ${formatDate(promo.startDate)} đến ${formatDate(promo.endDate)}
                </p>
            </div>
        `;
        container.innerHTML += promoCard;
    });
}

/**
 * Xử lý form nhập mã khuyến mãi
 * @param {string} formId - ID của form
 * @param {number} userId - ID người dùng
 * @param {number} orderValue - Giá trị đơn hàng
 * @param {Function} onSuccess - Callback khi áp dụng thành công
 */
function setupPromoCodeForm(formId, userId, orderValue, onSuccess) {
    const form = document.getElementById(formId);
    if (!form) return;

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const promoCodeInput = form.querySelector('[name="promoCode"]');
        const promoCode = promoCodeInput.value.trim();
        
        if (!promoCode) {
            showErrorMessage('Vui lòng nhập mã khuyến mãi');
            return;
        }

        try {
            // Hiển thị loading
            showLoading('Đang kiểm tra mã...');
            
            // Validate code
            const validateResult = await validatePromoCode(promoCode, userId, orderValue);
            
            if (validateResult.status === 'error') {
                hideLoading();
                showErrorMessage(validateResult.message);
                return;
            }

            // Apply code
            const applyResult = await applyPromoCode(promoCode, userId, orderValue);
            hideLoading();
            
            if (applyResult.status === 'success') {
                showSuccessMessage('Áp dụng mã thành công!');
                
                // Gọi callback
                if (onSuccess) {
                    onSuccess(applyResult.data);
                }
            } else {
                showErrorMessage(applyResult.message);
            }
        } catch (error) {
            hideLoading();
            showErrorMessage('Có lỗi xảy ra. Vui lòng thử lại!');
        }
    });
}

/**
 * Cập nhật UI sau khi áp dụng mã giảm giá
 * @param {Object} discountInfo - Thông tin giảm giá
 */
function updateOrderSummary(discountInfo) {
    // Cập nhật giá gốc
    const originalAmountEl = document.getElementById('originalAmount');
    if (originalAmountEl) {
        originalAmountEl.textContent = formatMoney(discountInfo.originalAmount) + ' VND';
    }

    // Hiển thị số tiền giảm
    const discountAmountEl = document.getElementById('discountAmount');
    if (discountAmountEl) {
        discountAmountEl.textContent = '- ' + formatMoney(discountInfo.discountAmount) + ' VND';
        discountAmountEl.parentElement.style.display = 'block';
    }

    // Cập nhật tổng tiền sau giảm
    const finalAmountEl = document.getElementById('finalAmount');
    if (finalAmountEl) {
        finalAmountEl.textContent = formatMoney(discountInfo.finalAmount) + ' VND';
    }

    // Hiển thị tên promotion
    const promoNameEl = document.getElementById('appliedPromoName');
    if (promoNameEl) {
        promoNameEl.textContent = `Đã áp dụng: ${discountInfo.promotionName}`;
        promoNameEl.style.display = 'block';
    }
}

/**
 * Tạo nút thanh toán VNPay
 * @param {string} containerId - ID container chứa nút
 * @param {number} userId - ID người dùng
 * @param {number} amount - Số tiền
 * @param {string} orderInfo - Thông tin đơn hàng
 */
function createVNPayButton(containerId, userId, amount, orderInfo) {
    const container = document.getElementById(containerId);
    if (!container) return;

    const button = document.createElement('button');
    button.className = 'vnpay-button';
    button.innerHTML = `
        <img src="../assets/icons/vnpay-logo.png" alt="VNPay" style="height: 20px; margin-right: 8px;">
        Thanh toán với VNPay
    `;
    
    button.addEventListener('click', () => {
        createVNPayPayment(userId, amount, orderInfo);
    });

    container.appendChild(button);
}

// ====================================================================
// 4. UTILITY FUNCTIONS
// ====================================================================

function formatMoney(amount) {
    return new Intl.NumberFormat('vi-VN').format(amount);
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('vi-VN');
}

function showSuccessMessage(message) {
    alert('✅ ' + message); // Có thể thay bằng toast notification
}

function showErrorMessage(message) {
    alert('❌ ' + message); // Có thể thay bằng toast notification
}

function showLoading(message) {
    // Implement loading overlay
    console.log('Loading:', message);
}

function hideLoading() {
    // Hide loading overlay
    console.log('Loading hidden');
}

// ====================================================================
// 5. EXPORT (Nếu dùng modules)
// ====================================================================

// Export cho ES6 modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        createVNPayPayment,
        getPaymentByOrderId,
        getUserPayments,
        handleVNPayReturn,
        getActivePromotions,
        validatePromoCode,
        applyPromoCode,
        getPromotionByCode,
        displayPromotions,
        setupPromoCodeForm,
        updateOrderSummary,
        createVNPayButton
    };
}
