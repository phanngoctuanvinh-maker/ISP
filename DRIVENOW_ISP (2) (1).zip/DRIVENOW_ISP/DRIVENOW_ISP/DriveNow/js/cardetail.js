document.addEventListener('DOMContentLoaded', function () {
    const itineraryRadios = document.querySelectorAll('input[name="itinerary"]');
    const itineraryLocal = document.getElementById('itinerary-local');
    const itineraryIntercity = document.getElementById('itinerary-intercity');
    const itineraryNote = itineraryIntercity.querySelector('.itinerary-note');
    const itineraryFees = document.getElementById('itinerary-info-fees');

    const notes = {
        local: 'Di chuyển nội thành hoặc lân cận, lộ trình tự do. <i class="far fa-question-circle"></i>',
        intercity: 'Di chuyển liên tỉnh, trả khách về lại điểm đón. <i class="far fa-question-circle"></i>',
        oneway: 'Di chuyển liên tỉnh, trả khách tại điểm đến. <i class="far fa-question-circle"></i>'
    };

    function updateItineraryView(selectedValue) {
        if (selectedValue === 'local') {
            itineraryLocal.style.display = 'block';
            itineraryIntercity.style.display = 'none';
            itineraryFees.style.display = 'none';
        } else {
            itineraryLocal.style.display = 'none';
            itineraryIntercity.style.display = 'block';
            itineraryFees.style.display = 'block';
            itineraryNote.innerHTML = notes[selectedValue];
        }
    }

    itineraryRadios.forEach(radio => {
        radio.addEventListener('change', function () {
            updateItineraryView(this.value);
        });
    });

    // Initial check
    const initialSelected = document.querySelector('input[name="itinerary"]:checked');
    if (initialSelected) {
        updateItineraryView(initialSelected.value);
    }
});
