// changepassword.js - Xử lý đổi mật khẩu cho người dùng

document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('changePasswordForm');
    const messageDiv = document.getElementById('changePasswordMessage');

    form.addEventListener('submit', async function(e) {
        e.preventDefault();
        messageDiv.textContent = '';
        
        const oldPassword = document.getElementById('oldPassword').value;
        const newPassword = document.getElementById('newPassword').value;
        const confirmPassword = document.getElementById('confirmPassword').value;

        if (newPassword !== confirmPassword) {
            messageDiv.textContent = 'Mật khẩu mới không khớp.';
            messageDiv.style.color = 'red';
            return;
        }

        try {
            // Gọi API đổi mật khẩu thông qua api.changePassword()
            const response = await api.changePassword(oldPassword, newPassword, confirmPassword);
            
            if (response.success) {
                messageDiv.textContent = response.message || 'Đổi mật khẩu thành công!';
                messageDiv.style.color = 'green';
                setTimeout(() => {
                    window.location.href = 'profileuser.html';
                }, 1200);
                form.reset();
            } else {
                messageDiv.textContent = response.message || 'Đổi mật khẩu thất bại.';
                messageDiv.style.color = 'red';
            }
        } catch (err) {
            messageDiv.textContent = err.message || 'Đổi mật khẩu thất bại.';
            messageDiv.style.color = 'red';
        }
    });
});
