// forgotpassword-redirect.js
// Đảm bảo khi nhấn vào "Quên mật khẩu?" sẽ chuyển hướng đúng sang trang forgotpassword.html

document.addEventListener('DOMContentLoaded', function() {
    const forgotBtn = document.getElementById('forgotPasswordBtn');
    if (forgotBtn) {
        forgotBtn.addEventListener('click', function(e) {
            e.preventDefault();
            window.location.href = 'forgotpassword.html';
        });
    }
});
