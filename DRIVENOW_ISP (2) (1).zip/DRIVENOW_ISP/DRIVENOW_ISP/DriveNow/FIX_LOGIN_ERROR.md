# 🔴 Lỗi: "Failed to execute 'json' on 'Response': Unexpected end of JSON input"

## Nguyên nhân:
Backend trả về response **KHÔNG PHẢI JSON** → có thể là:
1. ❌ Backend bị lỗi 500 Internal Server Error
2. ❌ Chưa có tài khoản test trong database
3. ❌ Backend chưa khởi động xong

---

## ✅ GIẢI PHÁP - Làm theo thứ tự:

### **Bước 1: Tạo tài khoản test trong SQL Server**

1. Mở **SQL Server Management Studio (SSMS)**
2. Connect đến SQL Server (localhost)
3. Mở file: `d:\ISP3392\Project1\drivenow\insert_test_accounts.sql`
4. Nhấn **Execute** (F5)

File SQL này sẽ tạo 3 tài khoản test:
- `admin@drivenow.com` / `123456` (admin)
- `customer@gmail.com` / `123456` (customer)  ← **Dùng cái này để test**
- `driver@gmail.com` / `123456` (driver)

### **Bước 2: Đợi Backend khởi động xong**

Backend đang restart. Đợi đến khi thấy dòng này trong terminal:
```
Started DrivenowApplication in X.XXX seconds
```

### **Bước 3: Test lại Login**

1. Refresh trang web (Ctrl + F5)
2. Nhấn nút "Đăng nhập"
3. Nhập:
   - **Username:** `customer@gmail.com`
   - **Password:** `123456`
4. Click "Đăng Nhập"

---

## 🔍 Kiểm tra Backend:

**Nếu vẫn lỗi, hãy kiểm tra:**

### 1. Backend có đang chạy không?
Mở browser, vào: `http://localhost:8080/auth/login`
- ✅ Nếu thấy lỗi **405 Method Not Allowed** → Backend OK
- ❌ Nếu không kết nối được → Backend chưa chạy

### 2. Xem log Backend
Xem terminal Java, có lỗi gì khi bạn nhấn "Đăng Nhập" không?

---

## 🧪 Test nhanh bằng PowerShell:

Mở PowerShell và chạy:

```powershell
# Test endpoint login
$body = @{
    username = "customer@gmail.com"
    password = "123456"
} | ConvertTo-Json

$response = Invoke-WebRequest -Uri "http://localhost:8080/api/auth/login" `
    -Method POST `
    -ContentType "application/json" `
    -Body $body

$response.Content | ConvertFrom-Json | ConvertTo-Json -Depth 10
```

**Kết quả mong đợi:**
```json
{
  "success": true,
  "message": "Đăng nhập thành công",
  "data": {
    "token": "eyJhbGc...",
    "accountId": 2,
    "username": "customer@gmail.com",
    "role": "customer",
    "fullName": "Nguyễn Văn A"
  }
}
```

---

## 📝 Tóm tắt checklist:

- [ ] Chạy file SQL để tạo tài khoản test
- [ ] Đợi backend khởi động xong (xem terminal Java)
- [ ] Refresh trang web (Ctrl + F5)
- [ ] Test login với `customer@gmail.com` / `123456`

---

**Sau khi làm xong, báo cho tôi kết quả nhé!** 🚀
