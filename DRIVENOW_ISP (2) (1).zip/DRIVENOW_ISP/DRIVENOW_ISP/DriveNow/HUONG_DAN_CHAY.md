# 🚀 HƯỚNG DẪN CHẠY PROJECT

## ⚠️ Nguyên nhân lỗi "Không kết nối được server"

### Vấn đề đã tìm thấy:
1. **CORS không khớp**: Backend chỉ cho phép request từ `localhost:3000` và `localhost:4200`
2. **Frontend chạy sai cách**: Mở file HTML trực tiếp → origin là `file://` → Browser chặn CORS
3. **Postman hoạt động**: Vì Postman không kiểm tra CORS

### ✅ Đã sửa:
- Cập nhật `SecurityConfig.java` để cho phép tất cả origins trong development
- Sử dụng `setAllowedOriginPatterns("*")` thay vì `setAllowedOrigins`

---

## 📋 CÁCH CHẠY ĐÚNG

### Bước 1: Chạy Backend (Spring Boot)
```powershell
cd d:\ISP3392\Project1\drivenow
.\mvnw.cmd spring-boot:run
```
**Hoặc** chạy `DrivenowApplication.java` trong IDE

✅ Backend sẽ chạy tại: **http://localhost:8080**

---

### Bước 2: Chạy Frontend (HTTP Server)

**Cách 1 - Dùng Python (Khuyên dùng):**
```powershell
cd d:\ISP3392\Project1\Project1
python -m http.server 5500
```

**Cách 2 - Dùng file .bat có sẵn:**
```powershell
cd d:\ISP3392\Project1\Project1
.\start-server.bat
```

**Cách 3 - Dùng Live Server trong VS Code:**
- Cài extension "Live Server"
- Click phải vào `login.html` → "Open with Live Server"

✅ Frontend sẽ chạy tại: **http://localhost:5500**

---

### Bước 3: Truy cập
Mở trình duyệt và vào: **http://localhost:5500/html/login.html**

---

## 🔍 Kiểm tra

### Backend đã chạy chưa?
Mở: http://localhost:8080/auth/login trong browser
- Nếu thấy lỗi 405 (Method Not Allowed) → **Backend OK** ✅
- Nếu không kết nối được → **Backend chưa chạy** ❌

### Frontend đúng cách?
- URL phải là: `http://localhost:5500/...` ✅
- **KHÔNG ĐƯỢC** là: `file:///d:/ISP3392/...` ❌

---

## 🐛 Nếu vẫn lỗi

### Lỗi CORS vẫn xuất hiện:
1. **Restart backend** sau khi sửa code
2. Xóa cache browser (Ctrl+Shift+Delete)
3. Kiểm tra Console (F12) xem lỗi gì

### Backend không chạy được:
```powershell
# Kiểm tra Java version
java -version

# Phải là Java 17 hoặc cao hơn
```

### Frontend không kết nối:
1. Kiểm tra `api.js` - `API_BASE_URL` phải là `http://localhost:8080/api`
2. Kiểm tra Network tab (F12) xem request có gửi đi không
3. Đảm bảo cả Backend VÀ Frontend đều đang chạy

---

## 📝 Tóm tắt

| Thành phần | URL | Lệnh chạy |
|------------|-----|-----------|
| Backend | http://localhost:8080 | `cd drivenow && .\mvnw.cmd spring-boot:run` |
| Frontend | http://localhost:5500 | `cd Project1 && python -m http.server 5500` |
| Login page | http://localhost:5500/html/login.html | Mở trong browser |

---

**✅ QUAN TRỌNG**: 
- **LUÔN** chạy frontend qua HTTP server (localhost:5500)
- **KHÔNG BAO GIỜ** mở file HTML trực tiếp từ Windows Explorer
- Đảm bảo **CẢ 2** backend và frontend đang chạy cùng lúc
