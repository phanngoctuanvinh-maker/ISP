@echo off
echo Starting frontend server on http://localhost:5500...
echo.
echo Nhan Ctrl+C de dung server
echo.
cd /d "%~dp0"
python -m http.server 5500
