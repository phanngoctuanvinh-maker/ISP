@echo off
chcp 65001 >nul
echo ========================================
echo SỬA LỖI GOOGLE LOGIN - TEST NGAY
echo ========================================
echo.
echo ✅ Đã sửa lỗi trong api.js
echo ✅ Backend response format được xử lý đúng
echo.
echo ========================================
echo HƯỚNG DẪN TEST:
echo ========================================
echo.
echo 1. Mở trang login (đang mở...)
echo 2. Nhấn Ctrl + Shift + R để hard refresh
echo 3. Mở Developer Console (F12)
echo 4. Click "Đăng nhập bằng Google"
echo 5. Chọn tài khoản Google
echo.
echo KẾT QUẢ MONG ĐỢI:
echo   ✓ TỰ ĐỘNG chuyển về homepage
echo   ✓ KHÔNG CÓ alert lỗi
echo   ✓ Console hiển thị: "Login successful, redirecting..."
echo.
echo ========================================

start "" "DriveNow\html\login.html"

echo.
echo Trang login đã mở! 
echo Nhớ nhấn Ctrl+Shift+R để refresh cache
echo.
pause
