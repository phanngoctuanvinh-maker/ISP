# 🚀 HƯỚNG DẪN CHẠY PROJECT DRIVENOW

## ✅ ĐÃ FIX CÁC LỖI:

### 1. Lỗi CORS → ✅ ĐÃ SỬA
- Đã cập nhật `SecurityConfig.java` để cho phép tất cả origins

### 2. Lỗi Port 8080 đã được sử dụng → ✅ ĐÃ SỬA  
- Đã kill process cũ (PID 5200)
- Tạo file `start-backend.bat` để chạy backend dễ dàng

---

## 📋 CÁCH CHẠY PROJECT:

### **Bước 1: Chạy Backend**

**Cách 1 - Dùng file .bat (Dễ nhất):**
```
Double-click file: d:\ISP3392\Project1\drivenow\start-backend.bat
```

**Cách 2 - Dùng PowerShell:**
```powershell
cd d:\ISP3392\Project1\drivenow
.\mvnw.cmd spring-boot:run
```

**Cách 3 - Dùng IDE (IntelliJ/Eclipse):**
- Mở project `drivenow` trong IDE
- Run `DrivenowApplication.java`

**✅ Backend thành công khi thấy:**
```
Started DrivenowApplication in X.XXX seconds
Tomcat started on port 8080
```

---

### **Bước 2: Chạy Frontend**

**Cách 1 - Live Server trong VS Code (Khuyên dùng):**
1. Cài extension "Live Server" (ritwickdey.liveserver)
2. Mở file `d:\ISP3392\Project1\Project1\html\homepage.html`
3. Click phải → **"Open with Live Server"**
4. Browser sẽ mở: `http://127.0.0.1:5500/html/homepage.html`

**Cách 2 - Mở trực tiếp (Nếu backend đã fix CORS):**
- Double-click file `homepage.html`
- Nhưng phải đảm bảo CORS đã được cấu hình đúng

---

## 🧪 TEST LOGIN:

### **Tài khoản test có sẵn trong database:**

| Username | Password | Role |
|----------|----------|------|
| customer@gmail.com | 123456 | customer |
| driver@gmail.com | 123456 | driver |
| admin@drivenow.com | 123456 | admin |

### **Test bằng PowerShell:**

```powershell
$body = @{
    username = "customer@gmail.com"
    password = "123456"
} | ConvertTo-Json

$response = Invoke-RestMethod `
    -Uri "http://localhost:8080/api/auth/login" `
    -Method POST `
    -ContentType "application/json" `
    -Body $body

$response | ConvertTo-Json -Depth 5
```

**Kết quả mong đợi:**
```json
{
  "success": true,
  "message": "Đăng nhập thành công",
  "data": {
    "token": "eyJhbGciOiJIUzI1NiJ9...",
    "accountId": 2,
    "username": "customer@gmail.com",
    "role": "customer",
    "fullName": "Nguyễn Văn A"
  }
}
```

---

## 🐛 TROUBLESHOOTING:

### **Lỗi: Port 8080 already in use**
```powershell
# Tìm process đang dùng port 8080
netstat -ano | findstr :8080

# Kill process (thay PID bằng số hiện ra)
taskkill /F /PID <PID>

# Chạy lại backend
.\start-backend.bat
```

### **Lỗi: CORS - Failed to fetch**
- Đảm bảo đã sửa `SecurityConfig.java` (dòng 67-68)
- Restart backend sau khi sửa code
- Clear cache browser (Ctrl + Shift + Delete)

### **Lỗi: Failed to execute 'json' on 'Response'**
- Backend chưa chạy hoặc bị lỗi
- Kiểm tra console của backend (terminal/CMD)
- Đảm bảo database đã có dữ liệu test

### **Lỗi: Cannot connect to database**
- Kiểm tra SQL Server đã chạy chưa
- Kiểm tra `application.properties`:
  ```properties
  spring.datasource.url=jdbc:sqlserver://localhost:1433;databaseName=drivenow_db
  spring.datasource.username=sa
  spring.datasource.password=12345
  ```

---

## 📊 KIỂM TRA TRẠNG THÁI:

### **Backend có chạy không?**
```powershell
# Test endpoint
curl http://localhost:8080/api/auth/login
```
- ✅ Lỗi 405 (Method Not Allowed) = Backend OK
- ❌ Không kết nối được = Backend chưa chạy

### **Frontend có chạy đúng không?**
- URL phải là: `http://127.0.0.1:5500/...` (với Live Server)
- Không được là: `file:///d:/ISP3392/...`

### **Database có dữ liệu chưa?**
```sql
USE drivenow_db;
SELECT * FROM Account WHERE username = 'customer@gmail.com';
SELECT * FROM Customer WHERE email = 'customer@gmail.com';
```

---

## 🎯 CHECKLIST HOÀN CHỈNH:

- [ ] SQL Server đang chạy
- [ ] Database `drivenow_db` đã tạo
- [ ] Đã có tài khoản test trong database
- [ ] Backend đang chạy (port 8080)
- [ ] Frontend chạy qua Live Server (port 5500)
- [ ] CORS đã được cấu hình đúng
- [ ] Test login thành công

---

## 📞 NẾU VẪN GẶP VẤN ĐỀ:

1. Chụp màn hình lỗi trong Console (F12)
2. Copy log từ terminal Backend
3. Kiểm tra file `application.properties`
4. Đảm bảo đã làm đúng các bước trên

---

**Good luck! 🚀**
