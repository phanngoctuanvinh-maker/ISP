# 🧪 HƯỚNG DẪN TEST API SEARCH CAR TRÊN POSTMAN

## 📋 Danh sách API Endpoints

Base URL: `http://localhost:8080/api/cars`

---

## 1️⃣ LẤY TẤT CẢ XE (GET)
**Endpoint:** `GET http://localhost:8080/api/cars/all`

**Method:** GET

**Response mẫu:**
```json
{
    "success": true,
    "message": "Tìm thấy 30 xe",
    "cars": [...],
    "totalCount": 30
}
```

**Cách test:**
1. Mở Postman
2. Chọn method: **GET**
3. Nhập URL: `http://localhost:8080/api/cars/all`
4. Click **Send**
5. Kết quả: Hiển thị tất cả xe trong database

---

## 2️⃣ TÌM XE ĐIỆN (GET)
**Endpoint:** `GET http://localhost:8080/api/cars/electric`

**Method:** GET

**Response mẫu:**
```json
{
    "success": true,
    "message": "Tìm thấy 3 xe điện",
    "cars": [
        {
            "carId": 19,
            "brand": "Vinfast",
            "model": "VF e34",
            "year": 2023,
            "fuelType": "electric",
            ...
        }
    ],
    "totalCount": 3
}
```

**Cách test:**
1. Method: **GET**
2. URL: `http://localhost:8080/api/cars/electric`
3. Click **Send**
4. Kết quả: Hiển thị các xe điện (Vinfast VF e34, VF 8, VF 9)

---

## 3️⃣ TÌM XE HYBRID - XĂNG & ĐIỆN (GET)
**Endpoint:** `GET http://localhost:8080/api/cars/hybrid`

**Method:** GET

**Response mẫu:**
```json
{
    "success": true,
    "message": "Tìm thấy 3 xe xăng & điện",
    "cars": [
        {
            "carId": 25,
            "brand": "Toyota",
            "model": "Corolla Cross Hybrid",
            "fuelType": "hybrid",
            ...
        }
    ],
    "totalCount": 3
}
```

**Cách test:**
1. Method: **GET**
2. URL: `http://localhost:8080/api/cars/hybrid`
3. Click **Send**
4. Kết quả: Hiển thị xe hybrid (Toyota Corolla Cross Hybrid, Honda Accord Hybrid, Hyundai Tucson Hybrid)

---

## 4️⃣ TÌM XE THEO LOẠI - SỐ CHỖ NGỒI (GET)
**Endpoint:** `GET http://localhost:8080/api/cars/by-type?seats={số_chỗ}`

**Method:** GET

**Parameters:**
- `seats` (query parameter): 4, 5, 7, hoặc 16

**Ví dụ:**

### Test xe 4 chỗ:
**URL:** `http://localhost:8080/api/cars/by-type?seats=4`

**Response:**
```json
{
    "success": true,
    "message": "Tìm thấy 3 xe 4 chỗ",
    "cars": [
        {
            "brand": "Kia",
            "model": "Morning",
            "seats": 4
        }
    ],
    "totalCount": 3
}
```

### Test xe 5 chỗ:
**URL:** `http://localhost:8080/api/cars/by-type?seats=5`

### Test xe 7 chỗ:
**URL:** `http://localhost:8080/api/cars/by-type?seats=7`

**Cách test:**
1. Method: **GET**
2. URL: `http://localhost:8080/api/cars/by-type?seats=7`
3. Click **Send**
4. Kết quả: Hiển thị xe 7 chỗ

---

## 5️⃣ TÌM XE THEO HÃNG (GET)
**Endpoint:** `GET http://localhost:8080/api/cars/by-brand?brand={tên_hãng}`

**Method:** GET

**Parameters:**
- `brand` (query parameter): Toyota, Honda, Mazda, Ford, Kia, Hyundai, Vinfast, Mitsubishi

**Ví dụ:**

### Test xe Toyota:
**URL:** `http://localhost:8080/api/cars/by-brand?brand=Toyota`

**Response:**
```json
{
    "success": true,
    "message": "Tìm thấy 4 xe hãng Toyota",
    "cars": [
        {
            "brand": "Toyota",
            "model": "Vios"
        },
        {
            "brand": "Toyota",
            "model": "Camry"
        }
    ],
    "totalCount": 4
}
```

### Test các hãng khác:
- Honda: `http://localhost:8080/api/cars/by-brand?brand=Honda`
- Mazda: `http://localhost:8080/api/cars/by-brand?brand=Mazda`
- Ford: `http://localhost:8080/api/cars/by-brand?brand=Ford`
- Kia: `http://localhost:8080/api/cars/by-brand?brand=Kia`
- Hyundai: `http://localhost:8080/api/cars/by-brand?brand=Hyundai`
- Vinfast: `http://localhost:8080/api/cars/by-brand?brand=Vinfast`
- Mitsubishi: `http://localhost:8080/api/cars/by-brand?brand=Mitsubishi`

**Cách test:**
1. Method: **GET**
2. URL: `http://localhost:8080/api/cars/by-brand?brand=Toyota`
3. Click **Send**

---

## 6️⃣ TÌM XE THEO TRUYỀN ĐỘNG (GET)
**Endpoint:** `GET http://localhost:8080/api/cars/by-transmission?type={loại_truyền_động}`

**Method:** GET

**Parameters:**
- `type` (query parameter): "Tất cả", "Số sàn", "Số tự động"

**Ví dụ:**

### Test xe số sàn:
**URL:** `http://localhost:8080/api/cars/by-transmission?type=Số sàn`

**Response:**
```json
{
    "success": true,
    "message": "Tìm thấy 3 xe Số sàn",
    "cars": [
        {
            "brand": "Ford",
            "model": "Ranger",
            "transmissionType": "manual"
        }
    ],
    "totalCount": 3
}
```

### Test xe số tự động:
**URL:** `http://localhost:8080/api/cars/by-transmission?type=Số tự động`

### Test tất cả:
**URL:** `http://localhost:8080/api/cars/by-transmission?type=Tất cả`

**Cách test:**
1. Method: **GET**
2. URL: `http://localhost:8080/api/cars/by-transmission?type=Số tự động`
3. Click **Send**

**⚠️ Lưu ý:** Nếu có lỗi với tiếng Việt, encode URL:
- `Số sàn` → `S%E1%BB%91%20s%C3%A0n`
- `Số tự động` → `S%E1%BB%91%20t%E1%BB%B1%20%C4%91%E1%BB%99ng`

---

## 7️⃣ TÌM KIẾM NÂNG CAO (POST)
**Endpoint:** `POST http://localhost:8080/api/cars/search`

**Method:** POST

**Headers:**
```
Content-Type: application/json
```

**Body (JSON):**
```json
{
    "filterType": "type",
    "brand": "Toyota",
    "transmissionType": "Số tự động",
    "seats": 5,
    "fuelType": "gasoline"
}
```

**Các loại filterType:**
- `"all"` - Tất cả xe
- `"type"` - Lọc theo loại (seats)
- `"brand"` - Lọc theo hãng
- `"transmission"` - Lọc theo truyền động
- `"electric"` - Xe điện
- `"hybrid"` - Xe hybrid

**Ví dụ các request:**

### Tìm xe Toyota 5 chỗ số tự động:
```json
{
    "filterType": "brand",
    "brand": "Toyota",
    "transmissionType": "automatic",
    "seats": 5,
    "fuelType": "gasoline"
}
```

### Tìm xe 7 chỗ bất kỳ hãng:
```json
{
    "filterType": "type",
    "seats": 7
}
```

### Tìm xe Honda số tự động:
```json
{
    "filterType": "brand",
    "brand": "Honda",
    "transmissionType": "automatic"
}
```

**Cách test:**
1. Method: **POST**
2. URL: `http://localhost:8080/api/cars/search`
3. Tab **Headers**: Thêm `Content-Type: application/json`
4. Tab **Body**: Chọn **raw** và **JSON**, paste JSON request
5. Click **Send**

---

## 8️⃣ LẤY CHI TIẾT XE THEO ID (GET)
**Endpoint:** `GET http://localhost:8080/api/cars/{id}`

**Method:** GET

**Ví dụ:**
**URL:** `http://localhost:8080/api/cars/1`

**Response:**
```json
{
    "carId": 1,
    "brand": "Toyota",
    "model": "Vios",
    "year": 2023,
    "color": "Trắng",
    "seats": 5,
    "fuelType": "gasoline",
    "transmissionType": "automatic",
    "pricePerDay": 500000,
    "dailyRate": 500000,
    "description": "Toyota Vios đời mới, tiết kiệm nhiên liệu",
    "imageUrl": "https://example.com/toyota-vios.jpg",
    "status": "available"
}
```

**Cách test:**
1. Method: **GET**
2. URL: `http://localhost:8080/api/cars/1` (thay 1 bằng ID xe khác)
3. Click **Send**

---

## 9️⃣ DANH SÁCH HÃNG XE (GET)
**Endpoint:** `GET http://localhost:8080/api/cars/brands`

**Response:**
```json
[
    "Toyota",
    "Honda",
    "Mazda",
    "Ford",
    "Kia",
    "Hyundai",
    "Vinfast",
    "Mitsubishi"
]
```

---

## 🔟 DANH SÁCH LOẠI TRUYỀN ĐỘNG (GET)
**Endpoint:** `GET http://localhost:8080/api/cars/transmissions`

**Response:**
```json
[
    "Tất cả",
    "Số sàn",
    "Số tự động"
]
```

---

## 📝 CHECKLIST TEST

### ✅ Test GET Endpoints:
- [ ] GET /api/cars/all - Lấy tất cả xe
- [ ] GET /api/cars/electric - Xe điện
- [ ] GET /api/cars/hybrid - Xe hybrid
- [ ] GET /api/cars/by-type?seats=4 - Xe 4 chỗ
- [ ] GET /api/cars/by-type?seats=5 - Xe 5 chỗ
- [ ] GET /api/cars/by-type?seats=7 - Xe 7 chỗ
- [ ] GET /api/cars/by-brand?brand=Toyota - Xe Toyota
- [ ] GET /api/cars/by-brand?brand=Honda - Xe Honda
- [ ] GET /api/cars/by-transmission?type=Số sàn - Xe số sàn
- [ ] GET /api/cars/by-transmission?type=Số tự động - Xe số tự động
- [ ] GET /api/cars/1 - Chi tiết xe ID=1
- [ ] GET /api/cars/brands - Danh sách hãng
- [ ] GET /api/cars/transmissions - Danh sách truyền động

### ✅ Test POST Endpoint:
- [ ] POST /api/cars/search - Tìm kiếm nâng cao

---

## 🚨 XỬ LÝ LỖI

### Nếu không có xe:
```json
{
    "success": false,
    "message": "Không tìm thấy xe phù hợp với tiêu chí tìm kiếm",
    "cars": [],
    "totalCount": 0
}
```

### Nếu lỗi server:
```json
{
    "success": false,
    "message": "Lỗi hệ thống: ...",
    "cars": null,
    "totalCount": 0
}
```

---

## 💡 TIPS

1. **Sử dụng Collection trong Postman:**
   - Tạo một Collection mới tên "DriveNow Car Search API"
   - Lưu tất cả các request vào collection để test nhanh

2. **Environment Variables:**
   - Tạo biến `base_url` = `http://localhost:8080/api/cars`
   - Dùng `{{base_url}}/all` thay vì URL đầy đủ

3. **Test nhiều trường hợp:**
   - Test với dữ liệu có trong DB
   - Test với dữ liệu không có (ví dụ: brand=BMW)
   - Test với tham số trống
   - Test với tham số không hợp lệ

4. **Kiểm tra Response:**
   - Status code phải là 200 OK
   - Response có đúng format JSON
   - Dữ liệu trả về đúng với điều kiện tìm kiếm

---

## 🎯 KẾT LUẬN

Sau khi test xong tất cả API trên Postman, bạn có thể:
1. ✅ Chắc chắn backend hoạt động đúng
2. ✅ Tích hợp vào frontend với tin tưởng
3. ✅ Xử lý các trường hợp lỗi phù hợp

**Server đang chạy tại:** `http://localhost:8080`

**Happy Testing! 🚀**
