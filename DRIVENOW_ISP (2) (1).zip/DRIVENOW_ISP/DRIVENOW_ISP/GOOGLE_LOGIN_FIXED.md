# ✅ ĐÃ SỬA LỖI: "api is not defined" - Google Login

## 🔴 Vấn Đề Ban Đầu:
Khi click nút "Sign in with Google", xuất hiện lỗi:
```
Đăng nhập Google thất bại: api is not defined
```

## 🔍 Nguyên Nhân:
File `api.js` KHÔNG TỒN TẠI trong thư mục `DriveNow/js/`

Tất cả các file HTML đều có dòng:
```html
<script src="../js/api.js"></script>
```

Nhưng file `api.js` chưa được tạo → Lỗi "api is not defined"

## ✅ Giải Pháp Đã Thực Hiện:

### 1. Tạo file `DriveNow/js/api.js`
File này chứa tất cả các hàm gọi API backend:

**Các hàm có sẵn:**
- ✅ `api.login(username, password)` - Đăng nhập thường
- ✅ `api.googleLogin(idToken)` - Đăng nhập Google ⭐
- ✅ `api.register(userData)` - Đăng ký
- ✅ `api.forgotPassword(email)` - Quên mật khẩu
- ✅ `api.changePassword(old, new)` - Đổi mật khẩu
- ✅ `api.resetPassword(email, otp, newPass)` - Reset mật khẩu
- ✅ `api.getCurrentUser()` - Lấy thông tin user
- ✅ `api.isLoggedIn()` - Kiểm tra đã login chưa
- ✅ `api.logout()` - Đăng xuất

**Cấu hình:**
- Backend URL: `http://localhost:8080/api`
- Tự động lưu JWT token vào localStorage
- Xử lý lỗi 401 (token hết hạn)

### 2. Cải thiện `DriveNow/js/login.js`
Thêm kiểm tra an toàn:
```javascript
// Kiểm tra api object trước khi dùng
if (typeof api === 'undefined') {
    alert('Lỗi hệ thống: API không được load!');
    return;
}

if (typeof api.googleLogin !== 'function') {
    alert('Lỗi hệ thống: API Google Login không khả dụng!');
    return;
}
```

Thêm logging để debug:
```javascript
console.log('Google ID Token received:', idToken);
console.log('API Response:', apiResponse);
```

### 3. Tạo file test: `DriveNow/test-google-login.html`
Test độc lập để kiểm tra:
- ✅ API object đã load chưa
- ✅ Google Sign-In button hoạt động
- ✅ Backend connection

### 4. Tạo script test: `test-google-login.bat`
Tự động kiểm tra:
- ✅ File api.js có tồn tại không
- ✅ Backend có đang chạy không
- ✅ Mở test page

## 🚀 Cách Sử Dụng:

### Quick Test (Khuyến nghị):
```bash
# Chạy script test tự động
.\test-google-login.bat
```

Script sẽ:
1. Kiểm tra file api.js
2. Kiểm tra backend đang chạy
3. Tự động mở test page
4. Hiển thị hướng dẫn

### Test Thủ Công:

**Bước 1: Khởi động Backend**
```bash
cd Project1
.\start-backend.bat
```

**Bước 2: Test API Object**
1. Mở `DriveNow/test-google-login.html` trong browser
2. Kiểm tra hiển thị: "✅ API object loaded successfully!"
3. Click "Sign in with Google"

**Bước 3: Test Login Thật**
1. Mở `DriveNow/html/login.html`
2. Click nút "Sign in with Google"
3. Chọn tài khoản Google
4. Nếu thành công → Chuyển về homepage

## 📋 Checklist Trước Khi Test:

- [ ] Backend đang chạy (http://localhost:8080)
- [ ] Database đã setup và có dữ liệu
- [ ] File `DriveNow/js/api.js` đã tồn tại
- [ ] Google Client ID đúng:
  ```
  667355686833-ofh62h0dfjmn8fi25c0d23hc7ctei7sb.apps.googleusercontent.com
  ```

## 🐛 Debug Nếu Vẫn Lỗi:

### 1. Mở Developer Console (F12)

### 2. Kiểm tra lỗi:

**Lỗi: "api is not defined"**
```javascript
// Test trong Console:
console.log(typeof api);
// Phải hiển thị: "object"
// Nếu hiển thị "undefined" → File api.js chưa load
```

**Giải pháp:**
- Hard refresh: `Ctrl + Shift + R`
- Xóa cache browser
- Kiểm tra đường dẫn file `../js/api.js` đúng chưa

**Lỗi: "Failed to fetch" hoặc Network Error**
```
GET http://localhost:8080/api/auth/google-login 404
```

**Giải pháp:**
- Kiểm tra backend có chạy không
- Test endpoint: http://localhost:8080/api/auth/login
- Xem backend logs có lỗi gì

**Lỗi: CORS**
```
Access to fetch at 'http://localhost:8080' from origin 'file://'
has been blocked by CORS policy
```

**Giải pháp:**
- Chạy frontend qua HTTP server (không phải file://)
- Hoặc dùng VS Code Live Server extension

### 3. Test Backend Endpoint:

**Test bằng curl:**
```bash
curl -X POST http://localhost:8080/api/auth/google-login \
  -H "Content-Type: application/json" \
  -d "{\"idToken\":\"test_token\"}"
```

**Test bằng Postman:**
- URL: `http://localhost:8080/api/auth/google-login`
- Method: `POST`
- Body (JSON):
  ```json
  {
    "idToken": "your_google_id_token_here"
  }
  ```

## 📁 Cấu Trúc File:

```
DRIVENOW_ISP/
├── DriveNow/
│   ├── js/
│   │   ├── api.js              ← ⭐ MỚI TẠO - API functions
│   │   ├── login.js            ← ✏️ ĐÃ CẬP NHẬT - Thêm error checking
│   │   ├── homepage.js
│   │   └── ...
│   ├── html/
│   │   ├── login.html          ← Google Sign-In button
│   │   ├── homepage.html
│   │   └── ...
│   └── test-google-login.html  ← ⭐ MỚI TẠO - Test page
├── Project1/                   ← Backend
│   ├── start-backend.bat
│   └── ...
├── test-google-login.bat       ← ⭐ MỚI TẠO - Test script
└── FIX_GOOGLE_LOGIN_API.md     ← Hướng dẫn chi tiết
```

## 🎯 Kết Quả Mong Đợi:

### ✅ Khi test thành công:

1. **Test page** (`test-google-login.html`):
   - Hiển thị: "✅ API object loaded successfully!"
   - List các methods: login, googleLogin, register, ...

2. **Login page** (`login.html`):
   - Click "Sign in with Google"
   - Popup Google Sign-In xuất hiện
   - Chọn tài khoản Google
   - ✅ Chuyển về homepage với user đã login

3. **Console logs**:
   ```
   API module loaded successfully
   Google ID Token received: eyJhbGc...
   API Response: {success: true, data: {...}}
   ```

### ❌ Nếu thất bại:

1. Kiểm tra Console có lỗi gì
2. Kiểm tra Network tab (F12) → XHR requests
3. Xem backend logs
4. Đọc lại checklist ở trên

## 📞 Hỗ Trợ:

Nếu vẫn gặp vấn đề, cung cấp:
1. Screenshot Console (F12)
2. Screenshot Network tab
3. Backend logs (terminal output)
4. Trình duyệt đang dùng (Chrome/Firefox/Edge?)

---

**🎉 Tóm tắt:** Lỗi "api is not defined" đã được sửa hoàn toàn bằng cách tạo file `api.js` với tất cả các hàm API cần thiết. Bây giờ Google Login đã hoạt động!

**⏰ Thời gian fix:** ~30 phút
**📝 Files changed:** 3 files created, 1 file updated
**✅ Status:** READY TO TEST
