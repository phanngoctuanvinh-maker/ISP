# BOOKING TABLE - DATABASE SCHEMA

## 📊 Table Structure

```sql
bookings
├── booking_id (PK)
├── customer_id (FK → Customer)
├── car_id (FK → Car)
├── driver_id (FK → Driver) [nullable]
│
├── ────────── CORE FIELDS ──────────
├── pickup_date
├── return_date
├── pickup_location
├── return_location
├── total_days
├── total_price
├── status
├── payment_status
├── payment_method
├── notes
├── cancellation_reason
│
├── ────────── [EXTENSION FEATURE] ──────────
├── original_return_date  ⭐ NEW
├── extension_days        ⭐ NEW
├── extension_price       ⭐ NEW
├── is_extended          ⭐ NEW
│
└── ────────── TIMESTAMPS ──────────
    ├── created_at
    └── updated_at
```

---

## 🔗 Relationships

```
Customer (1) ───< (*) Booking
                      │
Car (1) ─────────────< │
                      │
Driver (0..1) ────────< (*) Booking
```

---

## 📋 Column Details

### **CORE COLUMNS (13 columns)**

| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| `booking_id` | INT | NO | AUTO | Primary Key |
| `customer_id` | INT | NO | - | FK to Customer |
| `car_id` | INT | NO | - | FK to Car |
| `driver_id` | INT | YES | NULL | FK to Driver (optional) |
| `pickup_date` | DATETIME2 | NO | - | Ngày nhận xe |
| `return_date` | DATETIME2 | NO | - | Ngày trả xe |
| `pickup_location` | NVARCHAR(255) | NO | - | Địa điểm nhận xe |
| `return_location` | NVARCHAR(255) | YES | NULL | Địa điểm trả xe |
| `total_days` | INT | NO | - | Tổng số ngày thuê |
| `total_price` | DECIMAL(10,2) | NO | - | Tổng tiền (VNĐ) |
| `status` | NVARCHAR(20) | NO | 'pending' | pending/confirmed/ongoing/completed/cancelled |
| `payment_status` | NVARCHAR(20) | YES | 'unpaid' | unpaid/paid/refunded/partially_paid |
| `payment_method` | NVARCHAR(50) | YES | NULL | cash/bank_transfer/credit_card/momo/zalopay |
| `notes` | TEXT | YES | NULL | Ghi chú từ khách hàng |
| `cancellation_reason` | TEXT | YES | NULL | Lý do hủy (nếu cancelled) |

### **EXTENSION COLUMNS (4 columns)** ⭐

| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| `original_return_date` | DATETIME2 | YES | NULL | Ngày trả ban đầu (trước khi gia hạn) |
| `extension_days` | INT | YES | 0 | Số ngày đã gia hạn thêm |
| `extension_price` | DECIMAL(10,2) | YES | 0 | Tiền phụ thu do gia hạn (VNĐ) |
| `is_extended` | BIT | YES | 0 | Flag đánh dấu đã gia hạn (0/1) |

### **TIMESTAMP COLUMNS (2 columns)**

| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| `created_at` | DATETIME2 | NO | GETDATE() | Thời gian tạo booking |
| `updated_at` | DATETIME2 | NO | GETDATE() | Thời gian cập nhật gần nhất |

---

## 💾 Sample Data

### **Regular Booking (No Extension)**
```sql
INSERT INTO bookings VALUES (
    1,                          -- booking_id
    1,                          -- customer_id
    5,                          -- car_id
    NULL,                       -- driver_id
    '2025-10-20 09:00:00',     -- pickup_date
    '2025-10-25 18:00:00',     -- return_date
    'Hà Nội',                   -- pickup_location
    'Hà Nội',                   -- return_location
    5,                          -- total_days
    4000000,                    -- total_price
    'pending',                  -- status
    'unpaid',                   -- payment_status
    'bank_transfer',            -- payment_method
    'Cần xe sạch',             -- notes
    NULL,                       -- cancellation_reason
    NULL,                       -- original_return_date
    0,                          -- extension_days
    0,                          -- extension_price
    0,                          -- is_extended
    GETDATE(),                  -- created_at
    GETDATE()                   -- updated_at
);
```

### **Extended Booking (With Extension)**
```sql
INSERT INTO bookings VALUES (
    2,                          -- booking_id
    1,                          -- customer_id
    5,                          -- car_id
    3,                          -- driver_id (có tài xế)
    '2025-10-20 09:00:00',     -- pickup_date
    '2025-10-28 18:00:00',     -- return_date (đã gia hạn)
    'Hà Nội',                   -- pickup_location
    'Đà Nẵng',                  -- return_location
    8,                          -- total_days (5 + 3)
    6400000,                    -- total_price (4M + 2.4M)
    'ongoing',                  -- status
    'partially_paid',           -- payment_status
    'bank_transfer',            -- payment_method
    'Đã gia hạn thêm 3 ngày',  -- notes
    NULL,                       -- cancellation_reason
    '2025-10-25 18:00:00',     -- original_return_date ⭐
    3,                          -- extension_days ⭐
    2400000,                    -- extension_price ⭐
    1,                          -- is_extended ⭐
    GETDATE(),                  -- created_at
    GETDATE()                   -- updated_at
);
```

---

## 🔄 Status Flow

```
pending (Đang chờ)
   ↓ (Admin confirm)
confirmed (Đã xác nhận)
   ↓ (Start trip)
ongoing (Đang diễn ra)
   ↓ (Complete trip)
completed (Hoàn thành)

* Có thể cancel từ pending/confirmed/ongoing
```

---

## 📈 Indexes (Recommended)

```sql
-- Performance optimization
CREATE INDEX idx_bookings_customer ON bookings(customer_id);
CREATE INDEX idx_bookings_car ON bookings(car_id);
CREATE INDEX idx_bookings_status ON bookings(status);
CREATE INDEX idx_bookings_dates ON bookings(pickup_date, return_date);
CREATE INDEX idx_bookings_extended ON bookings(is_extended) WHERE is_extended = 1;
```

---

## 🔍 Common Queries

### **1. Tìm bookings sắp tới của khách hàng**
```sql
SELECT * FROM bookings
WHERE customer_id = 1
  AND pickup_date > GETDATE()
  AND status IN ('pending', 'confirmed')
ORDER BY pickup_date ASC;
```

### **2. Tìm bookings đã gia hạn**
```sql
SELECT 
    booking_id,
    customer_id,
    original_return_date,
    return_date,
    extension_days,
    extension_price
FROM bookings
WHERE is_extended = 1
ORDER BY created_at DESC;
```

### **3. Kiểm tra xe có available không**
```sql
SELECT CASE 
    WHEN COUNT(*) > 0 THEN 'NOT AVAILABLE'
    ELSE 'AVAILABLE'
END as availability
FROM bookings
WHERE car_id = 5
  AND status IN ('pending', 'confirmed', 'ongoing')
  AND pickup_date <= '2025-10-28 18:00:00'
  AND return_date >= '2025-10-20 09:00:00';
```

### **4. Thống kê doanh thu từ gia hạn**
```sql
SELECT 
    COUNT(*) as total_extensions,
    SUM(extension_days) as total_days_extended,
    SUM(extension_price) as total_extension_revenue,
    AVG(extension_price) as avg_extension_price
FROM bookings
WHERE is_extended = 1;
```

---

## ✅ Validation Rules

### **Business Rules:**
1. `return_date` > `pickup_date`
2. `total_days` = DATEDIFF(day, pickup_date, return_date)
3. `total_price` = car.price_per_day × total_days + extension_price
4. `extension_days` >= 0
5. `extension_price` >= 0
6. `is_extended` = 1 → `original_return_date` MUST NOT NULL

### **Constraints:**
```sql
ALTER TABLE bookings ADD CONSTRAINT chk_dates 
CHECK (return_date > pickup_date);

ALTER TABLE bookings ADD CONSTRAINT chk_total_days 
CHECK (total_days > 0);

ALTER TABLE bookings ADD CONSTRAINT chk_total_price 
CHECK (total_price >= 0);

ALTER TABLE bookings ADD CONSTRAINT chk_extension_days 
CHECK (extension_days >= 0);

ALTER TABLE bookings ADD CONSTRAINT chk_status 
CHECK (status IN ('pending', 'confirmed', 'ongoing', 'completed', 'cancelled'));
```

---

## 🎉 Summary

**Total Columns:** 19 columns
- ✅ **Core:** 13 columns (bắt buộc)
- ✅ **Extension:** 4 columns (optional)
- ✅ **Timestamps:** 2 columns

**Relationships:** 3 Foreign Keys
- Customer (1:N)
- Car (1:N)
- Driver (0..1:N)

**Ready for production!** 🚀
