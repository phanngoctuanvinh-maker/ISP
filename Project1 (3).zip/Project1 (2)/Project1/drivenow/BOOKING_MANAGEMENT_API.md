# BOOKING MANAGEMENT API (ADMIN) - Quản lý đơn đặt xe

## Tổng quan
API cho Admin quản lý các đơn đặt xe: Xác nhận, từ chối, hủy, đổi lịch booking.

**Base URL**: `/api/admin/bookings`

**Tổng số endpoints**: 8 endpoints

---

## Danh sách APIs

### 1. Lấy danh sách tất cả bookings
**GET** `/api/admin/bookings`

Lấy danh sách tất cả bookings với filter options.

**Query Parameters**:
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| status | String | No | Lọc theo trạng thái (pending, confirmed, ongoing, completed, cancelled, rejected) |
| customerId | Integer | No | Lọc theo khách hàng |
| carId | Integer | No | Lọc theo xe |

**Response**: `200 OK`
```json
[
  {
    "bookingId": 1,
    "customerId": 10,
    "customerName": "Nguyễn Văn A",
    "customerPhone": "0901234567",
    "carId": 5,
    "carBrand": "Toyota",
    "carModel": "Camry",
    "licensePlate": "30A-12345",
    "driverId": null,
    "driverName": null,
    "pickupDate": "2024-02-01T10:00:00",
    "returnDate": "2024-02-05T10:00:00",
    "pickupLocation": "Sân bay Tân Sơn Nhất",
    "returnLocation": "Quận 1",
    "totalDays": 4,
    "totalPrice": 4000000,
    "status": "pending",
    "paymentStatus": "pending",
    "paymentMethod": "cash",
    "notes": "Cần xe sạch sẽ",
    "cancellationReason": null,
    "originalReturnDate": null,
    "extensionDays": null,
    "extensionPrice": null,
    "isExtended": false,
    "createdAt": "2024-01-25T08:00:00",
    "updatedAt": "2024-01-25T08:00:00"
  }
]
```

**Examples**:
```bash
# Lấy tất cả bookings
GET /api/admin/bookings

# Lấy bookings theo status
GET /api/admin/bookings?status=pending

# Lấy bookings của khách hàng
GET /api/admin/bookings?customerId=10

# Lấy bookings của xe
GET /api/admin/bookings?carId=5

# Lấy bookings của khách hàng theo status
GET /api/admin/bookings?customerId=10&status=confirmed
```

---

### 2. Lấy thống kê bookings
**GET** `/api/admin/bookings/statistics`

Lấy thống kê tổng quan về các bookings.

**Response**: `200 OK`
```json
{
  "totalBookings": 100,
  "pendingCount": 10,
  "confirmedCount": 20,
  "ongoingCount": 5,
  "completedCount": 50,
  "cancelledCount": 10,
  "rejectedCount": 5
}
```

---

### 3. Xác nhận booking
**PATCH** `/api/admin/bookings/{id}/confirm`

Admin xác nhận booking (chuyển từ pending → confirmed).

**Path Parameters**:
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| id | Integer | Yes | ID của booking |

**Business Rules**:
- Chỉ booking ở trạng thái `pending` mới có thể xác nhận
- Sau khi xác nhận, status chuyển thành `confirmed`

**Response**: `200 OK`
```json
{
  "bookingId": 1,
  "status": "confirmed",
  ...
}
```

**Error Responses**:

`404 Not Found` - Không tìm thấy booking
```json
{
  "error": "Không tìm thấy booking với ID: 999"
}
```

`400 Bad Request` - Không thể xác nhận
```json
{
  "error": "Chỉ những booking đang chờ mới có thể được xác nhận"
}
```

---

### 4. Từ chối booking (MỚI)
**PATCH** `/api/admin/bookings/{id}/reject`

Admin từ chối booking (chuyển từ pending → rejected).

**Path Parameters**:
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| id | Integer | Yes | ID của booking |

**Request Body**:
```json
{
  "rejectionReason": "Xe đang bảo trì"
}
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| rejectionReason | String | Yes | Lý do từ chối |

**Business Rules**:
- Chỉ booking ở trạng thái `pending` mới có thể từ chối
- Lý do từ chối là bắt buộc
- Sau khi từ chối, status chuyển thành `rejected`
- Lý do từ chối được lưu vào field `cancellationReason`

**Response**: `200 OK`
```json
{
  "bookingId": 1,
  "status": "rejected",
  "cancellationReason": "Xe đang bảo trì",
  ...
}
```

**Error Responses**:

`400 Bad Request` - Thiếu lý do từ chối
```json
{
  "error": "Lý do từ chối là bắt buộc"
}
```

`400 Bad Request` - Không thể từ chối
```json
{
  "error": "Chỉ có thể từ chối booking đang ở trạng thái pending. Trạng thái hiện tại: confirmed"
}
```

`404 Not Found` - Không tìm thấy booking
```json
{
  "error": "Không tìm thấy booking với ID: 999"
}
```

---

### 5. Hủy booking
**PATCH** `/api/admin/bookings/{id}/cancel`

Admin hủy booking (chuyển sang cancelled).

**Path Parameters**:
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| id | Integer | Yes | ID của booking |

**Request Body**:
```json
{
  "cancellationReason": "Khách hàng yêu cầu hủy"
}
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| cancellationReason | String | Yes | Lý do hủy |

**Business Rules**:
- Có thể hủy booking ở trạng thái `pending` hoặc `confirmed`
- Lý do hủy là bắt buộc
- Sau khi hủy, status chuyển thành `cancelled`
- Nếu booking đang `ongoing`, xe sẽ được chuyển về trạng thái `available`

**Response**: `200 OK`
```json
{
  "bookingId": 1,
  "status": "cancelled",
  "cancellationReason": "Khách hàng yêu cầu hủy",
  ...
}
```

**Error Responses**:

`400 Bad Request` - Thiếu lý do hủy
```json
{
  "error": "Lý do hủy là bắt buộc"
}
```

`400 Bad Request` - Không thể hủy
```json
{
  "error": "Không thể hủy booking đã hoàn thành"
}
```

---

### 6. Đổi lịch booking (MỚI)
**PATCH** `/api/admin/bookings/{id}/reschedule`

Admin đổi lịch booking (thay đổi ngày nhận/trả xe).

**Path Parameters**:
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| id | Integer | Yes | ID của booking |

**Request Body**:
```json
{
  "newPickupDate": "2024-02-10T10:00:00",
  "newReturnDate": "2024-02-15T10:00:00",
  "rescheduleReason": "Khách hàng yêu cầu đổi lịch"
}
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| newPickupDate | DateTime | Yes | Ngày nhận xe mới (ISO 8601 format) |
| newReturnDate | DateTime | Yes | Ngày trả xe mới (ISO 8601 format) |
| rescheduleReason | String | No | Lý do đổi lịch (tối đa 500 ký tự) |

**Business Rules**:
- Chỉ booking ở trạng thái `pending` hoặc `confirmed` mới có thể đổi lịch
- Ngày trả xe mới phải sau ngày nhận xe mới
- Ngày nhận xe mới không được là quá khứ
- Xe phải khả dụng trong khoảng thời gian mới (không trùng với booking khác)
- Tính toán lại `totalDays` và `totalPrice`
- Lý do đổi lịch được thêm vào field `notes` với timestamp

**Response**: `200 OK`
```json
{
  "bookingId": 1,
  "pickupDate": "2024-02-10T10:00:00",
  "returnDate": "2024-02-15T10:00:00",
  "totalDays": 5,
  "totalPrice": 5000000,
  "notes": "[RESCHEDULED] 2024-01-26T14:30:00: Khách hàng yêu cầu đổi lịch",
  ...
}
```

**Error Responses**:

`400 Bad Request` - Ngày không hợp lệ
```json
{
  "error": "Ngày trả xe phải sau ngày nhận xe"
}
```

```json
{
  "error": "Ngày nhận xe không được là quá khứ"
}
```

`400 Bad Request` - Không thể đổi lịch
```json
{
  "error": "Chỉ có thể đổi lịch booking đang ở trạng thái pending hoặc confirmed. Trạng thái hiện tại: completed"
}
```

`400 Bad Request` - Xe không khả dụng
```json
{
  "error": "Xe không khả dụng trong thời gian mới"
}
```

`404 Not Found` - Không tìm thấy booking
```json
{
  "error": "Không tìm thấy booking với ID: 999"
}
```

---

### 7. Lấy các booking sắp diễn ra
**GET** `/api/admin/bookings/upcoming`

Lấy danh sách các booking sắp diễn ra (trong 7 ngày tới).

**Response**: `200 OK`
```json
[
  {
    "bookingId": 1,
    "status": "confirmed",
    "pickupDate": "2024-02-01T10:00:00",
    ...
  },
  {
    "bookingId": 2,
    "status": "pending",
    "pickupDate": "2024-02-03T14:00:00",
    ...
  }
]
```

**Logic**:
- Lọc bookings có status là `confirmed` hoặc `pending`
- Lọc bookings có `pickupDate` trong 7 ngày tới
- Sắp xếp theo `pickupDate` tăng dần

---

### 8. Lấy các booking đang diễn ra
**GET** `/api/admin/bookings/ongoing`

Lấy danh sách các booking đang diễn ra (status = ongoing).

**Response**: `200 OK`
```json
[
  {
    "bookingId": 5,
    "status": "ongoing",
    "pickupDate": "2024-01-20T10:00:00",
    "returnDate": "2024-02-05T10:00:00",
    ...
  }
]
```

---

## Trạng thái Booking (Status Flow)

```
pending → confirmed → ongoing → completed
   ↓           ↓
rejected   cancelled
```

**Các trạng thái**:
- `pending`: Chờ xác nhận (có thể: confirm, reject, cancel, reschedule)
- `confirmed`: Đã xác nhận (có thể: cancel, reschedule, start)
- `ongoing`: Đang diễn ra (có thể: cancel, complete, extend)
- `completed`: Đã hoàn thành (không thể thay đổi)
- `cancelled`: Đã hủy (không thể thay đổi)
- `rejected`: Đã từ chối (không thể thay đổi)

---

## Testing với Postman/cURL

### Test 1: Lấy tất cả bookings
```bash
GET http://localhost:8080/api/admin/bookings
```

### Test 2: Lấy thống kê
```bash
GET http://localhost:8080/api/admin/bookings/statistics
```

### Test 3: Xác nhận booking
```bash
PATCH http://localhost:8080/api/admin/bookings/1/confirm
```

### Test 4: Từ chối booking
```bash
PATCH http://localhost:8080/api/admin/bookings/1/reject
Content-Type: application/json

{
  "rejectionReason": "Xe đang bảo trì"
}
```

### Test 5: Hủy booking
```bash
PATCH http://localhost:8080/api/admin/bookings/1/cancel
Content-Type: application/json

{
  "cancellationReason": "Khách hàng yêu cầu hủy"
}
```

### Test 6: Đổi lịch booking
```bash
PATCH http://localhost:8080/api/admin/bookings/1/reschedule
Content-Type: application/json

{
  "newPickupDate": "2024-02-10T10:00:00",
  "newReturnDate": "2024-02-15T10:00:00",
  "rescheduleReason": "Khách hàng yêu cầu đổi lịch vì lý do cá nhân"
}
```

### Test 7: Lấy bookings sắp diễn ra
```bash
GET http://localhost:8080/api/admin/bookings/upcoming
```

### Test 8: Lấy bookings đang diễn ra
```bash
GET http://localhost:8080/api/admin/bookings/ongoing
```

---

## Các trường hợp đặc biệt

### 1. Đổi lịch khi xe đã có booking khác
**Scenario**: Admin đổi lịch booking A, nhưng thời gian mới trùng với booking B.

**Kết quả**: API trả về lỗi `400 Bad Request`
```json
{
  "error": "Xe không khả dụng trong thời gian mới"
}
```

### 2. Đổi lịch booking của chính nó
**Scenario**: Booking A từ 01/02 → 05/02, admin đổi sang 03/02 → 07/02 (có overlap).

**Kết quả**: Thành công vì API loại bỏ booking hiện tại khỏi danh sách conflicts.

### 3. Từ chối booking đã confirmed
**Scenario**: Admin cố gắng từ chối booking đã được confirmed.

**Kết quả**: API trả về lỗi `400 Bad Request`
```json
{
  "error": "Chỉ có thể từ chối booking đang ở trạng thái pending. Trạng thái hiện tại: confirmed"
}
```

### 4. Tính toán lại giá khi đổi lịch
**Scenario**: Booking gốc 4 ngày (4,000,000 VND), đổi sang 6 ngày.

**Kết quả**: 
- `totalDays` = 6
- `totalPrice` = 6 × 1,000,000 = 6,000,000 VND
- `notes` được cập nhật với lý do và timestamp

---

## Tổng kết

**Tổng số APIs**: 8 endpoints
- 2 endpoints để xem danh sách (list all, statistics)
- 4 endpoints để quản lý trạng thái (confirm, reject, cancel, reschedule)
- 2 endpoints để lọc (upcoming, ongoing)

**Tính năng mới**:
- ✅ Từ chối booking (reject)
- ✅ Đổi lịch booking (reschedule) với validation đầy đủ
- ✅ Thống kê tổng quan
- ✅ Lọc bookings theo nhiều tiêu chí

**Validation**:
- Kiểm tra trạng thái hợp lệ
- Kiểm tra ngày hợp lệ
- Kiểm tra xe khả dụng
- Yêu cầu lý do bắt buộc cho reject/cancel
