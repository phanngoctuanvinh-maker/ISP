# 🔒 HƯỚNG DẪN CẤU HÌNH SECURITY CHO PRODUCTION

## 📌 HIỆN TẠI (Testing Mode)

Bạn đang **DISABLE Security** để test APIs dễ dàng trên Postman:
- Tất cả APIs đều public (không cần token)
- Chỉ dùng cho **DEVELOPMENT/TESTING**
- ⚠️ **KHÔNG ĐƯỢC deploy lên production như vậy!**

---

## 🚀 KHI CHẠY THẬT TRÊN WEB (Production)

### Bước 1: BẬT LẠI Spring Security

Mở file `SecurityConfig.java` và sửa lại như sau:

```java
@Configuration
@EnableWebSecurity  // ← BẬT LẠI dòng này
@EnableMethodSecurity  // ← BẬT LẠI dòng này
public class SecurityConfig {

    @Autowired
    private UserDetailsService userDetailsService;

    @Autowired
    private JwtAuthenticationFilter jwtAuthenticationFilter;

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
        authProvider.setUserDetailsService(userDetailsService);
        authProvider.setPasswordEncoder(passwordEncoder());
        return authProvider;
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authConfig) throws Exception {
        return authConfig.getAuthenticationManager();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .cors(cors -> cors.configurationSource(corsConfigurationSource()))
            .csrf(csrf -> csrf.disable())
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                // PUBLIC APIs - Không cần login
                .requestMatchers("/api/auth/**").permitAll()
                .requestMatchers("/api/cars/**").permitAll() // Xem xe công khai
                .requestMatchers("/api/reviews/**").permitAll() // Xem review công khai
                
                // PROTECTED APIs - Cần login (có JWT token)
                .requestMatchers("/api/bookings/**").authenticated()
                .requestMatchers("/api/history/**").authenticated()
                .requestMatchers("/api/favorites/**").authenticated()
                .requestMatchers("/api/profile/**").authenticated()
                .requestMatchers("/api/rental-contracts/**").authenticated()
                .requestMatchers("/api/delivery-schedules/**").authenticated()
                .requestMatchers("/api/group-bookings/**").authenticated()
                
                // Tất cả request khác phải authenticate
                .anyRequest().authenticated()
            )
            .authenticationProvider(authenticationProvider())
            .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOriginPatterns(Arrays.asList("*"));
        configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"));
        configuration.setAllowedHeaders(Arrays.asList("*"));
        configuration.setAllowCredentials(true);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }
}
```

---

## 🔑 CÁCH FRONTEND SỬ DỤNG JWT TOKEN

### 1. **Login để lấy Token**

```javascript
// Frontend code (JavaScript/React/Vue)
async function login(username, password) {
  const response = await fetch('http://localhost:8080/api/auth/login', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ username, password })
  });

  const data = await response.json();
  
  // Lưu token vào localStorage
  localStorage.setItem('accessToken', data.accessToken);
  localStorage.setItem('accountId', data.accountId);
  localStorage.setItem('role', data.role);
  
  return data;
}
```

### 2. **Gửi Token khi gọi Protected APIs**

```javascript
// Gọi API cần authentication
async function getBookingHistory(accountId) {
  const token = localStorage.getItem('accessToken');
  
  const response = await fetch(`http://localhost:8080/api/history/account/${accountId}/bookings`, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${token}`, // ← GỬI TOKEN Ở ĐÂY
      'Content-Type': 'application/json'
    }
  });

  return await response.json();
}
```

### 3. **Tạo một Axios Interceptor (Khuyên dùng)**

```javascript
// axios-config.js
import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:8080/api'
});

// Tự động thêm token vào mọi request
api.interceptors.request.use(
  config => {
    const token = localStorage.getItem('accessToken');
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`;
    }
    return config;
  },
  error => {
    return Promise.reject(error);
  }
);

// Xử lý khi token hết hạn (401)
api.interceptors.response.use(
  response => response,
  error => {
    if (error.response?.status === 401) {
      // Token hết hạn → Redirect về login
      localStorage.clear();
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export default api;

// Sử dụng:
// import api from './axios-config';
// const data = await api.get('/history/account/1/bookings');
```

---

## 📱 TEST VỚI POSTMAN (Có Security)

### Bước 1: Login để lấy Token

**Request:**
```http
POST http://localhost:8080/api/auth/login
Content-Type: application/json

{
  "username": "testuser@gmail.com",
  "password": "123456"
}
```

**Response:**
```json
{
  "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "accountId": 4,
  "username": "testuser@gmail.com",
  "role": "customer"
}
```

### Bước 2: Copy Token

Copy giá trị `accessToken` từ response.

### Bước 3: Thêm Token vào Header

Trong Postman, với mọi protected API:

1. Chọn tab **"Authorization"**
2. Type: chọn **"Bearer Token"**
3. Paste token vào field **"Token"**

**Hoặc** thêm vào **Headers** tab:
```
Key: Authorization
Value: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

### Bước 4: Gọi Protected APIs

```http
GET http://localhost:8080/api/history/account/4/bookings
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

✅ Nếu token hợp lệ → **200 OK**  
❌ Nếu không có token hoặc token sai → **401 Unauthorized**

---

## 🎯 CẤU HÌNH PHÂN QUYỀN (Role-Based Access)

### Admin có thể làm gì?

```java
// Trong SecurityConfig
.requestMatchers("/api/cars/**").hasRole("ADMIN") // Chỉ admin quản lý xe
.requestMatchers("/api/bookings/all").hasRole("ADMIN") // Admin xem tất cả bookings
.requestMatchers("/api/delivery-schedules/**").hasAnyRole("ADMIN", "DRIVER") // Admin và driver
```

### Trong Controller, dùng annotation:

```java
@RestController
@RequestMapping("/api/cars")
public class CarController {

    // Chỉ admin mới tạo được xe
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping
    public ResponseEntity<Car> createCar(@RequestBody Car car) {
        // ...
    }

    // Public - ai cũng xem được
    @GetMapping
    public ResponseEntity<List<Car>> getAllCars() {
        // ...
    }

    // Chỉ admin hoặc chủ xe
    @PreAuthorize("hasRole('ADMIN') or @carService.isOwner(#carId, authentication.principal.id)")
    @DeleteMapping("/{carId}")
    public ResponseEntity<?> deleteCar(@PathVariable Integer carId) {
        // ...
    }
}
```

---

## ⚙️ CẤU HÌNH TOKEN EXPIRATION

Trong `application.properties`:

```properties
# JWT Configuration
jwt.secret=your-secret-key-must-be-at-least-256-bits-long-for-production
jwt.expiration=86400000  # 24 hours (milliseconds)
jwt.refresh-expiration=604800000  # 7 days
```

**Lưu ý:**
- Token ngắn (1-24h) cho security tốt hơn
- Dùng Refresh Token cho UX tốt hơn (không phải login lại liên tục)

---

## 🔐 BEST PRACTICES CHO PRODUCTION

### 1. HTTPS Only
```properties
# application-prod.properties
server.ssl.enabled=true
server.ssl.key-store=classpath:keystore.p12
server.ssl.key-store-password=your-password
server.ssl.key-store-type=PKCS12
```

### 2. Environment Variables
```properties
# Không hard-code secret key!
jwt.secret=${JWT_SECRET:fallback-secret-for-dev}
spring.datasource.password=${DB_PASSWORD}
```

### 3. Rate Limiting
```java
// Thêm dependency: bucket4j-spring-boot-starter
@RateLimiter(name = "loginLimiter")
@PostMapping("/login")
public ResponseEntity<?> login(@RequestBody LoginRequest request) {
    // ...
}
```

### 4. CORS Strict
```java
// Production: Chỉ cho phép domain cụ thể
configuration.setAllowedOriginPatterns(Arrays.asList(
    "https://yourdomain.com",
    "https://www.yourdomain.com"
));
```

---

## 📊 TÓM TẮT CÁC CHẾ ĐỘ

| Chế độ | Security | Sử dụng | Token Required? |
|--------|----------|---------|-----------------|
| **Testing** (Hiện tại) | ❌ Disabled | Postman testing | ❌ No |
| **Development** | ✅ Enabled (loose) | Local dev với frontend | ✅ Yes |
| **Production** | ✅ Enabled (strict) | Deploy live | ✅ Yes + HTTPS |

---

## 🚀 CHECKLIST TRƯỚC KHI DEPLOY PRODUCTION

- [ ] ✅ Bật lại `@EnableWebSecurity`
- [ ] ✅ Cấu hình JWT secret từ environment variable
- [ ] ✅ Bật HTTPS
- [ ] ✅ Cấu hình CORS chỉ cho phép domain chính thức
- [ ] ✅ Set token expiration hợp lý (1-24h)
- [ ] ✅ Thêm rate limiting cho login
- [ ] ✅ Test tất cả protected APIs với token
- [ ] ✅ Thêm logging cho security events
- [ ] ✅ Setup error handling cho 401/403
- [ ] ✅ Document APIs với authentication requirements

---

## 💡 NẾU CẦN TOGGLE GIỮA TESTING VÀ PRODUCTION

Tạo 2 profiles:

**application-dev.properties:**
```properties
security.enabled=false
```

**application-prod.properties:**
```properties
security.enabled=true
```

**SecurityConfig.java:**
```java
@Value("${security.enabled:true}")
private boolean securityEnabled;

@Bean
public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
    if (!securityEnabled) {
        // Testing mode - tất cả public
        http.authorizeHttpRequests(auth -> auth.anyRequest().permitAll());
    } else {
        // Production mode - có authentication
        http.authorizeHttpRequests(auth -> auth
            .requestMatchers("/api/auth/**").permitAll()
            .anyRequest().authenticated()
        );
    }
    return http.build();
}
```

Chạy với profile:
```bash
# Testing
.\mvnw spring-boot:run -Dspring-boot.run.profiles=dev

# Production
.\mvnw spring-boot:run -Dspring-boot.run.profiles=prod
```

---

## 📞 HỖ TRỢ

Nếu gặp vấn đề khi enable security:
1. Kiểm tra JWT token có được gửi đúng header không
2. Xem log server để debug authentication errors
3. Test login API trước, đảm bảo nhận được token
4. Verify token không expired

**Happy Coding! 🚀**
