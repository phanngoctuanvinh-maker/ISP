package com.carrentleproject.drivenow.dto;

import java.util.List;

public class CarSearchResponse {
    private List<CarDTO> cars;
    private int totalResults;
    private CarSearchRequest searchCriteria;

    // Constructors
    public CarSearchResponse() {
    }

    public CarSearchResponse(List<CarDTO> cars, int totalResults, CarSearchRequest searchCriteria) {
        this.cars = cars;
        this.totalResults = totalResults;
        this.searchCriteria = searchCriteria;
    }

    // Getters and Setters
    public List<CarDTO> getCars() {
        return cars;
    }

    public void setCars(List<CarDTO> cars) {
        this.cars = cars;
    }

    public int getTotalResults() {
        return totalResults;
    }

    public void setTotalResults(int totalResults) {
        this.totalResults = totalResults;
    }

    public CarSearchRequest getSearchCriteria() {
        return searchCriteria;
    }

    public void setSearchCriteria(CarSearchRequest searchCriteria) {
        this.searchCriteria = searchCriteria;
    }
}
