package com.carrentleproject.drivenow.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

/**
 * Request DTO để tạo hợp đồng thuê xe
 */
public class RentalContractCreateRequest {

    @NotNull(message = "Booking ID là bắt buộc")
    private Integer bookingId;

    @Size(max = 50, message = "Contract template không được vượt quá 50 ký tự")
    private String contractTemplate; // standard, premium, vip

    private BigDecimal depositAmount; // Tiền đặt cọc

    private BigDecimal insuranceAmount; // Phí bảo hiểm

    // Thông tin bên cho thuê (tự động điền, có thể override)
    @Size(max = 200, message = "Tên bên cho thuê không được vượt quá 200 ký tự")
    private String lessorName;

    @Size(max = 255, message = "Địa chỉ không được vượt quá 255 ký tự")
    private String lessorAddress;

    @Size(max = 20, message = "SĐT không được vượt quá 20 ký tự")
    private String lessorPhone;

    @Size(max = 100, message = "Email không được vượt quá 100 ký tự")
    private String lessorEmail;

    @Size(max = 50, message = "Mã số thuế không được vượt quá 50 ký tự")
    private String lessorTaxCode;

    @Size(max = 100, message = "Người đại diện không được vượt quá 100 ký tự")
    private String lessorRepresentative;

    // Thông tin bên thuê (lấy từ customer)
    @Size(max = 20, message = "CMND/CCCD không được vượt quá 20 ký tự")
    private String lesseeIdCard;

    private LocalDateTime lesseeDateOfBirth;

    @Size(max = 50, message = "Số GPLX không được vượt quá 50 ký tự")
    private String lesseeLicenseNumber;

    private LocalDateTime lesseeLicenseExpiry;

    // Tình trạng xe khi bàn giao
    @Size(max = 2000, message = "Tình trạng xe không được vượt quá 2000 ký tự")
    private String carCondition;

    // Điều khoản bổ sung (optional)
    @Size(max = 5000, message = "Điều khoản bổ sung không được vượt quá 5000 ký tự")
    private String additionalTerms;

    @Size(max = 1000, message = "Ghi chú không được vượt quá 1000 ký tự")
    private String notes;

    // Constructors
    public RentalContractCreateRequest() {
    }

    // Getters and Setters
    public Integer getBookingId() {
        return bookingId;
    }

    public void setBookingId(Integer bookingId) {
        this.bookingId = bookingId;
    }

    public String getContractTemplate() {
        return contractTemplate;
    }

    public void setContractTemplate(String contractTemplate) {
        this.contractTemplate = contractTemplate;
    }

    public BigDecimal getDepositAmount() {
        return depositAmount;
    }

    public void setDepositAmount(BigDecimal depositAmount) {
        this.depositAmount = depositAmount;
    }

    public BigDecimal getInsuranceAmount() {
        return insuranceAmount;
    }

    public void setInsuranceAmount(BigDecimal insuranceAmount) {
        this.insuranceAmount = insuranceAmount;
    }

    public String getLessorName() {
        return lessorName;
    }

    public void setLessorName(String lessorName) {
        this.lessorName = lessorName;
    }

    public String getLessorAddress() {
        return lessorAddress;
    }

    public void setLessorAddress(String lessorAddress) {
        this.lessorAddress = lessorAddress;
    }

    public String getLessorPhone() {
        return lessorPhone;
    }

    public void setLessorPhone(String lessorPhone) {
        this.lessorPhone = lessorPhone;
    }

    public String getLessorEmail() {
        return lessorEmail;
    }

    public void setLessorEmail(String lessorEmail) {
        this.lessorEmail = lessorEmail;
    }

    public String getLessorTaxCode() {
        return lessorTaxCode;
    }

    public void setLessorTaxCode(String lessorTaxCode) {
        this.lessorTaxCode = lessorTaxCode;
    }

    public String getLessorRepresentative() {
        return lessorRepresentative;
    }

    public void setLessorRepresentative(String lessorRepresentative) {
        this.lessorRepresentative = lessorRepresentative;
    }

    public String getLesseeIdCard() {
        return lesseeIdCard;
    }

    public void setLesseeIdCard(String lesseeIdCard) {
        this.lesseeIdCard = lesseeIdCard;
    }

    public LocalDateTime getLesseeDateOfBirth() {
        return lesseeDateOfBirth;
    }

    public void setLesseeDateOfBirth(LocalDateTime lesseeDateOfBirth) {
        this.lesseeDateOfBirth = lesseeDateOfBirth;
    }

    public String getLesseeLicenseNumber() {
        return lesseeLicenseNumber;
    }

    public void setLesseeLicenseNumber(String lesseeLicenseNumber) {
        this.lesseeLicenseNumber = lesseeLicenseNumber;
    }

    public LocalDateTime getLesseeLicenseExpiry() {
        return lesseeLicenseExpiry;
    }

    public void setLesseeLicenseExpiry(LocalDateTime lesseeLicenseExpiry) {
        this.lesseeLicenseExpiry = lesseeLicenseExpiry;
    }

    public String getCarCondition() {
        return carCondition;
    }

    public void setCarCondition(String carCondition) {
        this.carCondition = carCondition;
    }

    public String getAdditionalTerms() {
        return additionalTerms;
    }

    public void setAdditionalTerms(String additionalTerms) {
        this.additionalTerms = additionalTerms;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }
}
