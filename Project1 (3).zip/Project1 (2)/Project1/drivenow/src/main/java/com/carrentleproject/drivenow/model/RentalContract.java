package com.carrentleproject.drivenow.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/**
 * Entity quản lý hợp đồng điện tử
 * Electronic contract for car rental
 */
@Entity
@Table(name = "rental_contracts")
public class RentalContract {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "contract_id")
    private Integer contractId;

    @ManyToOne
    @JoinColumn(name = "booking_id", nullable = false, unique = true)
    private Booking booking; // Mỗi booking có 1 hợp đồng

    @Column(name = "contract_number", nullable = false, unique = true, length = 50)
    private String contractNumber; // Mã hợp đồng (auto generate: HDT-2024-0001)

    @Column(name = "contract_date", nullable = false)
    private LocalDateTime contractDate; // Ngày ký hợp đồng

    @Column(name = "start_date", nullable = false)
    private LocalDateTime startDate; // Ngày bắt đầu thuê

    @Column(name = "end_date", nullable = false)
    private LocalDateTime endDate; // Ngày kết thúc thuê

    @Column(name = "total_amount", nullable = false, precision = 12, scale = 2)
    private BigDecimal totalAmount; // Tổng tiền thuê

    @Column(name = "deposit_amount", precision = 12, scale = 2)
    private BigDecimal depositAmount; // Tiền đặt cọc

    @Column(name = "insurance_amount", precision = 12, scale = 2)
    private BigDecimal insuranceAmount; // Phí bảo hiểm

    @Column(name = "status", nullable = false, length = 20)
    private String status = "draft"; // draft, active, completed, cancelled, expired

    // Thông tin bên A (DriveNow - Bên cho thuê)
    @Column(name = "lessor_name", nullable = false, length = 200)
    private String lessorName; // Tên công ty cho thuê

    @Column(name = "lessor_address", nullable = false, length = 255)
    private String lessorAddress; // Địa chỉ công ty

    @Column(name = "lessor_phone", length = 20)
    private String lessorPhone; // SĐT công ty

    @Column(name = "lessor_email", length = 100)
    private String lessorEmail; // Email công ty

    @Column(name = "lessor_tax_code", length = 50)
    private String lessorTaxCode; // Mã số thuế

    @Column(name = "lessor_representative", length = 100)
    private String lessorRepresentative; // Người đại diện

    // Thông tin bên B (Customer - Bên thuê)
    @Column(name = "lessee_name", nullable = false, length = 200)
    private String lesseeName; // Tên khách hàng

    @Column(name = "lessee_id_card", length = 20)
    private String lesseeIdCard; // CMND/CCCD

    @Column(name = "lessee_phone", length = 20)
    private String lesseePhone; // SĐT khách

    @Column(name = "lessee_email", length = 100)
    private String lesseeEmail; // Email khách

    @Column(name = "lessee_address", length = 255)
    private String lesseeAddress; // Địa chỉ khách

    @Column(name = "lessee_date_of_birth")
    private LocalDateTime lesseeDateOfBirth; // Ngày sinh

    @Column(name = "lessee_license_number", length = 50)
    private String lesseeLicenseNumber; // Số giấy phép lái xe

    @Column(name = "lessee_license_expiry")
    private LocalDateTime lesseeLicenseExpiry; // Ngày hết hạn GPLX

    // Thông tin xe
    @Column(name = "car_info", nullable = false, columnDefinition = "TEXT")
    private String carInfo; // JSON: {brand, model, year, licensePlate, color, seats}

    @Column(name = "car_condition", columnDefinition = "TEXT")
    private String carCondition; // Tình trạng xe khi bàn giao

    // Điều khoản hợp đồng
    @Column(name = "terms_and_conditions", nullable = false, columnDefinition = "TEXT")
    private String termsAndConditions; // Điều khoản và điều kiện

    @Column(name = "additional_terms", columnDefinition = "TEXT")
    private String additionalTerms; // Điều khoản bổ sung (nếu có)

    // Chữ ký điện tử
    @Column(name = "lessor_signature_url", length = 500)
    private String lessorSignatureUrl; // URL chữ ký bên cho thuê

    @Column(name = "lessee_signature_url", length = 500)
    private String lesseeSignatureUrl; // URL chữ ký bên thuê

    @Column(name = "lessor_signed_at")
    private LocalDateTime lessorSignedAt; // Thời gian ký (bên cho thuê)

    @Column(name = "lessee_signed_at")
    private LocalDateTime lesseeSignedAt; // Thời gian ký (bên thuê)

    // File hợp đồng
    @Column(name = "contract_file_url", length = 500)
    private String contractFileUrl; // URL file PDF hợp đồng

    @Column(name = "contract_template", length = 50)
    private String contractTemplate; // Mẫu hợp đồng sử dụng (standard, premium, etc.)

    // Ghi chú và metadata
    @Column(name = "notes", columnDefinition = "TEXT")
    private String notes; // Ghi chú

    @Column(name = "cancellation_reason", columnDefinition = "TEXT")
    private String cancellationReason; // Lý do hủy hợp đồng

    @Column(name = "expiry_date")
    private LocalDateTime expiryDate; // Ngày hết hiệu lực

    @Column(name = "is_signed")
    private Boolean isSigned = false; // Đã ký đầy đủ chưa (cả 2 bên)

    @Column(name = "is_archived")
    private Boolean isArchived = false; // Đã lưu trữ chưa

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    // Constructors
    public RentalContract() {
    }

    public RentalContract(Booking booking, String contractNumber, LocalDateTime contractDate) {
        this.booking = booking;
        this.contractNumber = contractNumber;
        this.contractDate = contractDate;
        this.status = "draft";
        this.isSigned = false;
        this.isArchived = false;
    }

    // Helper method: Check if contract is fully signed
    public boolean isFullySigned() {
        return lessorSignedAt != null && lesseeSignedAt != null;
    }

    // Helper method: Check if contract is valid
    public boolean isValid() {
        return "active".equals(status) && isSigned && LocalDateTime.now().isBefore(expiryDate);
    }

    // Getters and Setters
    public Integer getContractId() {
        return contractId;
    }

    public void setContractId(Integer contractId) {
        this.contractId = contractId;
    }

    public Booking getBooking() {
        return booking;
    }

    public void setBooking(Booking booking) {
        this.booking = booking;
    }

    public String getContractNumber() {
        return contractNumber;
    }

    public void setContractNumber(String contractNumber) {
        this.contractNumber = contractNumber;
    }

    public LocalDateTime getContractDate() {
        return contractDate;
    }

    public void setContractDate(LocalDateTime contractDate) {
        this.contractDate = contractDate;
    }

    public LocalDateTime getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDateTime startDate) {
        this.startDate = startDate;
    }

    public LocalDateTime getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDateTime endDate) {
        this.endDate = endDate;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public BigDecimal getDepositAmount() {
        return depositAmount;
    }

    public void setDepositAmount(BigDecimal depositAmount) {
        this.depositAmount = depositAmount;
    }

    public BigDecimal getInsuranceAmount() {
        return insuranceAmount;
    }

    public void setInsuranceAmount(BigDecimal insuranceAmount) {
        this.insuranceAmount = insuranceAmount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getLessorName() {
        return lessorName;
    }

    public void setLessorName(String lessorName) {
        this.lessorName = lessorName;
    }

    public String getLessorAddress() {
        return lessorAddress;
    }

    public void setLessorAddress(String lessorAddress) {
        this.lessorAddress = lessorAddress;
    }

    public String getLessorPhone() {
        return lessorPhone;
    }

    public void setLessorPhone(String lessorPhone) {
        this.lessorPhone = lessorPhone;
    }

    public String getLessorEmail() {
        return lessorEmail;
    }

    public void setLessorEmail(String lessorEmail) {
        this.lessorEmail = lessorEmail;
    }

    public String getLessorTaxCode() {
        return lessorTaxCode;
    }

    public void setLessorTaxCode(String lessorTaxCode) {
        this.lessorTaxCode = lessorTaxCode;
    }

    public String getLessorRepresentative() {
        return lessorRepresentative;
    }

    public void setLessorRepresentative(String lessorRepresentative) {
        this.lessorRepresentative = lessorRepresentative;
    }

    public String getLesseeName() {
        return lesseeName;
    }

    public void setLesseeName(String lesseeName) {
        this.lesseeName = lesseeName;
    }

    public String getLesseeIdCard() {
        return lesseeIdCard;
    }

    public void setLesseeIdCard(String lesseeIdCard) {
        this.lesseeIdCard = lesseeIdCard;
    }

    public String getLesseePhone() {
        return lesseePhone;
    }

    public void setLesseePhone(String lesseePhone) {
        this.lesseePhone = lesseePhone;
    }

    public String getLesseeEmail() {
        return lesseeEmail;
    }

    public void setLesseeEmail(String lesseeEmail) {
        this.lesseeEmail = lesseeEmail;
    }

    public String getLesseeAddress() {
        return lesseeAddress;
    }

    public void setLesseeAddress(String lesseeAddress) {
        this.lesseeAddress = lesseeAddress;
    }

    public LocalDateTime getLesseeDateOfBirth() {
        return lesseeDateOfBirth;
    }

    public void setLesseeDateOfBirth(LocalDateTime lesseeDateOfBirth) {
        this.lesseeDateOfBirth = lesseeDateOfBirth;
    }

    public String getLesseeLicenseNumber() {
        return lesseeLicenseNumber;
    }

    public void setLesseeLicenseNumber(String lesseeLicenseNumber) {
        this.lesseeLicenseNumber = lesseeLicenseNumber;
    }

    public LocalDateTime getLesseeLicenseExpiry() {
        return lesseeLicenseExpiry;
    }

    public void setLesseeLicenseExpiry(LocalDateTime lesseeLicenseExpiry) {
        this.lesseeLicenseExpiry = lesseeLicenseExpiry;
    }

    public String getCarInfo() {
        return carInfo;
    }

    public void setCarInfo(String carInfo) {
        this.carInfo = carInfo;
    }

    public String getCarCondition() {
        return carCondition;
    }

    public void setCarCondition(String carCondition) {
        this.carCondition = carCondition;
    }

    public String getTermsAndConditions() {
        return termsAndConditions;
    }

    public void setTermsAndConditions(String termsAndConditions) {
        this.termsAndConditions = termsAndConditions;
    }

    public String getAdditionalTerms() {
        return additionalTerms;
    }

    public void setAdditionalTerms(String additionalTerms) {
        this.additionalTerms = additionalTerms;
    }

    public String getLessorSignatureUrl() {
        return lessorSignatureUrl;
    }

    public void setLessorSignatureUrl(String lessorSignatureUrl) {
        this.lessorSignatureUrl = lessorSignatureUrl;
    }

    public String getLesseeSignatureUrl() {
        return lesseeSignatureUrl;
    }

    public void setLesseeSignatureUrl(String lesseeSignatureUrl) {
        this.lesseeSignatureUrl = lesseeSignatureUrl;
    }

    public LocalDateTime getLessorSignedAt() {
        return lessorSignedAt;
    }

    public void setLessorSignedAt(LocalDateTime lessorSignedAt) {
        this.lessorSignedAt = lessorSignedAt;
    }

    public LocalDateTime getLesseeSignedAt() {
        return lesseeSignedAt;
    }

    public void setLesseeSignedAt(LocalDateTime lesseeSignedAt) {
        this.lesseeSignedAt = lesseeSignedAt;
    }

    public String getContractFileUrl() {
        return contractFileUrl;
    }

    public void setContractFileUrl(String contractFileUrl) {
        this.contractFileUrl = contractFileUrl;
    }

    public String getContractTemplate() {
        return contractTemplate;
    }

    public void setContractTemplate(String contractTemplate) {
        this.contractTemplate = contractTemplate;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getCancellationReason() {
        return cancellationReason;
    }

    public void setCancellationReason(String cancellationReason) {
        this.cancellationReason = cancellationReason;
    }

    public LocalDateTime getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(LocalDateTime expiryDate) {
        this.expiryDate = expiryDate;
    }

    public Boolean getIsSigned() {
        return isSigned;
    }

    public void setIsSigned(Boolean isSigned) {
        this.isSigned = isSigned;
    }

    public Boolean getIsArchived() {
        return isArchived;
    }

    public void setIsArchived(Boolean isArchived) {
        this.isArchived = isArchived;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public String toString() {
        return "RentalContract{" +
                "contractId=" + contractId +
                ", contractNumber='" + contractNumber + '\'' +
                ", contractDate=" + contractDate +
                ", status='" + status + '\'' +
                ", isSigned=" + isSigned +
                ", totalAmount=" + totalAmount +
                '}';
    }
}
