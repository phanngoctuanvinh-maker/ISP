package com.carrentleproject.drivenow.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.carrentleproject.drivenow.dto.FavoriteDTO;
import com.carrentleproject.drivenow.service.FavoriteService;

/**
 * Controller cho quản lý xe yêu thích (Favorites/Wishlist)
 * Base URL: /api/favorites
 */
@RestController
@RequestMapping("/api/favorites")
@CrossOrigin(origins = "*")
public class FavoriteController {

    @Autowired
    private FavoriteService favoriteService;

    /**
     * 1. Thêm xe vào danh sách yêu thích
     * POST /api/favorites?customerId={customerId}&carId={carId}
     * 
     * Response: FavoriteDTO
     */
    @PostMapping
    public ResponseEntity<?> addFavorite(
            @RequestParam Integer customerId,
            @RequestParam Integer carId) {
        
        try {
            FavoriteDTO favorite = favoriteService.addFavorite(customerId, carId);
            return ResponseEntity.status(HttpStatus.CREATED).body(favorite);
            
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", e.getMessage()));
        } catch (IllegalStateException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Lỗi khi thêm xe yêu thích: " + e.getMessage()));
        }
    }

    /**
     * 2. Xóa xe khỏi danh sách yêu thích
     * DELETE /api/favorites?customerId={customerId}&carId={carId}
     * 
     * Response: Success message
     */
    @DeleteMapping
    public ResponseEntity<?> removeFavorite(
            @RequestParam Integer customerId,
            @RequestParam Integer carId) {
        
        try {
            favoriteService.removeFavorite(customerId, carId);
            return ResponseEntity.ok(Map.of("message", "Đã xóa xe khỏi danh sách yêu thích"));
            
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Lỗi khi xóa xe yêu thích: " + e.getMessage()));
        }
    }

    /**
     * 3. Lấy danh sách xe yêu thích của khách hàng
     * GET /api/favorites/{customerId}
     * 
     * Response: Danh sách FavoriteDTO
     */
    @GetMapping("/{customerId}")
    public ResponseEntity<List<FavoriteDTO>> getFavorites(@PathVariable Integer customerId) {
        try {
            List<FavoriteDTO> favorites = favoriteService.getFavoritesByCustomer(customerId);
            return ResponseEntity.ok(favorites);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * 4. Kiểm tra xe đã được yêu thích chưa
     * GET /api/favorites/check?customerId={customerId}&carId={carId}
     * 
     * Response:
     * {
     *   "isFavorite": true
     * }
     */
    @GetMapping("/check")
    public ResponseEntity<Map<String, Boolean>> checkFavorite(
            @RequestParam Integer customerId,
            @RequestParam Integer carId) {
        
        try {
            boolean isFavorite = favoriteService.isFavorite(customerId, carId);
            return ResponseEntity.ok(Map.of("isFavorite", isFavorite));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * 5. Đếm số lượng xe yêu thích của khách hàng
     * GET /api/favorites/{customerId}/count
     * 
     * Response:
     * {
     *   "count": 5
     * }
     */
    @GetMapping("/{customerId}/count")
    public ResponseEntity<Map<String, Long>> countFavorites(@PathVariable Integer customerId) {
        try {
            Long count = favoriteService.countFavorites(customerId);
            return ResponseEntity.ok(Map.of("count", count));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * 6. Đếm số lượng khách hàng yêu thích xe này
     * GET /api/favorites/cars/{carId}/count
     * 
     * Response:
     * {
     *   "count": 10
     * }
     */
    @GetMapping("/cars/{carId}/count")
    public ResponseEntity<Map<String, Long>> countFavoritesByCar(@PathVariable Integer carId) {
        try {
            Long count = favoriteService.countFavoritesByCar(carId);
            return ResponseEntity.ok(Map.of("count", count));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * 7. Lấy top xe được yêu thích nhiều nhất
     * GET /api/favorites/top
     * 
     * Response:
     * [
     *   {
     *     "carId": 5,
     *     "favoriteCount": 25
     *   },
     *   ...
     * ]
     */
    @GetMapping("/top")
    public ResponseEntity<List<Map<String, Object>>> getTopFavoritedCars() {
        try {
            List<Object[]> topCars = favoriteService.getMostFavoritedCars();
            
            List<Map<String, Object>> result = topCars.stream()
                    .map(row -> Map.of(
                        "carId", row[0],
                        "favoriteCount", row[1]
                    ))
                    .collect(java.util.stream.Collectors.toList());
            
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
