package com.carrentleproject.drivenow.dto;

import jakarta.validation.constraints.Size;

/**
 * Request DTO để cập nhật thông tin hợp đồng
 */
public class RentalContractUpdateRequest {

    @Size(max = 2000, message = "Tình trạng xe không được vượt quá 2000 ký tự")
    private String carCondition;

    @Size(max = 5000, message = "Điều khoản bổ sung không được vượt quá 5000 ký tự")
    private String additionalTerms;

    @Size(max = 1000, message = "Ghi chú không được vượt quá 1000 ký tự")
    private String notes;

    @Size(max = 500, message = "URL không được vượt quá 500 ký tự")
    private String contractFileUrl;

    // Constructors
    public RentalContractUpdateRequest() {
    }

    // Getters and Setters
    public String getCarCondition() {
        return carCondition;
    }

    public void setCarCondition(String carCondition) {
        this.carCondition = carCondition;
    }

    public String getAdditionalTerms() {
        return additionalTerms;
    }

    public void setAdditionalTerms(String additionalTerms) {
        this.additionalTerms = additionalTerms;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getContractFileUrl() {
        return contractFileUrl;
    }

    public void setContractFileUrl(String contractFileUrl) {
        this.contractFileUrl = contractFileUrl;
    }
}
