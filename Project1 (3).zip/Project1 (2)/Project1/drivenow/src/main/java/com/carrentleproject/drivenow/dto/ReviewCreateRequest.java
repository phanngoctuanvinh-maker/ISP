package com.carrentleproject.drivenow.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

/**
 * Request DTO để tạo review mới
 */
public class ReviewCreateRequest {

    @NotNull(message = "Booking ID là bắt buộc")
    private Integer bookingId;

    @NotNull(message = "Rating là bắt buộc")
    @Min(value = 1, message = "Rating tối thiểu là 1")
    @Max(value = 5, message = "Rating tối đa là 5")
    private Integer rating;

    @Size(max = 2000, message = "Comment không được vượt quá 2000 ký tự")
    private String comment;

    @Min(value = 1, message = "Cleanliness rating tối thiểu là 1")
    @Max(value = 5, message = "Cleanliness rating tối đa là 5")
    private Integer cleanlinessRating;

    @Min(value = 1, message = "Performance rating tối thiểu là 1")
    @Max(value = 5, message = "Performance rating tối đa là 5")
    private Integer performanceRating;

    @Min(value = 1, message = "Service rating tối thiểu là 1")
    @Max(value = 5, message = "Service rating tối đa là 5")
    private Integer serviceRating;

    // Constructors
    public ReviewCreateRequest() {
    }

    public ReviewCreateRequest(Integer bookingId, Integer rating, String comment) {
        this.bookingId = bookingId;
        this.rating = rating;
        this.comment = comment;
    }

    // Getters and Setters
    public Integer getBookingId() {
        return bookingId;
    }

    public void setBookingId(Integer bookingId) {
        this.bookingId = bookingId;
    }

    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Integer getCleanlinessRating() {
        return cleanlinessRating;
    }

    public void setCleanlinessRating(Integer cleanlinessRating) {
        this.cleanlinessRating = cleanlinessRating;
    }

    public Integer getPerformanceRating() {
        return performanceRating;
    }

    public void setPerformanceRating(Integer performanceRating) {
        this.performanceRating = performanceRating;
    }

    public Integer getServiceRating() {
        return serviceRating;
    }

    public void setServiceRating(Integer serviceRating) {
        this.serviceRating = serviceRating;
    }
}
