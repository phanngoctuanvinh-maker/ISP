package com.carrentleproject.drivenow.dao;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.carrentleproject.drivenow.model.DeliverySchedule;

@Repository
public interface DeliveryScheduleRepository extends JpaRepository<DeliverySchedule, Integer> {

    /**
     * Tìm lịch giao/nhận theo booking ID
     */
    List<DeliverySchedule> findByBooking_BookingIdOrderByScheduledTimeAsc(Integer bookingId);

    /**
     * Tìm lịch giao (pickup) của booking
     */
    Optional<DeliverySchedule> findByBooking_BookingIdAndScheduleType(Integer bookingId, String scheduleType);

    /**
     * Tìm tất cả lịch của tài xế
     */
    List<DeliverySchedule> findByDriver_DriverIdOrderByScheduledTimeAsc(Integer driverId);

    /**
     * Tìm lịch của tài xế theo status
     */
    List<DeliverySchedule> findByDriver_DriverIdAndStatusOrderByScheduledTimeAsc(Integer driverId, String status);

    /**
     * Tìm lịch theo status
     */
    List<DeliverySchedule> findByStatusOrderByScheduledTimeAsc(String status);

    /**
     * Tìm lịch theo schedule type (pickup/return)
     */
    List<DeliverySchedule> findByScheduleTypeOrderByScheduledTimeAsc(String scheduleType);

    /**
     * Tìm lịch trong khoảng thời gian
     */
    @Query("SELECT ds FROM DeliverySchedule ds WHERE ds.scheduledTime BETWEEN :startTime AND :endTime ORDER BY ds.scheduledTime ASC")
    List<DeliverySchedule> findByScheduledTimeBetween(@Param("startTime") LocalDateTime startTime, 
                                                       @Param("endTime") LocalDateTime endTime);

    /**
     * Tìm lịch của tài xế trong khoảng thời gian
     */
    @Query("SELECT ds FROM DeliverySchedule ds WHERE ds.driver.driverId = :driverId " +
           "AND ds.scheduledTime BETWEEN :startTime AND :endTime " +
           "ORDER BY ds.scheduledTime ASC")
    List<DeliverySchedule> findByDriverAndScheduledTimeBetween(@Param("driverId") Integer driverId,
                                                                @Param("startTime") LocalDateTime startTime,
                                                                @Param("endTime") LocalDateTime endTime);

    /**
     * Tìm lịch sắp đến (scheduled trong 24h tới)
     */
    @Query("SELECT ds FROM DeliverySchedule ds WHERE ds.status = 'scheduled' " +
           "AND ds.scheduledTime BETWEEN :now AND :tomorrow " +
           "ORDER BY ds.scheduledTime ASC")
    List<DeliverySchedule> findUpcomingSchedules(@Param("now") LocalDateTime now, 
                                                  @Param("tomorrow") LocalDateTime tomorrow);

    /**
     * Tìm lịch trễ hẹn (scheduled time đã qua nhưng status vẫn là scheduled)
     */
    @Query("SELECT ds FROM DeliverySchedule ds WHERE ds.status = 'scheduled' " +
           "AND ds.scheduledTime < :now " +
           "ORDER BY ds.scheduledTime ASC")
    List<DeliverySchedule> findOverdueSchedules(@Param("now") LocalDateTime now);

    /**
     * Đếm số lịch theo status
     */
    Long countByStatus(String status);

    /**
     * Đếm số lịch của tài xế theo status
     */
    Long countByDriver_DriverIdAndStatus(Integer driverId, String status);

    /**
     * Kiểm tra tài xế có lịch trong khoảng thời gian không (để tránh conflict)
     */
    @Query("SELECT COUNT(ds) > 0 FROM DeliverySchedule ds WHERE ds.driver.driverId = :driverId " +
           "AND ds.status IN ('scheduled', 'in_progress') " +
           "AND ds.scheduledTime BETWEEN :startTime AND :endTime")
    boolean hasConflictingSchedule(@Param("driverId") Integer driverId,
                                   @Param("startTime") LocalDateTime startTime,
                                   @Param("endTime") LocalDateTime endTime);
}
