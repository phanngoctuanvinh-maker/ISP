package com.carrentleproject.drivenow.controller;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.carrentleproject.drivenow.dto.BookingDTO;
import com.carrentleproject.drivenow.dto.BookingRescheduleRequest;
import com.carrentleproject.drivenow.service.BookingService;

import jakarta.validation.Valid;

/**
 * Controller quản lý booking cho Admin
 * Bao gồm: Xác nhận, từ chối, hủy, đổi lịch booking
 */
@RestController
@RequestMapping("/api/admin/bookings")
@CrossOrigin(origins = "*")
public class BookingManagementController {

    @Autowired
    private BookingService bookingService;

    /**
     * 1. Lấy danh sách tất cả bookings (cho admin)
     * GET /api/admin/bookings
     * 
     * Query params:
     * - status: Lọc theo trạng thái (optional)
     * - customerId: Lọc theo khách hàng (optional)
     * - carId: Lọc theo xe (optional)
     */
    @GetMapping
    public ResponseEntity<List<BookingDTO>> getAllBookings(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) Integer customerId,
            @RequestParam(required = false) Integer carId) {
        
        try {
            List<BookingDTO> bookings;
            
            if (status != null && customerId != null) {
                bookings = bookingService.getBookingsByCustomerAndStatus(customerId, status);
            } else if (customerId != null) {
                bookings = bookingService.getBookingsByCustomer(customerId);
            } else if (carId != null) {
                bookings = bookingService.getBookingsByCar(carId);
            } else if (status != null) {
                bookings = bookingService.getBookingsByStatus(status);
            } else {
                bookings = bookingService.getAllBookings();
            }
            
            return ResponseEntity.ok(bookings);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * 2. Lấy thống kê bookings
     * GET /api/admin/bookings/statistics
     * 
     * Response:
     * {
     *   "totalBookings": 100,
     *   "pendingCount": 10,
     *   "confirmedCount": 20,
     *   "ongoingCount": 5,
     *   "completedCount": 50,
     *   "cancelledCount": 10,
     *   "rejectedCount": 5
     * }
     */
    @GetMapping("/statistics")
    public ResponseEntity<Map<String, Long>> getBookingStatistics() {
        try {
            Long totalBookings = bookingService.countAllBookings();
            Long pendingCount = bookingService.countBookingsByStatus("pending");
            Long confirmedCount = bookingService.countBookingsByStatus("confirmed");
            Long ongoingCount = bookingService.countBookingsByStatus("ongoing");
            Long completedCount = bookingService.countBookingsByStatus("completed");
            Long cancelledCount = bookingService.countBookingsByStatus("cancelled");
            Long rejectedCount = bookingService.countBookingsByStatus("rejected");
            
            Map<String, Long> statistics = Map.of(
                "totalBookings", totalBookings,
                "pendingCount", pendingCount,
                "confirmedCount", confirmedCount,
                "ongoingCount", ongoingCount,
                "completedCount", completedCount,
                "cancelledCount", cancelledCount,
                "rejectedCount", rejectedCount
            );
            
            return ResponseEntity.ok(statistics);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * 3. [ADMIN] Xác nhận booking
     * PATCH /api/admin/bookings/{id}/confirm
     * 
     * Request body: none
     * 
     * Response: BookingDTO với status = "confirmed"
     * 
     * Note: Method này đã có trong BookingService
     */
    @PatchMapping("/{id}/confirm")
    public ResponseEntity<?> confirmBooking(@PathVariable Integer id) {
        try {
            BookingDTO booking = bookingService.confirmBooking(id);
            return ResponseEntity.ok(booking);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", e.getMessage()));
        } catch (IllegalStateException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Lỗi khi xác nhận booking: " + e.getMessage()));
        }
    }

    /**
     * 4. [ADMIN] Từ chối booking
     * PATCH /api/admin/bookings/{id}/reject
     * 
     * Request body:
     * {
     *   "rejectionReason": "Xe đang bảo trì"
     * }
     * 
     * Response: BookingDTO với status = "rejected"
     * 
     * Business rules:
     * - Chỉ có thể từ chối booking đang ở trạng thái "pending"
     * - Lý do từ chối là bắt buộc
     */
    @PatchMapping("/{id}/reject")
    public ResponseEntity<?> rejectBooking(
            @PathVariable Integer id,
            @RequestBody Map<String, String> request) {
        
        try {
            String rejectionReason = request.get("rejectionReason");
            
            if (rejectionReason == null || rejectionReason.trim().isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(Map.of("error", "Lý do từ chối là bắt buộc"));
            }
            
            BookingDTO booking = bookingService.rejectBooking(id, rejectionReason);
            return ResponseEntity.ok(booking);
            
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", e.getMessage()));
        } catch (IllegalStateException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Lỗi khi từ chối booking: " + e.getMessage()));
        }
    }

    /**
     * 5. [ADMIN] Hủy booking
     * PATCH /api/admin/bookings/{id}/cancel
     * 
     * Request body:
     * {
     *   "cancellationReason": "Khách hàng yêu cầu hủy"
     * }
     * 
     * Response: BookingDTO với status = "cancelled"
     * 
     * Note: Method này đã có trong BookingService
     */
    @PatchMapping("/{id}/cancel")
    public ResponseEntity<?> cancelBooking(
            @PathVariable Integer id,
            @RequestBody Map<String, String> request) {
        
        try {
            String cancellationReason = request.get("cancellationReason");
            
            if (cancellationReason == null || cancellationReason.trim().isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(Map.of("error", "Lý do hủy là bắt buộc"));
            }
            
            BookingDTO booking = bookingService.cancelBooking(id, cancellationReason);
            return ResponseEntity.ok(booking);
            
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", e.getMessage()));
        } catch (IllegalStateException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Lỗi khi hủy booking: " + e.getMessage()));
        }
    }

    /**
     * 6. [ADMIN] Đổi lịch booking
     * PATCH /api/admin/bookings/{id}/reschedule
     * 
     * Request body:
     * {
     *   "newPickupDate": "2024-02-01T10:00:00",
     *   "newReturnDate": "2024-02-05T10:00:00",
     *   "rescheduleReason": "Khách hàng yêu cầu đổi lịch"
     * }
     * 
     * Response: BookingDTO với ngày mới và giá mới
     * 
     * Business rules:
     * - Chỉ có thể đổi lịch booking đang ở trạng thái "pending" hoặc "confirmed"
     * - Ngày trả xe mới phải sau ngày nhận xe mới
     * - Xe phải khả dụng trong khoảng thời gian mới
     * - Tính toán lại tổng số ngày và tổng giá
     */
    @PatchMapping("/{id}/reschedule")
    public ResponseEntity<?> rescheduleBooking(
            @PathVariable Integer id,
            @Valid @RequestBody BookingRescheduleRequest request) {
        
        try {
            BookingDTO booking = bookingService.rescheduleBooking(
                id, 
                request.getNewPickupDate(), 
                request.getNewReturnDate(), 
                request.getRescheduleReason()
            );
            return ResponseEntity.ok(booking);
            
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", e.getMessage()));
        } catch (IllegalStateException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Lỗi khi đổi lịch booking: " + e.getMessage()));
        }
    }

    /**
     * 7. [ADMIN] Lấy các booking sắp diễn ra (trong 7 ngày tới)
     * GET /api/admin/bookings/upcoming
     * 
     * Response: Danh sách BookingDTO có pickupDate trong 7 ngày tới
     */
    @GetMapping("/upcoming")
    public ResponseEntity<List<BookingDTO>> getUpcomingBookings() {
        try {
            // Get all confirmed or pending bookings
            List<BookingDTO> allBookings = bookingService.getAllBookings();
            
            LocalDateTime now = LocalDateTime.now();
            LocalDateTime sevenDaysLater = now.plusDays(7);
            
            // Filter bookings with pickup date in next 7 days
            List<BookingDTO> upcomingBookings = allBookings.stream()
                    .filter(b -> ("confirmed".equals(b.getStatus()) || "pending".equals(b.getStatus())))
                    .filter(b -> b.getPickupDate().isAfter(now) && b.getPickupDate().isBefore(sevenDaysLater))
                    .sorted((b1, b2) -> b1.getPickupDate().compareTo(b2.getPickupDate()))
                    .toList();
            
            return ResponseEntity.ok(upcomingBookings);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * 8. [ADMIN] Lấy các booking đang diễn ra
     * GET /api/admin/bookings/ongoing
     * 
     * Response: Danh sách BookingDTO có status = "ongoing"
     */
    @GetMapping("/ongoing")
    public ResponseEntity<List<BookingDTO>> getOngoingBookings() {
        try {
            List<BookingDTO> ongoingBookings = bookingService.getOngoingBookings();
            return ResponseEntity.ok(ongoingBookings);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
