package com.carrentleproject.drivenow.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

/**
 * Request DTO để tạo group booking mới
 */
public class GroupBookingCreateRequest {

    @NotNull(message = "Customer ID là bắt buộc")
    private Integer customerId;

    @Size(max = 200, message = "Tên nhóm không được vượt quá 200 ký tự")
    private String groupName; // Optional: "Tour Đà Lạt", "Đám cưới"

    @NotNull(message = "Ngày nhận xe là bắt buộc")
    @Future(message = "Ngày nhận xe phải là thời gian tương lai")
    private LocalDateTime pickupDate;

    @NotNull(message = "Ngày trả xe là bắt buộc")
    @Future(message = "Ngày trả xe phải là thời gian tương lai")
    private LocalDateTime returnDate;

    @NotNull(message = "Địa điểm nhận xe là bắt buộc")
    @Size(min = 5, max = 255, message = "Địa điểm nhận xe phải từ 5-255 ký tự")
    private String pickupLocation;

    @Size(max = 255, message = "Địa điểm trả xe không được vượt quá 255 ký tự")
    private String returnLocation;

    @NotEmpty(message = "Danh sách xe không được rỗng")
    @Size(min = 2, message = "Group booking phải có ít nhất 2 xe")
    private List<Integer> carIds; // Danh sách ID các xe muốn thuê

    private String paymentMethod; // cash, credit_card, bank_transfer

    @Size(max = 1000, message = "Ghi chú không được vượt quá 1000 ký tự")
    private String notes;

    @Min(value = 0, message = "Discount percentage phải >= 0")
    private BigDecimal discountPercentage; // Optional: Admin có thể set

    // Constructors
    public GroupBookingCreateRequest() {
    }

    // Getters and Setters
    public Integer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public LocalDateTime getPickupDate() {
        return pickupDate;
    }

    public void setPickupDate(LocalDateTime pickupDate) {
        this.pickupDate = pickupDate;
    }

    public LocalDateTime getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(LocalDateTime returnDate) {
        this.returnDate = returnDate;
    }

    public String getPickupLocation() {
        return pickupLocation;
    }

    public void setPickupLocation(String pickupLocation) {
        this.pickupLocation = pickupLocation;
    }

    public String getReturnLocation() {
        return returnLocation;
    }

    public void setReturnLocation(String returnLocation) {
        this.returnLocation = returnLocation;
    }

    public List<Integer> getCarIds() {
        return carIds;
    }

    public void setCarIds(List<Integer> carIds) {
        this.carIds = carIds;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public BigDecimal getDiscountPercentage() {
        return discountPercentage;
    }

    public void setDiscountPercentage(BigDecimal discountPercentage) {
        this.discountPercentage = discountPercentage;
    }
}
