package com.carrentleproject.drivenow.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.carrentleproject.drivenow.model.Car;
import com.carrentleproject.drivenow.model.CarImage;

@Repository
public interface CarImageRepository extends JpaRepository<CarImage, Integer> {

    // Tìm tất cả hình ảnh của một xe
    List<CarImage> findByCar(Car car);

    // Tìm hình ảnh theo car_id
    List<CarImage> findByCarCarId(Integer carId);

    // Tìm hình ảnh theo type (main, gallery, interior, exterior)
    List<CarImage> findByType(String type);

    // Tìm hình ảnh main của một xe
    List<CarImage> findByCarCarIdAndType(Integer carId, String type);

    // Xóa tất cả hình ảnh của một xe
    void deleteByCar(Car car);

    // Xóa hình ảnh theo car_id
    void deleteByCarCarId(Integer carId);
}
