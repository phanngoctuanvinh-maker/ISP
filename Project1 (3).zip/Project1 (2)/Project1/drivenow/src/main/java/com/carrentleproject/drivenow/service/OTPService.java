package com.carrentleproject.drivenow.service;

import java.time.LocalDateTime;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.carrentleproject.drivenow.dao.OTPDAO;
import com.carrentleproject.drivenow.exception.BadRequestException;
import com.carrentleproject.drivenow.model.OTP;

import jakarta.transaction.Transactional;

@Service
public class OTPService {

    @Autowired
    private OTPDAO otpDAO;

    @Value("${otp.expiration}")
    private long otpExpirationMs;

    @Transactional
    public void generateAndSendOTP(String email) {
        // Xóa các OTP cũ đã hết hạn
        cleanupExpiredOTPs(email);

        // Tạo mã OTP 6 số
        String otpCode = String.format("%06d", new Random().nextInt(1000000));

        // Tính thời gian hết hạn (5 phút)
        LocalDateTime expirationTime = LocalDateTime.now().plusNanos(otpExpirationMs * 1_000_000);

        // Lưu OTP vào database
        OTP otp = new OTP();
        otp.setEmail(email);
        otp.setOtpCode(otpCode);
        otp.setExpirationTime(expirationTime);
        otp.setIsUsed(false);
        otpDAO.save(otp);

        // Gửi email (comment tạm để test)
        // emailService.sendOTPEmail(email, otpCode);
        System.out.println("=== OTP FOR TESTING ===");
        System.out.println("Email: " + email);
        System.out.println("OTP Code: " + otpCode);
        System.out.println("=======================");
    }

    public boolean verifyOTP(String email, String otpCode) {
        return otpDAO.findByEmailAndOtpCodeAndIsUsedFalseAndExpirationTimeAfter(
                email, otpCode, LocalDateTime.now()).isPresent();
    }

    @Transactional
    public void markOTPAsUsed(String email, String otpCode) {
        OTP otp = otpDAO.findByEmailAndOtpCodeAndIsUsedFalseAndExpirationTimeAfter(
                email, otpCode, LocalDateTime.now())
                .orElseThrow(() -> new BadRequestException("OTP không hợp lệ hoặc đã hết hạn"));

        otp.setIsUsed(true);
        otpDAO.save(otp);
    }

    private void cleanupExpiredOTPs(String email) {
        otpDAO.deleteByEmailAndExpirationTimeBefore(email, LocalDateTime.now());
    }
}
