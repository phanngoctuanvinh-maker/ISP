package com.carrentleproject.drivenow.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.carrentleproject.drivenow.model.Review;

@Repository
public interface ReviewRepository extends JpaRepository<Review, Integer> {

    /**
     * Tìm review theo booking ID
     */
    Optional<Review> findByBooking_BookingId(Integer bookingId);

    /**
     * Tìm tất cả reviews của khách hàng
     */
    List<Review> findByCustomer_CustomerIdOrderByCreatedAtDesc(Integer customerId);

    /**
     * Tìm tất cả reviews của xe
     */
    List<Review> findByCar_CarIdOrderByCreatedAtDesc(Integer carId);

    /**
     * Tìm reviews đã được xác minh
     */
    List<Review> findByIsVerifiedOrderByCreatedAtDesc(Boolean isVerified);

    /**
     * Tìm reviews theo rating
     */
    List<Review> findByRatingOrderByCreatedAtDesc(Integer rating);

    /**
     * Kiểm tra khách hàng đã review booking này chưa
     */
    boolean existsByBooking_BookingId(Integer bookingId);

    /**
     * Tính điểm trung bình của xe
     */
    @Query("SELECT AVG(r.rating) FROM Review r WHERE r.car.carId = :carId AND r.isVerified = true")
    Double calculateAverageRatingByCar(@Param("carId") Integer carId);

    /**
     * Đếm số lượng reviews của xe
     */
    Long countByCar_CarId(Integer carId);

    /**
     * Đếm số lượng reviews theo rating của xe
     */
    @Query("SELECT COUNT(r) FROM Review r WHERE r.car.carId = :carId AND r.rating = :rating")
    Long countByCarAndRating(@Param("carId") Integer carId, @Param("rating") Integer rating);

    /**
     * Lấy top xe có rating cao nhất
     */
    @Query("SELECT r.car.carId, AVG(r.rating) as avgRating " +
           "FROM Review r WHERE r.isVerified = true " +
           "GROUP BY r.car.carId " +
           "ORDER BY avgRating DESC")
    List<Object[]> findTopRatedCars();
}
