package com.carrentleproject.drivenow.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.carrentleproject.drivenow.dao.CarRepository;
import com.carrentleproject.drivenow.dao.CustomerDAO;
import com.carrentleproject.drivenow.dao.FavoriteRepository;
import com.carrentleproject.drivenow.dto.FavoriteDTO;
import com.carrentleproject.drivenow.model.Car;
import com.carrentleproject.drivenow.model.Customer;
import com.carrentleproject.drivenow.model.Favorite;

@Service
public class FavoriteService {

    @Autowired
    private FavoriteRepository favoriteRepository;

    @Autowired
    private CarRepository carRepository;

    @Autowired
    private CustomerDAO customerDAO;

    /**
     * Thêm xe vào danh sách yêu thích
     */
    @Transactional
    public FavoriteDTO addFavorite(Integer customerId, Integer carId) {
        // 1. Kiểm tra customer tồn tại
        Customer customer = customerDAO.findById(customerId)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy khách hàng với ID: " + customerId));

        // 2. Kiểm tra car tồn tại
        Car car = carRepository.findById(carId)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy xe với ID: " + carId));

        // 3. Kiểm tra đã yêu thích chưa
        if (favoriteRepository.existsByCustomer_CustomerIdAndCar_CarId(customerId, carId)) {
            throw new IllegalStateException("Xe này đã có trong danh sách yêu thích");
        }

        // 4. Tạo favorite mới
        Favorite favorite = new Favorite(customer, car);
        Favorite savedFavorite = favoriteRepository.save(favorite);

        return convertToDTO(savedFavorite);
    }

    /**
     * Xóa xe khỏi danh sách yêu thích
     */
    @Transactional
    public void removeFavorite(Integer customerId, Integer carId) {
        // Kiểm tra favorite tồn tại
        if (!favoriteRepository.existsByCustomer_CustomerIdAndCar_CarId(customerId, carId)) {
            throw new IllegalArgumentException("Xe này không có trong danh sách yêu thích");
        }

        favoriteRepository.deleteByCustomer_CustomerIdAndCar_CarId(customerId, carId);
    }

    /**
     * Lấy danh sách xe yêu thích của khách hàng
     */
    public List<FavoriteDTO> getFavoritesByCustomer(Integer customerId) {
        return favoriteRepository.findByCustomer_CustomerIdOrderByCreatedAtDesc(customerId).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Kiểm tra xe đã được yêu thích chưa
     */
    public boolean isFavorite(Integer customerId, Integer carId) {
        return favoriteRepository.existsByCustomer_CustomerIdAndCar_CarId(customerId, carId);
    }

    /**
     * Đếm số lượng xe yêu thích của khách hàng
     */
    public Long countFavorites(Integer customerId) {
        return favoriteRepository.countByCustomer_CustomerId(customerId);
    }

    /**
     * Đếm số lượng khách hàng yêu thích xe này
     */
    public Long countFavoritesByCar(Integer carId) {
        return favoriteRepository.countByCar_CarId(carId);
    }

    /**
     * Lấy top xe được yêu thích nhiều nhất
     */
    public List<Object[]> getMostFavoritedCars() {
        return favoriteRepository.findMostFavoritedCars();
    }

    /**
     * Convert Favorite entity to DTO
     */
    private FavoriteDTO convertToDTO(Favorite favorite) {
        FavoriteDTO dto = new FavoriteDTO();
        dto.setFavoriteId(favorite.getFavoriteId());
        dto.setCustomerId(favorite.getCustomer().getCustomerId());
        dto.setCarId(favorite.getCar().getCarId());
        dto.setCarBrand(favorite.getCar().getBrand());
        dto.setCarModel(favorite.getCar().getModel());
        dto.setSeats(favorite.getCar().getSeats());
        dto.setFuelType(favorite.getCar().getFuelType());
        dto.setLicensePlate(favorite.getCar().getLicensePlate());
        dto.setImageUrl(favorite.getCar().getImageUrl());
        dto.setLocation(favorite.getCar().getLocation());
        dto.setPricePerDay(favorite.getCar().getPricePerDay());
        dto.setStatus(favorite.getCar().getStatus());
        dto.setCreatedAt(favorite.getCreatedAt());
        return dto;
    }
}
