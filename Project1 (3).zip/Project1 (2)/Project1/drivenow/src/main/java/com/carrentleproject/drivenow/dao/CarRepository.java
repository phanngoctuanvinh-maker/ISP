package com.carrentleproject.drivenow.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.carrentleproject.drivenow.model.Car;

@Repository
public interface CarRepository extends JpaRepository<Car, Integer> {

    // Tìm xe theo status
    List<Car> findByStatus(String status);

    // Tìm xe theo brand
    List<Car> findByBrand(String brand);

    // Tìm xe theo location
    List<Car> findByLocation(String location);

    // Tìm xe theo license plate
    Optional<Car> findByLicensePlate(String licensePlate);

    // Tìm xe theo brand và model
    List<Car> findByBrandAndModel(String brand, String model);

    // Tìm xe có số chỗ ngồi >= số chỉ định
    List<Car> findBySeatsGreaterThanEqual(Integer seats);

    // Tìm xe available trong location
    @Query("SELECT c FROM Car c WHERE c.status = 'available' AND c.location = :location")
    List<Car> findAvailableCarsByLocation(@Param("location") String location);

    // Tìm xe theo nhiều tiêu chí (custom query)
    @Query("SELECT c FROM Car c WHERE " +
            "(:brand IS NULL OR c.brand = :brand) AND " +
            "(:model IS NULL OR c.model = :model) AND " +
            "(:seats IS NULL OR c.seats >= :seats) AND " +
            "(:status IS NULL OR c.status = :status) AND " +
            "(:location IS NULL OR c.location = :location)")
    List<Car> searchCars(
            @Param("brand") String brand,
            @Param("model") String model,
            @Param("seats") Integer seats,
            @Param("status") String status,
            @Param("location") String location
    );

    // Đếm số xe theo status
    Long countByStatus(String status);
}
