package com.carrentleproject.drivenow.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.carrentleproject.drivenow.dao.BookingRepository;
import com.carrentleproject.drivenow.dao.DeliveryScheduleRepository;
import com.carrentleproject.drivenow.dao.DriverRepository;
import com.carrentleproject.drivenow.dto.DeliveryScheduleCreateRequest;
import com.carrentleproject.drivenow.dto.DeliveryScheduleDTO;
import com.carrentleproject.drivenow.dto.DeliveryScheduleUpdateRequest;
import com.carrentleproject.drivenow.exception.ResourceNotFoundException;
import com.carrentleproject.drivenow.model.Booking;
import com.carrentleproject.drivenow.model.DeliverySchedule;
import com.carrentleproject.drivenow.model.Driver;

@Service
public class DeliveryScheduleService {

    @Autowired
    private DeliveryScheduleRepository scheduleRepository;

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private DriverRepository driverRepository;

    /**
     * Tạo lịch giao/nhận xe mới
     */
    @Transactional
    public DeliveryScheduleDTO createSchedule(DeliveryScheduleCreateRequest request) {
        // Validate booking exists
        Booking booking = bookingRepository.findById(request.getBookingId())
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy booking với ID: " + request.getBookingId()));

        // Validate booking status
        if (!"confirmed".equalsIgnoreCase(booking.getStatus()) && !"pending".equalsIgnoreCase(booking.getStatus())) {
            throw new IllegalArgumentException("Chỉ có thể tạo lịch giao/nhận cho booking đã xác nhận hoặc đang pending");
        }

        // Check if schedule already exists for this booking and type
        scheduleRepository.findByBooking_BookingIdAndScheduleType(request.getBookingId(), request.getScheduleType())
                .ifPresent(s -> {
                    throw new IllegalArgumentException("Lịch " + request.getScheduleType() + " đã tồn tại cho booking này");
                });

        // Validate driver if provided
        Driver driver = null;
        if (request.getDriverId() != null) {
            driver = driverRepository.findById(request.getDriverId())
                    .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy tài xế với ID: " + request.getDriverId()));

            // Check driver availability (no conflicting schedules)
            boolean hasConflict = scheduleRepository.hasConflictingSchedule(
                    request.getDriverId(), 
                    request.getScheduledTime().minusHours(2), 
                    request.getScheduledTime().plusHours(2)
            );
            
            if (hasConflict) {
                throw new IllegalArgumentException("Tài xế đã có lịch trong khoảng thời gian này");
            }
        }

        // Validate scheduled time based on schedule type
        if ("pickup".equals(request.getScheduleType())) {
            if (request.getScheduledTime().isAfter(booking.getPickupDate())) {
                throw new IllegalArgumentException("Thời gian giao xe phải trước hoặc bằng thời gian pickup trong booking");
            }
        } else if ("return".equals(request.getScheduleType())) {
            if (request.getScheduledTime().isBefore(booking.getReturnDate())) {
                throw new IllegalArgumentException("Thời gian nhận xe phải sau hoặc bằng thời gian return trong booking");
            }
        }

        // Create schedule
        DeliverySchedule schedule = new DeliverySchedule();
        schedule.setBooking(booking);
        schedule.setDriver(driver);
        schedule.setScheduleType(request.getScheduleType());
        schedule.setScheduledTime(request.getScheduledTime());
        schedule.setLocation(request.getLocation());
        schedule.setDeliveryMethod(request.getDeliveryMethod());
        schedule.setContactPerson(request.getContactPerson());
        schedule.setContactPhone(request.getContactPhone());
        schedule.setNotes(request.getNotes());
        schedule.setStatus("scheduled");
        schedule.setCreatedAt(LocalDateTime.now());
        schedule.setUpdatedAt(LocalDateTime.now());

        schedule = scheduleRepository.save(schedule);

        return convertToDTO(schedule);
    }

    /**
     * Lấy chi tiết lịch theo ID
     */
    public DeliveryScheduleDTO getScheduleById(Integer scheduleId) {
        DeliverySchedule schedule = scheduleRepository.findById(scheduleId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy lịch với ID: " + scheduleId));
        return convertToDTO(schedule);
    }

    /**
     * Lấy tất cả lịch của booking
     */
    public List<DeliveryScheduleDTO> getSchedulesByBooking(Integer bookingId) {
        List<DeliverySchedule> schedules = scheduleRepository.findByBooking_BookingIdOrderByScheduledTimeAsc(bookingId);
        return schedules.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    /**
     * Lấy tất cả lịch của tài xế
     */
    public List<DeliveryScheduleDTO> getSchedulesByDriver(Integer driverId) {
        List<DeliverySchedule> schedules = scheduleRepository.findByDriver_DriverIdOrderByScheduledTimeAsc(driverId);
        return schedules.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    /**
     * Lấy lịch của tài xế theo status
     */
    public List<DeliveryScheduleDTO> getSchedulesByDriverAndStatus(Integer driverId, String status) {
        List<DeliverySchedule> schedules = scheduleRepository.findByDriver_DriverIdAndStatusOrderByScheduledTimeAsc(driverId, status);
        return schedules.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    /**
     * Lấy lịch theo status
     */
    public List<DeliveryScheduleDTO> getSchedulesByStatus(String status) {
        List<DeliverySchedule> schedules = scheduleRepository.findByStatusOrderByScheduledTimeAsc(status);
        return schedules.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    /**
     * Lấy lịch sắp đến (scheduled trong 24h tới)
     */
    public List<DeliveryScheduleDTO> getUpcomingSchedules() {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime tomorrow = now.plusHours(24);
        List<DeliverySchedule> schedules = scheduleRepository.findUpcomingSchedules(now, tomorrow);
        return schedules.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    /**
     * Lấy lịch trễ hẹn
     */
    public List<DeliveryScheduleDTO> getOverdueSchedules() {
        List<DeliverySchedule> schedules = scheduleRepository.findOverdueSchedules(LocalDateTime.now());
        return schedules.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    /**
     * Assign tài xế cho lịch
     */
    @Transactional
    public DeliveryScheduleDTO assignDriver(Integer scheduleId, Integer driverId) {
        DeliverySchedule schedule = scheduleRepository.findById(scheduleId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy lịch với ID: " + scheduleId));

        if (!"scheduled".equalsIgnoreCase(schedule.getStatus())) {
            throw new IllegalArgumentException("Chỉ có thể assign tài xế cho lịch đang scheduled");
        }

        Driver driver = driverRepository.findById(driverId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy tài xế với ID: " + driverId));

        // Check driver availability
        boolean hasConflict = scheduleRepository.hasConflictingSchedule(
                driverId, 
                schedule.getScheduledTime().minusHours(2), 
                schedule.getScheduledTime().plusHours(2)
        );
        
        if (hasConflict) {
            throw new IllegalArgumentException("Tài xế đã có lịch trong khoảng thời gian này");
        }

        schedule.setDriver(driver);
        schedule.setUpdatedAt(LocalDateTime.now());
        schedule = scheduleRepository.save(schedule);

        return convertToDTO(schedule);
    }

    /**
     * Bắt đầu giao/nhận xe (scheduled → in_progress)
     */
    @Transactional
    public DeliveryScheduleDTO startDelivery(Integer scheduleId) {
        DeliverySchedule schedule = scheduleRepository.findById(scheduleId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy lịch với ID: " + scheduleId));

        if (!"scheduled".equalsIgnoreCase(schedule.getStatus())) {
            throw new IllegalArgumentException("Chỉ có thể bắt đầu lịch đang scheduled");
        }

        schedule.setStatus("in_progress");
        schedule.setUpdatedAt(LocalDateTime.now());
        schedule = scheduleRepository.save(schedule);

        return convertToDTO(schedule);
    }

    /**
     * Hoàn thành giao/nhận xe (in_progress → completed)
     */
    @Transactional
    public DeliveryScheduleDTO completeDelivery(Integer scheduleId, DeliveryScheduleUpdateRequest request) {
        DeliverySchedule schedule = scheduleRepository.findById(scheduleId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy lịch với ID: " + scheduleId));

        if (!"in_progress".equalsIgnoreCase(schedule.getStatus()) && !"scheduled".equalsIgnoreCase(schedule.getStatus())) {
            throw new IllegalArgumentException("Chỉ có thể hoàn thành lịch đang in_progress hoặc scheduled");
        }

        // Set actual time
        LocalDateTime actualTime = request.getActualTime() != null ? request.getActualTime() : LocalDateTime.now();
        schedule.setActualTime(actualTime);

        // Check if delayed
        if (actualTime.isAfter(schedule.getScheduledTime().plusMinutes(15))) {
            schedule.setStatus("delayed");
            if (request.getDelayReason() != null) {
                schedule.setDelayReason(request.getDelayReason());
            }
        } else {
            schedule.setStatus("completed");
        }

        // Update vehicle condition info
        if ("pickup".equals(schedule.getScheduleType())) {
            // Giao xe
            if (request.getFuelLevel() != null) {
                schedule.setFuelLevelBefore(request.getFuelLevel());
            }
            if (request.getMileage() != null) {
                schedule.setMileageBefore(request.getMileage());
            }
            if (request.getCarCondition() != null) {
                schedule.setCarConditionBefore(request.getCarCondition());
            }
            if (request.getImageUrl() != null) {
                schedule.setImageUrlBefore(request.getImageUrl());
            }
        } else if ("return".equals(schedule.getScheduleType())) {
            // Nhận xe
            if (request.getFuelLevel() != null) {
                schedule.setFuelLevelAfter(request.getFuelLevel());
            }
            if (request.getMileage() != null) {
                schedule.setMileageAfter(request.getMileage());
            }
            if (request.getCarCondition() != null) {
                schedule.setCarConditionAfter(request.getCarCondition());
            }
            if (request.getImageUrl() != null) {
                schedule.setImageUrlAfter(request.getImageUrl());
            }
        }

        if (request.getNotes() != null) {
            schedule.setNotes(request.getNotes());
        }

        schedule.setUpdatedAt(LocalDateTime.now());
        schedule = scheduleRepository.save(schedule);

        return convertToDTO(schedule);
    }

    /**
     * Hủy lịch giao/nhận
     */
    @Transactional
    public DeliveryScheduleDTO cancelSchedule(Integer scheduleId, String cancellationReason) {
        DeliverySchedule schedule = scheduleRepository.findById(scheduleId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy lịch với ID: " + scheduleId));

        if ("completed".equalsIgnoreCase(schedule.getStatus()) || "cancelled".equalsIgnoreCase(schedule.getStatus())) {
            throw new IllegalArgumentException("Không thể hủy lịch đã hoàn thành hoặc đã hủy");
        }

        schedule.setStatus("cancelled");
        schedule.setCancellationReason(cancellationReason);
        schedule.setUpdatedAt(LocalDateTime.now());
        schedule = scheduleRepository.save(schedule);

        return convertToDTO(schedule);
    }

    /**
     * Đổi lịch (reschedule)
     */
    @Transactional
    public DeliveryScheduleDTO rescheduleDelivery(Integer scheduleId, LocalDateTime newScheduledTime) {
        DeliverySchedule schedule = scheduleRepository.findById(scheduleId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy lịch với ID: " + scheduleId));

        if (!"scheduled".equalsIgnoreCase(schedule.getStatus())) {
            throw new IllegalArgumentException("Chỉ có thể đổi lịch đang scheduled");
        }

        if (newScheduledTime.isBefore(LocalDateTime.now())) {
            throw new IllegalArgumentException("Thời gian mới phải là thời gian tương lai");
        }

        // Check driver availability if driver is assigned
        if (schedule.getDriver() != null) {
            boolean hasConflict = scheduleRepository.hasConflictingSchedule(
                    schedule.getDriver().getDriverId(), 
                    newScheduledTime.minusHours(2), 
                    newScheduledTime.plusHours(2)
            );
            
            if (hasConflict) {
                throw new IllegalArgumentException("Tài xế đã có lịch trong khoảng thời gian mới");
            }
        }

        schedule.setScheduledTime(newScheduledTime);
        schedule.setUpdatedAt(LocalDateTime.now());
        schedule = scheduleRepository.save(schedule);

        return convertToDTO(schedule);
    }

    /**
     * Convert entity to DTO
     */
    private DeliveryScheduleDTO convertToDTO(DeliverySchedule schedule) {
        DeliveryScheduleDTO dto = new DeliveryScheduleDTO();
        dto.setScheduleId(schedule.getScheduleId());
        dto.setBookingId(schedule.getBooking().getBookingId());
        dto.setScheduleType(schedule.getScheduleType());
        dto.setScheduledTime(schedule.getScheduledTime());
        dto.setActualTime(schedule.getActualTime());
        dto.setLocation(schedule.getLocation());
        dto.setStatus(schedule.getStatus());
        dto.setNotes(schedule.getNotes());
        dto.setDeliveryMethod(schedule.getDeliveryMethod());
        dto.setContactPerson(schedule.getContactPerson());
        dto.setContactPhone(schedule.getContactPhone());
        dto.setFuelLevelBefore(schedule.getFuelLevelBefore());
        dto.setFuelLevelAfter(schedule.getFuelLevelAfter());
        dto.setMileageBefore(schedule.getMileageBefore());
        dto.setMileageAfter(schedule.getMileageAfter());
        dto.setCarConditionBefore(schedule.getCarConditionBefore());
        dto.setCarConditionAfter(schedule.getCarConditionAfter());
        dto.setImageUrlBefore(schedule.getImageUrlBefore());
        dto.setImageUrlAfter(schedule.getImageUrlAfter());
        dto.setDelayReason(schedule.getDelayReason());
        dto.setCancellationReason(schedule.getCancellationReason());
        dto.setCreatedAt(schedule.getCreatedAt());
        dto.setUpdatedAt(schedule.getUpdatedAt());

        // Driver info
        if (schedule.getDriver() != null) {
            dto.setDriverId(schedule.getDriver().getDriverId());
            // Driver không có fullName/phone trực tiếp, lấy từ account nếu cần
            if (schedule.getDriver().getAccount() != null) {
                dto.setDriverName(schedule.getDriver().getAccount().getUsername());
            }
            // Phone có thể lấy từ address hoặc để null
            dto.setDriverPhone(null); // Driver model không có phone field
        }

        // Car info from booking
        if (schedule.getBooking().getCar() != null) {
            dto.setCarId(schedule.getBooking().getCar().getCarId());
            dto.setCarBrand(schedule.getBooking().getCar().getBrand());
            dto.setCarModel(schedule.getBooking().getCar().getModel());
            dto.setLicensePlate(schedule.getBooking().getCar().getLicensePlate());
        }

        // Customer info from booking
        if (schedule.getBooking().getCustomer() != null) {
            dto.setCustomerId(schedule.getBooking().getCustomer().getCustomerId());
            dto.setCustomerName(schedule.getBooking().getCustomer().getFullName());
            dto.setCustomerPhone(schedule.getBooking().getCustomer().getPhone());
        }

        return dto;
    }
}
