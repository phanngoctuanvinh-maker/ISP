package com.carrentleproject.drivenow.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.carrentleproject.drivenow.dto.GroupBookingCreateRequest;
import com.carrentleproject.drivenow.dto.GroupBookingDTO;
import com.carrentleproject.drivenow.service.GroupBookingService;

import jakarta.validation.Valid;

/**
 * Controller cho Group Booking APIs
 * Cho phép khách hàng thuê nhiều xe cùng lúc với giảm giá theo nhóm
 */
@RestController
@RequestMapping("/api/group-bookings")
@Validated
public class GroupBookingController {

    @Autowired
    private GroupBookingService groupBookingService;

    /**
     * API 1: Tạo group booking mới (thuê nhiều xe cùng lúc)
     * POST /api/group-bookings
     * 
     * Auto discount:
     * - 2 xe: 0% discount
     * - 3-4 xe: 5% discount  
     * - 5+ xe: 10% discount
     * 
     * Request body:
     * {
     *   "customerId": 1,
     *   "groupName": "Tour Đà Lạt",
     *   "pickupDate": "2024-01-15T08:00:00",
     *   "returnDate": "2024-01-18T18:00:00",
     *   "pickupLocation": "123 Nguyễn Văn Linh, TP HCM",
     *   "returnLocation": "123 Nguyễn Văn Linh, TP HCM",
     *   "carIds": [1, 3, 5, 7],
     *   "paymentMethod": "bank_transfer",
     *   "notes": "Tour du lịch công ty"
     * }
     */
    @PostMapping
    public ResponseEntity<?> createGroupBooking(@Valid @RequestBody GroupBookingCreateRequest request) {
        try {
            GroupBookingDTO groupBooking = groupBookingService.createGroupBooking(request);
            return ResponseEntity.status(HttpStatus.CREATED).body(groupBooking);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Lỗi khi tạo group booking: " + e.getMessage());
        }
    }

    /**
     * API 2: Lấy chi tiết group booking theo ID
     * GET /api/group-bookings/{id}
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getGroupBookingById(@PathVariable("id") Integer groupBookingId) {
        try {
            GroupBookingDTO groupBooking = groupBookingService.getGroupBookingById(groupBookingId);
            return ResponseEntity.ok(groupBooking);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    /**
     * API 3: Lấy tất cả group bookings của khách hàng
     * GET /api/group-bookings/customer/{customerId}
     */
    @GetMapping("/customer/{customerId}")
    public ResponseEntity<?> getCustomerGroupBookings(@PathVariable Integer customerId) {
        try {
            List<GroupBookingDTO> groupBookings = groupBookingService.getCustomerGroupBookings(customerId);
            return ResponseEntity.ok(groupBookings);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Lỗi khi lấy danh sách group bookings: " + e.getMessage());
        }
    }

    /**
     * API 4: Lấy group bookings theo status
     * GET /api/group-bookings/status?status=pending
     * 
     * Status options: pending, confirmed, in_progress, completed, cancelled
     */
    @GetMapping("/status")
    public ResponseEntity<?> getGroupBookingsByStatus(@RequestParam String status) {
        try {
            List<GroupBookingDTO> groupBookings = groupBookingService.getGroupBookingsByStatus(status);
            return ResponseEntity.ok(groupBookings);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Lỗi khi lấy danh sách group bookings: " + e.getMessage());
        }
    }

    /**
     * API 5: Hủy group booking (hủy tất cả bookings trong nhóm)
     * PATCH /api/group-bookings/{id}/cancel
     * 
     * Request body:
     * {
     *   "cancellationReason": "Khách hủy tour"
     * }
     */
    @PatchMapping("/{id}/cancel")
    public ResponseEntity<?> cancelGroupBooking(
            @PathVariable("id") Integer groupBookingId,
            @RequestParam String cancellationReason) {
        try {
            GroupBookingDTO groupBooking = groupBookingService.cancelGroupBooking(groupBookingId, cancellationReason);
            return ResponseEntity.ok(groupBooking);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Lỗi khi hủy group booking: " + e.getMessage());
        }
    }

    /**
     * API 6: Xác nhận group booking (Admin)
     * PATCH /api/group-bookings/{id}/confirm
     */
    @PatchMapping("/{id}/confirm")
    public ResponseEntity<?> confirmGroupBooking(@PathVariable("id") Integer groupBookingId) {
        try {
            GroupBookingDTO groupBooking = groupBookingService.confirmGroupBooking(groupBookingId);
            return ResponseEntity.ok(groupBooking);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Lỗi khi xác nhận group booking: " + e.getMessage());
        }
    }

    /**
     * API 7: Cập nhật payment status (Admin)
     * PATCH /api/group-bookings/{id}/payment-status
     * 
     * Request param: paymentStatus (paid, unpaid, partial)
     */
    @PatchMapping("/{id}/payment-status")
    public ResponseEntity<?> updatePaymentStatus(
            @PathVariable("id") Integer groupBookingId,
            @RequestParam String paymentStatus) {
        try {
            GroupBookingDTO groupBooking = groupBookingService.updatePaymentStatus(groupBookingId, paymentStatus);
            return ResponseEntity.ok(groupBooking);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Lỗi khi cập nhật payment status: " + e.getMessage());
        }
    }
}
