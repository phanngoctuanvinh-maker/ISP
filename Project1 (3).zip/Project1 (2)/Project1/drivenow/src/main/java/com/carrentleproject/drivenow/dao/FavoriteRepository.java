package com.carrentleproject.drivenow.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.carrentleproject.drivenow.model.Favorite;

@Repository
public interface FavoriteRepository extends JpaRepository<Favorite, Integer> {

    /**
     * Tìm tất cả xe yêu thích của khách hàng
     */
    List<Favorite> findByCustomer_CustomerIdOrderByCreatedAtDesc(Integer customerId);

    /**
     * Tìm favorite theo customer và car
     */
    Optional<Favorite> findByCustomer_CustomerIdAndCar_CarId(Integer customerId, Integer carId);

    /**
     * Kiểm tra xe đã được yêu thích chưa
     */
    boolean existsByCustomer_CustomerIdAndCar_CarId(Integer customerId, Integer carId);

    /**
     * Xóa favorite theo customer và car
     */
    void deleteByCustomer_CustomerIdAndCar_CarId(Integer customerId, Integer carId);

    /**
     * Đếm số lượng xe yêu thích của khách hàng
     */
    Long countByCustomer_CustomerId(Integer customerId);

    /**
     * Đếm số lượng khách hàng yêu thích xe này
     */
    Long countByCar_CarId(Integer carId);

    /**
     * Lấy top xe được yêu thích nhiều nhất
     */
    @Query("SELECT f.car.carId, COUNT(f) as favoriteCount " +
           "FROM Favorite f " +
           "GROUP BY f.car.carId " +
           "ORDER BY favoriteCount DESC")
    List<Object[]> findMostFavoritedCars();

    /**
     * Lấy danh sách customer yêu thích xe này
     */
    List<Favorite> findByCar_CarIdOrderByCreatedAtDesc(Integer carId);
}
