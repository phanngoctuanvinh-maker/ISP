package com.carrentleproject.drivenow.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;

@Entity
@Table(name = "bookings")
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "booking_id")
    private Integer bookingId;

    @ManyToOne
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;

    @ManyToOne
    @JoinColumn(name = "car_id", nullable = false)
    private Car car;

    @ManyToOne
    @JoinColumn(name = "driver_id")
    private Driver driver;

    @ManyToOne
    @JoinColumn(name = "group_booking_id")
    private GroupBooking groupBooking; // Thuộc về group booking nào (nullable)

    @Column(name = "pickup_date", nullable = false)
    private LocalDateTime pickupDate;

    @Column(name = "return_date", nullable = false)
    private LocalDateTime returnDate;

    @Column(name = "pickup_location", length = 255, nullable = false)
    private String pickupLocation;

    @Column(name = "return_location", length = 255)
    private String returnLocation;

    @Column(name = "total_days", nullable = false)
    private Integer totalDays;

    @Column(name = "total_price", precision = 10, scale = 2, nullable = false)
    private BigDecimal totalPrice;

    @Column(name = "status", length = 20, nullable = false)
    private String status = "pending"; // pending, confirmed, ongoing, completed, cancelled

    @Column(name = "payment_status", length = 20)
    private String paymentStatus = "unpaid"; // unpaid, paid, refunded

    @Column(name = "payment_method", length = 50)
    private String paymentMethod;

    @Column(name = "notes", columnDefinition = "TEXT")
    private String notes;

    @Column(name = "cancellation_reason", columnDefinition = "TEXT")
    private String cancellationReason;

    // ============================================================
    // [EXTENSION FEATURE] - Tính năng gia hạn booking
    // Phần này dùng để khách hàng gia hạn thêm thời gian thuê xe
    // API: PATCH /api/bookings/{id}/extend
    // ============================================================
    
    @Column(name = "original_return_date")
    private LocalDateTime originalReturnDate; // Ngày trả ban đầu (trước khi gia hạn)

    @Column(name = "extension_days")
    private Integer extensionDays = 0; // Số ngày đã gia hạn thêm

    @Column(name = "extension_price", precision = 10, scale = 2)
    private BigDecimal extensionPrice = BigDecimal.ZERO; // Tiền phụ thu do gia hạn

    @Column(name = "is_extended")
    private Boolean isExtended = false; // Đã gia hạn hay chưa
    
    // ============================================================
    // [END EXTENSION FEATURE]
    // ============================================================

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    // Constructors
    public Booking() {
    }

    public Booking(Customer customer, Car car, LocalDateTime pickupDate, LocalDateTime returnDate,
                   String pickupLocation, String returnLocation, Integer totalDays, BigDecimal totalPrice) {
        this.customer = customer;
        this.car = car;
        this.pickupDate = pickupDate;
        this.returnDate = returnDate;
        this.pickupLocation = pickupLocation;
        this.returnLocation = returnLocation;
        this.totalDays = totalDays;
        this.totalPrice = totalPrice;
    }

    // Getters and Setters
    public Integer getBookingId() {
        return bookingId;
    }

    public void setBookingId(Integer bookingId) {
        this.bookingId = bookingId;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
    }

    public Driver getDriver() {
        return driver;
    }

    public void setDriver(Driver driver) {
        this.driver = driver;
    }

    public GroupBooking getGroupBooking() {
        return groupBooking;
    }

    public void setGroupBooking(GroupBooking groupBooking) {
        this.groupBooking = groupBooking;
    }

    public LocalDateTime getPickupDate() {
        return pickupDate;
    }

    public void setPickupDate(LocalDateTime pickupDate) {
        this.pickupDate = pickupDate;
    }

    public LocalDateTime getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(LocalDateTime returnDate) {
        this.returnDate = returnDate;
    }

    public String getPickupLocation() {
        return pickupLocation;
    }

    public void setPickupLocation(String pickupLocation) {
        this.pickupLocation = pickupLocation;
    }

    public String getReturnLocation() {
        return returnLocation;
    }

    public void setReturnLocation(String returnLocation) {
        this.returnLocation = returnLocation;
    }

    public Integer getTotalDays() {
        return totalDays;
    }

    public void setTotalDays(Integer totalDays) {
        this.totalDays = totalDays;
    }

    public BigDecimal getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(BigDecimal totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getCancellationReason() {
        return cancellationReason;
    }

    public void setCancellationReason(String cancellationReason) {
        this.cancellationReason = cancellationReason;
    }

    // ============================================================
    // [EXTENSION FEATURE] - Getters/Setters cho tính năng gia hạn
    // ============================================================

    public LocalDateTime getOriginalReturnDate() {
        return originalReturnDate;
    }

    public void setOriginalReturnDate(LocalDateTime originalReturnDate) {
        this.originalReturnDate = originalReturnDate;
    }

    public Integer getExtensionDays() {
        return extensionDays;
    }

    public void setExtensionDays(Integer extensionDays) {
        this.extensionDays = extensionDays;
    }

    public BigDecimal getExtensionPrice() {
        return extensionPrice;
    }

    public void setExtensionPrice(BigDecimal extensionPrice) {
        this.extensionPrice = extensionPrice;
    }

    public Boolean getIsExtended() {
        return isExtended;
    }

    public void setIsExtended(Boolean isExtended) {
        this.isExtended = isExtended;
    }
    
    // ============================================================
    // [END EXTENSION FEATURE]
    // ============================================================

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
}
