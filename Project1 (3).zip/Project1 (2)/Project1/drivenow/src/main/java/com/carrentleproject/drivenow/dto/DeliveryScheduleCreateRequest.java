package com.carrentleproject.drivenow.dto;

import java.time.LocalDateTime;

import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/**
 * Request DTO để tạo lịch giao/nhận xe
 */
public class DeliveryScheduleCreateRequest {

    @NotNull(message = "Booking ID là bắt buộc")
    private Integer bookingId;

    private Integer driverId; // Optional: có thể assign sau

    @NotNull(message = "Loại lịch là bắt buộc")
    @Pattern(regexp = "pickup|return", message = "Schedule type phải là 'pickup' hoặc 'return'")
    private String scheduleType; // pickup, return

    @NotNull(message = "Thời gian dự kiến là bắt buộc")
    @Future(message = "Thời gian dự kiến phải là thời gian tương lai")
    private LocalDateTime scheduledTime;

    @NotNull(message = "Địa điểm là bắt buộc")
    @Size(min = 10, max = 255, message = "Địa điểm phải từ 10-255 ký tự")
    private String location;

    @Pattern(regexp = "self_pickup|home_delivery", message = "Delivery method phải là 'self_pickup' hoặc 'home_delivery'")
    private String deliveryMethod; // self_pickup, home_delivery

    @Size(max = 100, message = "Tên người liên hệ không được vượt quá 100 ký tự")
    private String contactPerson;

    @Size(max = 20, message = "SĐT liên hệ không được vượt quá 20 ký tự")
    private String contactPhone;

    @Size(max = 1000, message = "Ghi chú không được vượt quá 1000 ký tự")
    private String notes;

    // Constructors
    public DeliveryScheduleCreateRequest() {
    }

    // Getters and Setters
    public Integer getBookingId() {
        return bookingId;
    }

    public void setBookingId(Integer bookingId) {
        this.bookingId = bookingId;
    }

    public Integer getDriverId() {
        return driverId;
    }

    public void setDriverId(Integer driverId) {
        this.driverId = driverId;
    }

    public String getScheduleType() {
        return scheduleType;
    }

    public void setScheduleType(String scheduleType) {
        this.scheduleType = scheduleType;
    }

    public LocalDateTime getScheduledTime() {
        return scheduledTime;
    }

    public void setScheduledTime(LocalDateTime scheduledTime) {
        this.scheduledTime = scheduledTime;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDeliveryMethod() {
        return deliveryMethod;
    }

    public void setDeliveryMethod(String deliveryMethod) {
        this.deliveryMethod = deliveryMethod;
    }

    public String getContactPerson() {
        return contactPerson;
    }

    public void setContactPerson(String contactPerson) {
        this.contactPerson = contactPerson;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }
}
