package com.carrentleproject.drivenow.dao;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.carrentleproject.drivenow.model.Booking;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Integer> {

    /**
     * Tìm tất cả bookings của khách hàng
     */
    List<Booking> findByCustomer_CustomerId(Integer customerId);

    /**
     * Tìm tất cả bookings của xe
     */
    List<Booking> findByCar_CarId(Integer carId);

    /**
     * Tìm bookings theo trạng thái
     */
    List<Booking> findByStatus(String status);

    /**
     * Tìm bookings của khách hàng theo trạng thái
     */
    List<Booking> findByCustomer_CustomerIdAndStatus(Integer customerId, String status);

    /**
     * Tìm bookings của driver
     */
    List<Booking> findByDriver_DriverId(Integer driverId);

    /**
     * Kiểm tra xe có khả dụng trong khoảng thời gian không
     * (Không có booking nào đang pending, confirmed, hoặc ongoing trùng thời gian)
     */
    @Query("SELECT CASE WHEN COUNT(b) > 0 THEN false ELSE true END " +
           "FROM Booking b WHERE b.car.carId = :carId " +
           "AND b.status IN ('pending', 'confirmed', 'ongoing') " +
           "AND ((b.pickupDate <= :returnDate AND b.returnDate >= :pickupDate))")
    boolean isCarAvailable(@Param("carId") Integer carId,
                          @Param("pickupDate") LocalDateTime pickupDate,
                          @Param("returnDate") LocalDateTime returnDate);

    /**
     * Tìm các booking đang diễn ra (ongoing)
     */
    @Query("SELECT b FROM Booking b WHERE b.status = 'ongoing' " +
           "AND b.pickupDate <= :now AND b.returnDate >= :now")
    List<Booking> findOngoingBookings(@Param("now") LocalDateTime now);

    /**
     * Tìm các booking sắp tới của khách hàng
     */
    @Query("SELECT b FROM Booking b WHERE b.customer.customerId = :customerId " +
           "AND b.pickupDate > :now AND b.status IN ('pending', 'confirmed') " +
           "ORDER BY b.pickupDate ASC")
    List<Booking> findUpcomingBookingsByCustomer(@Param("customerId") Integer customerId,
                                                   @Param("now") LocalDateTime now);

    /**
     * Tìm lịch sử booking của khách hàng (completed hoặc cancelled)
     */
    @Query("SELECT b FROM Booking b WHERE b.customer.customerId = :customerId " +
           "AND b.status IN ('completed', 'cancelled') " +
           "ORDER BY b.createdAt DESC")
    List<Booking> findBookingHistoryByCustomer(@Param("customerId") Integer customerId);

    /**
     * Tìm booking theo payment status
     */
    List<Booking> findByPaymentStatus(String paymentStatus);

    /**
     * Đếm số lượng booking theo trạng thái
     */
    Long countByStatus(String status);

    /**
     * Tìm các booking trùng lịch với xe và khoảng thời gian cho trước
     * (Dùng cho reschedule để check conflicts)
     */
    @Query("SELECT b FROM Booking b WHERE b.car.carId = :carId " +
           "AND b.status IN ('pending', 'confirmed', 'ongoing') " +
           "AND ((b.pickupDate <= :returnDate AND b.returnDate >= :pickupDate))")
    List<Booking> findConflictingBookings(@Param("carId") Integer carId,
                                          @Param("pickupDate") LocalDateTime pickupDate,
                                          @Param("returnDate") LocalDateTime returnDate);
}
