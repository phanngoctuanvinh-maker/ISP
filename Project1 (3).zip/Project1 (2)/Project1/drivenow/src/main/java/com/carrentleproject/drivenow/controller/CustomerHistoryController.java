package com.carrentleproject.drivenow.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.carrentleproject.drivenow.dto.BookingDTO;
import com.carrentleproject.drivenow.dto.CarRatingDTO;
import com.carrentleproject.drivenow.dto.ReviewCreateRequest;
import com.carrentleproject.drivenow.dto.ReviewDTO;
import com.carrentleproject.drivenow.service.BookingService;
import com.carrentleproject.drivenow.service.ReviewService;

import jakarta.validation.Valid;

/**
 * Controller cho lịch sử đặt xe & đánh giá (Customer)
 * Base URL: /api/customer/history
 */
@RestController
@RequestMapping("/api/customer/history")
@CrossOrigin(origins = "*")
public class CustomerHistoryController {

    @Autowired
    private BookingService bookingService;

    @Autowired
    private ReviewService reviewService;

    /**
     * 1. Lấy lịch sử booking của khách hàng
     * GET /api/customer/history/bookings/{customerId}
     * 
     * Response: Danh sách BookingDTO (completed và cancelled)
     */
    @GetMapping("/bookings/{customerId}")
    public ResponseEntity<List<BookingDTO>> getBookingHistory(@PathVariable Integer customerId) {
        try {
            List<BookingDTO> history = bookingService.getBookingHistoryByCustomer(customerId);
            return ResponseEntity.ok(history);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * 2. Lấy tất cả bookings của khách hàng (bao gồm cả upcoming)
     * GET /api/customer/history/all-bookings/{customerId}
     * 
     * Response: Danh sách tất cả BookingDTO
     */
    @GetMapping("/all-bookings/{customerId}")
    public ResponseEntity<List<BookingDTO>> getAllBookings(@PathVariable Integer customerId) {
        try {
            List<BookingDTO> bookings = bookingService.getBookingsByCustomer(customerId);
            return ResponseEntity.ok(bookings);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * 3. Tạo review sau khi hoàn thành chuyến
     * POST /api/customer/history/reviews
     * 
     * Request body:
     * {
     *   "bookingId": 1,
     *   "rating": 5,
     *   "comment": "Xe rất đẹp và sạch sẽ",
     *   "cleanlinessRating": 5,
     *   "performanceRating": 5,
     *   "serviceRating": 5
     * }
     */
    @PostMapping("/reviews")
    public ResponseEntity<?> createReview(
            @RequestParam Integer customerId,
            @Valid @RequestBody ReviewCreateRequest request) {
        
        try {
            ReviewDTO review = reviewService.createReview(customerId, request);
            return ResponseEntity.status(HttpStatus.CREATED).body(review);
            
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", e.getMessage()));
        } catch (IllegalStateException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Lỗi khi tạo review: " + e.getMessage()));
        }
    }

    /**
     * 4. Lấy tất cả reviews của khách hàng
     * GET /api/customer/history/reviews/{customerId}
     * 
     * Response: Danh sách ReviewDTO
     */
    @GetMapping("/reviews/{customerId}")
    public ResponseEntity<List<ReviewDTO>> getCustomerReviews(@PathVariable Integer customerId) {
        try {
            List<ReviewDTO> reviews = reviewService.getReviewsByCustomer(customerId);
            return ResponseEntity.ok(reviews);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * 5. Kiểm tra đã review booking chưa
     * GET /api/customer/history/reviews/check/{bookingId}
     * 
     * Response:
     * {
     *   "hasReviewed": true
     * }
     */
    @GetMapping("/reviews/check/{bookingId}")
    public ResponseEntity<Map<String, Boolean>> checkReview(@PathVariable Integer bookingId) {
        try {
            boolean hasReviewed = reviewService.hasReviewed(bookingId);
            return ResponseEntity.ok(Map.of("hasReviewed", hasReviewed));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * 6. Lấy review của booking
     * GET /api/customer/history/reviews/booking/{bookingId}
     * 
     * Response: ReviewDTO
     */
    @GetMapping("/reviews/booking/{bookingId}")
    public ResponseEntity<?> getReviewByBooking(@PathVariable Integer bookingId) {
        try {
            ReviewDTO review = reviewService.getReviewByBooking(bookingId);
            return ResponseEntity.ok(review);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Lỗi khi lấy review: " + e.getMessage()));
        }
    }

    /**
     * 7. Lấy thống kê rating của xe
     * GET /api/customer/history/cars/{carId}/rating
     * 
     * Response: CarRatingDTO với average rating và distribution
     */
    @GetMapping("/cars/{carId}/rating")
    public ResponseEntity<?> getCarRating(@PathVariable Integer carId) {
        try {
            CarRatingDTO rating = reviewService.getCarRating(carId);
            return ResponseEntity.ok(rating);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Lỗi khi lấy rating: " + e.getMessage()));
        }
    }

    /**
     * 8. Lấy tất cả reviews của xe
     * GET /api/customer/history/cars/{carId}/reviews
     * 
     * Response: Danh sách ReviewDTO
     */
    @GetMapping("/cars/{carId}/reviews")
    public ResponseEntity<List<ReviewDTO>> getCarReviews(@PathVariable Integer carId) {
        try {
            List<ReviewDTO> reviews = reviewService.getReviewsByCar(carId);
            return ResponseEntity.ok(reviews);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
