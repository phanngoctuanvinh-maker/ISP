package com.carrentleproject.drivenow.dto;

import java.time.LocalDateTime;

public class CarImageDTO {
    private Integer carImageId;
    private Integer carId;
    private String type;
    private String url;
    private String description;
    private LocalDateTime createdAt;

    // Constructors
    public CarImageDTO() {
    }

    public CarImageDTO(Integer carImageId, Integer carId, String type, String url, 
            String description, LocalDateTime createdAt) {
        this.carImageId = carImageId;
        this.carId = carId;
        this.type = type;
        this.url = url;
        this.description = description;
        this.createdAt = createdAt;
    }

    // Getters and Setters
    public Integer getCarImageId() {
        return carImageId;
    }

    public void setCarImageId(Integer carImageId) {
        this.carImageId = carImageId;
    }

    public Integer getCarId() {
        return carId;
    }

    public void setCarId(Integer carId) {
        this.carId = carId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
