package com.carrentleproject.drivenow.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * DTO cho Rental Contract
 */
public class RentalContractDTO {

    private Integer contractId;
    private Integer bookingId;
    private String contractNumber;
    private LocalDateTime contractDate;
    private LocalDateTime startDate;
    private LocalDateTime endDate;
    private BigDecimal totalAmount;
    private BigDecimal depositAmount;
    private BigDecimal insuranceAmount;
    private String status; // draft, active, completed, cancelled, expired

    // Lessor (Bên cho thuê)
    private String lessorName;
    private String lessorAddress;
    private String lessorPhone;
    private String lessorEmail;
    private String lessorTaxCode;
    private String lessorRepresentative;

    // Lessee (Bên thuê)
    private String lesseeName;
    private String lesseeIdCard;
    private String lesseePhone;
    private String lesseeEmail;
    private String lesseeAddress;
    private LocalDateTime lesseeDateOfBirth;
    private String lesseeLicenseNumber;
    private LocalDateTime lesseeLicenseExpiry;

    // Car info
    private String carInfo; // JSON string
    private String carCondition;

    // Terms
    private String termsAndConditions;
    private String additionalTerms;

    // Signatures
    private String lessorSignatureUrl;
    private String lesseeSignatureUrl;
    private LocalDateTime lessorSignedAt;
    private LocalDateTime lesseeSignedAt;

    // Files
    private String contractFileUrl;
    private String contractTemplate;

    // Metadata
    private String notes;
    private String cancellationReason;
    private LocalDateTime expiryDate;
    private Boolean isSigned;
    private Boolean isArchived;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    // Constructors
    public RentalContractDTO() {
    }

    // Getters and Setters
    public Integer getContractId() {
        return contractId;
    }

    public void setContractId(Integer contractId) {
        this.contractId = contractId;
    }

    public Integer getBookingId() {
        return bookingId;
    }

    public void setBookingId(Integer bookingId) {
        this.bookingId = bookingId;
    }

    public String getContractNumber() {
        return contractNumber;
    }

    public void setContractNumber(String contractNumber) {
        this.contractNumber = contractNumber;
    }

    public LocalDateTime getContractDate() {
        return contractDate;
    }

    public void setContractDate(LocalDateTime contractDate) {
        this.contractDate = contractDate;
    }

    public LocalDateTime getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDateTime startDate) {
        this.startDate = startDate;
    }

    public LocalDateTime getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDateTime endDate) {
        this.endDate = endDate;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public BigDecimal getDepositAmount() {
        return depositAmount;
    }

    public void setDepositAmount(BigDecimal depositAmount) {
        this.depositAmount = depositAmount;
    }

    public BigDecimal getInsuranceAmount() {
        return insuranceAmount;
    }

    public void setInsuranceAmount(BigDecimal insuranceAmount) {
        this.insuranceAmount = insuranceAmount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getLessorName() {
        return lessorName;
    }

    public void setLessorName(String lessorName) {
        this.lessorName = lessorName;
    }

    public String getLessorAddress() {
        return lessorAddress;
    }

    public void setLessorAddress(String lessorAddress) {
        this.lessorAddress = lessorAddress;
    }

    public String getLessorPhone() {
        return lessorPhone;
    }

    public void setLessorPhone(String lessorPhone) {
        this.lessorPhone = lessorPhone;
    }

    public String getLessorEmail() {
        return lessorEmail;
    }

    public void setLessorEmail(String lessorEmail) {
        this.lessorEmail = lessorEmail;
    }

    public String getLessorTaxCode() {
        return lessorTaxCode;
    }

    public void setLessorTaxCode(String lessorTaxCode) {
        this.lessorTaxCode = lessorTaxCode;
    }

    public String getLessorRepresentative() {
        return lessorRepresentative;
    }

    public void setLessorRepresentative(String lessorRepresentative) {
        this.lessorRepresentative = lessorRepresentative;
    }

    public String getLesseeName() {
        return lesseeName;
    }

    public void setLesseeName(String lesseeName) {
        this.lesseeName = lesseeName;
    }

    public String getLesseeIdCard() {
        return lesseeIdCard;
    }

    public void setLesseeIdCard(String lesseeIdCard) {
        this.lesseeIdCard = lesseeIdCard;
    }

    public String getLesseePhone() {
        return lesseePhone;
    }

    public void setLesseePhone(String lesseePhone) {
        this.lesseePhone = lesseePhone;
    }

    public String getLesseeEmail() {
        return lesseeEmail;
    }

    public void setLesseeEmail(String lesseeEmail) {
        this.lesseeEmail = lesseeEmail;
    }

    public String getLesseeAddress() {
        return lesseeAddress;
    }

    public void setLesseeAddress(String lesseeAddress) {
        this.lesseeAddress = lesseeAddress;
    }

    public LocalDateTime getLesseeDateOfBirth() {
        return lesseeDateOfBirth;
    }

    public void setLesseeDateOfBirth(LocalDateTime lesseeDateOfBirth) {
        this.lesseeDateOfBirth = lesseeDateOfBirth;
    }

    public String getLesseeLicenseNumber() {
        return lesseeLicenseNumber;
    }

    public void setLesseeLicenseNumber(String lesseeLicenseNumber) {
        this.lesseeLicenseNumber = lesseeLicenseNumber;
    }

    public LocalDateTime getLesseeLicenseExpiry() {
        return lesseeLicenseExpiry;
    }

    public void setLesseeLicenseExpiry(LocalDateTime lesseeLicenseExpiry) {
        this.lesseeLicenseExpiry = lesseeLicenseExpiry;
    }

    public String getCarInfo() {
        return carInfo;
    }

    public void setCarInfo(String carInfo) {
        this.carInfo = carInfo;
    }

    public String getCarCondition() {
        return carCondition;
    }

    public void setCarCondition(String carCondition) {
        this.carCondition = carCondition;
    }

    public String getTermsAndConditions() {
        return termsAndConditions;
    }

    public void setTermsAndConditions(String termsAndConditions) {
        this.termsAndConditions = termsAndConditions;
    }

    public String getAdditionalTerms() {
        return additionalTerms;
    }

    public void setAdditionalTerms(String additionalTerms) {
        this.additionalTerms = additionalTerms;
    }

    public String getLessorSignatureUrl() {
        return lessorSignatureUrl;
    }

    public void setLessorSignatureUrl(String lessorSignatureUrl) {
        this.lessorSignatureUrl = lessorSignatureUrl;
    }

    public String getLesseeSignatureUrl() {
        return lesseeSignatureUrl;
    }

    public void setLesseeSignatureUrl(String lesseeSignatureUrl) {
        this.lesseeSignatureUrl = lesseeSignatureUrl;
    }

    public LocalDateTime getLessorSignedAt() {
        return lessorSignedAt;
    }

    public void setLessorSignedAt(LocalDateTime lessorSignedAt) {
        this.lessorSignedAt = lessorSignedAt;
    }

    public LocalDateTime getLesseeSignedAt() {
        return lesseeSignedAt;
    }

    public void setLesseeSignedAt(LocalDateTime lesseeSignedAt) {
        this.lesseeSignedAt = lesseeSignedAt;
    }

    public String getContractFileUrl() {
        return contractFileUrl;
    }

    public void setContractFileUrl(String contractFileUrl) {
        this.contractFileUrl = contractFileUrl;
    }

    public String getContractTemplate() {
        return contractTemplate;
    }

    public void setContractTemplate(String contractTemplate) {
        this.contractTemplate = contractTemplate;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getCancellationReason() {
        return cancellationReason;
    }

    public void setCancellationReason(String cancellationReason) {
        this.cancellationReason = cancellationReason;
    }

    public LocalDateTime getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(LocalDateTime expiryDate) {
        this.expiryDate = expiryDate;
    }

    public Boolean getIsSigned() {
        return isSigned;
    }

    public void setIsSigned(Boolean isSigned) {
        this.isSigned = isSigned;
    }

    public Boolean getIsArchived() {
        return isArchived;
    }

    public void setIsArchived(Boolean isArchived) {
        this.isArchived = isArchived;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
}
