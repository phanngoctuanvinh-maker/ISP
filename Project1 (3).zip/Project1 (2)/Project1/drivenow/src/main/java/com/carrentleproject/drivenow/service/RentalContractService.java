package com.carrentleproject.drivenow.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.carrentleproject.drivenow.dao.BookingRepository;
import com.carrentleproject.drivenow.dao.RentalContractRepository;
import com.carrentleproject.drivenow.dto.RentalContractCreateRequest;
import com.carrentleproject.drivenow.dto.RentalContractDTO;
import com.carrentleproject.drivenow.dto.RentalContractUpdateRequest;
import com.carrentleproject.drivenow.dto.SignatureRequest;
import com.carrentleproject.drivenow.exception.ResourceNotFoundException;
import com.carrentleproject.drivenow.model.Booking;
import com.carrentleproject.drivenow.model.Car;
import com.carrentleproject.drivenow.model.Customer;
import com.carrentleproject.drivenow.model.RentalContract;

@Service
public class RentalContractService {

    @Autowired
    private RentalContractRepository contractRepository;

    @Autowired
    private BookingRepository bookingRepository;

    /**
     * Tạo hợp đồng cho booking
     */
    @Transactional
    public RentalContractDTO createContract(RentalContractCreateRequest request) {
        // Tìm booking
        Booking booking = bookingRepository.findById(request.getBookingId())
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy booking"));

        // Kiểm tra booking đã có hợp đồng chưa
        if (contractRepository.existsByBooking_BookingId(booking.getBookingId())) {
            throw new IllegalArgumentException("Booking này đã có hợp đồng");
        }

        // Kiểm tra booking status
        if (!"confirmed".equals(booking.getStatus()) && !"paid".equals(booking.getStatus())) {
            throw new IllegalArgumentException("Chỉ có thể tạo hợp đồng cho booking đã xác nhận hoặc đã thanh toán");
        }

        // Generate contract number
        String contractNumber = generateContractNumber();

        // Tạo contract mới
        RentalContract contract = new RentalContract();
        contract.setBooking(booking);
        contract.setContractNumber(contractNumber);
        contract.setContractDate(LocalDateTime.now());
        contract.setStartDate(booking.getPickupDate());
        contract.setEndDate(booking.getReturnDate());
        contract.setTotalAmount(booking.getTotalPrice());
        contract.setDepositAmount(request.getDepositAmount() != null ? request.getDepositAmount() : BigDecimal.ZERO);
        contract.setInsuranceAmount(request.getInsuranceAmount() != null ? request.getInsuranceAmount() : BigDecimal.ZERO);
        contract.setStatus("draft");
        contract.setContractTemplate(request.getContractTemplate() != null ? request.getContractTemplate() : "standard");

        // Set lessor info (default or from request)
        contract.setLessorName(request.getLessorName() != null ? request.getLessorName() : "CÔNG TY TNHH DRIVENOW");
        contract.setLessorAddress(request.getLessorAddress() != null ? request.getLessorAddress() : "123 Nguyễn Huệ, Q.1, TP.HCM");
        contract.setLessorPhone(request.getLessorPhone() != null ? request.getLessorPhone() : "0901234567");
        contract.setLessorEmail(request.getLessorEmail() != null ? request.getLessorEmail() : "contact@drivenow.vn");
        contract.setLessorTaxCode(request.getLessorTaxCode() != null ? request.getLessorTaxCode() : "0123456789");
        contract.setLessorRepresentative(request.getLessorRepresentative() != null ? request.getLessorRepresentative() : "Nguyễn Văn A");

        // Set lessee info from customer
        Customer customer = booking.getCustomer();
        contract.setLesseeName(customer.getFullName());
        contract.setLesseePhone(customer.getPhone());
        contract.setLesseeEmail(customer.getEmail());
        contract.setLesseeAddress(customer.getAddress());
        contract.setLesseeIdCard(request.getLesseeIdCard());
        contract.setLesseeDateOfBirth(request.getLesseeDateOfBirth());
        contract.setLesseeLicenseNumber(request.getLesseeLicenseNumber());
        contract.setLesseeLicenseExpiry(request.getLesseeLicenseExpiry());

        // Set car info (JSON format)
        Car car = booking.getCar();
        int seats = Objects.requireNonNullElse(car.getSeats(), 0);
        String carInfoJson = String.format(
            "{\"brand\":\"%s\",\"model\":\"%s\",\"licensePlate\":\"%s\",\"fuelType\":\"%s\",\"seats\":%d,\"location\":\"%s\"}",
            car.getBrand(), car.getModel(), car.getLicensePlate(), 
            car.getFuelType() != null ? car.getFuelType() : "", 
            seats,
            car.getLocation() != null ? car.getLocation() : ""
        );
        contract.setCarInfo(carInfoJson);
        contract.setCarCondition(request.getCarCondition());

        // Set default terms and conditions
        contract.setTermsAndConditions(getDefaultTermsAndConditions());
        contract.setAdditionalTerms(request.getAdditionalTerms());
        contract.setNotes(request.getNotes());

        // Set expiry date (30 days after end date)
        contract.setExpiryDate(booking.getReturnDate().plusDays(30));

        contract.setIsSigned(false);
        contract.setIsArchived(false);

        // Save contract
        RentalContract savedContract = contractRepository.save(contract);

        return convertToDTO(savedContract);
    }

    /**
     * Lấy thông tin hợp đồng theo ID
     */
    public RentalContractDTO getContractById(Integer contractId) {
        RentalContract contract = contractRepository.findById(contractId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy hợp đồng"));
        return convertToDTO(contract);
    }

    /**
     * Lấy hợp đồng theo contract number
     */
    public RentalContractDTO getContractByNumber(String contractNumber) {
        RentalContract contract = contractRepository.findByContractNumber(contractNumber)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy hợp đồng"));
        return convertToDTO(contract);
    }

    /**
     * Lấy hợp đồng theo booking ID
     */
    public RentalContractDTO getContractByBookingId(Integer bookingId) {
        RentalContract contract = contractRepository.findByBooking_BookingId(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy hợp đồng cho booking này"));
        return convertToDTO(contract);
    }

    /**
     * Lấy danh sách hợp đồng của customer
     */
    public List<RentalContractDTO> getContractsByCustomerId(Integer customerId) {
        List<RentalContract> contracts = contractRepository.findByCustomerId(customerId);
        return contracts.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Lấy danh sách hợp đồng theo status
     */
    public List<RentalContractDTO> getContractsByStatus(String status) {
        List<RentalContract> contracts = contractRepository.findByStatusOrderByCreatedAtDesc(status);
        return contracts.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Lấy danh sách hợp đồng đang hoạt động
     */
    public List<RentalContractDTO> getActiveContracts() {
        List<RentalContract> contracts = contractRepository.findActiveContracts(LocalDateTime.now());
        return contracts.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Lấy danh sách hợp đồng sắp hết hạn (7 ngày)
     */
    public List<RentalContractDTO> getExpiringContracts() {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime oneWeekLater = now.plusDays(7);
        List<RentalContract> contracts = contractRepository.findExpiringContracts(now, oneWeekLater);
        return contracts.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Cập nhật thông tin hợp đồng
     */
    @Transactional
    public RentalContractDTO updateContract(Integer contractId, RentalContractUpdateRequest request) {
        RentalContract contract = contractRepository.findById(contractId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy hợp đồng"));

        // Chỉ cho phép cập nhật nếu status là draft hoặc active
        if (!"draft".equals(contract.getStatus()) && !"active".equals(contract.getStatus())) {
            throw new IllegalArgumentException("Không thể cập nhật hợp đồng đã hoàn thành hoặc đã hủy");
        }

        // Update fields
        if (request.getCarCondition() != null) {
            contract.setCarCondition(request.getCarCondition());
        }
        if (request.getAdditionalTerms() != null) {
            contract.setAdditionalTerms(request.getAdditionalTerms());
        }
        if (request.getNotes() != null) {
            contract.setNotes(request.getNotes());
        }
        if (request.getContractFileUrl() != null) {
            contract.setContractFileUrl(request.getContractFileUrl());
        }

        RentalContract updatedContract = contractRepository.save(contract);
        return convertToDTO(updatedContract);
    }

    /**
     * Lessor ký hợp đồng
     */
    @Transactional
    public RentalContractDTO signByLessor(Integer contractId, SignatureRequest request) {
        RentalContract contract = contractRepository.findById(contractId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy hợp đồng"));

        if (!"draft".equals(contract.getStatus()) && !"active".equals(contract.getStatus())) {
            throw new IllegalArgumentException("Không thể ký hợp đồng đã hoàn thành hoặc đã hủy");
        }

        contract.setLessorSignatureUrl(request.getSignatureUrl());
        contract.setLessorSignedAt(LocalDateTime.now());

        // Kiểm tra nếu cả 2 bên đã ký -> status = active
        if (contract.getLesseeSignedAt() != null) {
            contract.setStatus("active");
            contract.setIsSigned(true);
        }

        RentalContract updatedContract = contractRepository.save(contract);
        return convertToDTO(updatedContract);
    }

    /**
     * Lessee ký hợp đồng
     */
    @Transactional
    public RentalContractDTO signByLessee(Integer contractId, SignatureRequest request) {
        RentalContract contract = contractRepository.findById(contractId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy hợp đồng"));

        if (!"draft".equals(contract.getStatus()) && !"active".equals(contract.getStatus())) {
            throw new IllegalArgumentException("Không thể ký hợp đồng đã hoàn thành hoặc đã hủy");
        }

        contract.setLesseeSignatureUrl(request.getSignatureUrl());
        contract.setLesseeSignedAt(LocalDateTime.now());

        // Kiểm tra nếu cả 2 bên đã ký -> status = active
        if (contract.getLessorSignedAt() != null) {
            contract.setStatus("active");
            contract.setIsSigned(true);
        }

        RentalContract updatedContract = contractRepository.save(contract);
        return convertToDTO(updatedContract);
    }

    /**
     * Hoàn thành hợp đồng
     */
    @Transactional
    public RentalContractDTO completeContract(Integer contractId) {
        RentalContract contract = contractRepository.findById(contractId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy hợp đồng"));

        if (!"active".equals(contract.getStatus())) {
            throw new IllegalArgumentException("Chỉ có thể hoàn thành hợp đồng đang hoạt động");
        }

        contract.setStatus("completed");
        
        RentalContract updatedContract = contractRepository.save(contract);
        return convertToDTO(updatedContract);
    }

    /**
     * Hủy hợp đồng
     */
    @Transactional
    public RentalContractDTO cancelContract(Integer contractId, String reason) {
        RentalContract contract = contractRepository.findById(contractId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy hợp đồng"));

        if ("completed".equals(contract.getStatus()) || "cancelled".equals(contract.getStatus())) {
            throw new IllegalArgumentException("Không thể hủy hợp đồng đã hoàn thành hoặc đã hủy");
        }

        contract.setStatus("cancelled");
        contract.setCancellationReason(reason);
        
        RentalContract updatedContract = contractRepository.save(contract);
        return convertToDTO(updatedContract);
    }

    /**
     * Lưu trữ hợp đồng
     */
    @Transactional
    public RentalContractDTO archiveContract(Integer contractId) {
        RentalContract contract = contractRepository.findById(contractId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy hợp đồng"));

        if (!"completed".equals(contract.getStatus()) && !"cancelled".equals(contract.getStatus())) {
            throw new IllegalArgumentException("Chỉ có thể lưu trữ hợp đồng đã hoàn thành hoặc đã hủy");
        }

        contract.setIsArchived(true);
        
        RentalContract updatedContract = contractRepository.save(contract);
        return convertToDTO(updatedContract);
    }

    /**
     * Tự động cập nhật status cho hợp đồng hết hạn
     */
    @Transactional
    public void updateExpiredContracts() {
        List<RentalContract> expiredContracts = contractRepository.findExpiredContracts(LocalDateTime.now());
        for (RentalContract contract : expiredContracts) {
            contract.setStatus("expired");
            contractRepository.save(contract);
        }
    }

    /**
     * Generate contract number (HDT-YYYY-XXXX)
     */
    private String generateContractNumber() {
        String year = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy"));
        List<String> latestNumbers = contractRepository.findLatestContractNumbers();
        
        int nextNumber = 1;
        if (!latestNumbers.isEmpty()) {
            String latestNumber = latestNumbers.get(0);
            if (latestNumber.startsWith("HDT-" + year)) {
                try {
                    String numberPart = latestNumber.substring(latestNumber.lastIndexOf("-") + 1);
                    nextNumber = Integer.parseInt(numberPart) + 1;
                } catch (NumberFormatException e) {
                    nextNumber = 1;
                }
            }
        }
        
        return String.format("HDT-%s-%04d", year, nextNumber);
    }

    /**
     * Get default terms and conditions
     */
    private String getDefaultTermsAndConditions() {
        return """
                ĐIỀU KHOẢN VÀ ĐIỀU KIỆN HỢP ĐỒNG THUÊ XE
                
                1. NGHĨA VỤ CỦA BÊN CHO THUÊ (BÊN A):
                - Giao xe đúng thời gian, địa điểm đã thỏa thuận
                - Xe trong tình trạng hoạt động tốt, đầy đủ giấy tờ hợp lệ
                - Hướng dẫn sử dụng xe cho bên thuê
                
                2. NGHĨA VỤ CỦA BÊN THUÊ (BÊN B):
                - Thanh toán đầy đủ tiền thuê xe theo thỏa thuận
                - Giữ gìn xe cẩn thận, không cho người khác thuê lại
                - Trả xe đúng thời hạn, địa điểm đã thỏa thuận
                - Chịu trách nhiệm về các vi phạm giao thông trong thời gian thuê
                - Bồi thường thiệt hại nếu làm hư hỏng xe
                
                3. ĐIỀU KHOẢN BẢO HIỂM:
                - Xe được bảo hiểm bắt buộc trách nhiệm dân sự
                - Bên thuê có trách nhiệm báo ngay cho bên cho thuê khi có sự cố
                
                4. ĐIỀU KHOẢN HỦY HỢP ĐỒNG:
                - Hủy trước 24h: hoàn 80% tiền đặt cọc
                - Hủy trong 24h: hoàn 50% tiền đặt cọc
                - Không đến nhận xe: mất toàn bộ tiền đặt cọc
                
                5. TRANH CHẤP:
                - Các tranh chấp phát sinh sẽ được giải quyết thông qua thương lượng
                - Nếu không thỏa thuận được, sẽ đưa ra tòa án có thẩm quyền
                """;
    }

    /**
     * Convert entity to DTO
     */
    private RentalContractDTO convertToDTO(RentalContract contract) {
        RentalContractDTO dto = new RentalContractDTO();
        
        dto.setContractId(contract.getContractId());
        dto.setBookingId(contract.getBooking() != null ? contract.getBooking().getBookingId() : null);
        dto.setContractNumber(contract.getContractNumber());
        dto.setContractDate(contract.getContractDate());
        dto.setStartDate(contract.getStartDate());
        dto.setEndDate(contract.getEndDate());
        dto.setTotalAmount(contract.getTotalAmount());
        dto.setDepositAmount(contract.getDepositAmount());
        dto.setInsuranceAmount(contract.getInsuranceAmount());
        dto.setStatus(contract.getStatus());
        
        // Lessor info
        dto.setLessorName(contract.getLessorName());
        dto.setLessorAddress(contract.getLessorAddress());
        dto.setLessorPhone(contract.getLessorPhone());
        dto.setLessorEmail(contract.getLessorEmail());
        dto.setLessorTaxCode(contract.getLessorTaxCode());
        dto.setLessorRepresentative(contract.getLessorRepresentative());
        
        // Lessee info
        dto.setLesseeName(contract.getLesseeName());
        dto.setLesseeIdCard(contract.getLesseeIdCard());
        dto.setLesseePhone(contract.getLesseePhone());
        dto.setLesseeEmail(contract.getLesseeEmail());
        dto.setLesseeAddress(contract.getLesseeAddress());
        dto.setLesseeDateOfBirth(contract.getLesseeDateOfBirth());
        dto.setLesseeLicenseNumber(contract.getLesseeLicenseNumber());
        dto.setLesseeLicenseExpiry(contract.getLesseeLicenseExpiry());
        
        // Car & terms
        dto.setCarInfo(contract.getCarInfo());
        dto.setCarCondition(contract.getCarCondition());
        dto.setTermsAndConditions(contract.getTermsAndConditions());
        dto.setAdditionalTerms(contract.getAdditionalTerms());
        
        // Signatures
        dto.setLessorSignatureUrl(contract.getLessorSignatureUrl());
        dto.setLesseeSignatureUrl(contract.getLesseeSignatureUrl());
        dto.setLessorSignedAt(contract.getLessorSignedAt());
        dto.setLesseeSignedAt(contract.getLesseeSignedAt());
        
        // Files & metadata
        dto.setContractFileUrl(contract.getContractFileUrl());
        dto.setContractTemplate(contract.getContractTemplate());
        dto.setNotes(contract.getNotes());
        dto.setCancellationReason(contract.getCancellationReason());
        dto.setExpiryDate(contract.getExpiryDate());
        dto.setIsSigned(contract.getIsSigned());
        dto.setIsArchived(contract.getIsArchived());
        dto.setCreatedAt(contract.getCreatedAt());
        dto.setUpdatedAt(contract.getUpdatedAt());
        
        return dto;
    }
}
