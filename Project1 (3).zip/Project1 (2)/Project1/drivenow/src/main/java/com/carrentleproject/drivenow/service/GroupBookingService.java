package com.carrentleproject.drivenow.service;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.carrentleproject.drivenow.dao.BookingRepository;
import com.carrentleproject.drivenow.dao.CarRepository;
import com.carrentleproject.drivenow.dao.CustomerRepository;
import com.carrentleproject.drivenow.dao.GroupBookingRepository;
import com.carrentleproject.drivenow.dto.GroupBookingCreateRequest;
import com.carrentleproject.drivenow.dto.GroupBookingDTO;
import com.carrentleproject.drivenow.exception.ResourceNotFoundException;
import com.carrentleproject.drivenow.model.Booking;
import com.carrentleproject.drivenow.model.Car;
import com.carrentleproject.drivenow.model.Customer;
import com.carrentleproject.drivenow.model.GroupBooking;

@Service
public class GroupBookingService {

    @Autowired
    private GroupBookingRepository groupBookingRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private CarRepository carRepository;

    @Autowired
    private BookingRepository bookingRepository;

    /**
     * Tạo group booking mới
     */
    @Transactional
    public GroupBookingDTO createGroupBooking(GroupBookingCreateRequest request) {
        // Validate customer
        Customer customer = customerRepository.findById(request.getCustomerId())
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy khách hàng với ID: " + request.getCustomerId()));

        // Validate dates
        if (request.getReturnDate().isBefore(request.getPickupDate())) {
            throw new IllegalArgumentException("Ngày trả xe phải sau ngày nhận xe");
        }

        // Calculate total days
        long daysBetween = Duration.between(request.getPickupDate(), request.getReturnDate()).toDays();
        if (daysBetween == 0) {
            daysBetween = 1; // Minimum 1 day
        }

        // Validate all cars exist and available
        List<Car> cars = new ArrayList<>();
        for (Integer carId : request.getCarIds()) {
            Car car = carRepository.findById(carId)
                    .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy xe với ID: " + carId));
            
            if (!"available".equalsIgnoreCase(car.getStatus())) {
                throw new IllegalArgumentException("Xe " + car.getBrand() + " " + car.getModel() + " không có sẵn");
            }

            // Check if car is already booked in this period
            List<Booking> conflictBookings = bookingRepository.findConflictingBookings(
                    carId, request.getPickupDate(), request.getReturnDate());
            
            if (!conflictBookings.isEmpty()) {
                throw new IllegalArgumentException("Xe " + car.getBrand() + " " + car.getModel() + " đã được đặt trong khoảng thời gian này");
            }

            cars.add(car);
        }

        // Calculate total price
        BigDecimal totalPrice = BigDecimal.ZERO;
        for (Car car : cars) {
            BigDecimal carTotalPrice = car.getPricePerDay().multiply(BigDecimal.valueOf(daysBetween));
            totalPrice = totalPrice.add(carTotalPrice);
        }

        // Calculate discount
        BigDecimal discountPercentage = request.getDiscountPercentage();
        if (discountPercentage == null) {
            // Auto discount based on number of cars
            int carCount = cars.size();
            if (carCount >= 5) {
                discountPercentage = BigDecimal.valueOf(10); // 10% for 5+ cars
            } else if (carCount >= 3) {
                discountPercentage = BigDecimal.valueOf(5); // 5% for 3-4 cars
            } else {
                discountPercentage = BigDecimal.ZERO;
            }
        }

        BigDecimal discountAmount = totalPrice.multiply(discountPercentage).divide(BigDecimal.valueOf(100));

        // Create GroupBooking
        GroupBooking groupBooking = new GroupBooking();
        groupBooking.setCustomer(customer);
        groupBooking.setGroupName(request.getGroupName() != null ? request.getGroupName() : "Group Booking " + cars.size() + " cars");
        groupBooking.setPickupDate(request.getPickupDate());
        groupBooking.setReturnDate(request.getReturnDate());
        groupBooking.setPickupLocation(request.getPickupLocation());
        groupBooking.setReturnLocation(request.getReturnLocation() != null ? request.getReturnLocation() : request.getPickupLocation());
        groupBooking.setTotalCars(cars.size());
        groupBooking.setTotalDays((int) daysBetween);
        groupBooking.setTotalPrice(totalPrice);
        groupBooking.setDiscountPercentage(discountPercentage);
        groupBooking.setDiscountAmount(discountAmount);
        groupBooking.setStatus("pending");
        groupBooking.setPaymentStatus("unpaid");
        groupBooking.setPaymentMethod(request.getPaymentMethod());
        groupBooking.setNotes(request.getNotes());
        groupBooking.setCreatedAt(LocalDateTime.now());
        groupBooking.setUpdatedAt(LocalDateTime.now());

        // Save GroupBooking first to get ID
        groupBooking = groupBookingRepository.save(groupBooking);

        // Create individual bookings for each car
        for (Car car : cars) {
            Booking booking = new Booking();
            booking.setCustomer(customer);
            booking.setCar(car);
            booking.setGroupBooking(groupBooking); // Link to group booking
            booking.setPickupDate(request.getPickupDate());
            booking.setReturnDate(request.getReturnDate());
            booking.setPickupLocation(request.getPickupLocation());
            booking.setReturnLocation(groupBooking.getReturnLocation());
            
            // Calculate price for this car
            BigDecimal carTotalPrice = car.getPricePerDay().multiply(BigDecimal.valueOf(daysBetween));
            booking.setTotalPrice(carTotalPrice);
            
            booking.setStatus("pending");
            booking.setPaymentStatus("unpaid");
            booking.setPaymentMethod(request.getPaymentMethod());
            booking.setCreatedAt(LocalDateTime.now());
            booking.setUpdatedAt(LocalDateTime.now());

            bookingRepository.save(booking);
            groupBooking.addBooking(booking);
        }

        // Update group booking with bookings
        groupBooking = groupBookingRepository.save(groupBooking);

        return convertToDTO(groupBooking);
    }

    /**
     * Lấy chi tiết group booking
     */
    public GroupBookingDTO getGroupBookingById(Integer groupBookingId) {
        GroupBooking groupBooking = groupBookingRepository.findById(groupBookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy group booking với ID: " + groupBookingId));
        return convertToDTO(groupBooking);
    }

    /**
     * Lấy tất cả group bookings của khách hàng
     */
    public List<GroupBookingDTO> getCustomerGroupBookings(Integer customerId) {
        List<GroupBooking> groupBookings = groupBookingRepository.findByCustomer_CustomerIdOrderByCreatedAtDesc(customerId);
        return groupBookings.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    /**
     * Lấy group bookings theo status
     */
    public List<GroupBookingDTO> getGroupBookingsByStatus(String status) {
        List<GroupBooking> groupBookings = groupBookingRepository.findByStatusOrderByCreatedAtDesc(status);
        return groupBookings.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    /**
     * Hủy group booking
     */
    @Transactional
    public GroupBookingDTO cancelGroupBooking(Integer groupBookingId, String cancellationReason) {
        GroupBooking groupBooking = groupBookingRepository.findById(groupBookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy group booking với ID: " + groupBookingId));

        if ("cancelled".equalsIgnoreCase(groupBooking.getStatus()) || "completed".equalsIgnoreCase(groupBooking.getStatus())) {
            throw new IllegalArgumentException("Không thể hủy group booking đã hoàn thành hoặc đã hủy");
        }

        // Cancel all individual bookings
        for (Booking booking : groupBooking.getBookings()) {
            booking.setStatus("cancelled");
            booking.setCancellationReason(cancellationReason);
            booking.setUpdatedAt(LocalDateTime.now());
            bookingRepository.save(booking);
        }

        // Cancel group booking
        groupBooking.setStatus("cancelled");
        groupBooking.setCancellationReason(cancellationReason);
        groupBooking.setUpdatedAt(LocalDateTime.now());
        groupBooking = groupBookingRepository.save(groupBooking);

        return convertToDTO(groupBooking);
    }

    /**
     * Xác nhận group booking (Admin)
     */
    @Transactional
    public GroupBookingDTO confirmGroupBooking(Integer groupBookingId) {
        GroupBooking groupBooking = groupBookingRepository.findById(groupBookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy group booking với ID: " + groupBookingId));

        if (!"pending".equalsIgnoreCase(groupBooking.getStatus())) {
            throw new IllegalArgumentException("Chỉ có thể xác nhận group booking đang pending");
        }

        // Confirm all individual bookings
        for (Booking booking : groupBooking.getBookings()) {
            booking.setStatus("confirmed");
            booking.setUpdatedAt(LocalDateTime.now());
            bookingRepository.save(booking);
        }

        // Confirm group booking
        groupBooking.setStatus("confirmed");
        groupBooking.setUpdatedAt(LocalDateTime.now());
        groupBooking = groupBookingRepository.save(groupBooking);

        return convertToDTO(groupBooking);
    }

    /**
     * Cập nhật payment status
     */
    @Transactional
    public GroupBookingDTO updatePaymentStatus(Integer groupBookingId, String paymentStatus) {
        GroupBooking groupBooking = groupBookingRepository.findById(groupBookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy group booking với ID: " + groupBookingId));

        // Update payment status for all bookings
        for (Booking booking : groupBooking.getBookings()) {
            booking.setPaymentStatus(paymentStatus);
            booking.setUpdatedAt(LocalDateTime.now());
            bookingRepository.save(booking);
        }

        groupBooking.setPaymentStatus(paymentStatus);
        groupBooking.setUpdatedAt(LocalDateTime.now());
        groupBooking = groupBookingRepository.save(groupBooking);

        return convertToDTO(groupBooking);
    }

    /**
     * Convert GroupBooking entity to DTO
     */
    private GroupBookingDTO convertToDTO(GroupBooking groupBooking) {
        GroupBookingDTO dto = new GroupBookingDTO();
        dto.setGroupBookingId(groupBooking.getGroupBookingId());
        dto.setCustomerId(groupBooking.getCustomer().getCustomerId());
        dto.setCustomerName(groupBooking.getCustomer().getFullName());
        dto.setCustomerPhone(groupBooking.getCustomer().getPhone());
        dto.setGroupName(groupBooking.getGroupName());
        dto.setPickupDate(groupBooking.getPickupDate());
        dto.setReturnDate(groupBooking.getReturnDate());
        dto.setPickupLocation(groupBooking.getPickupLocation());
        dto.setReturnLocation(groupBooking.getReturnLocation());
        dto.setTotalCars(groupBooking.getTotalCars());
        dto.setTotalDays(groupBooking.getTotalDays());
        dto.setTotalPrice(groupBooking.getTotalPrice());
        dto.setStatus(groupBooking.getStatus());
        dto.setPaymentStatus(groupBooking.getPaymentStatus());
        dto.setPaymentMethod(groupBooking.getPaymentMethod());
        dto.setNotes(groupBooking.getNotes());
        dto.setCancellationReason(groupBooking.getCancellationReason());
        dto.setDiscountPercentage(groupBooking.getDiscountPercentage());
        dto.setDiscountAmount(groupBooking.getDiscountAmount());
        
        // Calculate final price
        BigDecimal finalPrice = groupBooking.getTotalPrice().subtract(groupBooking.getDiscountAmount());
        dto.setFinalPrice(finalPrice);
        
        // Get car IDs
        List<Integer> carIds = groupBooking.getBookings().stream()
                .map(booking -> booking.getCar().getCarId())
                .collect(Collectors.toList());
        dto.setCarIds(carIds);
        
        dto.setCreatedAt(groupBooking.getCreatedAt());
        dto.setUpdatedAt(groupBooking.getUpdatedAt());

        return dto;
    }
}
