package com.carrentleproject.drivenow.dto;

import java.math.BigDecimal;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;

public class CarSearchRequest {

    // Loại nhiên liệu (điện, xăng, dầu)
    private String fuelType; // Electric, Gasoline, Diesel, Hybrid

    // Khoảng giá
    @DecimalMin(value = "300000", inclusive = true, message = "Giá thấp nhất phải lớn hơn 300,000 VND")
    @DecimalMax(value = "10000000", inclusive = true, message = "Giá tối đa là 10,000,000 VND")
    private BigDecimal priceMin;

    @DecimalMin(value = "300000", inclusive = true, message = "Giá tối đa phải lớn hơn 300,000 VND")
    @DecimalMax(value = "10000000", inclusive = true, message = "Giá tối đa là 10,000,000 VND")
    private BigDecimal priceMax;

    // Hãng xe
    private String brand; // Toyota, Honda, Mercedes, BMW, etc.

    // Số ghế
    @Min(value = 4, message = "Số ghế phải tối thiểu là 4")
    @Max(value = 7, message = "Số ghế không được vượt quá 7")
    private Integer seats;

    // Địa điểm
    private String location; // Ho Chi Minh City, Hanoi, Da Nang, etc.

    // Status (optional - mặc định chỉ tìm xe available)
    private String status; // available, rented, maintenance

    // Model xe (optional)
    private String model;

    // Sắp xếp
    private String sortBy; // price_asc, price_desc, seats_asc, seats_desc, brand, newest
    
    // Constructors
    public CarSearchRequest() {
    }

    public CarSearchRequest(String fuelType, BigDecimal priceMin, BigDecimal priceMax, 
            String brand, Integer seats, String location, String status, String model, String sortBy) {
        this.fuelType = fuelType;
        this.priceMin = priceMin;
        this.priceMax = priceMax;
        this.brand = brand;
        this.seats = seats;
        this.location = location;
        this.status = status;
        this.model = model;
        this.sortBy = sortBy;
    }

    // Getters and Setters
    public String getFuelType() {
        return fuelType;
    }

    public void setFuelType(String fuelType) {
        this.fuelType = fuelType;
    }

    public BigDecimal getPriceMin() {
        return priceMin;
    }

    public void setPriceMin(BigDecimal priceMin) {
        this.priceMin = priceMin;
    }

    public BigDecimal getPriceMax() {
        return priceMax;
    }

    public void setPriceMax(BigDecimal priceMax) {
        this.priceMax = priceMax;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public Integer getSeats() {
        return seats;
    }

    public void setSeats(Integer seats) {
        this.seats = seats;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getSortBy() {
        return sortBy;
    }

    public void setSortBy(String sortBy) {
        this.sortBy = sortBy;
    }

    @Override
    public String toString() {
        return "CarSearchRequest{" +
                "fuelType='" + fuelType + '\'' +
                ", priceMin=" + priceMin +
                ", priceMax=" + priceMax +
                ", brand='" + brand + '\'' +
                ", seats=" + seats +
                ", location='" + location + '\'' +
                ", status='" + status + '\'' +
                ", sortBy='" + sortBy + '\'' +
                '}';
    }
}
