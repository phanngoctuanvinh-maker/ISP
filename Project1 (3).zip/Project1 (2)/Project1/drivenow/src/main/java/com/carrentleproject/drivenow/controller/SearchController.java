package com.carrentleproject.drivenow.controller;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.carrentleproject.drivenow.dto.CarDTO;
import com.carrentleproject.drivenow.dto.CarSearchRequest;
import com.carrentleproject.drivenow.dto.CarSearchResponse;
import com.carrentleproject.drivenow.service.SearchService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/search")
@CrossOrigin(origins = "*")
public class SearchController {

    @Autowired
    private SearchService searchService;

    /**
     * POST /api/search/cars - Tìm kiếm xe nâng cao với nhiều bộ lọc
     */
    @PostMapping("/cars")
    public ResponseEntity<Map<String, Object>> searchCars(@Valid @RequestBody CarSearchRequest request) {
        Map<String, Object> response = new HashMap<>();
        try {
            CarSearchResponse searchResponse = searchService.searchCars(request);
            
            response.put("success", true);
            response.put("data", searchResponse.getCars());
            response.put("total", searchResponse.getTotalResults());
            response.put("searchCriteria", searchResponse.getSearchCriteria());
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Đã xảy ra lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * GET /api/search/cars/fuel-type/{fuelType} - Tìm xe theo loại nhiên liệu
     */
    @GetMapping("/cars/fuel-type/{fuelType}")
    public ResponseEntity<Map<String, Object>> searchByFuelType(@PathVariable String fuelType) {
        Map<String, Object> response = new HashMap<>();
        try {
            List<CarDTO> cars = searchService.searchByFuelType(fuelType);
            
            response.put("success", true);
            response.put("data", cars);
            response.put("total", cars.size());
            response.put("fuelType", fuelType);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "An error occurred: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * GET /api/search/cars/price-range - Tìm xe theo khoảng giá
     */
    @GetMapping("/cars/price-range")
    public ResponseEntity<Map<String, Object>> searchByPriceRange(
            @RequestParam(required = false) BigDecimal min,
            @RequestParam(required = false) BigDecimal max) {
        Map<String, Object> response = new HashMap<>();
        try {
            List<CarDTO> cars = searchService.searchByPriceRange(min, max);
            
            response.put("success", true);
            response.put("data", cars);
            response.put("total", cars.size());
            response.put("priceRange", Map.of("min", min != null ? min : 0, "max", max != null ? max : "unlimited"));
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Đã xảy ra lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * GET /api/search/cars/brand/{brand} - Tìm xe theo hãng
     */
    @GetMapping("/cars/brand/{brand}")
    public ResponseEntity<Map<String, Object>> searchByBrand(@PathVariable String brand) {
        Map<String, Object> response = new HashMap<>();
        try {
            List<CarDTO> cars = searchService.searchByBrand(brand);
            
            response.put("success", true);
            response.put("data", cars);
            response.put("total", cars.size());
            response.put("brand", brand);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Đã xảy ra lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * GET /api/search/cars/seats/{seats} - Tìm xe theo số ghế
     */
    @GetMapping("/cars/seats/{seats}")
    public ResponseEntity<Map<String, Object>> searchBySeats(@PathVariable Integer seats) {
        Map<String, Object> response = new HashMap<>();
        try {
            List<CarDTO> cars = searchService.searchBySeats(seats);
            
            response.put("success", true);
            response.put("data", cars);
            response.put("total", cars.size());
            response.put("minSeats", seats);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Đã xảy ra lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * GET /api/search/filters/fuel-types - Lấy danh sách loại nhiên liệu có sẵn
     */
    @GetMapping("/filters/fuel-types")
    public ResponseEntity<Map<String, Object>> getAvailableFuelTypes() {
        Map<String, Object> response = new HashMap<>();
        try {
            List<String> fuelTypes = searchService.getAvailableFuelTypes();
            
            response.put("success", true);
            response.put("data", fuelTypes);
            response.put("total", fuelTypes.size());
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Đã xảy ra lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * GET /api/search/filters/brands - Lấy danh sách hãng xe có sẵn
     */
    @GetMapping("/filters/brands")
    public ResponseEntity<Map<String, Object>> getAvailableBrands() {
        Map<String, Object> response = new HashMap<>();
        try {
            List<String> brands = searchService.getAvailableBrands();
            
            response.put("success", true);
            response.put("data", brands);
            response.put("total", brands.size());
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Đã xảy ra lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * GET /api/search/filters/price-range - Lấy khoảng giá (min-max)
     */
    @GetMapping("/filters/price-range")
    public ResponseEntity<Map<String, Object>> getPriceRange() {
        Map<String, Object> response = new HashMap<>();
        try {
            SearchService.PriceRange priceRange = searchService.getPriceRange();
            
            response.put("success", true);
            response.put("data", Map.of(
                "min", priceRange.getMin(),
                "max", priceRange.getMax()
            ));
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Đã xảy ra lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }
}
