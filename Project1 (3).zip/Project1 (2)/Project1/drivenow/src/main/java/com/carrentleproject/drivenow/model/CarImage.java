package com.carrentleproject.drivenow.model;

import java.time.LocalDateTime;
import java.util.Objects;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "car_images")
public class CarImage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "car_image_id")
    private Integer carImageId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "car_id", nullable = false)
    private Car car;

    @Column(name = "type", length = 20)
    private String type; // main, gallery, interior, exterior

    @Column(name = "url", length = 255, nullable = false)
    private String url;

    @Column(name = "description", length = 255)
    private String description;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    // Constructors
    public CarImage() {
    }

    public CarImage(Car car, String type, String url, String description) {
        this.car = car;
        this.type = type;
        this.url = url;
        this.description = description;
    }

    // Getters and Setters
    public Integer getCarImageId() {
        return carImageId;
    }

    public void setCarImageId(Integer carImageId) {
        this.carImageId = carImageId;
    }

    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        CarImage carImage = (CarImage) o;
        return Objects.equals(carImageId, carImage.carImageId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(carImageId);
    }

    @Override
    public String toString() {
        return "CarImage{" +
                "carImageId=" + carImageId +
                ", type='" + type + '\'' +
                ", url='" + url + '\'' +
                '}';
    }
}
