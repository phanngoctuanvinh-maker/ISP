package com.carrentleproject.drivenow.controller;

import com.carrentleproject.drivenow.dto.ApiResponse;
import com.carrentleproject.drivenow.dto.AuthResponse;
import com.carrentleproject.drivenow.dto.GoogleLoginRequest;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class LoginGGController {

    /**
     * Google Login endpoint
     * TODO: Implement Google OAuth2 verification
     * Hiện tại chỉ là placeholder, cần implement full logic với Google API
     */
    @PostMapping("/google-login")
    public ResponseEntity<ApiResponse<AuthResponse>> googleLogin(@Valid @RequestBody GoogleLoginRequest request) {
        // TODO: Verify Google ID Token
        // 1. Verify token với Google API
        // 2. Lấy thông tin user từ Google (email, name, picture)
        // 3. Kiểm tra user đã tồn tại chưa
        // 4. Nếu chưa tồn tại thì tạo account mới (role = customer)
        // 5. Generate JWT token và trả về

        return ResponseEntity.ok(
                ApiResponse.error("Google login chưa được implement. Vui lòng sử dụng đăng nhập thông thường."));
    }
}
