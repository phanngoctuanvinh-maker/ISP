package com.carrentleproject.drivenow.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.carrentleproject.drivenow.model.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Integer> {

    /**
     * Tìm customer theo account ID
     */
    Optional<Customer> findByAccount_AccountId(Integer accountId);

    /**
     * Tìm customer theo email
     */
    Optional<Customer> findByEmail(String email);

    /**
     * Tìm customer theo phone
     */
    Optional<Customer> findByPhone(String phone);

    /**
     * Check customer có tồn tại theo email
     */
    boolean existsByEmail(String email);

    /**
     * Check customer có tồn tại theo phone
     */
    boolean existsByPhone(String phone);
}
