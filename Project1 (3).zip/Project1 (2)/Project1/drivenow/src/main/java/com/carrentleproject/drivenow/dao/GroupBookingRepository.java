package com.carrentleproject.drivenow.dao;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.carrentleproject.drivenow.model.GroupBooking;

@Repository
public interface GroupBookingRepository extends JpaRepository<GroupBooking, Integer> {

    /**
     * Tìm tất cả group bookings của khách hàng
     */
    List<GroupBooking> findByCustomer_CustomerIdOrderByCreatedAtDesc(Integer customerId);

    /**
     * Tìm group bookings theo status
     */
    List<GroupBooking> findByStatusOrderByCreatedAtDesc(String status);

    /**
     * Tìm group bookings của khách hàng theo status
     */
    List<GroupBooking> findByCustomer_CustomerIdAndStatusOrderByCreatedAtDesc(Integer customerId, String status);

    /**
     * Đếm số lượng group bookings theo status
     */
    Long countByStatus(String status);

    /**
     * Đếm tổng số group bookings
     */
    @Query("SELECT COUNT(gb) FROM GroupBooking gb")
    Long countAllGroupBookings();

    /**
     * Tính tổng doanh thu từ group bookings
     */
    @Query("SELECT SUM(gb.totalPrice - gb.discountAmount) FROM GroupBooking gb WHERE gb.status = 'completed'")
    BigDecimal calculateTotalRevenue();

    /**
     * Lấy group bookings theo khoảng thời gian pickup
     */
    @Query("SELECT gb FROM GroupBooking gb WHERE gb.pickupDate BETWEEN :startDate AND :endDate ORDER BY gb.pickupDate ASC")
    List<GroupBooking> findByPickupDateBetween(@Param("startDate") java.time.LocalDateTime startDate, 
                                                @Param("endDate") java.time.LocalDateTime endDate);
}
