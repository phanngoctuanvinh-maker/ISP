package com.carrentleproject.drivenow.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.carrentleproject.drivenow.dao.AccountRepository;
import com.carrentleproject.drivenow.dao.BookingRepository;
import com.carrentleproject.drivenow.dao.HistoryRepository;
import com.carrentleproject.drivenow.dto.HistoryDTO;
import com.carrentleproject.drivenow.exception.ResourceNotFoundException;
import com.carrentleproject.drivenow.model.Account;
import com.carrentleproject.drivenow.model.Booking;
import com.carrentleproject.drivenow.model.History;

@Service
public class HistoryService {

    @Autowired
    private HistoryRepository historyRepository;

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private BookingRepository bookingRepository;

    /**
     * Ghi lại lịch sử đăng nhập
     */
    @Transactional
    public HistoryDTO recordLogin(Integer accountId, String ipAddress, String userAgent) {
        Account account = accountRepository.findById(accountId)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found"));

        History history = History.createLoginHistory(account, ipAddress, userAgent);
        History savedHistory = historyRepository.save(history);

        return convertToDTO(savedHistory);
    }

    /**
     * Ghi lại lịch sử tạo booking
     */
    @Transactional
    public HistoryDTO recordCreateBooking(Integer accountId, Integer bookingId) {
        Account account = accountRepository.findById(accountId)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found"));

        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found"));

        History history = History.createBookingHistory(
            account, 
            booking, 
            "create_booking",
            String.format("User created booking #%d for car %s %s", 
                bookingId, 
                booking.getCar().getBrand(), 
                booking.getCar().getModel())
        );

        History savedHistory = historyRepository.save(history);
        return convertToDTO(savedHistory);
    }

    /**
     * Ghi lại lịch sử hủy booking
     */
    @Transactional
    public HistoryDTO recordCancelBooking(Integer accountId, Integer bookingId, String reason) {
        Account account = accountRepository.findById(accountId)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found"));

        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found"));

        History history = History.createBookingHistory(
            account, 
            booking, 
            "cancel_booking",
            String.format("User cancelled booking #%d. Reason: %s", bookingId, reason)
        );

        History savedHistory = historyRepository.save(history);
        return convertToDTO(savedHistory);
    }

    /**
     * Ghi lại lịch sử hoàn thành booking
     */
    @Transactional
    public HistoryDTO recordCompleteBooking(Integer accountId, Integer bookingId) {
        Account account = accountRepository.findById(accountId)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found"));

        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found"));

        History history = History.createBookingHistory(
            account, 
            booking, 
            "complete_booking",
            String.format("User completed booking #%d successfully", bookingId)
        );

        History savedHistory = historyRepository.save(history);
        return convertToDTO(savedHistory);
    }

    /**
     * Ghi lại lịch sử thanh toán
     */
    @Transactional
    public HistoryDTO recordPayment(Integer accountId, Integer bookingId, String paymentMethod) {
        Account account = accountRepository.findById(accountId)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found"));

        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found"));

        History history = History.createBookingHistory(
            account, 
            booking, 
            "payment",
            String.format("User paid for booking #%d using %s", bookingId, paymentMethod)
        );

        History savedHistory = historyRepository.save(history);
        return convertToDTO(savedHistory);
    }

    /**
     * Ghi lại hành động tùy chỉnh
     */
    @Transactional
    public HistoryDTO recordCustomAction(Integer accountId, String action, String description, 
                                         String entityType, Integer entityId) {
        Account account = accountRepository.findById(accountId)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found"));

        History history = new History();
        history.setAccount(account);
        history.setAction(action);
        history.setDescription(description);
        history.setEntityType(entityType);
        history.setEntityId(entityId);
        history.setStatus("success");

        History savedHistory = historyRepository.save(history);
        return convertToDTO(savedHistory);
    }

    /**
     * Lấy tất cả lịch sử của account
     */
    public List<HistoryDTO> getHistoryByAccountId(Integer accountId) {
        List<History> histories = historyRepository.findByAccount_AccountIdOrderByCreatedAtDesc(accountId);
        return histories.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Lấy lịch sử booking của account
     */
    public List<HistoryDTO> getBookingHistoryByAccountId(Integer accountId) {
        List<History> histories = historyRepository.findBookingHistoryByAccountId(accountId);
        return histories.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Lấy lịch sử login của account
     */
    public List<HistoryDTO> getLoginHistoryByAccountId(Integer accountId) {
        List<History> histories = historyRepository.findLoginHistoryByAccountId(accountId);
        return histories.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Lấy lịch sử theo booking ID
     */
    public List<HistoryDTO> getHistoryByBookingId(Integer bookingId) {
        List<History> histories = historyRepository.findByBooking_BookingIdOrderByCreatedAtDesc(bookingId);
        return histories.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Lấy lịch sử theo action type
     */
    public List<HistoryDTO> getHistoryByAction(String action) {
        List<History> histories = historyRepository.findByActionOrderByCreatedAtDesc(action);
        return histories.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Lấy lịch sử trong khoảng thời gian
     */
    public List<HistoryDTO> getHistoryByDateRange(Integer accountId, LocalDateTime startDate, LocalDateTime endDate) {
        List<History> histories = historyRepository.findByAccountIdAndDateRange(accountId, startDate, endDate);
        return histories.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Lấy các hoạt động gần đây (recent activities)
     */
    public List<HistoryDTO> getRecentActivities(int limit) {
        List<History> histories = historyRepository.findRecentActivities();
        return histories.stream()
                .limit(limit)
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Đếm số lượng hành động
     */
    public Long countActionsByAccountId(Integer accountId, String action) {
        return historyRepository.countByAccount_AccountIdAndAction(accountId, action);
    }

    /**
     * Convert entity to DTO
     */
    private HistoryDTO convertToDTO(History history) {
        HistoryDTO dto = new HistoryDTO();
        
        dto.setHistoryId(history.getHistoryId());
        dto.setAccountId(history.getAccount() != null ? history.getAccount().getAccountId() : null);
        dto.setUsername(history.getAccount() != null ? history.getAccount().getUsername() : null);
        dto.setBookingId(history.getBooking() != null ? history.getBooking().getBookingId() : null);
        dto.setDriverId(history.getDriver() != null ? history.getDriver().getDriverId() : null);
        dto.setAction(history.getAction());
        dto.setDescription(history.getDescription());
        dto.setEntityType(history.getEntityType());
        dto.setEntityId(history.getEntityId());
        dto.setIpAddress(history.getIpAddress());
        dto.setUserAgent(history.getUserAgent());
        dto.setStatus(history.getStatus());
        dto.setMetadata(history.getMetadata());
        dto.setCreatedAt(history.getCreatedAt());
        
        return dto;
    }
}
