package com.carrentleproject.drivenow.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.carrentleproject.drivenow.dao.BookingRepository;
import com.carrentleproject.drivenow.dao.CarRepository;
import com.carrentleproject.drivenow.dao.ReviewRepository;
import com.carrentleproject.drivenow.dto.CarRatingDTO;
import com.carrentleproject.drivenow.dto.ReviewCreateRequest;
import com.carrentleproject.drivenow.dto.ReviewDTO;
import com.carrentleproject.drivenow.model.Booking;
import com.carrentleproject.drivenow.model.Car;
import com.carrentleproject.drivenow.model.Review;

@Service
public class ReviewService {

    @Autowired
    private ReviewRepository reviewRepository;

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private CarRepository carRepository;

    /**
     * Tạo review mới
     */
    @Transactional
    public ReviewDTO createReview(Integer customerId, ReviewCreateRequest request) {
        // 1. Kiểm tra booking tồn tại
        Booking booking = bookingRepository.findById(request.getBookingId())
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy booking với ID: " + request.getBookingId()));

        // 2. Kiểm tra booking đã hoàn thành chưa
        if (!"completed".equalsIgnoreCase(booking.getStatus())) {
            throw new IllegalStateException("Chỉ có thể đánh giá sau khi hoàn thành chuyến đi. Trạng thái hiện tại: " + booking.getStatus());
        }

        // 3. Kiểm tra booking có thuộc về khách hàng này không
        if (!booking.getCustomer().getCustomerId().equals(customerId)) {
            throw new IllegalArgumentException("Bạn không có quyền đánh giá booking này");
        }

        // 4. Kiểm tra đã review chưa
        if (reviewRepository.existsByBooking_BookingId(request.getBookingId())) {
            throw new IllegalStateException("Bạn đã đánh giá booking này rồi");
        }

        // 5. Tạo review mới
        Review review = new Review();
        review.setBooking(booking);
        review.setCustomer(booking.getCustomer());
        review.setCar(booking.getCar());
        review.setRating(request.getRating());
        review.setComment(request.getComment());
        review.setCleanlinessRating(request.getCleanlinessRating());
        review.setPerformanceRating(request.getPerformanceRating());
        review.setServiceRating(request.getServiceRating());
        review.setIsVerified(false); // Mặc định chưa xác minh

        Review savedReview = reviewRepository.save(review);
        return convertToDTO(savedReview);
    }

    /**
     * Lấy review theo ID
     */
    public ReviewDTO getReviewById(Integer reviewId) {
        Review review = reviewRepository.findById(reviewId)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy review với ID: " + reviewId));
        return convertToDTO(review);
    }

    /**
     * Lấy tất cả reviews của khách hàng
     */
    public List<ReviewDTO> getReviewsByCustomer(Integer customerId) {
        return reviewRepository.findByCustomer_CustomerIdOrderByCreatedAtDesc(customerId).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Lấy tất cả reviews của xe
     */
    public List<ReviewDTO> getReviewsByCar(Integer carId) {
        return reviewRepository.findByCar_CarIdOrderByCreatedAtDesc(carId).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Lấy review theo booking ID
     */
    public ReviewDTO getReviewByBooking(Integer bookingId) {
        Review review = reviewRepository.findByBooking_BookingId(bookingId)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy review cho booking này"));
        return convertToDTO(review);
    }

    /**
     * Kiểm tra đã review booking chưa
     */
    public boolean hasReviewed(Integer bookingId) {
        return reviewRepository.existsByBooking_BookingId(bookingId);
    }

    /**
     * Lấy thống kê rating của xe
     */
    public CarRatingDTO getCarRating(Integer carId) {
        Car car = carRepository.findById(carId)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy xe với ID: " + carId));

        CarRatingDTO dto = new CarRatingDTO();
        dto.setCarId(carId);
        dto.setCarBrand(car.getBrand());
        dto.setCarModel(car.getModel());

        Double avgRating = reviewRepository.calculateAverageRatingByCar(carId);
        dto.setAverageRating(avgRating != null ? avgRating : 0.0);

        dto.setTotalReviews(reviewRepository.countByCar_CarId(carId));
        dto.setFiveStarCount(reviewRepository.countByCarAndRating(carId, 5));
        dto.setFourStarCount(reviewRepository.countByCarAndRating(carId, 4));
        dto.setThreeStarCount(reviewRepository.countByCarAndRating(carId, 3));
        dto.setTwoStarCount(reviewRepository.countByCarAndRating(carId, 2));
        dto.setOneStarCount(reviewRepository.countByCarAndRating(carId, 1));

        return dto;
    }

    /**
     * Lấy reviews đã xác minh
     */
    public List<ReviewDTO> getVerifiedReviews() {
        return reviewRepository.findByIsVerifiedOrderByCreatedAtDesc(true).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * [ADMIN] Xác minh review
     */
    @Transactional
    public ReviewDTO verifyReview(Integer reviewId) {
        Review review = reviewRepository.findById(reviewId)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy review với ID: " + reviewId));

        review.setIsVerified(true);
        Review updatedReview = reviewRepository.save(review);
        return convertToDTO(updatedReview);
    }

    /**
     * [ADMIN] Xóa review
     */
    @Transactional
    public void deleteReview(Integer reviewId) {
        if (!reviewRepository.existsById(reviewId)) {
            throw new IllegalArgumentException("Không tìm thấy review với ID: " + reviewId);
        }
        reviewRepository.deleteById(reviewId);
    }

    /**
     * Lấy tất cả reviews (for admin)
     */
    public List<ReviewDTO> getAllReviews() {
        return reviewRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Convert Review entity to DTO
     */
    private ReviewDTO convertToDTO(Review review) {
        ReviewDTO dto = new ReviewDTO();
        dto.setReviewId(review.getReviewId());
        dto.setBookingId(review.getBooking().getBookingId());
        dto.setCustomerId(review.getCustomer().getCustomerId());
        dto.setCustomerName(review.getCustomer().getFullName());
        dto.setCarId(review.getCar().getCarId());
        dto.setCarBrand(review.getCar().getBrand());
        dto.setCarModel(review.getCar().getModel());
        dto.setRating(review.getRating());
        dto.setComment(review.getComment());
        dto.setCleanlinessRating(review.getCleanlinessRating());
        dto.setPerformanceRating(review.getPerformanceRating());
        dto.setServiceRating(review.getServiceRating());
        dto.setIsVerified(review.getIsVerified());
        dto.setCreatedAt(review.getCreatedAt());
        dto.setUpdatedAt(review.getUpdatedAt());
        return dto;
    }
}
