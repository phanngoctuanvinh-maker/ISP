package com.carrentleproject.drivenow.dto;

import java.time.LocalDateTime;

import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class BookingCreateRequest {

    @NotNull(message = "Bắt buộc phải có ID xe")
    private Integer customerId;

    @NotNull(message = "Bắt buộc phải có ID xe")
    private Integer carId;

    private Integer driverId; // Optional - nếu khách muốn thuê kèm tài xế

    @NotNull(message = "Ngày đón là bắt buộc")
    @Future(message = "Ngày đón phải là một ngày trong tương lai")
    private LocalDateTime pickupDate;

    @NotNull(message = "Ngày trả là bắt buộc")
    @Future(message = "Ngày trả phải là một ngày trong tương lai")
    private LocalDateTime returnDate;

    @NotNull(message = "Địa điểm đón là bắt buộc")
    @Size(min = 5, max = 255, message = "Địa điểm đón phải từ 5 đến 255 ký tự")
    private String pickupLocation;

    @Size(max = 255, message = "Địa điểm trả không được vượt quá 255 ký tự")
    private String returnLocation;

    @Size(max = 50, message = "Phương thức thanh toán không được vượt quá 50 ký tự")
    private String paymentMethod; // cash, bank_transfer, credit_card, momo, zalopay

    @Size(max = 1000, message = "Ghi chú không được vượt quá 1000 ký tự")
    private String notes;

    // Constructors
    public BookingCreateRequest() {
    }

    // Getters and Setters
    public Integer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }

    public Integer getCarId() {
        return carId;
    }

    public void setCarId(Integer carId) {
        this.carId = carId;
    }

    public Integer getDriverId() {
        return driverId;
    }

    public void setDriverId(Integer driverId) {
        this.driverId = driverId;
    }

    public LocalDateTime getPickupDate() {
        return pickupDate;
    }

    public void setPickupDate(LocalDateTime pickupDate) {
        this.pickupDate = pickupDate;
    }

    public LocalDateTime getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(LocalDateTime returnDate) {
        this.returnDate = returnDate;
    }

    public String getPickupLocation() {
        return pickupLocation;
    }

    public void setPickupLocation(String pickupLocation) {
        this.pickupLocation = pickupLocation;
    }

    public String getReturnLocation() {
        return returnLocation;
    }

    public void setReturnLocation(String returnLocation) {
        this.returnLocation = returnLocation;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }
}
