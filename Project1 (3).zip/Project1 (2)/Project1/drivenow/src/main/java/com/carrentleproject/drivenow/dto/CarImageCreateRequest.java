package com.carrentleproject.drivenow.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class CarImageCreateRequest {

    @NotNull(message = "Bắt buộc phải có ID xe")
    private Integer carId;

    @Size(max = 20, message = "Loại hình ảnh không được vượt quá 20 ký tự")
    private String type; // main, gallery, interior, exterior

    @NotBlank(message = "Bắt buộc phải có URL hình ảnh")
    @Size(max = 255, message = "URL hình ảnh không được vượt quá 255 ký tự")
    private String url;

    @Size(max = 255, message = "Mô tả không được vượt quá 255 ký tự")
    private String description;

    // Constructors
    public CarImageCreateRequest() {
    }

    public CarImageCreateRequest(Integer carId, String type, String url, String description) {
        this.carId = carId;
        this.type = type;
        this.url = url;
        this.description = description;
    }

    // Getters and Setters
    public Integer getCarId() {
        return carId;
    }

    public void setCarId(Integer carId) {
        this.carId = carId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
