package com.carrentleproject.drivenow.dao;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.carrentleproject.drivenow.model.History;

@Repository
public interface HistoryRepository extends JpaRepository<History, Integer> {

    /**
     * Tìm lịch sử theo account ID
     */
    List<History> findByAccount_AccountIdOrderByCreatedAtDesc(Integer accountId);

    /**
     * Tìm lịch sử theo booking ID
     */
    List<History> findByBooking_BookingIdOrderByCreatedAtDesc(Integer bookingId);

    /**
     * Tìm lịch sử theo action type
     */
    List<History> findByActionOrderByCreatedAtDesc(String action);

    /**
     * Tìm lịch sử theo account và action
     */
    List<History> findByAccount_AccountIdAndActionOrderByCreatedAtDesc(Integer accountId, String action);

    /**
     * Tìm lịch sử booking của account
     */
    @Query("SELECT h FROM History h WHERE h.account.accountId = :accountId " +
           "AND h.entityType = 'booking' " +
           "ORDER BY h.createdAt DESC")
    List<History> findBookingHistoryByAccountId(@Param("accountId") Integer accountId);

    /**
     * Tìm lịch sử trong khoảng thời gian
     */
    @Query("SELECT h FROM History h WHERE h.account.accountId = :accountId " +
           "AND h.createdAt BETWEEN :startDate AND :endDate " +
           "ORDER BY h.createdAt DESC")
    List<History> findByAccountIdAndDateRange(
            @Param("accountId") Integer accountId,
            @Param("startDate") LocalDateTime startDate,
            @Param("endDate") LocalDateTime endDate);

    /**
     * Tìm lịch sử theo entity type và entity ID
     */
    List<History> findByEntityTypeAndEntityIdOrderByCreatedAtDesc(String entityType, Integer entityId);

    /**
     * Tìm lịch sử login của account
     */
    @Query("SELECT h FROM History h WHERE h.account.accountId = :accountId " +
           "AND h.action = 'login' " +
           "ORDER BY h.createdAt DESC")
    List<History> findLoginHistoryByAccountId(@Param("accountId") Integer accountId);

    /**
     * Tìm lịch sử login gần nhất
     */
    @Query("SELECT h FROM History h WHERE h.account.accountId = :accountId " +
           "AND h.action = 'login' " +
           "ORDER BY h.createdAt DESC")
    List<History> findLatestLoginByAccountId(@Param("accountId") Integer accountId);

    /**
     * Đếm số lượng hành động theo type
     */
    Long countByAccount_AccountIdAndAction(Integer accountId, String action);

    /**
     * Tìm tất cả lịch sử gần đây (recent activities)
     */
    @Query("SELECT h FROM History h ORDER BY h.createdAt DESC")
    List<History> findRecentActivities();

    /**
     * Tìm lịch sử theo status
     */
    List<History> findByStatusOrderByCreatedAtDesc(String status);

    /**
     * Tìm lịch sử failed actions
     */
    @Query("SELECT h FROM History h WHERE h.account.accountId = :accountId " +
           "AND h.status = 'failed' " +
           "ORDER BY h.createdAt DESC")
    List<History> findFailedActionsByAccountId(@Param("accountId") Integer accountId);
}
