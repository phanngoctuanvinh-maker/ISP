package com.carrentleproject.drivenow.controller;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.carrentleproject.drivenow.dto.HistoryDTO;
import com.carrentleproject.drivenow.service.HistoryService;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Controller quản lý lịch sử hành động
 * History Tracking Controller
 */
@RestController
@RequestMapping("/api/history")
public class HistoryController {

    @Autowired
    private HistoryService historyService;

    /**
     * 1. Ghi lại lịch sử đăng nhập
     * POST /api/history/login?accountId=1
     */
    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> recordLogin(
            @RequestParam Integer accountId,
            HttpServletRequest request) {
        try {
            String ipAddress = getClientIpAddress(request);
            String userAgent = request.getHeader("User-Agent");
            
            HistoryDTO history = historyService.recordLogin(accountId, ipAddress, userAgent);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Đã ghi lại lịch sử đăng nhập");
            response.put("data", history);
            
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Lỗi khi ghi lịch sử: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * 2. Ghi lại lịch sử tạo booking
     * POST /api/history/create-booking?accountId=1&bookingId=5
     */
    @PostMapping("/create-booking")
    public ResponseEntity<Map<String, Object>> recordCreateBooking(
            @RequestParam Integer accountId,
            @RequestParam Integer bookingId) {
        try {
            HistoryDTO history = historyService.recordCreateBooking(accountId, bookingId);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Đã ghi lại lịch sử tạo booking");
            response.put("data", history);
            
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Lỗi khi ghi lịch sử: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * 3. Ghi lại lịch sử hủy booking
     * POST /api/history/cancel-booking?accountId=1&bookingId=5&reason=Thay đổi kế hoạch
     */
    @PostMapping("/cancel-booking")
    public ResponseEntity<Map<String, Object>> recordCancelBooking(
            @RequestParam Integer accountId,
            @RequestParam Integer bookingId,
            @RequestParam(required = false) String reason) {
        try {
            HistoryDTO history = historyService.recordCancelBooking(accountId, bookingId, reason);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Đã ghi lại lịch sử hủy booking");
            response.put("data", history);
            
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Lỗi khi ghi lịch sử: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * 4. Ghi lại lịch sử hoàn thành booking
     * POST /api/history/complete-booking?accountId=1&bookingId=5
     */
    @PostMapping("/complete-booking")
    public ResponseEntity<Map<String, Object>> recordCompleteBooking(
            @RequestParam Integer accountId,
            @RequestParam Integer bookingId) {
        try {
            HistoryDTO history = historyService.recordCompleteBooking(accountId, bookingId);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Đã ghi lại lịch sử hoàn thành booking");
            response.put("data", history);
            
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Lỗi khi ghi lịch sử: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * 5. Ghi lại lịch sử thanh toán
     * POST /api/history/payment?accountId=1&bookingId=5&paymentMethod=credit_card
     */
    @PostMapping("/payment")
    public ResponseEntity<Map<String, Object>> recordPayment(
            @RequestParam Integer accountId,
            @RequestParam Integer bookingId,
            @RequestParam String paymentMethod) {
        try {
            HistoryDTO history = historyService.recordPayment(accountId, bookingId, paymentMethod);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Đã ghi lại lịch sử thanh toán");
            response.put("data", history);
            
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Lỗi khi ghi lịch sử: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * 6. Lấy tất cả lịch sử của account
     * GET /api/history/account/{accountId}
     */
    @GetMapping("/account/{accountId}")
    public ResponseEntity<Map<String, Object>> getHistoryByAccountId(@PathVariable Integer accountId) {
        try {
            List<HistoryDTO> histories = historyService.getHistoryByAccountId(accountId);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", histories);
            response.put("total", histories.size());
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Lỗi khi lấy lịch sử");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * 7. Lấy lịch sử booking của account
     * GET /api/history/account/{accountId}/bookings
     */
    @GetMapping("/account/{accountId}/bookings")
    public ResponseEntity<Map<String, Object>> getBookingHistoryByAccountId(@PathVariable Integer accountId) {
        try {
            List<HistoryDTO> histories = historyService.getBookingHistoryByAccountId(accountId);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", histories);
            response.put("total", histories.size());
            response.put("message", "Lịch sử đặt xe của account");
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Lỗi khi lấy lịch sử booking");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * 8. Lấy lịch sử login của account
     * GET /api/history/account/{accountId}/logins
     */
    @GetMapping("/account/{accountId}/logins")
    public ResponseEntity<Map<String, Object>> getLoginHistoryByAccountId(@PathVariable Integer accountId) {
        try {
            List<HistoryDTO> histories = historyService.getLoginHistoryByAccountId(accountId);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", histories);
            response.put("total", histories.size());
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Lỗi khi lấy lịch sử login");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * 9. Lấy lịch sử theo booking ID
     * GET /api/history/booking/{bookingId}
     */
    @GetMapping("/booking/{bookingId}")
    public ResponseEntity<Map<String, Object>> getHistoryByBookingId(@PathVariable Integer bookingId) {
        try {
            List<HistoryDTO> histories = historyService.getHistoryByBookingId(bookingId);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", histories);
            response.put("total", histories.size());
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Lỗi khi lấy lịch sử booking");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * 10. Lấy lịch sử theo action type
     * GET /api/history/action?action=create_booking
     */
    @GetMapping("/action")
    public ResponseEntity<Map<String, Object>> getHistoryByAction(@RequestParam String action) {
        try {
            List<HistoryDTO> histories = historyService.getHistoryByAction(action);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", histories);
            response.put("total", histories.size());
            response.put("action", action);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Lỗi khi lấy lịch sử theo action");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * 11. Lấy lịch sử trong khoảng thời gian
     * GET /api/history/account/{accountId}/date-range?startDate=2025-10-01T00:00:00&endDate=2025-10-31T23:59:59
     */
    @GetMapping("/account/{accountId}/date-range")
    public ResponseEntity<Map<String, Object>> getHistoryByDateRange(
            @PathVariable Integer accountId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDate) {
        try {
            List<HistoryDTO> histories = historyService.getHistoryByDateRange(accountId, startDate, endDate);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", histories);
            response.put("total", histories.size());
            response.put("startDate", startDate);
            response.put("endDate", endDate);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Lỗi khi lấy lịch sử theo khoảng thời gian");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * 12. Lấy các hoạt động gần đây
     * GET /api/history/recent?limit=20
     */
    @GetMapping("/recent")
    public ResponseEntity<Map<String, Object>> getRecentActivities(
            @RequestParam(defaultValue = "20") int limit) {
        try {
            List<HistoryDTO> histories = historyService.getRecentActivities(limit);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", histories);
            response.put("total", histories.size());
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Lỗi khi lấy hoạt động gần đây");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * 13. Đếm số lượng hành động
     * GET /api/history/account/{accountId}/count?action=create_booking
     */
    @GetMapping("/account/{accountId}/count")
    public ResponseEntity<Map<String, Object>> countActions(
            @PathVariable Integer accountId,
            @RequestParam String action) {
        try {
            Long count = historyService.countActionsByAccountId(accountId, action);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("count", count);
            response.put("action", action);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Lỗi khi đếm hành động");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * Helper method to get client IP address
     */
    private String getClientIpAddress(HttpServletRequest request) {
        String xForwardedFor = request.getHeader("X-Forwarded-For");
        if (xForwardedFor != null && !xForwardedFor.isEmpty()) {
            return xForwardedFor.split(",")[0].trim();
        }
        
        String xRealIp = request.getHeader("X-Real-IP");
        if (xRealIp != null && !xRealIp.isEmpty()) {
            return xRealIp;
        }
        
        return request.getRemoteAddr();
    }
}
