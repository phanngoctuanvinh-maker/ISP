package com.carrentleproject.drivenow.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public class CarDTO {
    private Integer carId;
    private String brand;
    private String model;
    private Integer seats;
    private String fuelType;
    private String licensePlate;
    private String insuranceInfo;
    private String imageUrl;
    private String location;
    private BigDecimal pricePerDay;
    private String status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private List<CarImageDTO> carImages;

    // Constructors
    public CarDTO() {
    }

    public CarDTO(Integer carId, String brand, String model, Integer seats, String fuelType,
            String licensePlate, String insuranceInfo, String imageUrl, String location,
            BigDecimal pricePerDay, String status, LocalDateTime createdAt, LocalDateTime updatedAt) {
        this.carId = carId;
        this.brand = brand;
        this.model = model;
        this.seats = seats;
        this.fuelType = fuelType;
        this.licensePlate = licensePlate;
        this.insuranceInfo = insuranceInfo;
        this.imageUrl = imageUrl;
        this.location = location;
        this.pricePerDay = pricePerDay;
        this.status = status;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    // Getters and Setters
    public Integer getCarId() {
        return carId;
    }

    public void setCarId(Integer carId) {
        this.carId = carId;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public Integer getSeats() {
        return seats;
    }

    public void setSeats(Integer seats) {
        this.seats = seats;
    }

    public String getFuelType() {
        return fuelType;
    }

    public void setFuelType(String fuelType) {
        this.fuelType = fuelType;
    }

    public String getLicensePlate() {
        return licensePlate;
    }

    public void setLicensePlate(String licensePlate) {
        this.licensePlate = licensePlate;
    }

    public String getInsuranceInfo() {
        return insuranceInfo;
    }

    public void setInsuranceInfo(String insuranceInfo) {
        this.insuranceInfo = insuranceInfo;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public BigDecimal getPricePerDay() {
        return pricePerDay;
    }

    public void setPricePerDay(BigDecimal pricePerDay) {
        this.pricePerDay = pricePerDay;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public List<CarImageDTO> getCarImages() {
        return carImages;
    }

    public void setCarImages(List<CarImageDTO> carImages) {
        this.carImages = carImages;
    }
}
