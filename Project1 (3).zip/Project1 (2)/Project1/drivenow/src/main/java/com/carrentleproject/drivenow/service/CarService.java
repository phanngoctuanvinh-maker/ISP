package com.carrentleproject.drivenow.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.carrentleproject.drivenow.dao.CarImageRepository;
import com.carrentleproject.drivenow.dao.CarRepository;
import com.carrentleproject.drivenow.dto.CarCreateRequest;
import com.carrentleproject.drivenow.dto.CarDTO;
import com.carrentleproject.drivenow.dto.CarImageCreateRequest;
import com.carrentleproject.drivenow.dto.CarImageDTO;
import com.carrentleproject.drivenow.dto.CarUpdateRequest;
import com.carrentleproject.drivenow.exception.ResourceNotFoundException;
import com.carrentleproject.drivenow.model.Car;
import com.carrentleproject.drivenow.model.CarImage;

@Service
@Transactional
public class CarService {

    @Autowired
    private CarRepository carRepository;

    @Autowired
    private CarImageRepository carImageRepository;

    // ==================== CAR CRUD OPERATIONS ====================

    /**
     * Thêm xe mới
     */
    public CarDTO createCar(CarCreateRequest request) {
        // Kiểm tra license plate đã tồn tại chưa
        if (carRepository.findByLicensePlate(request.getLicensePlate()).isPresent()) {
            throw new IllegalArgumentException("Biển số đã tồn tại: " + request.getLicensePlate());
        }

        Car car = new Car();
        car.setBrand(request.getBrand());
        car.setModel(request.getModel());
        car.setSeats(request.getSeats());
        car.setFuelType(request.getFuelType());
        car.setLicensePlate(request.getLicensePlate());
        car.setInsuranceInfo(request.getInsuranceInfo());
        car.setImageUrl(request.getImageUrl());
        car.setLocation(request.getLocation());
        car.setPricePerDay(request.getPricePerDay());
        car.setStatus(request.getStatus() != null ? request.getStatus() : "available");

        Car savedCar = carRepository.save(car);
        return convertToDTO(savedCar);
    }

    /**
     * Cập nhật thông tin xe
     */
    public CarDTO updateCar(Integer carId, CarUpdateRequest request) {
        Car car = carRepository.findById(carId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm được xe có ID: " + carId));

        // Update only non-null fields
        if (request.getBrand() != null) {
            car.setBrand(request.getBrand());
        }
        if (request.getModel() != null) {
            car.setModel(request.getModel());
        }
        if (request.getSeats() != null) {
            car.setSeats(request.getSeats());
        }
        if (request.getFuelType() != null) {
            car.setFuelType(request.getFuelType());
        }
        if (request.getLicensePlate() != null) {
            // Kiểm tra license plate mới có trùng với xe khác không
            carRepository.findByLicensePlate(request.getLicensePlate())
                    .ifPresent(existingCar -> {
                        if (!existingCar.getCarId().equals(carId)) {
                            throw new IllegalArgumentException("Biển số đã tồn tại: " + request.getLicensePlate());
                        }
                    });
            car.setLicensePlate(request.getLicensePlate());
        }
        if (request.getInsuranceInfo() != null) {
            car.setInsuranceInfo(request.getInsuranceInfo());
        }
        if (request.getImageUrl() != null) {
            car.setImageUrl(request.getImageUrl());
        }
        if (request.getLocation() != null) {
            car.setLocation(request.getLocation());
        }
        if (request.getPricePerDay() != null) {
            car.setPricePerDay(request.getPricePerDay());
        }
        if (request.getStatus() != null) {
            car.setStatus(request.getStatus());
        }

        Car updatedCar = carRepository.save(car);
        return convertToDTO(updatedCar);
    }

    /**
     * Xóa xe
     */
    public void deleteCar(Integer carId) {
        Car car = carRepository.findById(carId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm được xe có ID: " + carId));

        // Xóa tất cả hình ảnh liên quan
        carImageRepository.deleteByCarCarId(carId);

        // Xóa xe
        carRepository.delete(car);
    }

    /**
     * Cập nhật status của xe
     */
    public CarDTO updateCarStatus(Integer carId, String status) {
        Car car = carRepository.findById(carId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm được xe có ID: " + carId));

        // Validate status
        if (!status.matches("available|rented|maintenance")) {
            throw new IllegalArgumentException("Trạng thái không hợp lệ. Phải là: available, rented, hoặc maintenance");
        }

        car.setStatus(status);
        Car updatedCar = carRepository.save(car);
        return convertToDTO(updatedCar);
    }

    /**
     * Lấy chi tiết xe theo ID
     */
    public CarDTO getCarById(Integer carId) {
        Car car = carRepository.findById(carId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm được xe có ID: " + carId));
        return convertToDTOWithImages(car);
    }

    /**
     * Lấy tất cả xe
     */
    public List<CarDTO> getAllCars() {
        return carRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Tìm xe theo status
     */
    public List<CarDTO> getCarsByStatus(String status) {
        return carRepository.findByStatus(status).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Tìm xe theo location
     */
    public List<CarDTO> getCarsByLocation(String location) {
        return carRepository.findByLocation(location).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Tìm xe available theo location
     */
    public List<CarDTO> getAvailableCarsByLocation(String location) {
        return carRepository.findAvailableCarsByLocation(location).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Tìm kiếm xe theo nhiều tiêu chí
     */
    public List<CarDTO> searchCars(String brand, String model, Integer seats, String status, String location) {
        return carRepository.searchCars(brand, model, seats, status, location).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    // ==================== CAR IMAGE OPERATIONS ====================

    /**
     * Thêm hình ảnh cho xe
     */
    public CarImageDTO addCarImage(CarImageCreateRequest request) {
        Car car = carRepository.findById(request.getCarId())
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm được xe có ID: " + request.getCarId()));

        CarImage carImage = new CarImage();
        carImage.setCar(car);
        carImage.setType(request.getType());
        carImage.setUrl(request.getUrl());
        carImage.setDescription(request.getDescription());

        CarImage savedImage = carImageRepository.save(carImage);
        return convertImageToDTO(savedImage);
    }

    /**
     * Lấy tất cả hình ảnh của xe
     */
    public List<CarImageDTO> getCarImages(Integer carId) {
        // Kiểm tra xe có tồn tại không
        if (!carRepository.existsById(carId)) {
            throw new ResourceNotFoundException("Không tìm được xe có ID: " + carId);
        }

        return carImageRepository.findByCarCarId(carId).stream()
                .map(this::convertImageToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Xóa hình ảnh
     */
    public void deleteCarImage(Integer imageId) {
        CarImage carImage = carImageRepository.findById(imageId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm được hình ảnh xe có ID: " + imageId));

        carImageRepository.delete(carImage);
    }

    /**
     * Xóa tất cả hình ảnh của xe
     */
    public void deleteAllCarImages(Integer carId) {
        // Kiểm tra xe có tồn tại không
        if (!carRepository.existsById(carId)) {
            throw new ResourceNotFoundException("Không tìm được xe có ID: " + carId);
        }

        carImageRepository.deleteByCarCarId(carId);
    }

    // ==================== HELPER METHODS ====================

    /**
     * Convert Car entity to CarDTO (without images)
     */
    private CarDTO convertToDTO(Car car) {
        CarDTO dto = new CarDTO();
        dto.setCarId(car.getCarId());
        dto.setBrand(car.getBrand());
        dto.setModel(car.getModel());
        dto.setSeats(car.getSeats());
        dto.setFuelType(car.getFuelType());
        dto.setLicensePlate(car.getLicensePlate());
        dto.setInsuranceInfo(car.getInsuranceInfo());
        dto.setImageUrl(car.getImageUrl());
        dto.setLocation(car.getLocation());
        dto.setPricePerDay(car.getPricePerDay());
        dto.setStatus(car.getStatus());
        dto.setCreatedAt(car.getCreatedAt());
        dto.setUpdatedAt(car.getUpdatedAt());
        return dto;
    }

    /**
     * Convert Car entity to CarDTO (with images)
     */
    private CarDTO convertToDTOWithImages(Car car) {
        CarDTO dto = convertToDTO(car);

        // Load and convert car images
        List<CarImageDTO> imageDTOs = carImageRepository.findByCarCarId(car.getCarId()).stream()
                .map(this::convertImageToDTO)
                .collect(Collectors.toList());

        dto.setCarImages(imageDTOs);
        return dto;
    }

    /**
     * Convert CarImage entity to CarImageDTO
     */
    private CarImageDTO convertImageToDTO(CarImage carImage) {
        CarImageDTO dto = new CarImageDTO();
        dto.setCarImageId(carImage.getCarImageId());
        dto.setCarId(carImage.getCar().getCarId());
        dto.setType(carImage.getType());
        dto.setUrl(carImage.getUrl());
        dto.setDescription(carImage.getDescription());
        dto.setCreatedAt(carImage.getCreatedAt());
        return dto;
    }
}
