package com.carrentleproject.drivenow.model;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/**
 * Entity quản lý lịch giao/nhận xe
 * Tracks pickup and return schedules for bookings
 */
@Entity
@Table(name = "delivery_schedules")
public class DeliverySchedule {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "schedule_id")
    private Integer scheduleId;

    @ManyToOne
    @JoinColumn(name = "booking_id", nullable = false)
    private Booking booking;

    @ManyToOne
    @JoinColumn(name = "driver_id")
    private Driver driver; // Tài xế được phân công giao/nhận xe

    @Column(name = "schedule_type", nullable = false, length = 20)
    private String scheduleType; // pickup, return

    @Column(name = "scheduled_time", nullable = false)
    private LocalDateTime scheduledTime; // Thời gian dự kiến giao/nhận

    @Column(name = "actual_time")
    private LocalDateTime actualTime; // Thời gian thực tế giao/nhận

    @Column(name = "location", nullable = false, length = 255)
    private String location; // Địa điểm giao/nhận

    @Column(name = "status", nullable = false, length = 20)
    private String status = "scheduled"; // scheduled, in_progress, completed, cancelled, delayed

    @Column(name = "notes", columnDefinition = "TEXT")
    private String notes; // Ghi chú về lịch giao nhận

    @Column(name = "delivery_method", length = 50)
    private String deliveryMethod; // self_pickup (tự đến lấy), home_delivery (giao tận nơi)

    @Column(name = "contact_person", length = 100)
    private String contactPerson; // Người liên hệ

    @Column(name = "contact_phone", length = 20)
    private String contactPhone; // SĐT liên hệ

    @Column(name = "fuel_level_before")
    private Integer fuelLevelBefore; // Mức nhiên liệu trước khi giao (%)

    @Column(name = "fuel_level_after")
    private Integer fuelLevelAfter; // Mức nhiên liệu khi nhận lại (%)

    @Column(name = "mileage_before")
    private Integer mileageBefore; // Số km trước khi giao

    @Column(name = "mileage_after")
    private Integer mileageAfter; // Số km khi nhận lại

    @Column(name = "car_condition_before", columnDefinition = "TEXT")
    private String carConditionBefore; // Tình trạng xe trước khi giao

    @Column(name = "car_condition_after", columnDefinition = "TEXT")
    private String carConditionAfter; // Tình trạng xe khi nhận lại

    @Column(name = "image_url_before", length = 500)
    private String imageUrlBefore; // Ảnh xe trước khi giao (có thể nhiều ảnh, lưu dạng JSON array)

    @Column(name = "image_url_after", length = 500)
    private String imageUrlAfter; // Ảnh xe khi nhận lại

    @Column(name = "delay_reason", columnDefinition = "TEXT")
    private String delayReason; // Lý do trễ hẹn (nếu có)

    @Column(name = "cancellation_reason", columnDefinition = "TEXT")
    private String cancellationReason; // Lý do hủy lịch

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    // Constructors
    public DeliverySchedule() {
    }

    public DeliverySchedule(Booking booking, Driver driver, String scheduleType, 
                           LocalDateTime scheduledTime, String location, String deliveryMethod) {
        this.booking = booking;
        this.driver = driver;
        this.scheduleType = scheduleType;
        this.scheduledTime = scheduledTime;
        this.location = location;
        this.deliveryMethod = deliveryMethod;
        this.status = "scheduled";
    }

    // Getters and Setters
    public Integer getScheduleId() {
        return scheduleId;
    }

    public void setScheduleId(Integer scheduleId) {
        this.scheduleId = scheduleId;
    }

    public Booking getBooking() {
        return booking;
    }

    public void setBooking(Booking booking) {
        this.booking = booking;
    }

    public Driver getDriver() {
        return driver;
    }

    public void setDriver(Driver driver) {
        this.driver = driver;
    }

    public String getScheduleType() {
        return scheduleType;
    }

    public void setScheduleType(String scheduleType) {
        this.scheduleType = scheduleType;
    }

    public LocalDateTime getScheduledTime() {
        return scheduledTime;
    }

    public void setScheduledTime(LocalDateTime scheduledTime) {
        this.scheduledTime = scheduledTime;
    }

    public LocalDateTime getActualTime() {
        return actualTime;
    }

    public void setActualTime(LocalDateTime actualTime) {
        this.actualTime = actualTime;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getDeliveryMethod() {
        return deliveryMethod;
    }

    public void setDeliveryMethod(String deliveryMethod) {
        this.deliveryMethod = deliveryMethod;
    }

    public String getContactPerson() {
        return contactPerson;
    }

    public void setContactPerson(String contactPerson) {
        this.contactPerson = contactPerson;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public Integer getFuelLevelBefore() {
        return fuelLevelBefore;
    }

    public void setFuelLevelBefore(Integer fuelLevelBefore) {
        this.fuelLevelBefore = fuelLevelBefore;
    }

    public Integer getFuelLevelAfter() {
        return fuelLevelAfter;
    }

    public void setFuelLevelAfter(Integer fuelLevelAfter) {
        this.fuelLevelAfter = fuelLevelAfter;
    }

    public Integer getMileageBefore() {
        return mileageBefore;
    }

    public void setMileageBefore(Integer mileageBefore) {
        this.mileageBefore = mileageBefore;
    }

    public Integer getMileageAfter() {
        return mileageAfter;
    }

    public void setMileageAfter(Integer mileageAfter) {
        this.mileageAfter = mileageAfter;
    }

    public String getCarConditionBefore() {
        return carConditionBefore;
    }

    public void setCarConditionBefore(String carConditionBefore) {
        this.carConditionBefore = carConditionBefore;
    }

    public String getCarConditionAfter() {
        return carConditionAfter;
    }

    public void setCarConditionAfter(String carConditionAfter) {
        this.carConditionAfter = carConditionAfter;
    }

    public String getImageUrlBefore() {
        return imageUrlBefore;
    }

    public void setImageUrlBefore(String imageUrlBefore) {
        this.imageUrlBefore = imageUrlBefore;
    }

    public String getImageUrlAfter() {
        return imageUrlAfter;
    }

    public void setImageUrlAfter(String imageUrlAfter) {
        this.imageUrlAfter = imageUrlAfter;
    }

    public String getDelayReason() {
        return delayReason;
    }

    public void setDelayReason(String delayReason) {
        this.delayReason = delayReason;
    }

    public String getCancellationReason() {
        return cancellationReason;
    }

    public void setCancellationReason(String cancellationReason) {
        this.cancellationReason = cancellationReason;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public String toString() {
        return "DeliverySchedule{" +
                "scheduleId=" + scheduleId +
                ", scheduleType='" + scheduleType + '\'' +
                ", scheduledTime=" + scheduledTime +
                ", actualTime=" + actualTime +
                ", location='" + location + '\'' +
                ", status='" + status + '\'' +
                ", deliveryMethod='" + deliveryMethod + '\'' +
                '}';
    }
}
