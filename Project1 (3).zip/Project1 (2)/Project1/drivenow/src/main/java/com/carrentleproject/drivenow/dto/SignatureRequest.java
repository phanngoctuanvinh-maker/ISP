package com.carrentleproject.drivenow.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/**
 * Request DTO để ký hợp đồng
 */
public class SignatureRequest {

    @NotBlank(message = "URL chữ ký là bắt buộc")
    @Size(max = 500, message = "URL không được vượt quá 500 ký tự")
    private String signatureUrl;

    // Constructors
    public SignatureRequest() {
    }

    public SignatureRequest(String signatureUrl) {
        this.signatureUrl = signatureUrl;
    }

    // Getters and Setters
    public String getSignatureUrl() {
        return signatureUrl;
    }

    public void setSignatureUrl(String signatureUrl) {
        this.signatureUrl = signatureUrl;
    }
}
