package com.carrentleproject.drivenow.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.carrentleproject.drivenow.dto.RentalContractCreateRequest;
import com.carrentleproject.drivenow.dto.RentalContractDTO;
import com.carrentleproject.drivenow.dto.RentalContractUpdateRequest;
import com.carrentleproject.drivenow.dto.SignatureRequest;
import com.carrentleproject.drivenow.service.RentalContractService;

import jakarta.validation.Valid;

/**
 * Controller quản lý hợp đồng điện tử
 * Electronic Rental Contract Management
 */
@RestController
@RequestMapping("/api/rental-contracts")
public class RentalContractController {

    @Autowired
    private RentalContractService contractService;

    /**
     * 1. Tạo hợp đồng cho booking
     * POST /api/rental-contracts
     */
    @PostMapping
    public ResponseEntity<Map<String, Object>> createContract(
            @Valid @RequestBody RentalContractCreateRequest request) {
        try {
            RentalContractDTO contract = contractService.createContract(request);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Tạo hợp đồng thành công");
            response.put("data", contract);
            
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (IllegalArgumentException e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Lỗi khi tạo hợp đồng: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * 2. Lấy thông tin hợp đồng theo ID
     * GET /api/rental-contracts/{id}
     */
    @GetMapping("/{id}")
    public ResponseEntity<Map<String, Object>> getContractById(@PathVariable Integer id) {
        try {
            RentalContractDTO contract = contractService.getContractById(id);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", contract);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Không tìm thấy hợp đồng");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }

    /**
     * 3. Lấy hợp đồng theo contract number
     * GET /api/rental-contracts/number/{contractNumber}
     */
    @GetMapping("/number/{contractNumber}")
    public ResponseEntity<Map<String, Object>> getContractByNumber(@PathVariable String contractNumber) {
        try {
            RentalContractDTO contract = contractService.getContractByNumber(contractNumber);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", contract);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Không tìm thấy hợp đồng");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }

    /**
     * 4. Lấy hợp đồng theo booking ID
     * GET /api/rental-contracts/booking/{bookingId}
     */
    @GetMapping("/booking/{bookingId}")
    public ResponseEntity<Map<String, Object>> getContractByBookingId(@PathVariable Integer bookingId) {
        try {
            RentalContractDTO contract = contractService.getContractByBookingId(bookingId);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", contract);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Không tìm thấy hợp đồng cho booking này");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }

    /**
     * 5. Lấy danh sách hợp đồng của customer
     * GET /api/rental-contracts/customer/{customerId}
     */
    @GetMapping("/customer/{customerId}")
    public ResponseEntity<Map<String, Object>> getContractsByCustomerId(@PathVariable Integer customerId) {
        try {
            List<RentalContractDTO> contracts = contractService.getContractsByCustomerId(customerId);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", contracts);
            response.put("total", contracts.size());
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Lỗi khi lấy danh sách hợp đồng");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * 6. Lấy danh sách hợp đồng theo status
     * GET /api/rental-contracts/status?status=active
     */
    @GetMapping("/status")
    public ResponseEntity<Map<String, Object>> getContractsByStatus(
            @RequestParam(required = false, defaultValue = "active") String status) {
        try {
            List<RentalContractDTO> contracts = contractService.getContractsByStatus(status);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", contracts);
            response.put("total", contracts.size());
            response.put("status", status);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Lỗi khi lấy danh sách hợp đồng");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * 7. Lấy danh sách hợp đồng đang hoạt động
     * GET /api/rental-contracts/active
     */
    @GetMapping("/active")
    public ResponseEntity<Map<String, Object>> getActiveContracts() {
        try {
            List<RentalContractDTO> contracts = contractService.getActiveContracts();
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", contracts);
            response.put("total", contracts.size());
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Lỗi khi lấy danh sách hợp đồng");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * 8. Lấy danh sách hợp đồng sắp hết hạn (7 ngày)
     * GET /api/rental-contracts/expiring
     */
    @GetMapping("/expiring")
    public ResponseEntity<Map<String, Object>> getExpiringContracts() {
        try {
            List<RentalContractDTO> contracts = contractService.getExpiringContracts();
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", contracts);
            response.put("total", contracts.size());
            response.put("message", "Hợp đồng sắp hết hạn trong 7 ngày");
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Lỗi khi lấy danh sách hợp đồng");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * 9. Cập nhật thông tin hợp đồng
     * PUT /api/rental-contracts/{id}
     */
    @PutMapping("/{id}")
    public ResponseEntity<Map<String, Object>> updateContract(
            @PathVariable Integer id,
            @Valid @RequestBody RentalContractUpdateRequest request) {
        try {
            RentalContractDTO contract = contractService.updateContract(id, request);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Cập nhật hợp đồng thành công");
            response.put("data", contract);
            
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Lỗi khi cập nhật hợp đồng");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * 10. Lessor ký hợp đồng
     * PATCH /api/rental-contracts/{id}/sign-lessor
     */
    @PatchMapping("/{id}/sign-lessor")
    public ResponseEntity<Map<String, Object>> signByLessor(
            @PathVariable Integer id,
            @Valid @RequestBody SignatureRequest request) {
        try {
            RentalContractDTO contract = contractService.signByLessor(id, request);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Bên cho thuê đã ký hợp đồng thành công");
            response.put("data", contract);
            
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Lỗi khi ký hợp đồng");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * 11. Lessee ký hợp đồng
     * PATCH /api/rental-contracts/{id}/sign-lessee
     */
    @PatchMapping("/{id}/sign-lessee")
    public ResponseEntity<Map<String, Object>> signByLessee(
            @PathVariable Integer id,
            @Valid @RequestBody SignatureRequest request) {
        try {
            RentalContractDTO contract = contractService.signByLessee(id, request);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Bên thuê đã ký hợp đồng thành công");
            response.put("data", contract);
            
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Lỗi khi ký hợp đồng");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * 12. Hoàn thành hợp đồng
     * PATCH /api/rental-contracts/{id}/complete
     */
    @PatchMapping("/{id}/complete")
    public ResponseEntity<Map<String, Object>> completeContract(@PathVariable Integer id) {
        try {
            RentalContractDTO contract = contractService.completeContract(id);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Hợp đồng đã hoàn thành");
            response.put("data", contract);
            
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Lỗi khi hoàn thành hợp đồng");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * 13. Hủy hợp đồng
     * PATCH /api/rental-contracts/{id}/cancel
     */
    @PatchMapping("/{id}/cancel")
    public ResponseEntity<Map<String, Object>> cancelContract(
            @PathVariable Integer id,
            @RequestParam(required = false) String reason) {
        try {
            RentalContractDTO contract = contractService.cancelContract(id, reason);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Hợp đồng đã hủy");
            response.put("data", contract);
            
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Lỗi khi hủy hợp đồng");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * 14. Lưu trữ hợp đồng
     * PATCH /api/rental-contracts/{id}/archive
     */
    @PatchMapping("/{id}/archive")
    public ResponseEntity<Map<String, Object>> archiveContract(@PathVariable Integer id) {
        try {
            RentalContractDTO contract = contractService.archiveContract(id);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Hợp đồng đã lưu trữ");
            response.put("data", contract);
            
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Lỗi khi lưu trữ hợp đồng");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * 15. Cập nhật hợp đồng hết hạn (scheduled task)
     * PATCH /api/rental-contracts/update-expired
     */
    @PatchMapping("/update-expired")
    public ResponseEntity<Map<String, Object>> updateExpiredContracts() {
        try {
            contractService.updateExpiredContracts();
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Đã cập nhật trạng thái hợp đồng hết hạn");
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Lỗi khi cập nhật hợp đồng hết hạn");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }
}
