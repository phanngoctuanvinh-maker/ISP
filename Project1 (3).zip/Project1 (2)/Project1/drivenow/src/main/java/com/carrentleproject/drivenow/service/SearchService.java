package com.carrentleproject.drivenow.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.carrentleproject.drivenow.dao.CarRepository;
import com.carrentleproject.drivenow.dto.CarDTO;
import com.carrentleproject.drivenow.dto.CarSearchRequest;
import com.carrentleproject.drivenow.dto.CarSearchResponse;
import com.carrentleproject.drivenow.model.Car;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;

@Service
@Transactional(readOnly = true)
public class SearchService {

    @Autowired
    private CarRepository carRepository;

    @Autowired
    private EntityManager entityManager;

    /**
     * Tìm kiếm xe với các bộ lọc nâng cao
     */
    public CarSearchResponse searchCars(CarSearchRequest request) {
        // Build dynamic query using Criteria API
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Car> cq = cb.createQuery(Car.class);
        Root<Car> car = cq.from(Car.class);

        List<Predicate> predicates = new ArrayList<>();

        // Filter by fuel type (loại nhiên liệu)
        if (request.getFuelType() != null && !request.getFuelType().trim().isEmpty()) {
            predicates.add(cb.equal(
                cb.lower(car.get("fuelType")), 
                request.getFuelType().toLowerCase()
            ));
        }

        // Filter by price range (khoảng giá)
        if (request.getPriceMin() != null) {
            predicates.add(cb.greaterThanOrEqualTo(
                car.get("pricePerDay"), 
                request.getPriceMin()
            ));
        }
        if (request.getPriceMax() != null) {
            predicates.add(cb.lessThanOrEqualTo(
                car.get("pricePerDay"), 
                request.getPriceMax()
            ));
        }

        // Filter by brand (hãng xe)
        if (request.getBrand() != null && !request.getBrand().trim().isEmpty()) {
            predicates.add(cb.equal(
                cb.lower(car.get("brand")), 
                request.getBrand().toLowerCase()
            ));
        }

        // Filter by model (optional)
        if (request.getModel() != null && !request.getModel().trim().isEmpty()) {
            predicates.add(cb.like(
                cb.lower(car.get("model")), 
                "%" + request.getModel().toLowerCase() + "%"
            ));
        }

        // Filter by seats (số ghế)
        if (request.getSeats() != null) {
            predicates.add(cb.greaterThanOrEqualTo(
                car.get("seats"), 
                request.getSeats()
            ));
        }

        // Filter by location (địa điểm)
        if (request.getLocation() != null && !request.getLocation().trim().isEmpty()) {
            predicates.add(cb.like(
                cb.lower(car.get("location")), 
                "%" + request.getLocation().toLowerCase() + "%"
            ));
        }

        // Filter by status (mặc định là available)
        String status = request.getStatus();
        if (status == null || status.trim().isEmpty()) {
            status = "available"; // Default to available cars only
        }
        predicates.add(cb.equal(car.get("status"), status));

        // Combine all predicates with AND
        cq.where(cb.and(predicates.toArray(Predicate[]::new)));

        // Apply sorting
        applySorting(cb, cq, car, request.getSortBy());

        // Execute query
        TypedQuery<Car> query = entityManager.createQuery(cq);
        List<Car> cars = query.getResultList();

        // Convert to DTOs
        List<CarDTO> carDTOs = cars.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());

        // Build response
        CarSearchResponse response = new CarSearchResponse();
        response.setCars(carDTOs);
        response.setTotalResults(carDTOs.size());
        response.setSearchCriteria(request);

        return response;
    }

    /**
     * Apply sorting to the query
     */
    private void applySorting(CriteriaBuilder cb, CriteriaQuery<Car> cq, Root<Car> car, String sortBy) {
        if (sortBy == null || sortBy.trim().isEmpty()) {
            // Default sorting: newest first
            cq.orderBy(cb.desc(car.get("createdAt")));
            return;
        }

        switch (sortBy.toLowerCase()) {
            case "price_asc" -> cq.orderBy(cb.asc(car.get("pricePerDay")));
            case "price_desc" -> cq.orderBy(cb.desc(car.get("pricePerDay")));
            case "seats_asc" -> cq.orderBy(cb.asc(car.get("seats")));
            case "seats_desc" -> cq.orderBy(cb.desc(car.get("seats")));
            case "brand" -> cq.orderBy(cb.asc(car.get("brand")));
            case "newest" -> cq.orderBy(cb.desc(car.get("createdAt")));
            case "oldest" -> cq.orderBy(cb.asc(car.get("createdAt")));
            default -> cq.orderBy(cb.desc(car.get("createdAt")));
        }
    }

    /**
     * Tìm kiếm xe theo loại nhiên liệu
     */
    public List<CarDTO> searchByFuelType(String fuelType) {
        return carRepository.findAll().stream()
                .filter(car -> car.getFuelType() != null && 
                              car.getFuelType().equalsIgnoreCase(fuelType) &&
                              "available".equals(car.getStatus()))
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Tìm kiếm xe theo khoảng giá
     */
    public List<CarDTO> searchByPriceRange(BigDecimal priceMin, BigDecimal priceMax) {
        return carRepository.findAll().stream()
                .filter(car -> {
                    BigDecimal price = car.getPricePerDay();
                    if (price == null) return false;
                    boolean minOk = (priceMin == null || price.compareTo(priceMin) >= 0);
                    boolean maxOk = (priceMax == null || price.compareTo(priceMax) <= 0);
                    return minOk && maxOk && "available".equals(car.getStatus());
                })
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Tìm kiếm xe theo hãng
     */
    public List<CarDTO> searchByBrand(String brand) {
        return carRepository.findByBrand(brand).stream()
                .filter(car -> "available".equals(car.getStatus()))
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Tìm kiếm xe theo số ghế
     */
    public List<CarDTO> searchBySeats(Integer seats) {
        return carRepository.findBySeatsGreaterThanEqual(seats).stream()
                .filter(car -> "available".equals(car.getStatus()))
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Lấy danh sách loại nhiên liệu có sẵn
     */
    public List<String> getAvailableFuelTypes() {
        return carRepository.findAll().stream()
                .map(Car::getFuelType)
                .filter(fuelType -> fuelType != null && !fuelType.trim().isEmpty())
                .distinct()
                .sorted()
                .collect(Collectors.toList());
    }

    /**
     * Lấy danh sách hãng xe có sẵn
     */
    public List<String> getAvailableBrands() {
        return carRepository.findAll().stream()
                .map(Car::getBrand)
                .filter(brand -> brand != null && !brand.trim().isEmpty())
                .distinct()
                .sorted()
                .collect(Collectors.toList());
    }

    /**
     * Lấy khoảng giá (min-max)
     */
    public PriceRange getPriceRange() {
        List<Car> cars = carRepository.findAll();
        if (cars.isEmpty()) {
            return new PriceRange(BigDecimal.ZERO, BigDecimal.ZERO);
        }

        BigDecimal minPrice = cars.stream()
                .map(Car::getPricePerDay)
                .filter(price -> price != null)
                .min(BigDecimal::compareTo)
                .orElse(BigDecimal.ZERO);

        BigDecimal maxPrice = cars.stream()
                .map(Car::getPricePerDay)
                .filter(price -> price != null)
                .max(BigDecimal::compareTo)
                .orElse(BigDecimal.ZERO);

        return new PriceRange(minPrice, maxPrice);
    }

    /**
     * Convert Car entity to CarDTO
     */
    private CarDTO convertToDTO(Car car) {
        CarDTO dto = new CarDTO();
        dto.setCarId(car.getCarId());
        dto.setBrand(car.getBrand());
        dto.setModel(car.getModel());
        dto.setSeats(car.getSeats());
        dto.setFuelType(car.getFuelType());
        dto.setLicensePlate(car.getLicensePlate());
        dto.setInsuranceInfo(car.getInsuranceInfo());
        dto.setImageUrl(car.getImageUrl());
        dto.setLocation(car.getLocation());
        dto.setPricePerDay(car.getPricePerDay());
        dto.setStatus(car.getStatus());
        dto.setCreatedAt(car.getCreatedAt());
        dto.setUpdatedAt(car.getUpdatedAt());
        return dto;
    }

    /**
     * Inner class for price range
     */
    public static class PriceRange {
        private BigDecimal min;
        private BigDecimal max;

        public PriceRange(BigDecimal min, BigDecimal max) {
            this.min = min;
            this.max = max;
        }

        public BigDecimal getMin() {
            return min;
        }

        public void setMin(BigDecimal min) {
            this.min = min;
        }

        public BigDecimal getMax() {
            return max;
        }

        public void setMax(BigDecimal max) {
            this.max = max;
        }
    }
}
