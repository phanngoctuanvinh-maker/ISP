package com.carrentleproject.drivenow.controller;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.carrentleproject.drivenow.dto.DeliveryScheduleCreateRequest;
import com.carrentleproject.drivenow.dto.DeliveryScheduleDTO;
import com.carrentleproject.drivenow.dto.DeliveryScheduleUpdateRequest;
import com.carrentleproject.drivenow.service.DeliveryScheduleService;

import jakarta.validation.Valid;

/**
 * Controller cho Delivery Schedule APIs
 * Quản lý lịch giao/nhận xe
 */
@RestController
@RequestMapping("/api/delivery-schedules")
@Validated
public class DeliveryScheduleController {

    @Autowired
    private DeliveryScheduleService scheduleService;

    /**
     * API 1: Tạo lịch giao/nhận xe mới
     * POST /api/delivery-schedules
     * 
     * Request body:
     * {
     *   "bookingId": 1,
     *   "driverId": 2,
     *   "scheduleType": "pickup",
     *   "scheduledTime": "2024-01-15T08:00:00",
     *   "location": "123 Nguyễn Văn Linh, TP HCM",
     *   "deliveryMethod": "home_delivery",
     *   "contactPerson": "Nguyễn Văn A",
     *   "contactPhone": "0901234567",
     *   "notes": "Giao xe tận nơi"
     * }
     */
    @PostMapping
    public ResponseEntity<?> createSchedule(@Valid @RequestBody DeliveryScheduleCreateRequest request) {
        try {
            DeliveryScheduleDTO schedule = scheduleService.createSchedule(request);
            return ResponseEntity.status(HttpStatus.CREATED).body(schedule);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Lỗi khi tạo lịch: " + e.getMessage());
        }
    }

    /**
     * API 2: Lấy chi tiết lịch theo ID
     * GET /api/delivery-schedules/{id}
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getScheduleById(@PathVariable("id") Integer scheduleId) {
        try {
            DeliveryScheduleDTO schedule = scheduleService.getScheduleById(scheduleId);
            return ResponseEntity.ok(schedule);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    /**
     * API 3: Lấy tất cả lịch của booking
     * GET /api/delivery-schedules/booking/{bookingId}
     */
    @GetMapping("/booking/{bookingId}")
    public ResponseEntity<?> getSchedulesByBooking(@PathVariable Integer bookingId) {
        try {
            List<DeliveryScheduleDTO> schedules = scheduleService.getSchedulesByBooking(bookingId);
            return ResponseEntity.ok(schedules);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Lỗi khi lấy danh sách lịch: " + e.getMessage());
        }
    }

    /**
     * API 4: Lấy tất cả lịch của tài xế
     * GET /api/delivery-schedules/driver/{driverId}
     */
    @GetMapping("/driver/{driverId}")
    public ResponseEntity<?> getSchedulesByDriver(@PathVariable Integer driverId) {
        try {
            List<DeliveryScheduleDTO> schedules = scheduleService.getSchedulesByDriver(driverId);
            return ResponseEntity.ok(schedules);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Lỗi khi lấy danh sách lịch: " + e.getMessage());
        }
    }

    /**
     * API 5: Lấy lịch của tài xế theo status
     * GET /api/delivery-schedules/driver/{driverId}/status?status=scheduled
     */
    @GetMapping("/driver/{driverId}/status")
    public ResponseEntity<?> getSchedulesByDriverAndStatus(
            @PathVariable Integer driverId,
            @RequestParam String status) {
        try {
            List<DeliveryScheduleDTO> schedules = scheduleService.getSchedulesByDriverAndStatus(driverId, status);
            return ResponseEntity.ok(schedules);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Lỗi khi lấy danh sách lịch: " + e.getMessage());
        }
    }

    /**
     * API 6: Lấy lịch theo status
     * GET /api/delivery-schedules/status?status=scheduled
     */
    @GetMapping("/status")
    public ResponseEntity<?> getSchedulesByStatus(@RequestParam String status) {
        try {
            List<DeliveryScheduleDTO> schedules = scheduleService.getSchedulesByStatus(status);
            return ResponseEntity.ok(schedules);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Lỗi khi lấy danh sách lịch: " + e.getMessage());
        }
    }

    /**
     * API 7: Lấy lịch sắp đến (scheduled trong 24h tới)
     * GET /api/delivery-schedules/upcoming
     */
    @GetMapping("/upcoming")
    public ResponseEntity<?> getUpcomingSchedules() {
        try {
            List<DeliveryScheduleDTO> schedules = scheduleService.getUpcomingSchedules();
            return ResponseEntity.ok(schedules);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Lỗi khi lấy danh sách lịch sắp đến: " + e.getMessage());
        }
    }

    /**
     * API 8: Lấy lịch trễ hẹn
     * GET /api/delivery-schedules/overdue
     */
    @GetMapping("/overdue")
    public ResponseEntity<?> getOverdueSchedules() {
        try {
            List<DeliveryScheduleDTO> schedules = scheduleService.getOverdueSchedules();
            return ResponseEntity.ok(schedules);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Lỗi khi lấy danh sách lịch trễ: " + e.getMessage());
        }
    }

    /**
     * API 9: Assign tài xế cho lịch
     * PATCH /api/delivery-schedules/{id}/assign-driver?driverId=2
     */
    @PatchMapping("/{id}/assign-driver")
    public ResponseEntity<?> assignDriver(
            @PathVariable("id") Integer scheduleId,
            @RequestParam Integer driverId) {
        try {
            DeliveryScheduleDTO schedule = scheduleService.assignDriver(scheduleId, driverId);
            return ResponseEntity.ok(schedule);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Lỗi khi assign tài xế: " + e.getMessage());
        }
    }

    /**
     * API 10: Bắt đầu giao/nhận xe (scheduled → in_progress)
     * PATCH /api/delivery-schedules/{id}/start
     */
    @PatchMapping("/{id}/start")
    public ResponseEntity<?> startDelivery(@PathVariable("id") Integer scheduleId) {
        try {
            DeliveryScheduleDTO schedule = scheduleService.startDelivery(scheduleId);
            return ResponseEntity.ok(schedule);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Lỗi khi bắt đầu giao/nhận: " + e.getMessage());
        }
    }

    /**
     * API 11: Hoàn thành giao/nhận xe (in_progress → completed)
     * PATCH /api/delivery-schedules/{id}/complete
     * 
     * Request body:
     * {
     *   "actualTime": "2024-01-15T08:30:00",
     *   "fuelLevel": 100,
     *   "mileage": 15000,
     *   "carCondition": "Tốt, không trầy xước",
     *   "imageUrl": "http://...",
     *   "notes": "Giao xe thành công"
     * }
     */
    @PatchMapping("/{id}/complete")
    public ResponseEntity<?> completeDelivery(
            @PathVariable("id") Integer scheduleId,
            @Valid @RequestBody DeliveryScheduleUpdateRequest request) {
        try {
            DeliveryScheduleDTO schedule = scheduleService.completeDelivery(scheduleId, request);
            return ResponseEntity.ok(schedule);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Lỗi khi hoàn thành giao/nhận: " + e.getMessage());
        }
    }

    /**
     * API 12: Hủy lịch giao/nhận
     * PATCH /api/delivery-schedules/{id}/cancel?reason=...
     */
    @PatchMapping("/{id}/cancel")
    public ResponseEntity<?> cancelSchedule(
            @PathVariable("id") Integer scheduleId,
            @RequestParam String reason) {
        try {
            DeliveryScheduleDTO schedule = scheduleService.cancelSchedule(scheduleId, reason);
            return ResponseEntity.ok(schedule);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Lỗi khi hủy lịch: " + e.getMessage());
        }
    }

    /**
     * API 13: Đổi lịch (reschedule)
     * PATCH /api/delivery-schedules/{id}/reschedule?newTime=2024-01-16T10:00:00
     */
    @PatchMapping("/{id}/reschedule")
    public ResponseEntity<?> rescheduleDelivery(
            @PathVariable("id") Integer scheduleId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime newTime) {
        try {
            DeliveryScheduleDTO schedule = scheduleService.rescheduleDelivery(scheduleId, newTime);
            return ResponseEntity.ok(schedule);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Lỗi khi đổi lịch: " + e.getMessage());
        }
    }
}
