package com.carrentleproject.drivenow.dto;

import java.time.LocalDateTime;

import jakarta.validation.constraints.Size;

public class BookingRescheduleRequest {

    private LocalDateTime newPickupDate;

    private LocalDateTime newReturnDate;

    @Size(max = 1000, message = "Lý do không được vượt quá 1000 ký tự")
    private String rescheduleReason;

    // Constructors
    public BookingRescheduleRequest() {
    }

    // Getters and Setters
    public LocalDateTime getNewPickupDate() {
        return newPickupDate;
    }

    public void setNewPickupDate(LocalDateTime newPickupDate) {
        this.newPickupDate = newPickupDate;
    }

    public LocalDateTime getNewReturnDate() {
        return newReturnDate;
    }

    public void setNewReturnDate(LocalDateTime newReturnDate) {
        this.newReturnDate = newReturnDate;
    }

    public String getRescheduleReason() {
        return rescheduleReason;
    }

    public void setRescheduleReason(String rescheduleReason) {
        this.rescheduleReason = rescheduleReason;
    }
}
