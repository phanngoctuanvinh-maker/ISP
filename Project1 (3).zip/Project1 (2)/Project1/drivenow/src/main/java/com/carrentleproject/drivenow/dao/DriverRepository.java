package com.carrentleproject.drivenow.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.carrentleproject.drivenow.model.Driver;

@Repository
public interface DriverRepository extends JpaRepository<Driver, Integer> {

    /**
     * Tìm driver theo account ID
     */
    Optional<Driver> findByAccount_AccountId(Integer accountId);

    /**
     * Tìm driver theo license number
     */
    Optional<Driver> findByLicenseNumber(String licenseNumber);

    /**
     * Tìm driver theo ID card
     */
    Optional<Driver> findByIdCard(String idCard);

    /**
     * Tìm drivers theo status
     */
    List<Driver> findByStatus(String status);

    /**
     * Tìm drivers active (available)
     */
    @Query("SELECT d FROM Driver d WHERE d.status = 'active'")
    List<Driver> findAvailableDrivers();

    /**
     * Check driver exists by license number
     */
    boolean existsByLicenseNumber(String licenseNumber);

    /**
     * Check driver exists by ID card
     */
    boolean existsByIdCard(String idCard);
}
