package com.carrentleproject.drivenow.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.carrentleproject.drivenow.dao.BookingRepository;
import com.carrentleproject.drivenow.dao.CarRepository;
import com.carrentleproject.drivenow.dao.CustomerDAO;
import com.carrentleproject.drivenow.dao.DriverDAO;
import com.carrentleproject.drivenow.dto.BookingCreateRequest;
import com.carrentleproject.drivenow.dto.BookingDTO;
import com.carrentleproject.drivenow.dto.BookingUpdateRequest;
import com.carrentleproject.drivenow.model.Booking;
import com.carrentleproject.drivenow.model.Car;
import com.carrentleproject.drivenow.model.Customer;
import com.carrentleproject.drivenow.model.Driver;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private CarRepository carRepository;

    @Autowired
    private CustomerDAO customerRepository;

    @Autowired
    private DriverDAO driverRepository;

    /**
     * Tạo booking mới
     */
    @Transactional
    public BookingDTO createBooking(BookingCreateRequest request) {
        // Validate customer
        Customer customer = customerRepository.findById(request.getCustomerId())
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy khách hàng với ID: " + request.getCustomerId()));

        // Validate car
        Car car = carRepository.findById(request.getCarId())
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy xe với ID: " + request.getCarId()));

        // Check car status
        if (!"available".equalsIgnoreCase(car.getStatus())) {
            throw new IllegalArgumentException("Xe không khả dụng để đặt");
        }

        // Validate dates
        if (request.getReturnDate().isBefore(request.getPickupDate())) {
            throw new IllegalArgumentException("Ngày trả phải sau ngày đón");
        }

        // Check if car is available in the requested time period
        boolean isAvailable = bookingRepository.isCarAvailable(
                request.getCarId(),
                request.getPickupDate(),
                request.getReturnDate()
        );

        if (!isAvailable) {
            throw new IllegalArgumentException("Xe không khả dụng cho các ngày đã chọn");
        }

        // Validate driver if provided
        Driver driver = null;
        if (request.getDriverId() != null) {
            driver = driverRepository.findById(request.getDriverId())
                    .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy tài xế với ID: " + request.getDriverId()));

            if (!"active".equalsIgnoreCase(driver.getStatus())) {
                throw new IllegalArgumentException("Tài xế không khả dụng");
            }
        }

        // Calculate total days and price
        long days = ChronoUnit.DAYS.between(
                request.getPickupDate().toLocalDate(),
                request.getReturnDate().toLocalDate()
        );
        if (days < 1) {
            days = 1; // Minimum 1 day
        }

        BigDecimal totalPrice = car.getPricePerDay().multiply(BigDecimal.valueOf(days));

        // Create booking
        Booking booking = new Booking();
        booking.setCustomer(customer);
        booking.setCar(car);
        booking.setDriver(driver);
        booking.setPickupDate(request.getPickupDate());
        booking.setReturnDate(request.getReturnDate());
        booking.setPickupLocation(request.getPickupLocation());
        booking.setReturnLocation(request.getReturnLocation() != null ? request.getReturnLocation() : request.getPickupLocation());
        booking.setTotalDays((int) days);
        booking.setTotalPrice(totalPrice);
        booking.setStatus("pending");
        booking.setPaymentStatus("unpaid");
        booking.setPaymentMethod(request.getPaymentMethod());
        booking.setNotes(request.getNotes());

        Booking savedBooking = bookingRepository.save(booking);

        return convertToDTO(savedBooking);
    }

    /**
     * Cập nhật booking (chỉ cho phép khi status = pending)
     */
    @Transactional
    public BookingDTO updateBooking(Integer bookingId, BookingUpdateRequest request) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy booking với ID: " + bookingId));

        // Chỉ cho phép update khi booking đang pending
        if (!"pending".equalsIgnoreCase(booking.getStatus())) {
            throw new IllegalArgumentException("Không thể cập nhật booking với trạng thái: " + booking.getStatus());
        }

        // Update driver
        if (request.getDriverId() != null) {
            Driver driver = driverRepository.findById(request.getDriverId())
                    .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy tài xế với ID: " + request.getDriverId()));
            booking.setDriver(driver);
        }

        // Update dates and recalculate price if changed
        if (request.getPickupDate() != null && request.getReturnDate() != null) {
            if (request.getReturnDate().isBefore(request.getPickupDate())) {
                throw new IllegalArgumentException("Ngày trả phải sau ngày đón");
            }

            // Check car availability for new dates
            boolean isAvailable = bookingRepository.isCarAvailable(
                    booking.getCar().getCarId(),
                    request.getPickupDate(),
                    request.getReturnDate()
            );

            if (!isAvailable) {
                throw new IllegalArgumentException("Xe không khả dụng cho các ngày đã chọn");
            }

            booking.setPickupDate(request.getPickupDate());
            booking.setReturnDate(request.getReturnDate());

            // Recalculate total days and price
            long days = ChronoUnit.DAYS.between(
                    request.getPickupDate().toLocalDate(),
                    request.getReturnDate().toLocalDate()
            );
            if (days < 1) {
                days = 1;
            }

            booking.setTotalDays((int) days);
            booking.setTotalPrice(booking.getCar().getPricePerDay().multiply(BigDecimal.valueOf(days)));
        }

        // Update locations
        if (request.getPickupLocation() != null) {
            booking.setPickupLocation(request.getPickupLocation());
        }
        if (request.getReturnLocation() != null) {
            booking.setReturnLocation(request.getReturnLocation());
        }

        // Update payment method
        if (request.getPaymentMethod() != null) {
            booking.setPaymentMethod(request.getPaymentMethod());
        }

        // Update notes
        if (request.getNotes() != null) {
            booking.setNotes(request.getNotes());
        }

        Booking updatedBooking = bookingRepository.save(booking);
        return convertToDTO(updatedBooking);
    }

    /**
     * Lấy chi tiết booking
     */
    public BookingDTO getBookingById(Integer bookingId) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy booking với ID: " + bookingId));
        return convertToDTO(booking);
    }

    /**
     * Lấy tất cả bookings của khách hàng
     */
    public List<BookingDTO> getBookingsByCustomer(Integer customerId) {
        return bookingRepository.findByCustomer_CustomerId(customerId).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Lấy bookings sắp tới của khách hàng
     */
    public List<BookingDTO> getUpcomingBookingsByCustomer(Integer customerId) {
        return bookingRepository.findUpcomingBookingsByCustomer(customerId, LocalDateTime.now()).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Lấy lịch sử booking của khách hàng
     */
    public List<BookingDTO> getBookingHistoryByCustomer(Integer customerId) {
        return bookingRepository.findBookingHistoryByCustomer(customerId).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Lấy tất cả bookings (for admin)
     */
    public List<BookingDTO> getAllBookings() {
        return bookingRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Lấy bookings theo status
     */
    public List<BookingDTO> getBookingsByStatus(String status) {
        return bookingRepository.findByStatus(status).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Xác nhận booking (admin)
     */
    @Transactional
    public BookingDTO confirmBooking(Integer bookingId) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy booking với ID: " + bookingId));

        if (!"pending".equalsIgnoreCase(booking.getStatus())) {
            throw new IllegalArgumentException("Chỉ những booking đang chờ mới có thể được xác nhận");
        }

        booking.setStatus("confirmed");
        Booking updatedBooking = bookingRepository.save(booking);
        return convertToDTO(updatedBooking);
    }

    /**
     * Bắt đầu chuyến đi (admin/driver)
     */
    @Transactional
    public BookingDTO startBooking(Integer bookingId) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy booking với ID: " + bookingId));

        if (!"confirmed".equalsIgnoreCase(booking.getStatus())) {
            throw new IllegalArgumentException("Chỉ những booking đã xác nhận mới có thể bắt đầu");
        }

        booking.setStatus("ongoing");
        
        // Update car status to rented
        Car car = booking.getCar();
        car.setStatus("rented");
        carRepository.save(car);

        Booking updatedBooking = bookingRepository.save(booking);
        return convertToDTO(updatedBooking);
    }

    /**
     * Hoàn thành booking
     */
    @Transactional
    public BookingDTO completeBooking(Integer bookingId) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy booking với ID: " + bookingId));

        if (!"ongoing".equalsIgnoreCase(booking.getStatus())) {
            throw new IllegalArgumentException("Chỉ những booking đang diễn ra mới có thể hoàn thành");
        }

        booking.setStatus("completed");

        // Update car status back to available
        Car car = booking.getCar();
        car.setStatus("available");
        carRepository.save(car);

        Booking updatedBooking = bookingRepository.save(booking);
        return convertToDTO(updatedBooking);
    }

    // ============================================================
    // [EXTENSION FEATURE] - Tính năng gia hạn booking
    // API: PATCH /api/bookings/{id}/extend
    // Cho phép khách hàng gia hạn thêm thời gian thuê xe
    // ============================================================

    /**
     * Gia hạn booking (Extend)
     */
    @Transactional
    public BookingDTO extendBooking(Integer bookingId, LocalDateTime newReturnDate) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy booking với ID: " + bookingId));

        // Chỉ cho phép gia hạn khi booking đang confirmed hoặc ongoing
        if (!"confirmed".equalsIgnoreCase(booking.getStatus()) && 
            !"ongoing".equalsIgnoreCase(booking.getStatus())) {
            throw new IllegalArgumentException("Chỉ những booking đã xác nhận hoặc đang diễn ra mới có thể được gia hạn");
        }

        // Validate new return date
        if (newReturnDate.isBefore(booking.getReturnDate())) {
            throw new IllegalArgumentException("Ngày trả mới phải sau ngày trả hiện tại");
        }

        if (newReturnDate.isBefore(LocalDateTime.now())) {
            throw new IllegalArgumentException("Ngày trả mới phải ở tương lai");
        }

        // Check if car is available for the extended period
        // (Từ returnDate cũ đến newReturnDate)
        boolean isAvailable = bookingRepository.isCarAvailable(
                booking.getCar().getCarId(),
                booking.getReturnDate(),
                newReturnDate
        );

        if (!isAvailable) {
            throw new IllegalArgumentException(
                "Không thể gia hạn booking. Xe đã được đặt bởi khách hàng khác trong khoảng thời gian gia hạn"
            );
        }

        // Calculate extension days and price
        long extensionDaysCount = ChronoUnit.DAYS.between(
                booking.getReturnDate().toLocalDate(),
                newReturnDate.toLocalDate()
        );
        if (extensionDaysCount < 1) {
            extensionDaysCount = 1; // Minimum 1 day
        }

        BigDecimal extensionPrice = booking.getCar().getPricePerDay()
                .multiply(BigDecimal.valueOf(extensionDaysCount));

        // Save original return date if this is the first extension
        if (!Boolean.TRUE.equals(booking.getIsExtended())) {
            booking.setOriginalReturnDate(booking.getReturnDate());
            booking.setIsExtended(true);
        }

        // Update booking
        booking.setReturnDate(newReturnDate);
        booking.setTotalDays(booking.getTotalDays() + (int) extensionDaysCount);
        booking.setTotalPrice(booking.getTotalPrice().add(extensionPrice));
        booking.setExtensionDays(
            booking.getExtensionDays() != null ? 
            booking.getExtensionDays() + (int) extensionDaysCount : 
            (int) extensionDaysCount
        );
        booking.setExtensionPrice(
            booking.getExtensionPrice() != null ? 
            booking.getExtensionPrice().add(extensionPrice) : 
            extensionPrice
        );

        // Update payment status to unpaid if there's additional charge
        if ("paid".equalsIgnoreCase(booking.getPaymentStatus())) {
            booking.setPaymentStatus("partially_paid"); // Need to pay extension fee
        }

        Booking updatedBooking = bookingRepository.save(booking);
        return convertToDTO(updatedBooking);
    }
    
    // ============================================================
    // [END EXTENSION FEATURE]
    // ============================================================

    /**
     * Hủy booking
     */
    @Transactional
    public BookingDTO cancelBooking(Integer bookingId, String cancellationReason) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy booking với ID: " + bookingId));

        if ("completed".equalsIgnoreCase(booking.getStatus()) || "cancelled".equalsIgnoreCase(booking.getStatus())) {
            throw new IllegalArgumentException("Không thể hủy booking với trạng thái: " + booking.getStatus());
        }

        booking.setStatus("cancelled");
        booking.setCancellationReason(cancellationReason);

        // If booking was ongoing, update car status back to available
        if ("ongoing".equalsIgnoreCase(booking.getStatus())) {
            Car car = booking.getCar();
            car.setStatus("available");
            carRepository.save(car);
        }

        Booking updatedBooking = bookingRepository.save(booking);
        return convertToDTO(updatedBooking);
    }

    /**
     * Cập nhật payment status
     */
    @Transactional
    public BookingDTO updatePaymentStatus(Integer bookingId, String paymentStatus) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy booking với ID: " + bookingId));

        booking.setPaymentStatus(paymentStatus);
        Booking updatedBooking = bookingRepository.save(booking);
        return convertToDTO(updatedBooking);
    }

    /**
     * Kiểm tra xe có khả dụng không
     */
    public boolean checkCarAvailability(Integer carId, LocalDateTime pickupDate, LocalDateTime returnDate) {
        return bookingRepository.isCarAvailable(carId, pickupDate, returnDate);
    }

    // ===== ADMIN MANAGEMENT METHODS =====

    /**
     * [ADMIN] Từ chối booking
     */
    @Transactional
    public BookingDTO rejectBooking(Integer bookingId, String rejectionReason) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy booking với ID: " + bookingId));

        // Only pending bookings can be rejected
        if (!"pending".equalsIgnoreCase(booking.getStatus())) {
            throw new IllegalStateException("Chỉ có thể từ chối booking đang ở trạng thái pending. Trạng thái hiện tại: " + booking.getStatus());
        }

        booking.setStatus("rejected");
        booking.setCancellationReason(rejectionReason); // Reuse cancellation_reason field for rejection reason
        
        Booking updatedBooking = bookingRepository.save(booking);
        return convertToDTO(updatedBooking);
    }

    /**
     * [ADMIN] Đổi lịch booking
     */
    @Transactional
    public BookingDTO rescheduleBooking(Integer bookingId, LocalDateTime newPickupDate, LocalDateTime newReturnDate, String rescheduleReason) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy booking với ID: " + bookingId));

        // Can only reschedule pending or confirmed bookings
        if (!"pending".equalsIgnoreCase(booking.getStatus()) && 
            !"confirmed".equalsIgnoreCase(booking.getStatus())) {
            throw new IllegalStateException("Chỉ có thể đổi lịch booking đang ở trạng thái pending hoặc confirmed. Trạng thái hiện tại: " + booking.getStatus());
        }

        // Validate new dates
        if (newReturnDate.isBefore(newPickupDate) || newReturnDate.isEqual(newPickupDate)) {
            throw new IllegalArgumentException("Ngày trả xe phải sau ngày nhận xe");
        }

        if (newPickupDate.isBefore(LocalDateTime.now())) {
            throw new IllegalArgumentException("Ngày nhận xe không được là quá khứ");
        }

        // Check car availability for new dates (excluding current booking)
        List<Booking> conflictingBookings = bookingRepository.findConflictingBookings(
            booking.getCar().getCarId(), 
            newPickupDate, 
            newReturnDate
        );
        
        // Remove current booking from conflicts
        conflictingBookings.removeIf(b -> b.getBookingId().equals(bookingId));
        
        if (!conflictingBookings.isEmpty()) {
            throw new IllegalStateException("Xe không khả dụng trong thời gian mới");
        }

        // Calculate new total days and price
        long newTotalDays = java.time.Duration.between(newPickupDate, newReturnDate).toDays();
        if (newTotalDays == 0) newTotalDays = 1; // Minimum 1 day

        BigDecimal newTotalPrice = booking.getCar().getPricePerDay()
                .multiply(BigDecimal.valueOf(newTotalDays));

        // Update booking
        booking.setPickupDate(newPickupDate);
        booking.setReturnDate(newReturnDate);
        booking.setTotalDays((int) newTotalDays);
        booking.setTotalPrice(newTotalPrice);
        
        // Add reschedule reason to notes
        String updatedNotes = booking.getNotes() != null ? booking.getNotes() : "";
        updatedNotes += "\n[RESCHEDULED] " + LocalDateTime.now() + ": " + rescheduleReason;
        booking.setNotes(updatedNotes.trim());

        Booking updatedBooking = bookingRepository.save(booking);
        return convertToDTO(updatedBooking);
    }

    /**
     * Lấy bookings của xe
     */
    public List<BookingDTO> getBookingsByCar(Integer carId) {
        return bookingRepository.findByCar_CarId(carId).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Lấy bookings của khách hàng theo status
     */
    public List<BookingDTO> getBookingsByCustomerAndStatus(Integer customerId, String status) {
        return bookingRepository.findByCustomer_CustomerIdAndStatus(customerId, status).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Lấy các booking đang diễn ra
     */
    public List<BookingDTO> getOngoingBookings() {
        return bookingRepository.findOngoingBookings(LocalDateTime.now()).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Đếm số lượng booking theo status
     */
    public Long countBookingsByStatus(String status) {
        return bookingRepository.countByStatus(status);
    }

    /**
     * Đếm tổng số booking
     */
    public Long countAllBookings() {
        return bookingRepository.count();
    }

    // ===== END ADMIN MANAGEMENT METHODS =====

    /**
     * Convert Booking entity to DTO
     */
    private BookingDTO convertToDTO(Booking booking) {
        BookingDTO dto = new BookingDTO();
        dto.setBookingId(booking.getBookingId());
        
        // Customer info
        dto.setCustomerId(booking.getCustomer().getCustomerId());
        dto.setCustomerName(booking.getCustomer().getFullName());
        dto.setCustomerPhone(booking.getCustomer().getPhone());
        
        // Car info
        dto.setCarId(booking.getCar().getCarId());
        dto.setCarBrand(booking.getCar().getBrand());
        dto.setCarModel(booking.getCar().getModel());
        dto.setLicensePlate(booking.getCar().getLicensePlate());
        
        // Driver info (if exists)
        if (booking.getDriver() != null) {
            dto.setDriverId(booking.getDriver().getDriverId());
            // Note: Driver entity doesn't have name field, you may need to add it or fetch from Account
            dto.setDriverName("Driver #" + booking.getDriver().getDriverId());
        }
        
        // Booking details
        dto.setPickupDate(booking.getPickupDate());
        dto.setReturnDate(booking.getReturnDate());
        dto.setPickupLocation(booking.getPickupLocation());
        dto.setReturnLocation(booking.getReturnLocation());
        dto.setTotalDays(booking.getTotalDays());
        dto.setTotalPrice(booking.getTotalPrice());
        dto.setStatus(booking.getStatus());
        dto.setPaymentStatus(booking.getPaymentStatus());
        dto.setPaymentMethod(booking.getPaymentMethod());
        dto.setNotes(booking.getNotes());
        dto.setCancellationReason(booking.getCancellationReason());
        
        // [EXTENSION FEATURE] - Map extension fields
        dto.setOriginalReturnDate(booking.getOriginalReturnDate());
        dto.setExtensionDays(booking.getExtensionDays());
        dto.setExtensionPrice(booking.getExtensionPrice());
        dto.setIsExtended(booking.getIsExtended());
        
        dto.setCreatedAt(booking.getCreatedAt());
        dto.setUpdatedAt(booking.getUpdatedAt());
        
        return dto;
    }
}
