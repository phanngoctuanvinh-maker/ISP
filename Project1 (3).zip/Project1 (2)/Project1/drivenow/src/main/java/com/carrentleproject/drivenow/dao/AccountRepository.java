package com.carrentleproject.drivenow.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.carrentleproject.drivenow.model.Account;

@Repository
public interface AccountRepository extends JpaRepository<Account, Integer> {

    /**
     * Tìm account theo username
     */
    Optional<Account> findByUsername(String username);

    /**
     * Kiểm tra username đã tồn tại chưa
     */
    boolean existsByUsername(String username);

    /**
     * Tìm account theo role
     */
    java.util.List<Account> findByRole(String role);

    /**
     * Tìm account theo status
     */
    java.util.List<Account> findByStatus(String status);
}
