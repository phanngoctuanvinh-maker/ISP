package com.carrentleproject.drivenow.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.carrentleproject.drivenow.dto.CarCreateRequest;
import com.carrentleproject.drivenow.dto.CarDTO;
import com.carrentleproject.drivenow.dto.CarImageCreateRequest;
import com.carrentleproject.drivenow.dto.CarImageDTO;
import com.carrentleproject.drivenow.dto.CarUpdateRequest;
import com.carrentleproject.drivenow.service.CarService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/cars")
@CrossOrigin(origins = "*")
public class CarController {

    @Autowired
    private CarService carService;

    // ==================== CAR CRUD ENDPOINTS ====================

    /**
     * POST /api/cars - Thêm xe mới
     */
    @PostMapping
    public ResponseEntity<Map<String, Object>> createCar(@Valid @RequestBody CarCreateRequest request) {
        Map<String, Object> response = new HashMap<>();
        try {
            CarDTO carDTO = carService.createCar(request);
            response.put("success", true);
            response.put("message", "Tạo xe thành công");
            response.put("data", carDTO);
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (IllegalArgumentException e) {
            response.put("success", false);
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Đã xảy ra lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * PUT /api/cars/{id} - Cập nhật thông tin xe
     */
    @PutMapping("/{id}")
    public ResponseEntity<Map<String, Object>> updateCar(
            @PathVariable("id") Integer carId,
            @Valid @RequestBody CarUpdateRequest request) {
        Map<String, Object> response = new HashMap<>();
        try {
            CarDTO carDTO = carService.updateCar(carId, request);
            response.put("success", true);
            response.put("message", "Cập nhật xe thành công");
            response.put("data", carDTO);
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            response.put("success", false);
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Đã xảy ra lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * DELETE /api/cars/{id} - Xóa xe
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, Object>> deleteCar(@PathVariable("id") Integer carId) {
        Map<String, Object> response = new HashMap<>();
        try {
            carService.deleteCar(carId);
            response.put("success", true);
            response.put("message", "Xóa xe thành công");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Đã xảy ra lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * PATCH /api/cars/{id}/status - Cập nhật status của xe
     */
    @PatchMapping("/{id}/status")
    public ResponseEntity<Map<String, Object>> updateCarStatus(
            @PathVariable("id") Integer carId,
            @RequestBody Map<String, String> request) {
        Map<String, Object> response = new HashMap<>();
        try {
            String status = request.get("status");
            if (status == null || status.trim().isEmpty()) {
                response.put("success", false);
                response.put("message", "Bắt buộc phải có trạng thái");
                return ResponseEntity.badRequest().body(response);
            }

            CarDTO carDTO = carService.updateCarStatus(carId, status);
            response.put("success", true);
            response.put("message", "Cập nhật trạng thái xe thành công");
            response.put("data", carDTO);
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            response.put("success", false);
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Đã xảy ra lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * GET /api/cars/{id} - Lấy chi tiết xe
     */
    @GetMapping("/{id}")
    public ResponseEntity<Map<String, Object>> getCarById(@PathVariable("id") Integer carId) {
        Map<String, Object> response = new HashMap<>();
        try {
            CarDTO carDTO = carService.getCarById(carId);
            response.put("success", true);
            response.put("data", carDTO);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Không tìm được xe: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }

    /**
     * GET /api/cars - Lấy danh sách xe (có thể filter)
     */
    @GetMapping
    public ResponseEntity<Map<String, Object>> getCars(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String location,
            @RequestParam(required = false) String brand,
            @RequestParam(required = false) String model,
            @RequestParam(required = false) Integer seats) {
        Map<String, Object> response = new HashMap<>();
        try {
            // Sử dụng searchCars cho mọi trường hợp (hỗ trợ cả null parameters)
            List<CarDTO> cars = carService.searchCars(brand, model, seats, status, location);

            response.put("success", true);
            response.put("data", cars);
            response.put("total", cars.size());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Đã xảy ra lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * GET /api/cars/available - Lấy xe available theo location
     */
    @GetMapping("/available")
    public ResponseEntity<Map<String, Object>> getAvailableCars(
            @RequestParam(required = false) String location) {
        Map<String, Object> response = new HashMap<>();
        try {
            List<CarDTO> cars;
            if (location != null) {
                cars = carService.getAvailableCarsByLocation(location);
            } else {
                cars = carService.getCarsByStatus("available");
            }

            response.put("success", true);
            response.put("data", cars);
            response.put("total", cars.size());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Đã xảy ra lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // ==================== CAR IMAGE ENDPOINTS ====================

    /**
     * POST /api/cars/{id}/images - Thêm hình ảnh cho xe
     */
    @PostMapping("/{id}/images")
    public ResponseEntity<Map<String, Object>> addCarImage(
            @PathVariable("id") Integer carId,
            @Valid @RequestBody CarImageCreateRequest request) {
        Map<String, Object> response = new HashMap<>();
        try {
            // Set carId from path parameter
            request.setCarId(carId);

            CarImageDTO imageDTO = carService.addCarImage(request);
            response.put("success", true);
            response.put("message", "Thêm hình ảnh thành công");
            response.put("data", imageDTO);
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Đã xảy ra lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * GET /api/cars/{id}/images - Lấy tất cả hình ảnh của xe
     */
    @GetMapping("/{id}/images")
    public ResponseEntity<Map<String, Object>> getCarImages(@PathVariable("id") Integer carId) {
        Map<String, Object> response = new HashMap<>();
        try {
            List<CarImageDTO> images = carService.getCarImages(carId);
            response.put("success", true);
            response.put("data", images);
            response.put("total", images.size());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Đã xảy ra lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * DELETE /api/cars/images/{imageId} - Xóa hình ảnh
     */
    @DeleteMapping("/images/{imageId}")
    public ResponseEntity<Map<String, Object>> deleteCarImage(@PathVariable("imageId") Integer imageId) {
        Map<String, Object> response = new HashMap<>();
        try {
            carService.deleteCarImage(imageId);
            response.put("success", true);
            response.put("message", "Xóa hình ảnh thành công");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Đã xảy ra lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * DELETE /api/cars/{id}/images - Xóa tất cả hình ảnh của xe
     */
    @DeleteMapping("/{id}/images")
    public ResponseEntity<Map<String, Object>> deleteAllCarImages(@PathVariable("id") Integer carId) {
        Map<String, Object> response = new HashMap<>();
        try {
            carService.deleteAllCarImages(carId);
            response.put("success", true);
            response.put("message", "Xóa tất cả hình ảnh của xe thành công");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Đã xảy ra lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }
}
