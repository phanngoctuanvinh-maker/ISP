package com.carrentleproject.drivenow.dto;

import java.time.LocalDateTime;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;

/**
 * Request DTO để cập nhật thông tin giao/nhận xe (khi thực tế giao/nhận)
 */
public class DeliveryScheduleUpdateRequest {

    private LocalDateTime actualTime; // Thời gian thực tế

    @Size(max = 1000, message = "Ghi chú không được vượt quá 1000 ký tự")
    private String notes;

    @Min(value = 0, message = "Fuel level phải >= 0")
    @Max(value = 100, message = "Fuel level phải <= 100")
    private Integer fuelLevel; // Mức nhiên liệu (%)

    @Min(value = 0, message = "Mileage phải >= 0")
    private Integer mileage; // Số km

    @Size(max = 2000, message = "Tình trạng xe không được vượt quá 2000 ký tự")
    private String carCondition; // Tình trạng xe

    @Size(max = 500, message = "Image URL không được vượt quá 500 ký tự")
    private String imageUrl; // URL ảnh xe

    @Size(max = 1000, message = "Lý do trễ không được vượt quá 1000 ký tự")
    private String delayReason; // Lý do trễ (nếu có)

    // Constructors
    public DeliveryScheduleUpdateRequest() {
    }

    // Getters and Setters
    public LocalDateTime getActualTime() {
        return actualTime;
    }

    public void setActualTime(LocalDateTime actualTime) {
        this.actualTime = actualTime;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public Integer getFuelLevel() {
        return fuelLevel;
    }

    public void setFuelLevel(Integer fuelLevel) {
        this.fuelLevel = fuelLevel;
    }

    public Integer getMileage() {
        return mileage;
    }

    public void setMileage(Integer mileage) {
        this.mileage = mileage;
    }

    public String getCarCondition() {
        return carCondition;
    }

    public void setCarCondition(String carCondition) {
        this.carCondition = carCondition;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getDelayReason() {
        return delayReason;
    }

    public void setDelayReason(String delayReason) {
        this.delayReason = delayReason;
    }
}
