package com.carrentleproject.drivenow.dto;

import java.time.LocalDateTime;

/**
 * DTO cho Delivery Schedule
 */
public class DeliveryScheduleDTO {

    private Integer scheduleId;
    private Integer bookingId;
    private Integer driverId;
    private String driverName;
    private String driverPhone;
    private Integer carId;
    private String carBrand;
    private String carModel;
    private String licensePlate;
    private Integer customerId;
    private String customerName;
    private String customerPhone;
    private String scheduleType; // pickup, return
    private LocalDateTime scheduledTime;
    private LocalDateTime actualTime;
    private String location;
    private String status; // scheduled, in_progress, completed, cancelled, delayed
    private String notes;
    private String deliveryMethod; // self_pickup, home_delivery
    private String contactPerson;
    private String contactPhone;
    private Integer fuelLevelBefore;
    private Integer fuelLevelAfter;
    private Integer mileageBefore;
    private Integer mileageAfter;
    private String carConditionBefore;
    private String carConditionAfter;
    private String imageUrlBefore;
    private String imageUrlAfter;
    private String delayReason;
    private String cancellationReason;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    // Constructors
    public DeliveryScheduleDTO() {
    }

    // Getters and Setters
    public Integer getScheduleId() {
        return scheduleId;
    }

    public void setScheduleId(Integer scheduleId) {
        this.scheduleId = scheduleId;
    }

    public Integer getBookingId() {
        return bookingId;
    }

    public void setBookingId(Integer bookingId) {
        this.bookingId = bookingId;
    }

    public Integer getDriverId() {
        return driverId;
    }

    public void setDriverId(Integer driverId) {
        this.driverId = driverId;
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    public String getDriverPhone() {
        return driverPhone;
    }

    public void setDriverPhone(String driverPhone) {
        this.driverPhone = driverPhone;
    }

    public Integer getCarId() {
        return carId;
    }

    public void setCarId(Integer carId) {
        this.carId = carId;
    }

    public String getCarBrand() {
        return carBrand;
    }

    public void setCarBrand(String carBrand) {
        this.carBrand = carBrand;
    }

    public String getCarModel() {
        return carModel;
    }

    public void setCarModel(String carModel) {
        this.carModel = carModel;
    }

    public String getLicensePlate() {
        return licensePlate;
    }

    public void setLicensePlate(String licensePlate) {
        this.licensePlate = licensePlate;
    }

    public Integer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerPhone() {
        return customerPhone;
    }

    public void setCustomerPhone(String customerPhone) {
        this.customerPhone = customerPhone;
    }

    public String getScheduleType() {
        return scheduleType;
    }

    public void setScheduleType(String scheduleType) {
        this.scheduleType = scheduleType;
    }

    public LocalDateTime getScheduledTime() {
        return scheduledTime;
    }

    public void setScheduledTime(LocalDateTime scheduledTime) {
        this.scheduledTime = scheduledTime;
    }

    public LocalDateTime getActualTime() {
        return actualTime;
    }

    public void setActualTime(LocalDateTime actualTime) {
        this.actualTime = actualTime;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getDeliveryMethod() {
        return deliveryMethod;
    }

    public void setDeliveryMethod(String deliveryMethod) {
        this.deliveryMethod = deliveryMethod;
    }

    public String getContactPerson() {
        return contactPerson;
    }

    public void setContactPerson(String contactPerson) {
        this.contactPerson = contactPerson;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public Integer getFuelLevelBefore() {
        return fuelLevelBefore;
    }

    public void setFuelLevelBefore(Integer fuelLevelBefore) {
        this.fuelLevelBefore = fuelLevelBefore;
    }

    public Integer getFuelLevelAfter() {
        return fuelLevelAfter;
    }

    public void setFuelLevelAfter(Integer fuelLevelAfter) {
        this.fuelLevelAfter = fuelLevelAfter;
    }

    public Integer getMileageBefore() {
        return mileageBefore;
    }

    public void setMileageBefore(Integer mileageBefore) {
        this.mileageBefore = mileageBefore;
    }

    public Integer getMileageAfter() {
        return mileageAfter;
    }

    public void setMileageAfter(Integer mileageAfter) {
        this.mileageAfter = mileageAfter;
    }

    public String getCarConditionBefore() {
        return carConditionBefore;
    }

    public void setCarConditionBefore(String carConditionBefore) {
        this.carConditionBefore = carConditionBefore;
    }

    public String getCarConditionAfter() {
        return carConditionAfter;
    }

    public void setCarConditionAfter(String carConditionAfter) {
        this.carConditionAfter = carConditionAfter;
    }

    public String getImageUrlBefore() {
        return imageUrlBefore;
    }

    public void setImageUrlBefore(String imageUrlBefore) {
        this.imageUrlBefore = imageUrlBefore;
    }

    public String getImageUrlAfter() {
        return imageUrlAfter;
    }

    public void setImageUrlAfter(String imageUrlAfter) {
        this.imageUrlAfter = imageUrlAfter;
    }

    public String getDelayReason() {
        return delayReason;
    }

    public void setDelayReason(String delayReason) {
        this.delayReason = delayReason;
    }

    public String getCancellationReason() {
        return cancellationReason;
    }

    public void setCancellationReason(String cancellationReason) {
        this.cancellationReason = cancellationReason;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
}
