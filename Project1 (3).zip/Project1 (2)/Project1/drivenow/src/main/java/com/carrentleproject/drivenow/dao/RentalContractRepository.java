package com.carrentleproject.drivenow.dao;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.carrentleproject.drivenow.model.RentalContract;

@Repository
public interface RentalContractRepository extends JpaRepository<RentalContract, Integer> {

    /**
     * Tìm hợp đồng theo mã hợp đồng
     */
    Optional<RentalContract> findByContractNumber(String contractNumber);

    /**
     * Tìm hợp đồng theo booking ID
     */
    Optional<RentalContract> findByBooking_BookingId(Integer bookingId);

    /**
     * Tìm hợp đồng theo customer ID
     */
    @Query("SELECT rc FROM RentalContract rc WHERE rc.booking.customer.customerId = :customerId ORDER BY rc.createdAt DESC")
    List<RentalContract> findByCustomerId(@Param("customerId") Integer customerId);

    /**
     * Tìm hợp đồng theo status
     */
    List<RentalContract> findByStatusOrderByCreatedAtDesc(String status);

    /**
     * Tìm hợp đồng đã ký đầy đủ
     */
    List<RentalContract> findByIsSignedTrueOrderByCreatedAtDesc();

    /**
     * Tìm hợp đồng chưa ký đầy đủ
     */
    List<RentalContract> findByIsSignedFalseOrderByCreatedAtDesc();

    /**
     * Tìm hợp đồng đã lưu trữ
     */
    List<RentalContract> findByIsArchivedTrueOrderByCreatedAtDesc();

    /**
     * Tìm hợp đồng đang hoạt động (active)
     */
    @Query("SELECT rc FROM RentalContract rc WHERE rc.status = 'active' " +
           "AND rc.isSigned = true " +
           "AND rc.expiryDate > :now " +
           "ORDER BY rc.expiryDate ASC")
    List<RentalContract> findActiveContracts(@Param("now") LocalDateTime now);

    /**
     * Tìm hợp đồng sắp hết hạn (còn 7 ngày)
     */
    @Query("SELECT rc FROM RentalContract rc WHERE rc.status = 'active' " +
           "AND rc.expiryDate BETWEEN :now AND :oneWeekLater " +
           "ORDER BY rc.expiryDate ASC")
    List<RentalContract> findExpiringContracts(@Param("now") LocalDateTime now,
                                                @Param("oneWeekLater") LocalDateTime oneWeekLater);

    /**
     * Tìm hợp đồng đã hết hạn nhưng chưa update status
     */
    @Query("SELECT rc FROM RentalContract rc WHERE rc.status = 'active' " +
           "AND rc.expiryDate < :now " +
           "ORDER BY rc.expiryDate ASC")
    List<RentalContract> findExpiredContracts(@Param("now") LocalDateTime now);

    /**
     * Tìm hợp đồng trong khoảng thời gian
     */
    @Query("SELECT rc FROM RentalContract rc WHERE rc.contractDate BETWEEN :startDate AND :endDate " +
           "ORDER BY rc.contractDate DESC")
    List<RentalContract> findByContractDateBetween(@Param("startDate") LocalDateTime startDate,
                                                    @Param("endDate") LocalDateTime endDate);

    /**
     * Đếm hợp đồng theo status
     */
    Long countByStatus(String status);

    /**
     * Đếm tổng hợp đồng
     */
    @Query("SELECT COUNT(rc) FROM RentalContract rc")
    Long countAllContracts();

    /**
     * Đếm hợp đồng đã ký
     */
    Long countByIsSignedTrue();

    /**
     * Kiểm tra hợp đồng đã tồn tại cho booking chưa
     */
    boolean existsByBooking_BookingId(Integer bookingId);

    /**
     * Kiểm tra contract number đã tồn tại chưa
     */
    boolean existsByContractNumber(String contractNumber);

    /**
     * Lấy contract number cuối cùng để generate mã mới
     */
    @Query("SELECT rc.contractNumber FROM RentalContract rc ORDER BY rc.createdAt DESC")
    List<String> findLatestContractNumbers();
}
