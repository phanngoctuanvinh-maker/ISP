package com.carrentleproject.drivenow.model;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/**
 * Entity lưu lịch sử hành động của user
 * History tracking for user actions
 */
@Entity
@Table(name = "history")
public class History {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "history_id")
    private Integer historyId;

    @ManyToOne
    @JoinColumn(name = "account_id", nullable = false)
    private Account account; // Tài khoản thực hiện hành động

    @ManyToOne
    @JoinColumn(name = "booking_id")
    private Booking booking; // Booking liên quan (nếu có)

    @ManyToOne
    @JoinColumn(name = "driver_id")
    private Driver driver; // Driver liên quan (nếu có)

    @Column(name = "action", nullable = false, length = 100)
    private String action; // login, create_booking, cancel_booking, complete_booking, etc.

    @Column(name = "description", columnDefinition = "TEXT")
    private String description; // Mô tả chi tiết hành động

    @Column(name = "entity_type", length = 50)
    private String entityType; // booking, car, payment, contract, etc.

    @Column(name = "entity_id")
    private Integer entityId; // ID của entity liên quan

    @Column(name = "ip_address", length = 50)
    private String ipAddress; // IP address của user

    @Column(name = "user_agent", length = 255)
    private String userAgent; // Browser/device info

    @Column(name = "status", length = 20)
    private String status; // success, failed, pending

    @Column(name = "metadata", columnDefinition = "TEXT")
    private String metadata; // JSON data bổ sung

    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    // Constructors
    public History() {
    }

    public History(Account account, String action, String description) {
        this.account = account;
        this.action = action;
        this.description = description;
        this.status = "success";
    }

    public History(Account account, Booking booking, String action, String description) {
        this.account = account;
        this.booking = booking;
        this.action = action;
        this.description = description;
        this.entityType = "booking";
        this.entityId = booking != null ? booking.getBookingId() : null;
        this.status = "success";
    }

    // Helper method: Create login history
    public static History createLoginHistory(Account account, String ipAddress, String userAgent) {
        History history = new History();
        history.setAccount(account);
        history.setAction("login");
        history.setDescription("User logged in successfully");
        history.setIpAddress(ipAddress);
        history.setUserAgent(userAgent);
        history.setStatus("success");
        return history;
    }

    // Helper method: Create booking history
    public static History createBookingHistory(Account account, Booking booking, String action, String description) {
        History history = new History();
        history.setAccount(account);
        history.setBooking(booking);
        history.setAction(action);
        history.setDescription(description);
        history.setEntityType("booking");
        history.setEntityId(booking.getBookingId());
        history.setStatus("success");
        return history;
    }

    // Getters and Setters
    public Integer getHistoryId() {
        return historyId;
    }

    public void setHistoryId(Integer historyId) {
        this.historyId = historyId;
    }

    public Account getAccount() {
        return account;
    }

    public void setAccount(Account account) {
        this.account = account;
    }

    public Booking getBooking() {
        return booking;
    }

    public void setBooking(Booking booking) {
        this.booking = booking;
    }

    public Driver getDriver() {
        return driver;
    }

    public void setDriver(Driver driver) {
        this.driver = driver;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getEntityType() {
        return entityType;
    }

    public void setEntityType(String entityType) {
        this.entityType = entityType;
    }

    public Integer getEntityId() {
        return entityId;
    }

    public void setEntityId(Integer entityId) {
        this.entityId = entityId;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public String getUserAgent() {
        return userAgent;
    }

    public void setUserAgent(String userAgent) {
        this.userAgent = userAgent;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMetadata() {
        return metadata;
    }

    public void setMetadata(String metadata) {
        this.metadata = metadata;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        return "History{" +
                "historyId=" + historyId +
                ", action='" + action + '\'' +
                ", description='" + description + '\'' +
                ", status='" + status + '\'' +
                ", createdAt=" + createdAt +
                '}';
    }
}
