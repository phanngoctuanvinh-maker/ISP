# Car Management API Documentation

## Tổng quan
API quản lý xe cho hệ thống DriveNow - Cho thuê xe có tài xế.

**Base URL:** `http://localhost:8080/api/cars`

---

## 📋 Endpoints

### 1. Thêm xe mới
**POST** `/api/cars`

**Request Body:**
```json
{
  "brand": "Toyota",
  "model": "Camry",
  "seats": 5,
  "fuelType": "Gasoline",
  "licensePlate": "51A-12345",
  "insuranceInfo": "Insurance Company ABC - Policy #123456",
  "imageUrl": "https://example.com/images/toyota-camry.jpg",
  "location": "Ho Chi Minh City",
  "pricePerDay": 800000,
  "status": "available"
}
```

**Response (201 Created):**
```json
{
  "success": true,
  "message": "Car created successfully",
  "data": {
    "carId": 1,
    "brand": "Toyota",
    "model": "Camry",
    "seats": 5,
    "fuelType": "Gasoline",
    "licensePlate": "51A-12345",
    "insuranceInfo": "Insurance Company ABC - Policy #123456",
    "imageUrl": "https://example.com/images/toyota-camry.jpg",
    "location": "Ho Chi Minh City",
    "pricePerDay": 800000,
    "status": "available",
    "createdAt": "2025-10-14T10:30:00",
    "updatedAt": "2025-10-14T10:30:00"
  }
}
```

---

### 2. Cập nhật thông tin xe
**PUT** `/api/cars/{id}`

**Request Body:** (Tất cả fields đều optional)
```json
{
  "brand": "Toyota",
  "model": "Camry 2024",
  "seats": 5,
  "pricePerDay": 850000,
  "location": "Hanoi",
  "status": "maintenance"
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Car updated successfully",
  "data": {
    "carId": 1,
    "brand": "Toyota",
    "model": "Camry 2024",
    "seats": 5,
    "pricePerDay": 850000,
    "location": "Hanoi",
    "status": "maintenance",
    "updatedAt": "2025-10-14T11:00:00"
  }
}
```

---

### 3. Xóa xe
**DELETE** `/api/cars/{id}`

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Car deleted successfully"
}
```

---

### 4. Cập nhật status xe
**PATCH** `/api/cars/{id}/status`

**Request Body:**
```json
{
  "status": "rented"
}
```

**Status values:** `available`, `rented`, `maintenance`

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Car status updated successfully",
  "data": {
    "carId": 1,
    "status": "rented",
    "updatedAt": "2025-10-14T11:15:00"
  }
}
```

---

### 5. Lấy chi tiết xe
**GET** `/api/cars/{id}`

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "carId": 1,
    "brand": "Toyota",
    "model": "Camry",
    "seats": 5,
    "fuelType": "Gasoline",
    "licensePlate": "51A-12345",
    "insuranceInfo": "Insurance Company ABC",
    "imageUrl": "https://example.com/images/toyota-camry.jpg",
    "location": "Ho Chi Minh City",
    "pricePerDay": 800000,
    "status": "available",
    "createdAt": "2025-10-14T10:30:00",
    "updatedAt": "2025-10-14T10:30:00",
    "carImages": [
      {
        "carImageId": 1,
        "carId": 1,
        "type": "main",
        "url": "https://example.com/images/car1-main.jpg",
        "description": "Front view",
        "createdAt": "2025-10-14T10:35:00"
      },
      {
        "carImageId": 2,
        "carId": 1,
        "type": "gallery",
        "url": "https://example.com/images/car1-interior.jpg",
        "description": "Interior",
        "createdAt": "2025-10-14T10:36:00"
      }
    ]
  }
}
```

---

### 6. Lấy danh sách xe (với filters)
**GET** `/api/cars?status={status}&location={location}&brand={brand}&model={model}&seats={seats}`

**Query Parameters:** (All optional)
- `status`: available, rented, maintenance
- `location`: Ho Chi Minh City, Hanoi, Da Nang, etc.
- `brand`: Toyota, Honda, Mercedes, etc.
- `model`: Camry, Civic, E-Class, etc.
- `seats`: Minimum number of seats (e.g., 5, 7)

**Examples:**
- Get all cars: `GET /api/cars`
- Get available cars: `GET /api/cars?status=available`
- Get cars in HCM: `GET /api/cars?location=Ho Chi Minh City`
- Get Toyota cars with 5+ seats: `GET /api/cars?brand=Toyota&seats=5`

**Response (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "carId": 1,
      "brand": "Toyota",
      "model": "Camry",
      "seats": 5,
      "licensePlate": "51A-12345",
      "location": "Ho Chi Minh City",
      "pricePerDay": 800000,
      "status": "available"
    },
    {
      "carId": 2,
      "brand": "Honda",
      "model": "Civic",
      "seats": 5,
      "licensePlate": "51B-67890",
      "location": "Hanoi",
      "pricePerDay": 750000,
      "status": "available"
    }
  ],
  "total": 2
}
```

---

### 7. Lấy xe available
**GET** `/api/cars/available?location={location}`

**Query Parameters:**
- `location` (optional): Filter by location

**Response (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "carId": 1,
      "brand": "Toyota",
      "model": "Camry",
      "location": "Ho Chi Minh City",
      "pricePerDay": 800000,
      "status": "available"
    }
  ],
  "total": 1
}
```

---

## 📷 Car Images Endpoints

### 8. Thêm hình ảnh cho xe
**POST** `/api/cars/{id}/images`

**Request Body:**
```json
{
  "type": "main",
  "url": "https://example.com/images/car-main.jpg",
  "description": "Front view of the car"
}
```

**Image types:** `main`, `gallery`, `interior`, `exterior`

**Response (201 Created):**
```json
{
  "success": true,
  "message": "Car image added successfully",
  "data": {
    "carImageId": 1,
    "carId": 1,
    "type": "main",
    "url": "https://example.com/images/car-main.jpg",
    "description": "Front view of the car",
    "createdAt": "2025-10-14T10:40:00"
  }
}
```

---

### 9. Lấy tất cả hình ảnh của xe
**GET** `/api/cars/{id}/images`

**Response (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "carImageId": 1,
      "carId": 1,
      "type": "main",
      "url": "https://example.com/images/car-main.jpg",
      "description": "Front view",
      "createdAt": "2025-10-14T10:40:00"
    },
    {
      "carImageId": 2,
      "carId": 1,
      "type": "gallery",
      "url": "https://example.com/images/car-interior.jpg",
      "description": "Interior",
      "createdAt": "2025-10-14T10:41:00"
    }
  ],
  "total": 2
}
```

---

### 10. Xóa hình ảnh
**DELETE** `/api/cars/images/{imageId}`

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Car image deleted successfully"
}
```

---

### 11. Xóa tất cả hình ảnh của xe
**DELETE** `/api/cars/{id}/images`

**Response (200 OK):**
```json
{
  "success": true,
  "message": "All car images deleted successfully"
}
```

---

## 🔒 Error Responses

### 400 Bad Request
```json
{
  "success": false,
  "message": "License plate already exists: 51A-12345"
}
```

### 404 Not Found
```json
{
  "success": false,
  "message": "Car not found with id: 999"
}
```

### 500 Internal Server Error
```json
{
  "success": false,
  "message": "An error occurred: Database connection failed"
}
```

---

## 🧪 Testing với cURL

### Thêm xe mới
```bash
curl -X POST http://localhost:8080/api/cars \
  -H "Content-Type: application/json" \
  -d '{
    "brand": "Toyota",
    "model": "Camry",
    "seats": 5,
    "fuelType": "Gasoline",
    "licensePlate": "51A-12345",
    "location": "Ho Chi Minh City",
    "pricePerDay": 800000,
    "status": "available"
  }'
```

### Lấy tất cả xe
```bash
curl -X GET http://localhost:8080/api/cars
```

### Lấy xe available tại HCM
```bash
curl -X GET "http://localhost:8080/api/cars/available?location=Ho%20Chi%20Minh%20City"
```

### Cập nhật status
```bash
curl -X PATCH http://localhost:8080/api/cars/1/status \
  -H "Content-Type: application/json" \
  -d '{"status": "rented"}'
```

### Xóa xe
```bash
curl -X DELETE http://localhost:8080/api/cars/1
```

---

## 📝 Validation Rules

### CarCreateRequest
- `brand`: Required, max 50 characters
- `model`: Required, max 50 characters
- `seats`: Required, min 4, max 7
- `licensePlate`: Required, max 50 characters, must be unique
- `pricePerDay`: Required, must be > 0
- `status`: Must be one of: available, rented, maintenance

### CarUpdateRequest
- All fields optional
- Same validation rules as CarCreateRequest

### CarImageCreateRequest
- `carId`: Required
- `url`: Required, max 255 characters
- `type`: Optional, max 20 characters
- `description`: Optional, max 255 characters

---

## 🗂️ Database Schema

### Table: cars
```sql
CREATE TABLE cars (
    car_id INT IDENTITY(1,1) PRIMARY KEY,
    brand VARCHAR(50),
    model VARCHAR(50),
    seats INT,
    fuel_type VARCHAR(50),
    license_plate VARCHAR(50) UNIQUE,
    insurance_info VARCHAR(255),
    image_url VARCHAR(255),
    location VARCHAR(100),
    price_per_day DECIMAL(10,2),
    status VARCHAR(20) DEFAULT 'available',
    created_at DATETIME2 DEFAULT GETDATE(),
    updated_at DATETIME2 DEFAULT GETDATE()
);
```

### Table: car_images
```sql
CREATE TABLE car_images (
    car_image_id INT IDENTITY(1,1) PRIMARY KEY,
    car_id INT NOT NULL,
    type VARCHAR(20),
    url VARCHAR(255) NOT NULL,
    description VARCHAR(255),
    created_at DATETIME2 DEFAULT GETDATE(),
    FOREIGN KEY (car_id) REFERENCES cars(car_id)
);
```
