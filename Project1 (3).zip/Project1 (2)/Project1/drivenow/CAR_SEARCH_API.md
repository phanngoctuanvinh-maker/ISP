# Car Search API Documentation

## Tổng quan
API tìm kiếm xe nâng cao cho hệ thống DriveNow - Lọc xe theo loại nhiên liệu, giá, hãng, số ghế.

**Base URL:** `http://localhost:8080/api/search`

---

## 📋 Endpoints

### 1. Tìm kiếm xe nâng cao (Advanced Search)
**POST** `/api/search/cars`

**Mô tả:** Tìm kiếm xe với nhiều bộ lọc kết hợp (fuel type, price range, brand, seats, location)

**Request Body:**
```json
{
  "fuelType": "Gasoline",
  "priceMin": 500000,
  "priceMax": 1000000,
  "brand": "Toyota",
  "seats": 5,
  "location": "Ho Chi Minh City",
  "status": "available",
  "model": "Camry",
  "sortBy": "price_asc"
}
```

**Request Parameters** (tất cả đều optional):
- `fuelType`: Loại nhiên liệu (Electric, Gasoline, Diesel, Hybrid)
- `priceMin`: Giá tối thiểu (300,000 - 10,000,000 VNĐ/ngày)
- `priceMax`: Giá tối đa (300,000 - 10,000,000 VNĐ/ngày)
- `brand`: Hãng xe (Toyota, Honda, Mercedes, BMW, etc.)
- `seats`: Số ghế tối thiểu (4-7)
- `location`: Địa điểm (Ho Chi Minh City, Hanoi, Da Nang)
- `status`: Trạng thái (available, rented, maintenance) - mặc định: available
- `model`: Model xe (tìm kiếm partial match)
- `sortBy`: Sắp xếp theo
  - `price_asc`: Giá tăng dần
  - `price_desc`: Giá giảm dần
  - `seats_asc`: Số ghế tăng dần
  - `seats_desc`: Số ghế giảm dần
  - `brand`: Theo hãng (A-Z)
  - `newest`: Mới nhất (mặc định)
  - `oldest`: Cũ nhất

**Response (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "carId": 1,
      "brand": "Toyota",
      "model": "Camry",
      "seats": 5,
      "fuelType": "Gasoline",
      "licensePlate": "51A-12345",
      "imageUrl": "https://example.com/images/toyota-camry.jpg",
      "location": "Ho Chi Minh City",
      "pricePerDay": 800000,
      "status": "available",
      "createdAt": "2025-10-14T10:30:00",
      "updatedAt": "2025-10-14T10:30:00"
    },
    {
      "carId": 3,
      "brand": "Toyota",
      "model": "Vios",
      "seats": 5,
      "fuelType": "Gasoline",
      "licensePlate": "51C-99999",
      "imageUrl": "https://example.com/images/toyota-vios.jpg",
      "location": "Ho Chi Minh City",
      "pricePerDay": 600000,
      "status": "available"
    }
  ],
  "total": 2,
  "searchCriteria": {
    "fuelType": "Gasoline",
    "priceMin": 500000,
    "priceMax": 1000000,
    "brand": "Toyota",
    "seats": 5,
    "location": "Ho Chi Minh City",
    "sortBy": "price_asc"
  }
}
```

---

### 2. Tìm xe theo loại nhiên liệu
**GET** `/api/search/cars/fuel-type/{fuelType}`

**Path Parameters:**
- `fuelType`: Loại nhiên liệu (Electric, Gasoline, Diesel, Hybrid)

**Examples:**
- `GET /api/search/cars/fuel-type/Electric` - Tìm xe điện
- `GET /api/search/cars/fuel-type/Gasoline` - Tìm xe xăng
- `GET /api/search/cars/fuel-type/Diesel` - Tìm xe dầu
- `GET /api/search/cars/fuel-type/Hybrid` - Tìm xe hybrid

**Response (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "carId": 5,
      "brand": "Tesla",
      "model": "Model 3",
      "seats": 5,
      "fuelType": "Electric",
      "pricePerDay": 1500000,
      "status": "available"
    }
  ],
  "total": 1,
  "fuelType": "Electric"
}
```

---

### 3. Tìm xe theo khoảng giá
**GET** `/api/search/cars/price-range?min={min}&max={max}`

**Query Parameters:**
- `min` (optional): Giá tối thiểu (300,000 - 10,000,000 VNĐ/ngày)
- `max` (optional): Giá tối đa (300,000 - 10,000,000 VNĐ/ngày)

**Examples:**
- `GET /api/search/cars/price-range?min=500000&max=1000000` - Xe từ 500k-1tr
- `GET /api/search/cars/price-range?max=800000` - Xe dưới 800k
- `GET /api/search/cars/price-range?min=5000000` - Xe trên 5tr (tối đa 10tr)

**Response (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "carId": 2,
      "brand": "Honda",
      "model": "Civic",
      "pricePerDay": 750000,
      "status": "available"
    }
  ],
  "total": 1,
  "priceRange": {
    "min": 500000,
    "max": 1000000
  }
}
```

---

### 4. Tìm xe theo hãng
**GET** `/api/search/cars/brand/{brand}`

**Path Parameters:**
- `brand`: Hãng xe (Toyota, Honda, Mercedes, BMW, etc.)

**Examples:**
- `GET /api/search/cars/brand/Toyota`
- `GET /api/search/cars/brand/Mercedes`
- `GET /api/search/cars/brand/Honda`

**Response (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "carId": 1,
      "brand": "Toyota",
      "model": "Camry",
      "pricePerDay": 800000
    },
    {
      "carId": 3,
      "brand": "Toyota",
      "model": "Vios",
      "pricePerDay": 600000
    }
  ],
  "total": 2,
  "brand": "Toyota"
}
```

---

### 5. Tìm xe theo số ghế
**GET** `/api/search/cars/seats/{seats}`

**Path Parameters:**
- `seats`: Số ghế tối thiểu (4-7)

**Mô tả:** Tìm xe có số ghế >= số chỉ định

**Examples:**
- `GET /api/search/cars/seats/7` - Xe 7 chỗ trở lên
- `GET /api/search/cars/seats/5` - Xe 5 chỗ trở lên
- `GET /api/search/cars/seats/4` - Tất cả xe (4+ chỗ)

**Response (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "carId": 6,
      "brand": "Toyota",
      "model": "Innova",
      "seats": 7,
      "pricePerDay": 900000
    }
  ],
  "total": 1,
  "minSeats": 7
}
```

---

## 🔍 Filter Helper Endpoints

### 6. Lấy danh sách loại nhiên liệu
**GET** `/api/search/filters/fuel-types`

**Mô tả:** Lấy danh sách các loại nhiên liệu có sẵn trong hệ thống

**Response (200 OK):**
```json
{
  "success": true,
  "data": [
    "Diesel",
    "Electric",
    "Gasoline",
    "Hybrid"
  ],
  "total": 4
}
```

---

### 7. Lấy danh sách hãng xe
**GET** `/api/search/filters/brands`

**Mô tả:** Lấy danh sách các hãng xe có sẵn trong hệ thống

**Response (200 OK):**
```json
{
  "success": true,
  "data": [
    "BMW",
    "Honda",
    "Mercedes",
    "Tesla",
    "Toyota"
  ],
  "total": 5
}
```

---

### 8. Lấy khoảng giá min-max
**GET** `/api/search/filters/price-range`

**Mô tả:** Lấy giá thấp nhất và cao nhất của xe trong hệ thống

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "min": 300000,
    "max": 10000000
  }
}
```

---

## 🔒 Error Responses

### 400 Bad Request
```json
{
  "success": false,
  "message": "Invalid fuel type. Must be: Electric, Gasoline, Diesel, or Hybrid"
}
```

### 500 Internal Server Error
```json
{
  "success": false,
  "message": "An error occurred: Database connection failed"
}
```

---

## 🧪 Testing với cURL

### Tìm kiếm nâng cao
```bash
curl -X POST http://localhost:8080/api/search/cars \
  -H "Content-Type: application/json" \
  -d '{
    "fuelType": "Gasoline",
    "priceMin": 500000,
    "priceMax": 1000000,
    "brand": "Toyota",
    "seats": 5,
    "sortBy": "price_asc"
  }'
```

### Tìm xe điện
```bash
curl -X GET http://localhost:8080/api/search/cars/fuel-type/Electric
```

### Tìm xe theo giá
```bash
curl -X GET "http://localhost:8080/api/search/cars/price-range?min=500000&max=1000000"
```

### Tìm xe Toyota
```bash
curl -X GET http://localhost:8080/api/search/cars/brand/Toyota
```

### Tìm xe 7 chỗ
```bash
curl -X GET http://localhost:8080/api/search/cars/seats/7
```

### Lấy danh sách loại nhiên liệu
```bash
curl -X GET http://localhost:8080/api/search/filters/fuel-types
```

### Lấy danh sách hãng xe
```bash
curl -X GET http://localhost:8080/api/search/filters/brands
```

### Lấy khoảng giá
```bash
curl -X GET http://localhost:8080/api/search/filters/price-range
```

---

## 📊 Use Cases

### Use Case 1: Tìm xe xăng Toyota 5 chỗ giá dưới 1 triệu
```json
POST /api/search/cars
{
  "fuelType": "Gasoline",
  "brand": "Toyota",
  "seats": 5,
  "priceMax": 1000000,
  "sortBy": "price_asc"
}
```

### Use Case 2: Tìm xe điện tại Hà Nội
```json
POST /api/search/cars
{
  "fuelType": "Electric",
  "location": "Hanoi",
  "sortBy": "price_desc"
}
```

### Use Case 3: Tìm xe 7 chỗ giá từ 800k-5tr
```json
POST /api/search/cars
{
  "seats": 7,
  "priceMin": 800000,
  "priceMax": 5000000,
  "sortBy": "newest"
}
```

### Use Case 4: Lấy tất cả xe Mercedes available
```json
POST /api/search/cars
{
  "brand": "Mercedes",
  "status": "available"
}
```

---

## 💡 Tips

1. **Mặc định chỉ tìm xe available:** Nếu không truyền `status`, hệ thống tự động lọc xe có status = "available"

2. **Tất cả filters đều optional:** Có thể gửi request body rỗng `{}` để lấy tất cả xe available

3. **Case-insensitive search:** Tìm kiếm không phân biệt hoa thường (Toyota = toyota = TOYOTA)

4. **Partial match cho model:** Model search hỗ trợ tìm kiếm một phần (ví dụ: "Cam" sẽ match "Camry")

5. **Sắp xếp mặc định:** Nếu không truyền `sortBy`, xe sẽ được sắp xếp theo newest (mới nhất)

6. **Filter helpers:** Sử dụng các endpoint `/api/search/filters/*` để lấy danh sách options cho dropdown filters

---

## 🎯 Frontend Integration Example

```javascript
// Tìm kiếm xe
async function searchCars() {
  const searchCriteria = {
    fuelType: document.getElementById('fuelType').value,
    priceMin: document.getElementById('priceMin').value,
    priceMax: document.getElementById('priceMax').value,
    brand: document.getElementById('brand').value,
    seats: document.getElementById('seats').value,
    location: document.getElementById('location').value,
    sortBy: document.getElementById('sortBy').value
  };

  const response = await fetch('http://localhost:8080/api/search/cars', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(searchCriteria)
  });

  const result = await response.json();
  console.log(`Found ${result.total} cars:`, result.data);
}

// Lấy filter options
async function loadFilterOptions() {
  // Load fuel types
  const fuelTypesRes = await fetch('http://localhost:8080/api/search/filters/fuel-types');
  const fuelTypes = await fuelTypesRes.json();
  
  // Load brands
  const brandsRes = await fetch('http://localhost:8080/api/search/filters/brands');
  const brands = await brandsRes.json();
  
  // Load price range
  const priceRangeRes = await fetch('http://localhost:8080/api/search/filters/price-range');
  const priceRange = await priceRangeRes.json();
  
  console.log('Fuel Types:', fuelTypes.data);
  console.log('Brands:', brands.data);
  console.log('Price Range:', priceRange.data);
}
```
