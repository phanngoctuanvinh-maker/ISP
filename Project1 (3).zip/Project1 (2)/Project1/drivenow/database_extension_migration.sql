-- =============================================
-- BOOKING EXTENSION FEATURE - DATABASE MIGRATION
-- Thêm các columns cho tính năng gia hạn booking
-- =============================================

USE drivenow_db;
GO

-- Kiểm tra bảng bookings đã tồn tại chưa
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'bookings')
BEGIN
    PRINT 'Table bookings exists. Adding extension columns...';

    -- 1. Thêm column: original_return_date (Ngày trả ban đầu trước khi gia hạn)
    IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS 
                   WHERE TABLE_NAME = 'bookings' AND COLUMN_NAME = 'original_return_date')
    BEGIN
        ALTER TABLE bookings ADD original_return_date DATETIME2 NULL;
        PRINT '✓ Added column: original_return_date';
    END
    ELSE
    BEGIN
        PRINT '○ Column original_return_date already exists';
    END

    -- 2. Thêm column: extension_days (Số ngày đã gia hạn thêm)
    IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS 
                   WHERE TABLE_NAME = 'bookings' AND COLUMN_NAME = 'extension_days')
    BEGIN
        ALTER TABLE bookings ADD extension_days INT DEFAULT 0 NULL;
        PRINT '✓ Added column: extension_days';
    END
    ELSE
    BEGIN
        PRINT '○ Column extension_days already exists';
    END

    -- 3. Thêm column: extension_price (Tiền phụ thu do gia hạn)
    IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS 
                   WHERE TABLE_NAME = 'bookings' AND COLUMN_NAME = 'extension_price')
    BEGIN
        ALTER TABLE bookings ADD extension_price DECIMAL(10,2) DEFAULT 0 NULL;
        PRINT '✓ Added column: extension_price';
    END
    ELSE
    BEGIN
        PRINT '○ Column extension_price already exists';
    END

    -- 4. Thêm column: is_extended (Flag đánh dấu đã gia hạn)
    IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS 
                   WHERE TABLE_NAME = 'bookings' AND COLUMN_NAME = 'is_extended')
    BEGIN
        ALTER TABLE bookings ADD is_extended BIT DEFAULT 0 NULL;
        PRINT '✓ Added column: is_extended';
    END
    ELSE
    BEGIN
        PRINT '○ Column is_extended already exists';
    END

    PRINT '';
    PRINT '=================================================';
    PRINT 'Extension columns added successfully!';
    PRINT '=================================================';
END
ELSE
BEGIN
    PRINT 'ERROR: Table bookings does not exist!';
    PRINT 'Please run the main database setup script first.';
END
GO

-- =============================================
-- VERIFICATION - Xem cấu trúc bảng bookings
-- =============================================
SELECT 
    COLUMN_NAME,
    DATA_TYPE,
    CHARACTER_MAXIMUM_LENGTH,
    IS_NULLABLE,
    COLUMN_DEFAULT
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'bookings'
ORDER BY ORDINAL_POSITION;
GO

-- =============================================
-- ROLLBACK SCRIPT (Nếu muốn xóa extension columns)
-- Uncomment để chạy
-- =============================================
/*
USE drivenow_db;
GO

ALTER TABLE bookings DROP COLUMN IF EXISTS original_return_date;
ALTER TABLE bookings DROP COLUMN IF EXISTS extension_days;
ALTER TABLE bookings DROP COLUMN IF EXISTS extension_price;
ALTER TABLE bookings DROP COLUMN IF EXISTS is_extended;

PRINT 'Extension columns removed successfully!';
GO
*/
