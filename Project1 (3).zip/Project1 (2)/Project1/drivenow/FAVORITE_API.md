# FAVORITE API - Xe yêu thích

## Tổng quan
API cho khách hàng thêm/xóa/xem danh sách xe yêu thích (Favorites/Wishlist).

**Base URL**: `/api/favorites`

**Tổng số endpoints**: 7 endpoints

---

## Danh sách APIs

### 1. Thêm xe vào danh sách yêu thích
**POST** `/api/favorites?customerId={customerId}&carId={carId}`

Thêm xe vào danh sách yêu thích của khách hàng.

**Query Parameters**:
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| customerId | Integer | Yes | ID khách hàng |
| carId | Integer | Yes | ID xe muốn thêm |

**Business Rules**:
- Khách hàng và xe phải tồn tại
- Không thể thêm cùng 1 xe nhiều lần
- Unique constraint: (customer_id, car_id)

**Response**: `201 Created`
```json
{
  "favoriteId": 1,
  "customerId": 10,
  "carId": 5,
  "carBrand": "Toyota",
  "carModel": "Camry",
  "seats": 5,
  "fuelType": "gasoline",
  "licensePlate": "30A-12345",
  "imageUrl": "https://example.com/camry.jpg",
  "location": "Hồ Chí Minh",
  "pricePerDay": 1000000,
  "status": "available",
  "createdAt": "2024-01-26T16:00:00"
}
```

**Error Responses**:

`404 Not Found` - Không tìm thấy khách hàng hoặc xe
```json
{
  "error": "Không tìm thấy khách hàng với ID: 999"
}
```

```json
{
  "error": "Không tìm thấy xe với ID: 999"
}
```

`400 Bad Request` - Xe đã có trong danh sách yêu thích
```json
{
  "error": "Xe này đã có trong danh sách yêu thích"
}
```

---

### 2. Xóa xe khỏi danh sách yêu thích
**DELETE** `/api/favorites?customerId={customerId}&carId={carId}`

Xóa xe khỏi danh sách yêu thích.

**Query Parameters**:
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| customerId | Integer | Yes | ID khách hàng |
| carId | Integer | Yes | ID xe muốn xóa |

**Response**: `200 OK`
```json
{
  "message": "Đã xóa xe khỏi danh sách yêu thích"
}
```

**Error Response**:

`404 Not Found` - Xe không có trong danh sách yêu thích
```json
{
  "error": "Xe này không có trong danh sách yêu thích"
}
```

---

### 3. Lấy danh sách xe yêu thích
**GET** `/api/favorites/{customerId}`

Lấy tất cả xe yêu thích của khách hàng.

**Path Parameters**:
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| customerId | Integer | Yes | ID khách hàng |

**Response**: `200 OK`
```json
[
  {
    "favoriteId": 1,
    "customerId": 10,
    "carId": 5,
    "carBrand": "Toyota",
    "carModel": "Camry",
    "seats": 5,
    "fuelType": "gasoline",
    "licensePlate": "30A-12345",
    "imageUrl": "https://example.com/camry.jpg",
    "location": "Hồ Chí Minh",
    "pricePerDay": 1000000,
    "status": "available",
    "createdAt": "2024-01-26T16:00:00"
  },
  {
    "favoriteId": 2,
    "customerId": 10,
    "carId": 8,
    "carBrand": "Honda",
    "carModel": "City",
    "seats": 5,
    "fuelType": "gasoline",
    "licensePlate": "51G-98765",
    "imageUrl": "https://example.com/city.jpg",
    "location": "Hà Nội",
    "pricePerDay": 800000,
    "status": "available",
    "createdAt": "2024-01-25T14:30:00"
  }
]
```

**Use case**:
- Hiển thị trang "Xe yêu thích của tôi"
- Sắp xếp theo thời gian thêm (mới nhất trước)

---

### 4. Kiểm tra xe đã yêu thích chưa
**GET** `/api/favorites/check?customerId={customerId}&carId={carId}`

Kiểm tra xe có trong danh sách yêu thích không.

**Query Parameters**:
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| customerId | Integer | Yes | ID khách hàng |
| carId | Integer | Yes | ID xe cần check |

**Response**: `200 OK`
```json
{
  "isFavorite": true
}
```

hoặc

```json
{
  "isFavorite": false
}
```

**Use case**:
- Hiển thị icon ❤️ (đỏ) nếu `isFavorite = true`
- Hiển thị icon 🤍 (trắng) nếu `isFavorite = false`
- Toggle trạng thái khi user click vào icon

---

### 5. Đếm số xe yêu thích của khách hàng
**GET** `/api/favorites/{customerId}/count`

Đếm tổng số xe trong danh sách yêu thích.

**Path Parameters**:
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| customerId | Integer | Yes | ID khách hàng |

**Response**: `200 OK`
```json
{
  "count": 5
}
```

**Use case**:
- Hiển thị badge trên icon favorites: ❤️ (5)
- Thống kê trong profile

---

### 6. Đếm số người yêu thích xe
**GET** `/api/favorites/cars/{carId}/count`

Đếm số lượng khách hàng đã yêu thích xe này.

**Path Parameters**:
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| carId | Integer | Yes | ID xe |

**Response**: `200 OK`
```json
{
  "count": 25
}
```

**Use case**:
- Hiển thị trên trang chi tiết xe: "❤️ 25 người đã yêu thích"
- Indicator về độ phổ biến của xe

---

### 7. Top xe được yêu thích nhiều nhất
**GET** `/api/favorites/top`

Lấy danh sách xe được yêu thích nhiều nhất.

**Response**: `200 OK`
```json
[
  {
    "carId": 5,
    "favoriteCount": 50
  },
  {
    "carId": 8,
    "favoriteCount": 35
  },
  {
    "carId": 3,
    "favoriteCount": 28
  }
]
```

**Use case**:
- Hiển thị section "Xe được yêu thích nhiều nhất"
- Analytics cho admin
- Recommend xe hot cho khách hàng

---

## Testing với Postman/cURL

### Test 1: Thêm xe yêu thích
```bash
POST http://localhost:8080/api/favorites?customerId=10&carId=5
```

**Expected**: `201 Created` với FavoriteDTO

### Test 2: Thử thêm lại xe đã yêu thích
```bash
POST http://localhost:8080/api/favorites?customerId=10&carId=5
```

**Expected**: `400 Bad Request` - "Xe này đã có trong danh sách yêu thích"

### Test 3: Lấy danh sách xe yêu thích
```bash
GET http://localhost:8080/api/favorites/10
```

**Expected**: Array of FavoriteDTO

### Test 4: Kiểm tra xe đã yêu thích chưa
```bash
GET http://localhost:8080/api/favorites/check?customerId=10&carId=5
```

**Expected**: `{ "isFavorite": true }`

### Test 5: Đếm số xe yêu thích
```bash
GET http://localhost:8080/api/favorites/10/count
```

**Expected**: `{ "count": 1 }`

### Test 6: Xóa xe yêu thích
```bash
DELETE http://localhost:8080/api/favorites?customerId=10&carId=5
```

**Expected**: `200 OK` - "Đã xóa xe khỏi danh sách yêu thích"

### Test 7: Đếm người yêu thích xe
```bash
GET http://localhost:8080/api/favorites/cars/5/count
```

**Expected**: `{ "count": 0 }` (vì đã xóa ở test 6)

### Test 8: Top xe yêu thích
```bash
GET http://localhost:8080/api/favorites/top
```

**Expected**: Array of top favorited cars

---

## Database Schema

### Bảng `favorites`
```sql
CREATE TABLE favorites (
  favorite_id INT PRIMARY KEY AUTO_INCREMENT,
  customer_id INT NOT NULL,
  car_id INT NOT NULL,
  created_at DATETIME DEFAULT GETDATE(),
  
  FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
  FOREIGN KEY (car_id) REFERENCES cars(car_id),
  
  -- Unique constraint: mỗi khách chỉ có thể yêu thích 1 xe 1 lần
  UNIQUE (customer_id, car_id)
);
```

**Indexes** (để tối ưu performance):
```sql
CREATE INDEX idx_favorites_customer ON favorites(customer_id);
CREATE INDEX idx_favorites_car ON favorites(car_id);
CREATE INDEX idx_favorites_created_at ON favorites(created_at DESC);
```

**Lưu ý**:
- Hibernate sẽ tự động tạo bảng với `spring.jpa.hibernate.ddl-auto=update`
- UNIQUE constraint đảm bảo không trùng lặp
- Cascade delete: Khi xóa customer/car → xóa favorites liên quan

---

## Use Cases (Luồng sử dụng)

### Use Case 1: Thêm xe yêu thích từ trang tìm kiếm

**Flow**:
1. Khách hàng vào trang tìm kiếm xe
2. Danh sách xe hiển thị với icon ❤️ bên cạnh mỗi xe
3. Check từng xe đã yêu thích chưa:
   ```
   GET /api/favorites/check?customerId=10&carId=5
   GET /api/favorites/check?customerId=10&carId=8
   ...
   ```
4. Hiển thị icon:
   - ❤️ (đỏ) nếu `isFavorite = true`
   - 🤍 (trắng) nếu `isFavorite = false`
5. Khách click vào icon 🤍 → Gọi API:
   ```
   POST /api/favorites?customerId=10&carId=5
   ```
6. Icon đổi thành ❤️ (đỏ)
7. Hiển thị toast: "Đã thêm vào yêu thích"

---

### Use Case 2: Xem và quản lý danh sách yêu thích

**Flow**:
1. Khách hàng click vào icon ❤️ trên header
2. Badge hiển thị số lượng:
   ```
   GET /api/favorites/10/count
   Response: { "count": 5 }
   → Hiển thị: ❤️ (5)
   ```
3. Vào trang "Xe yêu thích"
4. Load danh sách:
   ```
   GET /api/favorites/10
   ```
5. Hiển thị grid/list các xe với:
   - Hình ảnh xe
   - Thông tin: Brand, Model, Price
   - Nút ❌ để xóa
   - Nút "Thuê ngay"
6. Click nút ❌ → Confirm → Gọi API:
   ```
   DELETE /api/favorites?customerId=10&carId=5
   ```
7. Cập nhật UI: Xóa xe khỏi danh sách

---

### Use Case 3: Hiển thị độ phổ biến trên chi tiết xe

**Flow**:
1. Khách hàng click vào 1 xe
2. Trang chi tiết xe load:
   ```
   GET /api/favorites/cars/5/count
   Response: { "count": 25 }
   ```
3. Hiển thị: "❤️ 25 người đã yêu thích xe này"
4. Section "Xe tương tự phổ biến":
   ```
   GET /api/favorites/top
   ```
5. Hiển thị top 3 xe được yêu thích nhiều nhất

---

## UI Components

### 1. Favorite Button Component
```javascript
// Pseudo code
function FavoriteButton({ carId, customerId }) {
  const [isFavorite, setIsFavorite] = useState(false);
  
  useEffect(() => {
    // Check favorite status
    fetch(`/api/favorites/check?customerId=${customerId}&carId=${carId}`)
      .then(res => res.json())
      .then(data => setIsFavorite(data.isFavorite));
  }, []);
  
  const toggleFavorite = async () => {
    if (isFavorite) {
      // Remove
      await fetch(`/api/favorites?customerId=${customerId}&carId=${carId}`, {
        method: 'DELETE'
      });
      setIsFavorite(false);
      showToast('Đã xóa khỏi yêu thích');
    } else {
      // Add
      await fetch(`/api/favorites?customerId=${customerId}&carId=${carId}`, {
        method: 'POST'
      });
      setIsFavorite(true);
      showToast('Đã thêm vào yêu thích');
    }
  };
  
  return (
    <button onClick={toggleFavorite}>
      {isFavorite ? '❤️' : '🤍'}
    </button>
  );
}
```

### 2. Favorites Count Badge
```javascript
function FavoritesCountBadge({ customerId }) {
  const [count, setCount] = useState(0);
  
  useEffect(() => {
    fetch(`/api/favorites/${customerId}/count`)
      .then(res => res.json())
      .then(data => setCount(data.count));
  }, []);
  
  return (
    <div className="favorites-badge">
      ❤️ {count > 0 && <span className="badge">{count}</span>}
    </div>
  );
}
```

---

## Validation Rules

### Add Favorite:
- `customerId`: Bắt buộc, phải tồn tại
- `carId`: Bắt buộc, phải tồn tại
- Unique: Không được trùng (customer_id, car_id)

### Remove Favorite:
- Favorite phải tồn tại mới xóa được

### Business Rules:
- Không giới hạn số lượng xe yêu thích
- Tự động xóa khi customer/car bị xóa (cascade)
- Không ảnh hưởng đến booking

---

## Performance Optimization

### 1. Indexes:
- Index trên `customer_id` → Fast lookup favorites by customer
- Index trên `car_id` → Fast count favorites by car
- Index trên `created_at DESC` → Fast sort by latest

### 2. Caching Strategy:
- Cache favorite count của customer (TTL: 5 minutes)
- Cache top favorited cars (TTL: 1 hour)
- Invalidate cache khi add/remove favorite

### 3. Batch Operations:
- Load favorite status cho multiple cars cùng lúc
- Frontend: Check 10 cars cùng 1 request (có thể tạo endpoint `/api/favorites/check-batch`)

---

## Tổng kết

**Tổng số APIs**: 7 endpoints
- 1 endpoint thêm favorite
- 1 endpoint xóa favorite
- 1 endpoint lấy danh sách
- 4 endpoints query/statistics

**Tính năng**:
- ✅ Thêm/xóa xe yêu thích
- ✅ Xem danh sách xe yêu thích
- ✅ Check trạng thái yêu thích
- ✅ Đếm số lượng favorites
- ✅ Top xe phổ biến
- ✅ Unique constraint (không trùng)
- ✅ Cascade delete

**Database**:
- Bảng `favorites` với 4 columns
- UNIQUE constraint trên (customer_id, car_id)
- 3 indexes để tối ưu
- Auto-creation với Hibernate

**Ready for production!** 🚀
