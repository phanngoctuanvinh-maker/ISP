-- =============================================
-- DRIVENOW - SQL SERVER DATABASE SCRIPT
-- Hệ thống cho thuê xe ô tô có tài xế
-- =============================================

-- 1. Tạo Database
IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'drivenow_db')
BEGIN
    CREATE DATABASE drivenow_db;
    PRINT 'Database drivenow_db created successfully!';
END
ELSE
BEGIN
    PRINT 'Database drivenow_db already exists!';
END
GO

USE drivenow_db;
GO

-- =============================================
-- LƯU Ý:
-- Spring Boot JPA sẽ tự động tạo tables khi chạy
-- (do spring.jpa.hibernate.ddl-auto=update)
-- 
-- File này chỉ để reference cấu trúc database
-- Nếu muốn tạo tables manual, uncomment code bên dưới
-- =============================================

/*
-- 2. Tạo bảng Account
CREATE TABLE Account (
    account_id INT IDENTITY(1,1) PRIMARY KEY,
    username NVARCHAR(50) UNIQUE NOT NULL,
    password NVARCHAR(255) NOT NULL,
    role NVARCHAR(20) NOT NULL CHECK (role IN ('customer', 'driver', 'admin')),
    status NVARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'banned')),
    created_at DATETIME2 DEFAULT GETDATE(),
    updated_at DATETIME2 DEFAULT GETDATE()
);

-- 3. Tạo bảng Customer
CREATE TABLE Customer (
    customer_id INT IDENTITY(1,1) PRIMARY KEY,
    account_id INT UNIQUE NOT NULL,
    full_name NVARCHAR(100) NOT NULL,
    phone NVARCHAR(20),
    email NVARCHAR(100),
    address NVARCHAR(255),
    dob DATE,
    gender NVARCHAR(10),
    avatar_url NVARCHAR(255),
    created_at DATETIME2 DEFAULT GETDATE(),
    updated_at DATETIME2 DEFAULT GETDATE(),
    FOREIGN KEY (account_id) REFERENCES Account(account_id) ON DELETE CASCADE
);

-- 4. Tạo bảng Driver
CREATE TABLE Driver (
    driver_id INT IDENTITY(1,1) PRIMARY KEY,
    account_id INT UNIQUE NOT NULL,
    license_number NVARCHAR(50),
    years_of_experience INT,
    id_card NVARCHAR(50),
    address NVARCHAR(255),
    avatar_url NVARCHAR(255),
    average_rating DECIMAL(3,2),
    bio NVARCHAR(MAX),
    status NVARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'busy')),
    created_at DATETIME2 DEFAULT GETDATE(),
    updated_at DATETIME2 DEFAULT GETDATE(),
    FOREIGN KEY (account_id) REFERENCES Account(account_id) ON DELETE CASCADE
);

-- 5. Tạo bảng Admin
CREATE TABLE Admin (
    admin_id INT IDENTITY(1,1) PRIMARY KEY,
    account_id INT UNIQUE NOT NULL,
    role NVARCHAR(50),
    created_at DATETIME2 DEFAULT GETDATE(),
    updated_at DATETIME2 DEFAULT GETDATE(),
    FOREIGN KEY (account_id) REFERENCES Account(account_id) ON DELETE CASCADE
);

-- 6. Tạo bảng OTP
CREATE TABLE OTP (
    otp_id INT IDENTITY(1,1) PRIMARY KEY,
    email NVARCHAR(100) NOT NULL,
    otp_code NVARCHAR(6) NOT NULL,
    expiration_time DATETIME2 NOT NULL,
    is_used BIT DEFAULT 0,
    created_at DATETIME2 DEFAULT GETDATE()
);

-- 7. Tạo Indexes
CREATE INDEX idx_account_username ON Account(username);
CREATE INDEX idx_account_role ON Account(role);
CREATE INDEX idx_account_status ON Account(status);

CREATE INDEX idx_customer_email ON Customer(email);
CREATE INDEX idx_customer_phone ON Customer(phone);

CREATE INDEX idx_driver_license ON Driver(license_number);
CREATE INDEX idx_driver_status ON Driver(status);

CREATE INDEX idx_otp_email ON OTP(email);
CREATE INDEX idx_otp_expiration ON OTP(expiration_time);

PRINT 'All tables and indexes created successfully!';
*/

-- =============================================
-- INSERT DỮ LIỆU MẪU (Optional - for testing)
-- =============================================

-- Chạy sau khi Spring Boot đã tạo tables

/*
-- Password: 123456 (đã hash bằng BCrypt)
-- $2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy

-- Admin account
INSERT INTO Account (username, password, role, status) 
VALUES ('admin@drivenow.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'admin', 'active');

DECLARE @AdminAccountId INT = SCOPE_IDENTITY();

INSERT INTO Admin (account_id, role)
VALUES (@AdminAccountId, 'super_admin');

-- Customer account
INSERT INTO Account (username, password, role, status)
VALUES ('customer@gmail.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'customer', 'active');

DECLARE @CustomerAccountId INT = SCOPE_IDENTITY();

INSERT INTO Customer (account_id, full_name, phone, email, address, dob, gender)
VALUES (@CustomerAccountId, N'Nguyễn Văn A', '0987654321', 'customer@gmail.com', N'123 Đường ABC, TP.HCM', '2000-01-15', 'male');

-- Driver account
INSERT INTO Account (username, password, role, status)
VALUES ('driver@gmail.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'driver', 'active');

DECLARE @DriverAccountId INT = SCOPE_IDENTITY();

INSERT INTO Driver (account_id, license_number, years_of_experience, id_card, address, average_rating, status)
VALUES (@DriverAccountId, 'B2-123456', 5, '001234567890', N'456 Đường XYZ, Hà Nội', 4.5, 'active');

PRINT 'Sample data inserted successfully!';
PRINT 'Test accounts (password: 123456):';
PRINT '  - admin@drivenow.com (admin)';
PRINT '  - customer@gmail.com (customer)';
PRINT '  - driver@gmail.com (driver)';
*/

-- =============================================
-- QUERY KIỂM TRA DỮ LIỆU
-- =============================================

-- Kiểm tra tất cả accounts
-- SELECT * FROM Account;

-- Kiểm tra customers
-- SELECT c.*, a.username, a.role, a.status 
-- FROM Customer c 
-- INNER JOIN Account a ON c.account_id = a.account_id;

-- Kiểm tra drivers
-- SELECT d.*, a.username, a.role, a.status
-- FROM Driver d
-- INNER JOIN Account a ON d.account_id = a.account_id;

-- Kiểm tra admins
-- SELECT ad.*, a.username, a.role, a.status
-- FROM Admin ad
-- INNER JOIN Account a ON ad.account_id = a.account_id;

PRINT 'Database setup completed!';

-- =============================================
-- NOTE: EXTENSION FEATURE (Optional)
-- =============================================
-- Nếu cần tính năng gia hạn booking, chạy script:
-- database_extension_migration.sql
--
-- Script đó sẽ thêm 4 columns vào bảng bookings:
-- - original_return_date (DATETIME2)
-- - extension_days (INT)
-- - extension_price (DECIMAL(10,2))
-- - is_extended (BIT)
-- =============================================

