# API Documentation: Quản lý Hợp đồng Điện tử (Rental Contract Management)

## Tổng quan
Module quản lý hợp đồng điện tử cho phép tạo, lưu trữ và quản lý hợp đồng thuê xe. Hợp đồng được tạo tự động từ booking đã xác nhận và có chữ ký điện tử của cả 2 bên.

**Số lượng APIs:** 15 endpoints  
**Base URL:** `/api/rental-contracts`

---

## Các API Endpoints

### 1. Tạo Hợp đồng
**POST** `/api/rental-contracts`

Tạo hợp đồng điện tử cho booking đã xác nhận.

**Request Body:**
```json
{
  "bookingId": 1,
  "contractTemplate": "standard",
  "depositAmount": 5000000,
  "insuranceAmount": 500000,
  "lessorName": "CÔNG TY TNHH DRIVENOW",
  "lessorAddress": "123 Nguyễn Huệ, Q.1, TP.HCM",
  "lessorPhone": "0901234567",
  "lessorEmail": "contact@drivenow.vn",
  "lessorTaxCode": "0123456789",
  "lessorRepresentative": "Nguyễn Văn A",
  "lesseeIdCard": "123456789",
  "lesseeDateOfBirth": "1990-01-15T00:00:00",
  "lesseeLicenseNumber": "B1-123456",
  "lesseeLicenseExpiry": "2028-12-31T00:00:00",
  "carCondition": "Xe trong tình trạng tốt, đầy đủ phụ kiện",
  "additionalTerms": "Khách hàng cam kết trả xe đúng hạn",
  "notes": "Khách VIP, ưu tiên phục vụ"
}
```

**Response (201 Created):**
```json
{
  "success": true,
  "message": "Tạo hợp đồng thành công",
  "data": {
    "contractId": 1,
    "bookingId": 1,
    "contractNumber": "HDT-2025-0001",
    "contractDate": "2025-10-14T16:30:00",
    "startDate": "2025-10-20T10:00:00",
    "endDate": "2025-10-25T10:00:00",
    "totalAmount": 15000000,
    "depositAmount": 5000000,
    "insuranceAmount": 500000,
    "status": "draft",
    "lessorName": "CÔNG TY TNHH DRIVENOW",
    "lessorAddress": "123 Nguyễn Huệ, Q.1, TP.HCM",
    "lesseeName": "Nguyễn Văn B",
    "lesseePhone": "0912345678",
    "carInfo": "{\"brand\":\"Toyota\",\"model\":\"Camry\",\"licensePlate\":\"59A-12345\"}",
    "isSigned": false,
    "isArchived": false,
    "expiryDate": "2025-11-24T10:00:00"
  }
}
```

**Business Rules:**
- Chỉ tạo hợp đồng cho booking có status `confirmed` hoặc `paid`
- Mỗi booking chỉ có 1 hợp đồng
- Contract number tự động generate: `HDT-YYYY-XXXX`
- Thông tin bên cho thuê (lessor) có giá trị mặc định
- Thông tin bên thuê (lessee) lấy từ customer
- Thông tin xe lưu dạng JSON
- Hợp đồng hết hiệu lực sau 30 ngày kể từ ngày trả xe
- Status mặc định: `draft`

---

### 2. Lấy Hợp đồng theo ID
**GET** `/api/rental-contracts/{id}`

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "contractId": 1,
    "contractNumber": "HDT-2025-0001",
    "status": "active",
    "isSigned": true,
    ...
  }
}
```

---

### 3. Lấy Hợp đồng theo Contract Number
**GET** `/api/rental-contracts/number/{contractNumber}`

**Example:** `/api/rental-contracts/number/HDT-2025-0001`

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "contractId": 1,
    "contractNumber": "HDT-2025-0001",
    ...
  }
}
```

---

### 4. Lấy Hợp đồng theo Booking ID
**GET** `/api/rental-contracts/booking/{bookingId}`

**Example:** `/api/rental-contracts/booking/1`

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "contractId": 1,
    "bookingId": 1,
    ...
  }
}
```

**Use Case:** Hiển thị hợp đồng khi xem chi tiết booking

---

### 5. Lấy Danh sách Hợp đồng của Customer
**GET** `/api/rental-contracts/customer/{customerId}`

**Example:** `/api/rental-contracts/customer/5`

**Response (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "contractId": 1,
      "contractNumber": "HDT-2025-0001",
      "contractDate": "2025-10-14T16:30:00",
      "status": "active",
      "totalAmount": 15000000
    },
    {
      "contractId": 2,
      "contractNumber": "HDT-2025-0002",
      "contractDate": "2025-09-10T10:00:00",
      "status": "completed",
      "totalAmount": 8000000
    }
  ],
  "total": 2
}
```

**Use Case:** Customer xem lịch sử hợp đồng của mình

---

### 6. Lấy Hợp đồng theo Status
**GET** `/api/rental-contracts/status?status=active`

**Query Parameters:**
- `status` (optional, default="active"): draft, active, completed, cancelled, expired

**Response (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "contractId": 1,
      "contractNumber": "HDT-2025-0001",
      "status": "active",
      ...
    }
  ],
  "total": 15,
  "status": "active"
}
```

**Các Status:**
- `draft`: Nháp, chưa ký
- `active`: Đang hoạt động (đã ký đầy đủ)
- `completed`: Đã hoàn thành
- `cancelled`: Đã hủy
- `expired`: Đã hết hạn

---

### 7. Lấy Hợp đồng Đang Hoạt động
**GET** `/api/rental-contracts/active`

Lấy danh sách hợp đồng active, đã ký, chưa hết hạn.

**Response (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "contractId": 1,
      "contractNumber": "HDT-2025-0001",
      "status": "active",
      "isSigned": true,
      "expiryDate": "2025-11-24T10:00:00"
    }
  ],
  "total": 12
}
```

---

### 8. Lấy Hợp đồng Sắp Hết hạn
**GET** `/api/rental-contracts/expiring`

Lấy danh sách hợp đồng sẽ hết hạn trong vòng 7 ngày.

**Response (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "contractId": 3,
      "contractNumber": "HDT-2025-0003",
      "expiryDate": "2025-10-18T10:00:00",
      "status": "active"
    }
  ],
  "total": 3,
  "message": "Hợp đồng sắp hết hạn trong 7 ngày"
}
```

**Use Case:** Thông báo reminder để hoàn tất hợp đồng hoặc lưu trữ

---

### 9. Cập nhật Thông tin Hợp đồng
**PUT** `/api/rental-contracts/{id}`

Chỉ cập nhật được khi status là `draft` hoặc `active`.

**Request Body:**
```json
{
  "carCondition": "Xe đã được kiểm tra kỹ, không có trầy xước",
  "additionalTerms": "Khách hàng được miễn phí giao xe tận nơi",
  "notes": "Ưu tiên giao xe sáng sớm",
  "contractFileUrl": "https://drivenow.vn/contracts/HDT-2025-0001.pdf"
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Cập nhật hợp đồng thành công",
  "data": {
    "contractId": 1,
    "carCondition": "Xe đã được kiểm tra kỹ, không có trầy xước",
    ...
  }
}
```

---

### 10. Lessor Ký Hợp đồng
**PATCH** `/api/rental-contracts/{id}/sign-lessor`

Bên cho thuê (DriveNow) ký hợp đồng.

**Request Body:**
```json
{
  "signatureUrl": "https://drivenow.vn/signatures/lessor_sign_001.png"
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Bên cho thuê đã ký hợp đồng thành công",
  "data": {
    "contractId": 1,
    "lessorSignatureUrl": "https://drivenow.vn/signatures/lessor_sign_001.png",
    "lessorSignedAt": "2025-10-14T17:00:00",
    "status": "draft",
    "isSigned": false
  }
}
```

**Business Rules:**
- Khi cả 2 bên đã ký → `status` = "active", `isSigned` = true
- Chỉ ký được khi status là `draft` hoặc `active`

---

### 11. Lessee Ký Hợp đồng
**PATCH** `/api/rental-contracts/{id}/sign-lessee`

Bên thuê (Customer) ký hợp đồng.

**Request Body:**
```json
{
  "signatureUrl": "https://drivenow.vn/signatures/customer_sign_001.png"
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Bên thuê đã ký hợp đồng thành công",
  "data": {
    "contractId": 1,
    "lesseeSignatureUrl": "https://drivenow.vn/signatures/customer_sign_001.png",
    "lesseeSignedAt": "2025-10-14T18:00:00",
    "lessorSignedAt": "2025-10-14T17:00:00",
    "status": "active",
    "isSigned": true
  }
}
```

**Flow ký hợp đồng:**
1. Lessor ký trước → status vẫn "draft"
2. Lessee ký sau → Cả 2 đã ký → status = "active", isSigned = true
3. Hoặc ngược lại, ai ký trước cũng được

---

### 12. Hoàn thành Hợp đồng
**PATCH** `/api/rental-contracts/{id}/complete`

Đánh dấu hợp đồng đã hoàn thành (sau khi booking completed).

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Hợp đồng đã hoàn thành",
  "data": {
    "contractId": 1,
    "status": "completed"
  }
}
```

**Business Rules:**
- Chỉ complete được hợp đồng có status `active`

---

### 13. Hủy Hợp đồng
**PATCH** `/api/rental-contracts/{id}/cancel?reason=Khách hủy đột xuất`

**Query Parameters:**
- `reason` (optional): Lý do hủy hợp đồng

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Hợp đồng đã hủy",
  "data": {
    "contractId": 1,
    "status": "cancelled",
    "cancellationReason": "Khách hủy đột xuất"
  }
}
```

**Business Rules:**
- Không thể hủy hợp đồng đã completed hoặc đã cancelled

---

### 14. Lưu trữ Hợp đồng
**PATCH** `/api/rental-contracts/{id}/archive`

Đưa hợp đồng vào kho lưu trữ.

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Hợp đồng đã lưu trữ",
  "data": {
    "contractId": 1,
    "isArchived": true
  }
}
```

**Business Rules:**
- Chỉ lưu trữ được hợp đồng `completed` hoặc `cancelled`

---

### 15. Cập nhật Hợp đồng Hết hạn (Scheduled Task)
**PATCH** `/api/rental-contracts/update-expired`

Tự động cập nhật status = "expired" cho các hợp đồng đã quá hạn.

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Đã cập nhật trạng thái hợp đồng hết hạn"
}
```

**Use Case:** Chạy định kỳ hàng ngày bằng Cron Job hoặc Scheduler

---

## Các Use Cases Thực tế

### Use Case 1: Tạo và Ký Hợp đồng Hoàn chỉnh
```
1. Customer đặt xe → Booking created (status: confirmed)
2. Admin tạo hợp đồng:
   POST /api/rental-contracts
   {bookingId: 1, depositAmount: 5000000, ...}
   
3. Admin (Lessor) ký hợp đồng:
   PATCH /api/rental-contracts/1/sign-lessor
   {signatureUrl: "..."}
   
4. Customer (Lessee) ký hợp đồng:
   PATCH /api/rental-contracts/1/sign-lessee
   {signatureUrl: "..."}
   → Status = "active", isSigned = true
   
5. Giao xe và sử dụng...

6. Trả xe thành công → Hoàn thành hợp đồng:
   PATCH /api/rental-contracts/1/complete
   → Status = "completed"
   
7. Lưu trữ hợp đồng:
   PATCH /api/rental-contracts/1/archive
```

### Use Case 2: Customer Xem Hợp đồng của Mình
```
GET /api/rental-contracts/customer/5
→ Hiển thị tất cả hợp đồng của customer ID 5
→ Customer có thể tải PDF, xem chi tiết, chữ ký
```

### Use Case 3: Admin Quản lý Hợp đồng Sắp Hết hạn
```
GET /api/rental-contracts/expiring
→ Lấy danh sách hợp đồng sẽ hết hạn trong 7 ngày
→ Gửi reminder cho customer và staff
→ Hoàn tất/lưu trữ hợp đồng đúng hạn
```

### Use Case 4: Hủy Hợp đồng khi Booking Bị Hủy
```
Customer hủy booking → Admin hủy hợp đồng:
PATCH /api/rental-contracts/1/cancel?reason=Khách hủy booking
→ Status = "cancelled"
```

---

## Database Schema

### Table: `rental_contracts`
```sql
CREATE TABLE rental_contracts (
    contract_id INT PRIMARY KEY AUTO_INCREMENT,
    booking_id INT NOT NULL UNIQUE,
    contract_number VARCHAR(50) NOT NULL UNIQUE,
    contract_date DATETIME NOT NULL,
    start_date DATETIME NOT NULL,
    end_date DATETIME NOT NULL,
    total_amount DECIMAL(12,2) NOT NULL,
    deposit_amount DECIMAL(12,2),
    insurance_amount DECIMAL(12,2),
    status VARCHAR(20) NOT NULL DEFAULT 'draft',
    
    -- Lessor info (Bên cho thuê)
    lessor_name VARCHAR(200) NOT NULL,
    lessor_address VARCHAR(255) NOT NULL,
    lessor_phone VARCHAR(20),
    lessor_email VARCHAR(100),
    lessor_tax_code VARCHAR(50),
    lessor_representative VARCHAR(100),
    
    -- Lessee info (Bên thuê)
    lessee_name VARCHAR(200) NOT NULL,
    lessee_id_card VARCHAR(20),
    lessee_phone VARCHAR(20),
    lessee_email VARCHAR(100),
    lessee_address VARCHAR(255),
    lessee_date_of_birth DATETIME,
    lessee_license_number VARCHAR(50),
    lessee_license_expiry DATETIME,
    
    -- Car & terms
    car_info TEXT NOT NULL,
    car_condition TEXT,
    terms_and_conditions TEXT NOT NULL,
    additional_terms TEXT,
    
    -- Signatures
    lessor_signature_url VARCHAR(500),
    lessee_signature_url VARCHAR(500),
    lessor_signed_at DATETIME,
    lessee_signed_at DATETIME,
    
    -- Files & metadata
    contract_file_url VARCHAR(500),
    contract_template VARCHAR(50),
    notes TEXT,
    cancellation_reason TEXT,
    expiry_date DATETIME,
    is_signed BOOLEAN DEFAULT FALSE,
    is_archived BOOLEAN DEFAULT FALSE,
    
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id)
);

-- Indexes
CREATE INDEX idx_contract_number ON rental_contracts(contract_number);
CREATE INDEX idx_booking_id ON rental_contracts(booking_id);
CREATE INDEX idx_status ON rental_contracts(status);
CREATE INDEX idx_expiry_date ON rental_contracts(expiry_date);
CREATE INDEX idx_is_signed ON rental_contracts(is_signed);
```

---

## Business Logic Rules

### 1. Contract Number Generation
- Format: `HDT-YYYY-XXXX`
- `HDT`: Hợp đồng thuê
- `YYYY`: Năm hiện tại
- `XXXX`: Số thứ tự tự động tăng (0001, 0002, ...)
- Ví dụ: `HDT-2025-0001`, `HDT-2025-0002`

### 2. Status Flow
```
draft → active → completed
  ↓       ↓
cancelled expired
```

### 3. Signing Rules
- Cả 2 bên (lessor và lessee) phải ký thì hợp đồng mới `active`
- Thứ tự ký tùy ý (lessor trước hoặc lessee trước)
- Chỉ ký được khi status = `draft` hoặc `active`

### 4. Expiry Rules
- Hợp đồng hết hiệu lực sau **30 ngày** kể từ ngày trả xe
- Status tự động chuyển sang `expired` khi quá hạn
- Sử dụng scheduled task để tự động update

### 5. Archive Rules
- Chỉ lưu trữ được hợp đồng đã `completed` hoặc `cancelled`
- Hợp đồng archived không thể update

---

## Error Handling

### Common Errors
```json
// Booking không tồn tại
{
  "success": false,
  "message": "Không tìm thấy booking"
}

// Booking đã có hợp đồng
{
  "success": false,
  "message": "Booking này đã có hợp đồng"
}

// Booking chưa confirmed
{
  "success": false,
  "message": "Chỉ có thể tạo hợp đồng cho booking đã xác nhận hoặc đã thanh toán"
}

// Update hợp đồng không hợp lệ
{
  "success": false,
  "message": "Không thể cập nhật hợp đồng đã hoàn thành hoặc đã hủy"
}

// Complete hợp đồng không hợp lệ
{
  "success": false,
  "message": "Chỉ có thể hoàn thành hợp đồng đang hoạt động"
}
```

---

## Integration với Các Module Khác

### 1. Integration với Booking Module
- Hợp đồng được tạo từ booking confirmed/paid
- Mỗi booking có tối đa 1 hợp đồng
- Khi booking completed → complete contract
- Khi booking cancelled → cancel contract

### 2. Integration với Customer Module
- Thông tin lessee tự động lấy từ customer
- Customer có thể xem danh sách hợp đồng của mình

### 3. Integration với Car Module
- Thông tin xe lưu dạng JSON snapshot
- Giúp lưu lại trạng thái xe tại thời điểm ký hợp đồng

### 4. Future: PDF Generation
- Generate PDF từ contract template
- Embed chữ ký điện tử vào PDF
- Upload lên storage (AWS S3, Azure Blob)
- Lưu URL vào `contractFileUrl`

---

## Testing Examples

### Test 1: Create và Sign Contract
```bash
# 1. Tạo hợp đồng
curl -X POST http://localhost:8080/api/rental-contracts \
  -H "Content-Type: application/json" \
  -d '{
    "bookingId": 1,
    "depositAmount": 5000000,
    "insuranceAmount": 500000,
    "lesseeIdCard": "123456789",
    "lesseeLicenseNumber": "B1-123456"
  }'

# 2. Lessor ký
curl -X PATCH http://localhost:8080/api/rental-contracts/1/sign-lessor \
  -H "Content-Type: application/json" \
  -d '{"signatureUrl": "https://example.com/sign1.png"}'

# 3. Lessee ký
curl -X PATCH http://localhost:8080/api/rental-contracts/1/sign-lessee \
  -H "Content-Type: application/json" \
  -d '{"signatureUrl": "https://example.com/sign2.png"}'
  
# → Contract status = "active", isSigned = true
```

### Test 2: View Customer Contracts
```bash
curl http://localhost:8080/api/rental-contracts/customer/5
```

### Test 3: Check Expiring Contracts
```bash
curl http://localhost:8080/api/rental-contracts/expiring
```

---

## Tổng kết Module

### Thống kê
- **15 APIs** cho quản lý hợp đồng điện tử
- **1 Entity**: RentalContract (40+ fields)
- **6 DTOs**: RentalContractDTO, CreateRequest, UpdateRequest, SignatureRequest
- **1 Repository**: 16 query methods
- **1 Service**: 13 business methods

### Key Features
✅ Tạo hợp đồng từ booking  
✅ Chữ ký điện tử 2 bên  
✅ Quản lý status (draft → active → completed)  
✅ Lưu trữ thông tin chi tiết (lessor, lessee, car)  
✅ Tự động generate contract number  
✅ Expiry tracking & alerts  
✅ Archive completed contracts  
✅ Cancellation with reason  

### Next Steps
- [ ] PDF generation với template
- [ ] Email notification khi hợp đồng được tạo/ký
- [ ] Scheduled task tự động update expired contracts
- [ ] Integration với e-signature provider (DocuSign, etc.)
- [ ] Contract history tracking (version control)
