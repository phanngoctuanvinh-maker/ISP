# BOOKING SYSTEM - CODE STRUCTURE

## 📋 Tổng quan

Hệ thống Booking bao gồm **2 phần chính**:

### 1️⃣ **CORE BOOKING** (Bắt buộc - 13 APIs)
Tính năng cơ bản để đặt xe và quản lý booking

### 2️⃣ **EXTENSION FEATURE** (Tùy chọn - 1 API)
Tính năng gia hạn thêm thời gian thuê xe

---

## 🗂️ File Structure & Comments

### **Model Layer**

#### `Booking.java`
```java
// ✅ CORE FIELDS (Bắt buộc)
private Integer bookingId;
private Customer customer;
private Car car;
private Driver driver;
private LocalDateTime pickupDate;
private LocalDateTime returnDate;
private String pickupLocation;
private String returnLocation;
private Integer totalDays;
private BigDecimal totalPrice;
private String status;
private String paymentStatus;
private String paymentMethod;
private String notes;
private String cancellationReason;

// ============================================================
// [EXTENSION FEATURE] - Tính năng gia hạn booking (Optional)
// ============================================================
private LocalDateTime originalReturnDate;
private Integer extensionDays;
private BigDecimal extensionPrice;
private Boolean isExtended;
// ============================================================
```

**Location:** Lines 70-92  
**Comment markers:** `[EXTENSION FEATURE]` và `[END EXTENSION FEATURE]`

---

### **DTO Layer**

#### `BookingDTO.java`
```java
// ✅ CORE FIELDS (Bắt buộc)
private Integer bookingId;
private Integer customerId;
private String customerName;
// ... các fields cơ bản ...

// ============================================================
// [EXTENSION FEATURE] - Fields cho tính năng gia hạn
// ============================================================
private LocalDateTime originalReturnDate;
private Integer extensionDays;
private BigDecimal extensionPrice;
private Boolean isExtended;
// ============================================================
```

**Location:** Lines 28-38  
**Comment markers:** `[EXTENSION FEATURE]`

---

### **Service Layer**

#### `BookingService.java`

**✅ CORE METHODS (13 methods - Bắt buộc):**
1. `createBooking()` - Tạo booking mới
2. `updateBooking()` - Cập nhật booking
3. `getBookingById()` - Xem chi tiết
4. `getBookingsByCustomer()` - Danh sách của khách hàng
5. `getUpcomingBookingsByCustomer()` - Bookings sắp tới
6. `getBookingHistoryByCustomer()` - Lịch sử booking
7. `getAllBookings()` - Tất cả bookings (Admin)
8. `getBookingsByStatus()` - Lọc theo status
9. `confirmBooking()` - Xác nhận booking
10. `startBooking()` - Bắt đầu chuyến đi
11. `completeBooking()` - Hoàn thành
12. `cancelBooking()` - Hủy booking
13. `updatePaymentStatus()` - Cập nhật payment
14. `checkCarAvailability()` - Kiểm tra xe trống

```java
// ============================================================
// [EXTENSION FEATURE] - Tính năng gia hạn booking
// API: PATCH /api/bookings/{id}/extend
// ============================================================

@Transactional
public BookingDTO extendBooking(Integer bookingId, LocalDateTime newReturnDate) {
    // Logic gia hạn...
}

// ============================================================
// [END EXTENSION FEATURE]
// ============================================================
```

**Location:** Lines 295-400  
**Comment markers:** `[EXTENSION FEATURE]` và `[END EXTENSION FEATURE]`

---

### **Controller Layer**

#### `BookingController.java`

**✅ CORE ENDPOINTS (13 APIs - Bắt buộc):**
1. `POST /api/bookings` - Tạo booking
2. `PUT /api/bookings/{id}` - Update booking
3. `GET /api/bookings/{id}` - Chi tiết
4. `GET /api/bookings/customer/{customerId}` - Danh sách
5. `GET /api/bookings/customer/{customerId}/upcoming` - Sắp tới
6. `GET /api/bookings/customer/{customerId}/history` - Lịch sử
7. `GET /api/bookings?status=...` - Admin xem tất cả
8. `PATCH /api/bookings/{id}/confirm` - Xác nhận
9. `PATCH /api/bookings/{id}/start` - Bắt đầu
10. `PATCH /api/bookings/{id}/complete` - Hoàn thành
11. `PATCH /api/bookings/{id}/cancel` - Hủy
12. `PATCH /api/bookings/{id}/payment` - Update payment
13. `GET /api/bookings/check-availability` - Kiểm tra

```java
// ============================================================
// [EXTENSION FEATURE] - API gia hạn booking
// ============================================================

@PatchMapping("/{id}/extend")
public ResponseEntity<Map<String, Object>> extendBooking(...) {
    // Logic API...
}

// ============================================================
// [END EXTENSION FEATURE]
// ============================================================
```

**Location:** Lines 270-325  
**Comment markers:** `[EXTENSION FEATURE]` và `[END EXTENSION FEATURE]`

---

## 📊 Summary Table

| Component | Core Features | Extension Feature | Total |
|-----------|--------------|-------------------|-------|
| **Model Fields** | 14 fields | 4 fields | 18 fields |
| **DTO Fields** | 14 fields | 4 fields | 18 fields |
| **Service Methods** | 13 methods | 1 method | 14 methods |
| **API Endpoints** | 13 endpoints | 1 endpoint | **14 endpoints** |

---

## 🎯 Cách sử dụng

### **Option 1: Chỉ dùng Core Booking (13 APIs)**
Nếu không cần tính năng gia hạn:
- ✅ Code đầy đủ đã có, chỉ cần **bỏ qua** các phần có comment `[EXTENSION FEATURE]`
- ✅ Database sẽ tự động tạo các columns cho extension (không ảnh hưởng)
- ✅ Frontend không gọi API `/extend` là được

### **Option 2: Dùng đầy đủ (14 APIs)**
Nếu muốn có tính năng gia hạn:
- ✅ Code đã đầy đủ
- ✅ Database có sẵn các columns extension
- ✅ Frontend gọi thêm API `PATCH /api/bookings/{id}/extend`

---

## 📖 Documentation

### **Core Booking:**
- 📄 `BOOKING_API.md` - Tất cả 14 APIs (bao gồm core + extension)

### **Extension Feature:**
- 📄 `BOOKING_EXTENSION_FEATURE.md` - Chi tiết tính năng gia hạn
  - Business rules
  - Workflow
  - Use cases
  - Examples

---

## 🔍 Tìm code Extension nhanh

**Cách 1: Search comment**
```
Ctrl + F → "[EXTENSION FEATURE]"
```

**Cách 2: Search theo method/field name**
- `extendBooking` - Method gia hạn
- `originalReturnDate` - Field lưu ngày trả ban đầu
- `extensionDays` - Số ngày gia hạn
- `extensionPrice` - Tiền phụ thu
- `isExtended` - Flag đánh dấu đã gia hạn

**Cách 3: Search theo API endpoint**
```
PATCH /api/bookings/{id}/extend
```

---

## 💡 Best Practices

### **Khi đọc code:**
1. Bỏ qua sections có comment `[EXTENSION FEATURE]` nếu không cần
2. Focus vào 13 APIs core trước
3. Sau đó mới tìm hiểu extension feature

### **Khi modify code:**
1. Sửa core features: Không động vào sections có `[EXTENSION FEATURE]`
2. Sửa extension: Chỉ sửa trong sections có comment đó
3. Thêm features mới: Đặt comment tương tự

---

## 🎉 Summary

✅ **Code đầy đủ** cả Core + Extension  
✅ **Comment rõ ràng** phân biệt 2 phần  
✅ **Dễ maintain** khi cần sửa/thêm features  
✅ **Flexible** - Dùng core hoặc full tùy nhu cầu  

**Total:** 14 API endpoints (13 core + 1 extension) 🚀
