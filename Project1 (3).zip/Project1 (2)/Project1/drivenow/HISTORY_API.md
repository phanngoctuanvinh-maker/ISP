# API Documentation: History Tracking (Lịch sử Hành động)

## Tổng quan
Module History giúp tracking tất cả các hành động của user trong hệ thống, đặc biệt là lịch sử đặt xe. Mỗi lần user login, tạo booking, hủy booking... đều được ghi lại tự động.

**Số lượng APIs:** 13 endpoints  
**Base URL:** `/api/history`

---

## Luồng Hoạt động

### Luồng chính:
```
1. User Login 
   → Ghi history: action="login", IP address, user agent

2. User Book Xe 
   → Ghi history: action="create_booking", booking_id, car info

3. User Cancel/Complete Booking 
   → Ghi history: action="cancel_booking"/"complete_booking"

4. User xem lịch sử 
   → GET /api/history/account/{accountId}/bookings
   → Hiển thị toàn bộ lịch sử đặt xe
```

---

## Các API Endpoints

### 1. Ghi Lịch sử Đăng nhập
**POST** `/api/history/login?accountId=1`

Tự động ghi lại khi user login thành công.

**Response (201 Created):**
```json
{
  "success": true,
  "message": "Đã ghi lại lịch sử đăng nhập",
  "data": {
    "historyId": 1,
    "accountId": 1,
    "username": "user123",
    "action": "login",
    "description": "User logged in successfully",
    "ipAddress": "192.168.1.100",
    "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)...",
    "status": "success",
    "createdAt": "2025-10-14T17:00:00"
  }
}
```

**Use Case:** Gọi API này ngay sau khi user login thành công
```javascript
// Frontend code after login
fetch('/api/history/login?accountId=' + userId, {
  method: 'POST'
});
```

---

### 2. Ghi Lịch sử Tạo Booking
**POST** `/api/history/create-booking?accountId=1&bookingId=5`

Tự động ghi lại khi user tạo booking thành công.

**Response (201 Created):**
```json
{
  "success": true,
  "message": "Đã ghi lại lịch sử tạo booking",
  "data": {
    "historyId": 2,
    "accountId": 1,
    "username": "user123",
    "bookingId": 5,
    "action": "create_booking",
    "description": "User created booking #5 for car Toyota Camry",
    "entityType": "booking",
    "entityId": 5,
    "status": "success",
    "createdAt": "2025-10-14T17:05:00"
  }
}
```

**Integration:** Gọi sau khi tạo booking thành công
```javascript
// After booking created
fetch('/api/history/create-booking?accountId=' + userId + '&bookingId=' + bookingId, {
  method: 'POST'
});
```

---

### 3. Ghi Lịch sử Hủy Booking
**POST** `/api/history/cancel-booking?accountId=1&bookingId=5&reason=Thay đổi kế hoạch`

**Query Parameters:**
- `accountId` (required): ID của account
- `bookingId` (required): ID của booking bị hủy
- `reason` (optional): Lý do hủy

**Response (201 Created):**
```json
{
  "success": true,
  "message": "Đã ghi lại lịch sử hủy booking",
  "data": {
    "historyId": 3,
    "accountId": 1,
    "bookingId": 5,
    "action": "cancel_booking",
    "description": "User cancelled booking #5. Reason: Thay đổi kế hoạch",
    "entityType": "booking",
    "entityId": 5,
    "status": "success",
    "createdAt": "2025-10-14T17:10:00"
  }
}
```

---

### 4. Ghi Lịch sử Hoàn thành Booking
**POST** `/api/history/complete-booking?accountId=1&bookingId=5`

**Response (201 Created):**
```json
{
  "success": true,
  "message": "Đã ghi lại lịch sử hoàn thành booking",
  "data": {
    "historyId": 4,
    "accountId": 1,
    "bookingId": 5,
    "action": "complete_booking",
    "description": "User completed booking #5 successfully",
    "status": "success",
    "createdAt": "2025-10-14T18:00:00"
  }
}
```

---

### 5. Ghi Lịch sử Thanh toán
**POST** `/api/history/payment?accountId=1&bookingId=5&paymentMethod=credit_card`

**Response (201 Created):**
```json
{
  "success": true,
  "message": "Đã ghi lại lịch sử thanh toán",
  "data": {
    "historyId": 5,
    "accountId": 1,
    "bookingId": 5,
    "action": "payment",
    "description": "User paid for booking #5 using credit_card",
    "status": "success",
    "createdAt": "2025-10-14T17:06:00"
  }
}
```

---

### 6. Lấy Tất cả Lịch sử của Account
**GET** `/api/history/account/{accountId}`

Lấy toàn bộ lịch sử hành động của 1 account.

**Example:** `/api/history/account/1`

**Response (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "historyId": 5,
      "accountId": 1,
      "username": "user123",
      "action": "payment",
      "description": "User paid for booking #5 using credit_card",
      "bookingId": 5,
      "createdAt": "2025-10-14T17:06:00"
    },
    {
      "historyId": 4,
      "accountId": 1,
      "action": "complete_booking",
      "description": "User completed booking #5 successfully",
      "bookingId": 5,
      "createdAt": "2025-10-14T18:00:00"
    },
    {
      "historyId": 3,
      "accountId": 1,
      "action": "cancel_booking",
      "description": "User cancelled booking #5",
      "bookingId": 5,
      "createdAt": "2025-10-14T17:10:00"
    },
    {
      "historyId": 2,
      "accountId": 1,
      "action": "create_booking",
      "description": "User created booking #5 for car Toyota Camry",
      "bookingId": 5,
      "createdAt": "2025-10-14T17:05:00"
    },
    {
      "historyId": 1,
      "accountId": 1,
      "action": "login",
      "description": "User logged in successfully",
      "ipAddress": "192.168.1.100",
      "createdAt": "2025-10-14T17:00:00"
    }
  ],
  "total": 5
}
```

**Use Case:** Hiển thị timeline hành động của user

---

### 7. Lấy Lịch sử Đặt Xe của Account ⭐
**GET** `/api/history/account/{accountId}/bookings`

**Đây là API chính** để xem lịch sử các lần đặt xe của user.

**Example:** `/api/history/account/1/bookings`

**Response (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "historyId": 10,
      "accountId": 1,
      "username": "user123",
      "bookingId": 8,
      "action": "create_booking",
      "description": "User created booking #8 for car Honda CR-V",
      "entityType": "booking",
      "entityId": 8,
      "status": "success",
      "createdAt": "2025-10-12T09:30:00"
    },
    {
      "historyId": 6,
      "accountId": 1,
      "bookingId": 5,
      "action": "create_booking",
      "description": "User created booking #5 for car Toyota Camry",
      "entityType": "booking",
      "entityId": 5,
      "createdAt": "2025-10-10T14:20:00"
    },
    {
      "historyId": 2,
      "accountId": 1,
      "bookingId": 3,
      "action": "create_booking",
      "description": "User created booking #3 for car Mazda CX-5",
      "createdAt": "2025-10-08T11:15:00"
    }
  ],
  "total": 3,
  "message": "Lịch sử đặt xe của account"
}
```

**Frontend Display:**
```javascript
// Show booking history timeline
fetch('/api/history/account/' + userId + '/bookings')
  .then(res => res.json())
  .then(data => {
    data.data.forEach(history => {
      console.log(`${history.createdAt}: ${history.description}`);
    });
  });
```

---

### 8. Lấy Lịch sử Login của Account
**GET** `/api/history/account/{accountId}/logins`

**Response (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "historyId": 15,
      "accountId": 1,
      "action": "login",
      "description": "User logged in successfully",
      "ipAddress": "192.168.1.100",
      "userAgent": "Mozilla/5.0...",
      "createdAt": "2025-10-14T17:00:00"
    },
    {
      "historyId": 12,
      "accountId": 1,
      "action": "login",
      "ipAddress": "192.168.1.105",
      "createdAt": "2025-10-13T08:30:00"
    }
  ],
  "total": 2
}
```

**Use Case:** 
- Security: Kiểm tra các lần đăng nhập
- Phát hiện đăng nhập bất thường (IP khác lạ)

---

### 9. Lấy Lịch sử theo Booking ID
**GET** `/api/history/booking/{bookingId}`

Xem toàn bộ lịch sử của 1 booking (create, payment, cancel, complete).

**Example:** `/api/history/booking/5`

**Response (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "historyId": 8,
      "bookingId": 5,
      "action": "complete_booking",
      "description": "User completed booking #5 successfully",
      "createdAt": "2025-10-14T18:00:00"
    },
    {
      "historyId": 7,
      "bookingId": 5,
      "action": "payment",
      "description": "User paid for booking #5 using credit_card",
      "createdAt": "2025-10-14T17:06:00"
    },
    {
      "historyId": 6,
      "bookingId": 5,
      "action": "create_booking",
      "description": "User created booking #5 for car Toyota Camry",
      "createdAt": "2025-10-14T17:05:00"
    }
  ],
  "total": 3
}
```

**Use Case:** Timeline của 1 booking cụ thể

---

### 10. Lấy Lịch sử theo Action Type
**GET** `/api/history/action?action=create_booking`

**Các action có thể filter:**
- `login` - Đăng nhập
- `create_booking` - Tạo booking
- `cancel_booking` - Hủy booking
- `complete_booking` - Hoàn thành booking
- `payment` - Thanh toán

**Response (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "historyId": 10,
      "accountId": 2,
      "action": "create_booking",
      "bookingId": 8,
      "createdAt": "2025-10-14T09:00:00"
    },
    {
      "historyId": 6,
      "accountId": 1,
      "action": "create_booking",
      "bookingId": 5,
      "createdAt": "2025-10-14T08:00:00"
    }
  ],
  "total": 2,
  "action": "create_booking"
}
```

**Use Case:** Admin xem tất cả bookings được tạo trong hệ thống

---

### 11. Lấy Lịch sử theo Khoảng Thời gian
**GET** `/api/history/account/{accountId}/date-range?startDate=2025-10-01T00:00:00&endDate=2025-10-31T23:59:59`

**Query Parameters:**
- `startDate` (required): Ngày bắt đầu (ISO 8601 format)
- `endDate` (required): Ngày kết thúc

**Response (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "historyId": 10,
      "action": "create_booking",
      "createdAt": "2025-10-12T09:30:00"
    },
    {
      "historyId": 6,
      "action": "create_booking",
      "createdAt": "2025-10-10T14:20:00"
    }
  ],
  "total": 2,
  "startDate": "2025-10-01T00:00:00",
  "endDate": "2025-10-31T23:59:59"
}
```

**Use Case:** Báo cáo hoạt động theo tháng/tuần

---

### 12. Lấy Hoạt động Gần đây
**GET** `/api/history/recent?limit=20`

Lấy các hoạt động gần nhất của toàn hệ thống (dành cho admin).

**Query Parameters:**
- `limit` (optional, default=20): Số lượng records

**Response (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "historyId": 25,
      "accountId": 5,
      "username": "user789",
      "action": "create_booking",
      "createdAt": "2025-10-14T17:30:00"
    },
    {
      "historyId": 24,
      "accountId": 3,
      "username": "user456",
      "action": "login",
      "createdAt": "2025-10-14T17:25:00"
    }
  ],
  "total": 20
}
```

**Use Case:** Admin dashboard - Real-time activity feed

---

### 13. Đếm Số lượng Hành động
**GET** `/api/history/account/{accountId}/count?action=create_booking`

**Response (200 OK):**
```json
{
  "success": true,
  "count": 15,
  "action": "create_booking"
}
```

**Use Case:** 
- Thống kê: User này đã đặt bao nhiêu lần xe
- Badge: "Đã đặt 15 chuyến"

---

## Database Schema

### Table: `history`
```sql
CREATE TABLE history (
    history_id INT PRIMARY KEY AUTO_INCREMENT,
    account_id INT NOT NULL,
    booking_id INT,
    driver_id INT,
    action VARCHAR(100) NOT NULL,
    description TEXT,
    entity_type VARCHAR(50),
    entity_id INT,
    ip_address VARCHAR(50),
    user_agent VARCHAR(255),
    status VARCHAR(20),
    metadata TEXT,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (account_id) REFERENCES account(account_id),
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id),
    FOREIGN KEY (driver_id) REFERENCES driver(driver_id)
);

-- Indexes
CREATE INDEX idx_account_id ON history(account_id);
CREATE INDEX idx_booking_id ON history(booking_id);
CREATE INDEX idx_action ON history(action);
CREATE INDEX idx_created_at ON history(created_at);
CREATE INDEX idx_entity_type_id ON history(entity_type, entity_id);
```

---

## Action Types (Các loại hành động)

### Booking Related
- `create_booking` - Tạo booking mới
- `cancel_booking` - Hủy booking
- `complete_booking` - Hoàn thành booking
- `extend_booking` - Gia hạn booking
- `payment` - Thanh toán booking

### Account Related
- `login` - Đăng nhập
- `logout` - Đăng xuất
- `register` - Đăng ký tài khoản
- `update_profile` - Cập nhật thông tin

### Review Related
- `create_review` - Viết đánh giá
- `update_review` - Sửa đánh giá

### Favorites Related
- `add_favorite` - Thêm xe yêu thích
- `remove_favorite` - Xóa xe yêu thích

---

## Integration Examples

### Example 1: Tích hợp vào Login Flow
```javascript
// Login API response
async function handleLogin(username, password) {
  const loginRes = await fetch('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ username, password })
  });
  
  const loginData = await loginRes.json();
  
  if (loginData.success) {
    // Ghi history ngay sau login
    await fetch(`/api/history/login?accountId=${loginData.accountId}`, {
      method: 'POST'
    });
    
    // Redirect to dashboard
    window.location.href = '/dashboard';
  }
}
```

### Example 2: Tích hợp vào Booking Flow
```javascript
// After creating booking
async function createBooking(bookingData) {
  const bookingRes = await fetch('/api/bookings', {
    method: 'POST',
    body: JSON.stringify(bookingData)
  });
  
  const booking = await bookingRes.json();
  
  if (booking.success) {
    // Ghi history create booking
    await fetch(`/api/history/create-booking?accountId=${userId}&bookingId=${booking.data.bookingId}`, {
      method: 'POST'
    });
    
    // Redirect to booking details
    window.location.href = `/bookings/${booking.data.bookingId}`;
  }
}
```

### Example 3: Hiển thị Lịch sử Đặt Xe
```javascript
// User profile page - Booking history section
async function loadBookingHistory(userId) {
  const res = await fetch(`/api/history/account/${userId}/bookings`);
  const data = await res.json();
  
  const historyHTML = data.data.map(h => `
    <div class="history-item">
      <div class="date">${new Date(h.createdAt).toLocaleDateString()}</div>
      <div class="action">${h.action}</div>
      <div class="description">${h.description}</div>
    </div>
  `).join('');
  
  document.getElementById('booking-history').innerHTML = historyHTML;
}
```

---

## Use Cases Thực tế

### Use Case 1: User Profile - Activity Timeline
```
User vào trang Profile → Tab "Lịch sử hoạt động"
→ GET /api/history/account/{userId}
→ Hiển thị timeline:
  - 14/10/2025 17:00: Đăng nhập
  - 14/10/2025 17:05: Đặt xe Toyota Camry
  - 14/10/2025 17:06: Thanh toán thành công
  - 14/10/2025 18:00: Hoàn thành chuyến đi
```

### Use Case 2: Booking Details - Lifecycle
```
Admin xem chi tiết booking #5
→ GET /api/history/booking/5
→ Hiển thị timeline của booking:
  - Created: 14/10 17:05 by user123
  - Paid: 14/10 17:06 via credit_card
  - Completed: 14/10 18:00
```

### Use Case 3: Security - Login History
```
User settings → Security → Login History
→ GET /api/history/account/{userId}/logins
→ Hiển thị:
  - 14/10 17:00 - IP: 192.168.1.100 - Chrome on Windows
  - 13/10 08:30 - IP: 192.168.1.105 - Safari on iPhone
  - Cảnh báo nếu có IP lạ
```

### Use Case 4: Statistics - Booking Count
```
User profile badge
→ GET /api/history/account/{userId}/count?action=create_booking
→ Response: { count: 15 }
→ Hiển thị: "🎖️ Đã đặt 15 chuyến xe"
```

---

## Business Logic

### Auto-record History Flow
```
1. User Login
   → AuthController gọi HistoryService.recordLogin()
   → Lưu IP address, user agent, timestamp

2. User Create Booking
   → BookingController sau khi save booking
   → Gọi HistoryService.recordCreateBooking()
   → Lưu booking_id, car info

3. User Cancel Booking
   → BookingController.cancelBooking()
   → Gọi HistoryService.recordCancelBooking()
   → Lưu cancellation reason

4. User Complete Booking
   → BookingController.completeBooking()
   → Gọi HistoryService.recordCompleteBooking()
   → Mark booking lifecycle completed
```

### Metadata Field Usage
Lưu thêm thông tin dạng JSON:
```json
{
  "car_brand": "Toyota",
  "car_model": "Camry",
  "total_price": 15000000,
  "payment_method": "credit_card",
  "device": "mobile"
}
```

---

## Testing Examples

### Test 1: Record Login
```bash
curl -X POST "http://localhost:8080/api/history/login?accountId=1" \
  -H "User-Agent: Mozilla/5.0..."
```

### Test 2: Get Booking History
```bash
curl http://localhost:8080/api/history/account/1/bookings
```

### Test 3: Count User Actions
```bash
curl "http://localhost:8080/api/history/account/1/count?action=create_booking"
```

---

## Tổng kết Module

### Thống kê
- **13 APIs** cho history tracking
- **1 Entity**: History (14 fields)
- **1 DTO**: HistoryDTO
- **1 Repository**: 13 query methods
- **1 Service**: 11 business methods
- **1 Repository mới**: AccountRepository

### Key Features
✅ Auto-track login với IP & user agent  
✅ Track toàn bộ lifecycle của booking  
✅ Timeline view cho user profile  
✅ Security: Login history tracking  
✅ Statistics: Action counting  
✅ Date range filtering  
✅ Recent activities dashboard  
✅ Entity tracking (booking, payment, etc.)  

### Integration Points
- Login API → Record login history
- Booking API → Record create/cancel/complete
- Payment API → Record payment
- Profile Page → Display activity timeline
- Admin Dashboard → Recent activities feed

---

## Entity Relationships

```
Account (1) -------- (N) History
Booking (1) -------- (N) History
Driver (1) --------- (N) History
```

**Giải thích:**
- 1 Account có nhiều History records
- 1 Booking có nhiều History records (create, payment, complete, cancel)
- History luôn link về Account (bắt buộc)
- History có thể link về Booking (optional)

---

## Next Steps
- [ ] Background job: Cleanup old history (>1 năm)
- [ ] Export history to CSV/PDF
- [ ] Real-time notification khi có action mới
- [ ] Analytics dashboard từ history data
- [ ] Audit log cho admin actions
