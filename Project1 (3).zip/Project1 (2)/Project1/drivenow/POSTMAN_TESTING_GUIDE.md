# 📋 HƯỚNG DẪN TEST APIs TRÊN POSTMAN

## 🚀 Bước 1: Import Collection vào Postman

1. **Mở Postman** (Nếu chưa có, tải tại: https://www.postman.com/downloads/)

2. **Import Collection:**
   - Click nút **Import** ở góc trên bên trái
   - Chọn tab **File**
   - Duyệt đến file: `DriveNow_Postman_Collection.json`
   - Click **Import**

3. **Kiểm tra Collection:**
   - Bạn sẽ thấy collection "DriveNow API Collection" với 9 folders
   - Tổng cộng **97 APIs** để test

---

## 🔧 Bước 2: Đảm bảo Server đang chạy

### Kiểm tra Server:
```powershell
# Mở PowerShell và chạy:
cd "e:\DriveNowPorject\Project1 (2)\Project1\drivenow"
.\mvnw spring-boot:run
```

### Đợi đến khi thấy log:
```
Started DrivenowApplication in X.XXX seconds
Tomcat started on port(s): 8080
```

✅ Server đã sẵn sàng tại: **http://localhost:8080**

---

## 📝 Bước 3: Test Theo Thứ Tự

### 🔐 **1. AUTHENTICATION (Test đầu tiên)**

#### A. Register Customer
```http
POST http://localhost:8080/api/auth/register
Content-Type: application/json

{
  "username": "testuser",
  "password": "123456",
  "fullName": "Nguyen Van Test",
  "email": "test@gmail.com",
  "phone": "0901234567",
  "address": "123 Test Street, HCM"
}
```

**Kết quả mong đợi:**
```json
{
  "message": "Registration successful",
  "customerId": 1
}
```

#### B. Login
```http
POST http://localhost:8080/api/auth/login
Content-Type: application/json

{
  "username": "testuser",
  "password": "123456"
}
```

**Kết quả mong đợi:**
```json
{
  "accountId": 1,
  "customerId": 1,
  "username": "testuser",
  "role": "customer",
  "message": "Login successful"
}
```

> 📌 **Quan trọng:** Lưu lại `accountId` và `customerId` để dùng cho các API khác!

---

### 📊 **2. HISTORY TRACKING (Test ngay sau login)**

#### A. Record Login History
```http
POST http://localhost:8080/api/history/login?accountId=1
```

**Kết quả mong đợi:**
```json
{
  "historyId": 1,
  "action": "login",
  "description": "User logged in",
  "ipAddress": "127.0.0.1",
  "createdAt": "2025-10-14T10:30:00"
}
```

#### B. Get All History by Account
```http
GET http://localhost:8080/api/history/account/1
```

**Kết quả mong đợi:**
```json
[
  {
    "historyId": 1,
    "accountId": 1,
    "action": "login",
    "description": "User logged in",
    "createdAt": "2025-10-14T10:30:00"
  }
]
```

#### C. Get Login History
```http
GET http://localhost:8080/api/history/account/1/logins
```

---

### 🚗 **3. CAR MANAGEMENT**

#### A. Create Car (Admin)
```http
POST http://localhost:8080/api/cars
Content-Type: application/json

{
  "brand": "Toyota",
  "model": "Camry",
  "seats": 5,
  "fuelType": "Gasoline",
  "licensePlate": "59A-12345",
  "location": "HCM City",
  "pricePerDay": 800000,
  "status": "available"
}
```

**Kết quả mong đợi:**
```json
{
  "carId": 1,
  "brand": "Toyota",
  "model": "Camry",
  "pricePerDay": 800000,
  "status": "available"
}
```

#### B. Get All Cars
```http
GET http://localhost:8080/api/cars
```

#### C. Get Car by ID
```http
GET http://localhost:8080/api/cars/1
```

#### D. Update Car
```http
PUT http://localhost:8080/api/cars/1
Content-Type: application/json

{
  "brand": "Toyota",
  "model": "Camry 2024",
  "pricePerDay": 850000,
  "status": "available"
}
```

---

### 📅 **4. BOOKING**

#### A. Create Booking
```http
POST http://localhost:8080/api/bookings
Content-Type: application/json

{
  "customerId": 1,
  "carId": 1,
  "pickupDate": "2025-10-20T10:00:00",
  "returnDate": "2025-10-25T10:00:00",
  "pickupLocation": "123 Nguyen Hue, Q1, HCM",
  "returnLocation": "123 Nguyen Hue, Q1, HCM"
}
```

**Kết quả mong đợi:**
```json
{
  "bookingId": 1,
  "customerId": 1,
  "carId": 1,
  "status": "pending",
  "totalPrice": 4000000,
  "message": "Booking created successfully"
}
```

> 📌 **Lưu lại `bookingId` để test các API khác!**

#### B. Record Create Booking History
```http
POST http://localhost:8080/api/history/create-booking?accountId=1&bookingId=1
```

#### C. Get Booking History
```http
GET http://localhost:8080/api/history/account/1/bookings
```

**Kết quả mong đợi:**
```json
[
  {
    "historyId": 2,
    "action": "create_booking",
    "bookingId": 1,
    "description": "Created booking #1",
    "createdAt": "2025-10-14T10:35:00"
  }
]
```

#### D. Count Bookings
```http
GET http://localhost:8080/api/history/account/1/count?action=create_booking
```

**Kết quả mong đợi:**
```json
{
  "count": 1,
  "message": "User has 1 booking(s)"
}
```

#### E. Confirm Booking
```http
PATCH http://localhost:8080/api/bookings/1/confirm
```

#### F. Cancel Booking
```http
PATCH http://localhost:8080/api/bookings/1/cancel?reason=Change of plans
```

---

### 👥 **5. GROUP BOOKING**

#### A. Create Group Booking (3 cars)
```http
POST http://localhost:8080/api/group-bookings
Content-Type: application/json

{
  "customerId": 1,
  "carIds": [1, 2, 3],
  "pickupDate": "2025-10-20T10:00:00",
  "returnDate": "2025-10-25T10:00:00",
  "pickupLocation": "HCM Airport",
  "groupName": "Company Trip"
}
```

#### B. Get Group Booking by ID
```http
GET http://localhost:8080/api/group-bookings/1
```

#### C. Get Customer Group Bookings
```http
GET http://localhost:8080/api/group-bookings/customer/1
```

---

### 🚚 **6. DELIVERY SCHEDULE**

#### A. Create Delivery Schedule (Pickup)
```http
POST http://localhost:8080/api/delivery-schedules
Content-Type: application/json

{
  "bookingId": 1,
  "scheduleType": "pickup",
  "scheduledTime": "2025-10-20T09:00:00",
  "location": "123 Nguyen Hue, Q1, HCM"
}
```

#### B. Get Upcoming Schedules
```http
GET http://localhost:8080/api/delivery-schedules/upcoming
```

#### C. Assign Driver
```http
PATCH http://localhost:8080/api/delivery-schedules/1/assign-driver?driverId=1
```

#### D. Complete Delivery
```http
PATCH http://localhost:8080/api/delivery-schedules/1/complete
Content-Type: application/json

{
  "fuelLevel": 100,
  "mileage": 15000,
  "carCondition": "Good condition, no damage",
  "imageUrl": "https://example.com/car-photo.jpg"
}
```

---

### 📝 **7. RENTAL CONTRACT**

#### A. Create Contract
```http
POST http://localhost:8080/api/rental-contracts
Content-Type: application/json

{
  "bookingId": 1,
  "depositAmount": 5000000,
  "insuranceAmount": 500000,
  "lesseeIdCard": "123456789",
  "lesseeLicenseNumber": "B1-123456",
  "carCondition": "Xe trong tình trạng tốt"
}
```

**Kết quả mong đợi:**
```json
{
  "contractId": 1,
  "contractNumber": "HDT-2025-0001",
  "status": "draft",
  "message": "Contract created successfully"
}
```

#### B. Get Contract by ID
```http
GET http://localhost:8080/api/rental-contracts/1
```

#### C. Lessor Sign Contract
```http
PATCH http://localhost:8080/api/rental-contracts/1/sign-lessor
Content-Type: application/json

{
  "signatureUrl": "https://example.com/lessor-signature.png"
}
```

#### D. Lessee Sign Contract
```http
PATCH http://localhost:8080/api/rental-contracts/1/sign-lessee
Content-Type: application/json

{
  "signatureUrl": "https://example.com/lessee-signature.png"
}
```

---

### ⭐ **8. REVIEWS**

#### A. Create Review
```http
POST http://localhost:8080/api/reviews
Content-Type: application/json

{
  "bookingId": 1,
  "rating": 5,
  "comment": "Xe rất tốt, tài xế thân thiện!"
}
```

#### B. Get Reviews by Car
```http
GET http://localhost:8080/api/reviews/car/1
```

#### C. Get Reviews by Customer
```http
GET http://localhost:8080/api/reviews/customer/1
```

---

### ❤️ **9. FAVORITES**

#### A. Add Favorite
```http
POST http://localhost:8080/api/favorites?customerId=1&carId=1
```

#### B. Get Customer Favorites
```http
GET http://localhost:8080/api/favorites/customer/1
```

#### C. Remove Favorite
```http
DELETE http://localhost:8080/api/favorites/1
```

---

## 🎯 LUỒNG TEST HOÀN CHỈNH (End-to-End)

### Scenario: Customer đặt xe và hoàn thành chuyến đi

```
1. Register → Login → Record Login History
   ↓
2. Get All Cars → Add Favorite
   ↓
3. Create Booking → Record Create Booking History
   ↓
4. Create Rental Contract → Sign Contract
   ↓
5. Create Delivery Schedule → Assign Driver → Complete Delivery
   ↓
6. Complete Booking → Create Review
   ↓
7. Get Booking History → Count Total Bookings
```

### Code test nhanh:
```bash
# 1. Register
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username":"testuser","password":"123456","fullName":"Test User"}'

# 2. Login
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"testuser","password":"123456"}'

# 3. Record Login
curl -X POST "http://localhost:8080/api/history/login?accountId=1"

# 4. Get Cars
curl http://localhost:8080/api/cars

# 5. Create Booking
curl -X POST http://localhost:8080/api/bookings \
  -H "Content-Type: application/json" \
  -d '{"customerId":1,"carId":1,"pickupDate":"2025-10-20T10:00:00","returnDate":"2025-10-25T10:00:00"}'

# 6. Record Booking
curl -X POST "http://localhost:8080/api/history/create-booking?accountId=1&bookingId=1"

# 7. Get Booking History
curl http://localhost:8080/api/history/account/1/bookings
```

---

## ✅ CHECKLIST KIỂM TRA

- [ ] Server chạy thành công trên port 8080
- [ ] Database "drivenow_db" kết nối OK
- [ ] Bảng history đã được tạo (refresh SQL Server)
- [ ] Register user mới thành công
- [ ] Login trả về accountId và customerId
- [ ] Record login history thành công
- [ ] Create booking thành công
- [ ] Record booking history thành công
- [ ] Get booking history hiển thị đúng
- [ ] Count bookings trả về số chính xác
- [ ] Tất cả 97 APIs đều test được

---

## 🐛 XỬ LÝ LỖI THƯỜNG GẶP

### 1. **Connection refused**
```
❌ Error: connect ECONNREFUSED 127.0.0.1:8080
✅ Fix: Kiểm tra server đã chạy chưa: .\mvnw spring-boot:run
```

### 2. **404 Not Found**
```
❌ Error: 404 Not Found
✅ Fix: Kiểm tra URL đúng chưa: http://localhost:8080/api/...
```

### 3. **500 Internal Server Error**
```
❌ Error: 500 Internal Server Error
✅ Fix: Xem log server trong terminal để biết chi tiết lỗi
```

### 4. **Foreign Key Constraint**
```
❌ Error: FK constraint violation
✅ Fix: Tạo dữ liệu theo đúng thứ tự (Account → Car → Booking)
```

---

## 📊 KẾT QUẢ MONG ĐỢI

Sau khi test xong, bạn sẽ thấy:

### Trong Database:
- Bảng `history` có records về login và booking
- Bảng `account` có user mới
- Bảng `bookings` có booking mới
- Bảng `rental_contract` có contract mới

### Trong Postman:
- ✅ Status 200 OK cho GET requests
- ✅ Status 201 Created cho POST requests
- ✅ Status 200 OK cho PATCH/PUT requests
- ✅ JSON response đúng format

---

## 🎉 HOÀN THÀNH!

Nếu tất cả các APIs đều chạy OK, chúc mừng bạn! Hệ thống DriveNow đã sẵn sàng cho Frontend integration! 🚀

**Tổng số APIs đã test:** 97 endpoints  
**Số modules:** 10 modules  
**Trạng thái:** ✅ Production Ready
