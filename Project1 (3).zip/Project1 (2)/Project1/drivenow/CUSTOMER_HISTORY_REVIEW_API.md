# CUSTOMER HISTORY & REVIEW API - Lịch sử đặt xe & Đánh giá

## Tổng quan
API cho khách hàng xem lịch sử đặt xe và đánh giá sau khi hoàn thành chuyến.

**Base URL**: `/api/customer/history`

**Tổng số endpoints**: 8 endpoints

---

## Danh sách APIs

### 1. Lấy lịch sử booking
**GET** `/api/customer/history/bookings/{customerId}`

Lấy lịch sử đặt xe của khách hàng (chỉ completed và cancelled).

**Path Parameters**:
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| customerId | Integer | Yes | ID khách hàng |

**Response**: `200 OK`
```json
[
  {
    "bookingId": 1,
    "carBrand": "Toyota",
    "carModel": "Camry",
    "pickupDate": "2024-01-15T10:00:00",
    "returnDate": "2024-01-20T10:00:00",
    "totalPrice": 5000000,
    "status": "completed",
    "createdAt": "2024-01-10T08:00:00"
  },
  {
    "bookingId": 2,
    "carBrand": "Honda",
    "carModel": "City",
    "pickupDate": "2024-01-05T14:00:00",
    "returnDate": "2024-01-08T14:00:00",
    "totalPrice": 3000000,
    "status": "cancelled",
    "cancellationReason": "Thay đổi kế hoạch",
    "createdAt": "2024-01-02T09:00:00"
  }
]
```

---

### 2. Lấy tất cả bookings
**GET** `/api/customer/history/all-bookings/{customerId}`

Lấy tất cả bookings của khách hàng (bao gồm cả upcoming, ongoing).

**Path Parameters**:
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| customerId | Integer | Yes | ID khách hàng |

**Response**: `200 OK`
```json
[
  {
    "bookingId": 3,
    "status": "ongoing",
    ...
  },
  {
    "bookingId": 4,
    "status": "confirmed",
    ...
  },
  {
    "bookingId": 1,
    "status": "completed",
    ...
  }
]
```

---

### 3. Tạo review (Đánh giá sau chuyến)
**POST** `/api/customer/history/reviews?customerId={customerId}`

Khách hàng đánh giá xe sau khi hoàn thành chuyến.

**Query Parameters**:
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| customerId | Integer | Yes | ID khách hàng |

**Request Body**:
```json
{
  "bookingId": 1,
  "rating": 5,
  "comment": "Xe rất đẹp và sạch sẽ, tài xế lịch sự. Trải nghiệm tuyệt vời!",
  "cleanlinessRating": 5,
  "performanceRating": 5,
  "serviceRating": 5
}
```

| Field | Type | Required | Validation | Description |
|-------|------|----------|------------|-------------|
| bookingId | Integer | Yes | - | ID của booking đã completed |
| rating | Integer | Yes | 1-5 | Đánh giá tổng quan (1-5 sao) |
| comment | String | No | Max 2000 | Nhận xét chi tiết |
| cleanlinessRating | Integer | No | 1-5 | Đánh giá độ sạch sẽ |
| performanceRating | Integer | No | 1-5 | Đánh giá hiệu suất xe |
| serviceRating | Integer | No | 1-5 | Đánh giá dịch vụ |

**Business Rules**:
- Chỉ đánh giá được booking có status `completed`
- Mỗi booking chỉ được đánh giá 1 lần
- Booking phải thuộc về khách hàng đang đánh giá
- Rating từ 1-5 sao (bắt buộc)
- Comment tối đa 2000 ký tự (không bắt buộc)
- Các rating chi tiết (cleanliness, performance, service) là optional

**Response**: `201 Created`
```json
{
  "reviewId": 1,
  "bookingId": 1,
  "customerId": 10,
  "customerName": "Nguyễn Văn A",
  "carId": 5,
  "carBrand": "Toyota",
  "carModel": "Camry",
  "rating": 5,
  "comment": "Xe rất đẹp và sạch sẽ, tài xế lịch sự. Trải nghiệm tuyệt vời!",
  "cleanlinessRating": 5,
  "performanceRating": 5,
  "serviceRating": 5,
  "isVerified": false,
  "createdAt": "2024-01-26T15:00:00",
  "updatedAt": "2024-01-26T15:00:00"
}
```

**Error Responses**:

`404 Not Found` - Không tìm thấy booking
```json
{
  "error": "Không tìm thấy booking với ID: 999"
}
```

`400 Bad Request` - Booking chưa hoàn thành
```json
{
  "error": "Chỉ có thể đánh giá sau khi hoàn thành chuyến đi. Trạng thái hiện tại: ongoing"
}
```

`400 Bad Request` - Không có quyền
```json
{
  "error": "Bạn không có quyền đánh giá booking này"
}
```

`400 Bad Request` - Đã đánh giá rồi
```json
{
  "error": "Bạn đã đánh giá booking này rồi"
}
```

`400 Bad Request` - Validation fail
```json
{
  "rating": "Rating tối thiểu là 1",
  "comment": "Comment không được vượt quá 2000 ký tự"
}
```

---

### 4. Lấy reviews của khách hàng
**GET** `/api/customer/history/reviews/{customerId}`

Lấy tất cả reviews mà khách hàng đã viết.

**Path Parameters**:
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| customerId | Integer | Yes | ID khách hàng |

**Response**: `200 OK`
```json
[
  {
    "reviewId": 1,
    "bookingId": 1,
    "carId": 5,
    "carBrand": "Toyota",
    "carModel": "Camry",
    "rating": 5,
    "comment": "Xe rất đẹp và sạch sẽ",
    "cleanlinessRating": 5,
    "performanceRating": 5,
    "serviceRating": 5,
    "isVerified": true,
    "createdAt": "2024-01-20T15:00:00"
  },
  {
    "reviewId": 2,
    "bookingId": 2,
    "carId": 3,
    "carBrand": "Honda",
    "carModel": "City",
    "rating": 4,
    "comment": "Xe tốt nhưng hơi cũ",
    "isVerified": false,
    "createdAt": "2024-01-15T10:00:00"
  }
]
```

---

### 5. Kiểm tra đã review chưa
**GET** `/api/customer/history/reviews/check/{bookingId}`

Kiểm tra khách hàng đã review booking này chưa.

**Path Parameters**:
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| bookingId | Integer | Yes | ID booking |

**Response**: `200 OK`
```json
{
  "hasReviewed": true
}
```

hoặc

```json
{
  "hasReviewed": false
}
```

**Use case**: 
- Hiển thị nút "Đánh giá" nếu `hasReviewed = false`
- Hiển thị "Đã đánh giá" nếu `hasReviewed = true`

---

### 6. Lấy review của booking
**GET** `/api/customer/history/reviews/booking/{bookingId}`

Lấy review đã viết cho booking này.

**Path Parameters**:
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| bookingId | Integer | Yes | ID booking |

**Response**: `200 OK`
```json
{
  "reviewId": 1,
  "bookingId": 1,
  "customerId": 10,
  "customerName": "Nguyễn Văn A",
  "carId": 5,
  "carBrand": "Toyota",
  "carModel": "Camry",
  "rating": 5,
  "comment": "Xe rất đẹp và sạch sẽ",
  "cleanlinessRating": 5,
  "performanceRating": 5,
  "serviceRating": 5,
  "isVerified": true,
  "createdAt": "2024-01-20T15:00:00",
  "updatedAt": "2024-01-20T15:00:00"
}
```

**Error Response**:

`404 Not Found` - Chưa có review
```json
{
  "error": "Không tìm thấy review cho booking này"
}
```

---

### 7. Lấy thống kê rating của xe
**GET** `/api/customer/history/cars/{carId}/rating`

Lấy thống kê đánh giá của xe (average rating và phân bố sao).

**Path Parameters**:
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| carId | Integer | Yes | ID xe |

**Response**: `200 OK`
```json
{
  "carId": 5,
  "carBrand": "Toyota",
  "carModel": "Camry",
  "averageRating": 4.5,
  "totalReviews": 10,
  "fiveStarCount": 6,
  "fourStarCount": 3,
  "threeStarCount": 1,
  "twoStarCount": 0,
  "oneStarCount": 0
}
```

**Use case**:
- Hiển thị rating trung bình trên trang chi tiết xe
- Hiển thị biểu đồ phân bố sao (star distribution)
- Hiển thị số lượng đánh giá

---

### 8. Lấy tất cả reviews của xe
**GET** `/api/customer/history/cars/{carId}/reviews`

Lấy tất cả reviews của xe (để khách hàng xem trước khi thuê).

**Path Parameters**:
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| carId | Integer | Yes | ID xe |

**Response**: `200 OK`
```json
[
  {
    "reviewId": 1,
    "customerId": 10,
    "customerName": "Nguyễn Văn A",
    "rating": 5,
    "comment": "Xe rất đẹp và sạch sẽ",
    "cleanlinessRating": 5,
    "performanceRating": 5,
    "serviceRating": 5,
    "isVerified": true,
    "createdAt": "2024-01-20T15:00:00"
  },
  {
    "reviewId": 5,
    "customerId": 15,
    "customerName": "Trần Thị B",
    "rating": 4,
    "comment": "Xe tốt, giá hợp lý",
    "isVerified": true,
    "createdAt": "2024-01-18T10:00:00"
  }
]
```

---

## Testing với Postman/cURL

### Test 1: Lấy lịch sử booking
```bash
GET http://localhost:8080/api/customer/history/bookings/10
```

### Test 2: Lấy tất cả bookings
```bash
GET http://localhost:8080/api/customer/history/all-bookings/10
```

### Test 3: Tạo review
```bash
POST http://localhost:8080/api/customer/history/reviews?customerId=10
Content-Type: application/json

{
  "bookingId": 1,
  "rating": 5,
  "comment": "Xe rất đẹp và sạch sẽ, tài xế lịch sự. Trải nghiệm tuyệt vời!",
  "cleanlinessRating": 5,
  "performanceRating": 5,
  "serviceRating": 5
}
```

### Test 4: Lấy reviews của khách hàng
```bash
GET http://localhost:8080/api/customer/history/reviews/10
```

### Test 5: Kiểm tra đã review chưa
```bash
GET http://localhost:8080/api/customer/history/reviews/check/1
```

### Test 6: Lấy review của booking
```bash
GET http://localhost:8080/api/customer/history/reviews/booking/1
```

### Test 7: Lấy thống kê rating của xe
```bash
GET http://localhost:8080/api/customer/history/cars/5/rating
```

### Test 8: Lấy tất cả reviews của xe
```bash
GET http://localhost:8080/api/customer/history/cars/5/reviews
```

---

## Database Schema

### Bảng `reviews`
```sql
CREATE TABLE reviews (
  review_id INT PRIMARY KEY AUTO_INCREMENT,
  booking_id INT NOT NULL,
  customer_id INT NOT NULL,
  car_id INT NOT NULL,
  rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment TEXT,
  cleanliness_rating INT CHECK (cleanliness_rating >= 1 AND cleanliness_rating <= 5),
  performance_rating INT CHECK (performance_rating >= 1 AND performance_rating <= 5),
  service_rating INT CHECK (service_rating >= 1 AND service_rating <= 5),
  is_verified BIT DEFAULT 0,
  created_at DATETIME DEFAULT GETDATE(),
  updated_at DATETIME DEFAULT GETDATE(),
  
  FOREIGN KEY (booking_id) REFERENCES bookings(booking_id),
  FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
  FOREIGN KEY (car_id) REFERENCES cars(car_id),
  
  UNIQUE (booking_id) -- Mỗi booking chỉ có 1 review
);
```

**Indexes** (để tối ưu performance):
```sql
CREATE INDEX idx_reviews_customer ON reviews(customer_id);
CREATE INDEX idx_reviews_car ON reviews(car_id);
CREATE INDEX idx_reviews_rating ON reviews(rating);
CREATE INDEX idx_reviews_verified ON reviews(is_verified);
```

---

## Use Cases (Luồng sử dụng)

### Use Case 1: Khách hàng xem lịch sử và đánh giá

**Bước 1**: Khách hàng vào trang "Lịch sử của tôi"
```
GET /api/customer/history/bookings/10
```

**Bước 2**: Hiển thị danh sách bookings đã hoàn thành

**Bước 3**: Với mỗi booking, check đã review chưa
```
GET /api/customer/history/reviews/check/1
```

**Bước 4**: Nếu chưa review, hiển thị nút "Đánh giá"

**Bước 5**: Khách hàng click "Đánh giá", điền form và submit
```
POST /api/customer/history/reviews?customerId=10
{
  "bookingId": 1,
  "rating": 5,
  "comment": "...",
  ...
}
```

**Bước 6**: Hiển thị "Đánh giá thành công"

---

### Use Case 2: Khách hàng xem reviews trước khi thuê xe

**Bước 1**: Khách hàng vào trang chi tiết xe

**Bước 2**: Lấy thống kê rating
```
GET /api/customer/history/cars/5/rating
```

**Bước 3**: Hiển thị:
- Average rating: 4.5/5 ⭐⭐⭐⭐✰
- Tổng số reviews: 10 đánh giá
- Phân bố sao: 
  - 5⭐: 6 (60%)
  - 4⭐: 3 (30%)
  - 3⭐: 1 (10%)

**Bước 4**: Lấy danh sách reviews
```
GET /api/customer/history/cars/5/reviews
```

**Bước 5**: Hiển thị từng review với:
- Tên khách hàng
- Rating
- Comment
- Ngày đánh giá
- Badge "Đã xác minh" nếu isVerified = true

---

## Validation Rules

### Review Validation:
- `rating`: Bắt buộc, 1-5 sao
- `comment`: Không bắt buộc, tối đa 2000 ký tự
- `cleanlinessRating`: Optional, 1-5 sao
- `performanceRating`: Optional, 1-5 sao
- `serviceRating`: Optional, 1-5 sao
- `bookingId`: Bắt buộc, phải tồn tại và có status `completed`
- Mỗi booking chỉ được review 1 lần

### Business Rules:
- Chỉ review được booking đã `completed`
- Chỉ review được booking của chính mình
- Không thể sửa review sau khi tạo (cần liên hệ admin)
- Review mặc định `isVerified = false`, admin sẽ xác minh sau

---

## Tổng kết

**Tổng số APIs**: 8 endpoints
- 2 endpoints xem lịch sử booking
- 6 endpoints về review (tạo, xem, check, rating)

**Tính năng**:
- ✅ Xem lịch sử đặt xe (completed + cancelled)
- ✅ Đánh giá xe sau chuyến (rating 1-5 sao + comment)
- ✅ Rating chi tiết (cleanliness, performance, service)
- ✅ Xem reviews của khách hàng
- ✅ Xem reviews của xe
- ✅ Thống kê rating (average + distribution)
- ✅ Kiểm tra đã review chưa
- ✅ Validation đầy đủ

**Security**:
- Kiểm tra booking thuộc về khách hàng
- Không cho phép review nhiều lần
- Chỉ review được booking đã completed
