# DELIVERY SCHEDULE API DOCUMENTATION

## Tổng quan
Module **Delivery Schedule** (Quản lý lịch giao/nhận xe) giúp admin và tài xế lên lịch, theo dõi và quản lý việc giao nhận xe cho các bookings.

### Tính năng chính:
- ✅ Tạo lịch giao xe (pickup) và nhận xe (return)
- ✅ Assign tài xế cho lịch giao/nhận
- ✅ Theo dõi thời gian thực tế vs dự kiến
- ✅ Ghi nhận tình trạng xe (nhiên liệu, km, condition)
- ✅ Upload ảnh xe trước/sau giao nhận
- ✅ Phát hiện lịch trễ hẹn tự động
- ✅ Đổi lịch và hủy lịch
- ✅ Xem lịch sắp đến (24h tới)

### Schedule Types:
- **pickup**: Lịch giao xe cho khách (đầu chuyến)
- **return**: Lịch nhận xe từ khách (cuối chuyến)

### Status Flow:
```
scheduled → in_progress → completed
    ↓
cancelled / delayed
```

---

## API Endpoints

### 1. Tạo Lịch Giao/Nhận Xe
**Endpoint:** `POST /api/delivery-schedules`

**Mô tả:** Tạo lịch giao hoặc nhận xe cho một booking. Mỗi booking có thể có 2 lịch:
- 1 lịch pickup (giao xe)
- 1 lịch return (nhận xe)

**Request Body:**
```json
{
  "bookingId": 1,
  "driverId": 2,
  "scheduleType": "pickup",
  "scheduledTime": "2024-01-15T08:00:00",
  "location": "123 Nguyễn Văn Linh, Quận 7, TP HCM",
  "deliveryMethod": "home_delivery",
  "contactPerson": "Nguyễn Văn A",
  "contactPhone": "0901234567",
  "notes": "Giao xe tận nơi, khách yêu cầu check kỹ xe"
}
```

**Field Description:**
- `bookingId` (required): ID booking cần tạo lịch
- `driverId` (optional): ID tài xế (có thể assign sau)
- `scheduleType` (required): "pickup" hoặc "return"
- `scheduledTime` (required): Thời gian dự kiến (phải là tương lai)
- `location` (required): Địa điểm giao/nhận
- `deliveryMethod` (optional): "self_pickup" (tự đến lấy) hoặc "home_delivery" (giao tận nơi)
- `contactPerson` (optional): Tên người liên hệ
- `contactPhone` (optional): SĐT liên hệ
- `notes` (optional): Ghi chú

**Response Success (201 Created):**
```json
{
  "scheduleId": 1,
  "bookingId": 1,
  "driverId": 2,
  "driverName": "driver123",
  "driverPhone": null,
  "carId": 5,
  "carBrand": "Toyota",
  "carModel": "Camry",
  "licensePlate": "51A-12345",
  "customerId": 3,
  "customerName": "Nguyễn Văn A",
  "customerPhone": "0901234567",
  "scheduleType": "pickup",
  "scheduledTime": "2024-01-15T08:00:00",
  "actualTime": null,
  "location": "123 Nguyễn Văn Linh, Quận 7, TP HCM",
  "status": "scheduled",
  "deliveryMethod": "home_delivery",
  "contactPerson": "Nguyễn Văn A",
  "contactPhone": "0901234567",
  "notes": "Giao xe tận nơi, khách yêu cầu check kỹ xe",
  "createdAt": "2024-01-10T10:00:00",
  "updatedAt": "2024-01-10T10:00:00"
}
```

**Response Error (400 Bad Request):**
```json
"Lịch pickup đã tồn tại cho booking này"
```
```json
"Tài xế đã có lịch trong khoảng thời gian này"
```
```json
"Chỉ có thể tạo lịch giao/nhận cho booking đã xác nhận hoặc đang pending"
```

---

### 2. Lấy Chi Tiết Lịch
**Endpoint:** `GET /api/delivery-schedules/{id}`

**Mô tả:** Xem chi tiết một lịch giao/nhận cụ thể

**Path Parameters:**
- `id`: Schedule ID

**Response Success (200 OK):**
```json
{
  "scheduleId": 1,
  "bookingId": 1,
  "driverId": 2,
  "driverName": "driver123",
  "carBrand": "Toyota",
  "carModel": "Camry",
  "licensePlate": "51A-12345",
  "customerName": "Nguyễn Văn A",
  "customerPhone": "0901234567",
  "scheduleType": "pickup",
  "scheduledTime": "2024-01-15T08:00:00",
  "actualTime": "2024-01-15T08:15:00",
  "location": "123 Nguyễn Văn Linh, Quận 7, TP HCM",
  "status": "completed",
  "fuelLevelBefore": 100,
  "mileageBefore": 15000,
  "carConditionBefore": "Xe tốt, không trầy xước",
  "imageUrlBefore": "http://example.com/images/car_before.jpg",
  "notes": "Giao xe thành công",
  "createdAt": "2024-01-10T10:00:00",
  "updatedAt": "2024-01-15T08:20:00"
}
```

---

### 3. Lấy Lịch Của Booking
**Endpoint:** `GET /api/delivery-schedules/booking/{bookingId}`

**Mô tả:** Xem tất cả lịch giao/nhận của một booking (pickup + return)

**Path Parameters:**
- `bookingId`: Booking ID

**Response Success (200 OK):**
```json
[
  {
    "scheduleId": 1,
    "scheduleType": "pickup",
    "scheduledTime": "2024-01-15T08:00:00",
    "actualTime": "2024-01-15T08:15:00",
    "status": "completed",
    "driverName": "driver123",
    "location": "123 Nguyễn Văn Linh, TP HCM",
    "fuelLevelBefore": 100,
    "mileageBefore": 15000
  },
  {
    "scheduleId": 2,
    "scheduleType": "return",
    "scheduledTime": "2024-01-18T18:00:00",
    "actualTime": null,
    "status": "scheduled",
    "driverName": "driver456",
    "location": "123 Nguyễn Văn Linh, TP HCM"
  }
]
```

---

### 4. Lấy Lịch Của Tài Xế
**Endpoint:** `GET /api/delivery-schedules/driver/{driverId}`

**Mô tả:** Xem tất cả lịch giao/nhận của một tài xế (sắp xếp theo thời gian)

**Path Parameters:**
- `driverId`: Driver ID

**Response Success (200 OK):**
```json
[
  {
    "scheduleId": 5,
    "bookingId": 10,
    "scheduleType": "pickup",
    "scheduledTime": "2024-01-20T09:00:00",
    "status": "scheduled",
    "carBrand": "Honda",
    "carModel": "CR-V",
    "customerName": "Trần Thị B",
    "location": "456 Lê Văn Việt, Quận 9, TP HCM"
  },
  {
    "scheduleId": 3,
    "bookingId": 8,
    "scheduleType": "return",
    "scheduledTime": "2024-01-21T15:00:00",
    "status": "scheduled",
    "carBrand": "Toyota",
    "carModel": "Vios",
    "customerName": "Lê Văn C"
  }
]
```

---

### 5. Lấy Lịch Của Tài Xế Theo Status
**Endpoint:** `GET /api/delivery-schedules/driver/{driverId}/status?status=scheduled`

**Mô tả:** Lọc lịch của tài xế theo trạng thái

**Path Parameters:**
- `driverId`: Driver ID

**Query Parameters:**
- `status`: scheduled, in_progress, completed, cancelled, delayed

**Example:** `GET /api/delivery-schedules/driver/2/status?status=scheduled`

**Response:** Tương tự API 4, nhưng chỉ lịch có status được chọn

---

### 6. Lấy Lịch Theo Status (Admin)
**Endpoint:** `GET /api/delivery-schedules/status?status=scheduled`

**Mô tả:** Admin xem tất cả lịch theo trạng thái

**Query Parameters:**
- `status`: scheduled, in_progress, completed, cancelled, delayed

**Response Success (200 OK):**
```json
[
  {
    "scheduleId": 8,
    "driverId": 2,
    "driverName": "driver123",
    "scheduleType": "pickup",
    "scheduledTime": "2024-01-22T10:00:00",
    "status": "scheduled",
    "carBrand": "Toyota",
    "carModel": "Fortuner",
    "customerName": "Phạm Văn D"
  }
]
```

---

### 7. Lấy Lịch Sắp Đến (24h Tới)
**Endpoint:** `GET /api/delivery-schedules/upcoming`

**Mô tả:** Lấy tất cả lịch scheduled sắp đến trong vòng 24 giờ tới (để nhắc nhở tài xế/khách)

**Response Success (200 OK):**
```json
[
  {
    "scheduleId": 10,
    "driverName": "driver789",
    "scheduleType": "pickup",
    "scheduledTime": "2024-01-14T16:30:00",
    "carBrand": "Honda",
    "carModel": "City",
    "customerName": "Hoàng Thị E",
    "customerPhone": "0905678901",
    "location": "789 Võ Văn Ngân, Thủ Đức, TP HCM"
  },
  {
    "scheduleId": 12,
    "driverName": "driver456",
    "scheduleType": "return",
    "scheduledTime": "2024-01-15T08:00:00",
    "carBrand": "Toyota",
    "carModel": "Innova",
    "customerName": "Đặng Văn F"
  }
]
```

---

### 8. Lấy Lịch Trễ Hẹn
**Endpoint:** `GET /api/delivery-schedules/overdue`

**Mô tả:** Lấy tất cả lịch scheduled nhưng đã quá thời gian dự kiến (để xử lý)

**Response Success (200 OK):**
```json
[
  {
    "scheduleId": 7,
    "driverName": "driver123",
    "scheduleType": "pickup",
    "scheduledTime": "2024-01-13T10:00:00",
    "status": "scheduled",
    "carBrand": "Toyota",
    "carModel": "Camry",
    "customerName": "Nguyễn Văn A",
    "customerPhone": "0901234567"
  }
]
```

**Use Case:** Admin có thể gọi khách hoặc tài xế để kiểm tra tình hình

---

### 9. Assign Tài Xế
**Endpoint:** `PATCH /api/delivery-schedules/{id}/assign-driver?driverId=2`

**Mô tả:** Phân công tài xế cho lịch giao/nhận (nếu chưa có khi tạo)

**Path Parameters:**
- `id`: Schedule ID

**Query Parameters:**
- `driverId`: Driver ID cần assign

**Response Success (200 OK):**
```json
{
  "scheduleId": 1,
  "driverId": 2,
  "driverName": "driver123",
  "scheduleType": "pickup",
  "scheduledTime": "2024-01-15T08:00:00",
  "status": "scheduled",
  "updatedAt": "2024-01-10T11:00:00"
}
```

**Response Error (400 Bad Request):**
```json
"Tài xế đã có lịch trong khoảng thời gian này"
```

---

### 10. Bắt Đầu Giao/Nhận Xe
**Endpoint:** `PATCH /api/delivery-schedules/{id}/start`

**Mô tả:** Tài xế bắt đầu quá trình giao/nhận (scheduled → in_progress)

**Path Parameters:**
- `id`: Schedule ID

**Response Success (200 OK):**
```json
{
  "scheduleId": 1,
  "status": "in_progress",
  "updatedAt": "2024-01-15T08:00:00"
}
```

**Use Case:** Tài xế click nút "Bắt đầu" trên app khi đã đến nơi giao xe

---

### 11. Hoàn Thành Giao/Nhận Xe
**Endpoint:** `PATCH /api/delivery-schedules/{id}/complete`

**Mô tả:** Hoàn tất quá trình giao/nhận, ghi nhận thông tin xe (in_progress → completed hoặc delayed)

**Path Parameters:**
- `id`: Schedule ID

**Request Body:**
```json
{
  "actualTime": "2024-01-15T08:30:00",
  "fuelLevel": 100,
  "mileage": 15000,
  "carCondition": "Xe tốt, không trầy xước, đầy đủ tiện nghi",
  "imageUrl": "http://example.com/images/car_before.jpg",
  "notes": "Giao xe thành công, khách đã kiểm tra kỹ",
  "delayReason": "Khách đến muộn 15 phút"
}
```

**Field Description:**
- `actualTime` (optional): Thời gian thực tế (mặc định = hiện tại)
- `fuelLevel` (optional): Mức nhiên liệu 0-100%
- `mileage` (optional): Số km hiện tại
- `carCondition` (optional): Tình trạng xe (text)
- `imageUrl` (optional): Link ảnh xe (có thể nhiều ảnh)
- `notes` (optional): Ghi chú
- `delayReason` (optional): Lý do trễ (nếu có)

**Response Success (200 OK):**
```json
{
  "scheduleId": 1,
  "scheduleType": "pickup",
  "scheduledTime": "2024-01-15T08:00:00",
  "actualTime": "2024-01-15T08:30:00",
  "status": "delayed",
  "fuelLevelBefore": 100,
  "mileageBefore": 15000,
  "carConditionBefore": "Xe tốt, không trầy xước, đầy đủ tiện nghi",
  "imageUrlBefore": "http://example.com/images/car_before.jpg",
  "delayReason": "Khách đến muộn 15 phút",
  "notes": "Giao xe thành công, khách đã kiểm tra kỹ",
  "updatedAt": "2024-01-15T08:35:00"
}
```

**Business Logic:**
- Nếu `actualTime` > `scheduledTime` + 15 phút → status = "delayed"
- Nếu không → status = "completed"
- Nếu `scheduleType` = "pickup" → lưu info vào `*_before` fields
- Nếu `scheduleType` = "return" → lưu info vào `*_after` fields

---

### 12. Hủy Lịch
**Endpoint:** `PATCH /api/delivery-schedules/{id}/cancel?reason=Khách%20hủy%20booking`

**Mô tả:** Hủy lịch giao/nhận (không thể hủy nếu đã completed)

**Path Parameters:**
- `id`: Schedule ID

**Query Parameters:**
- `reason`: Lý do hủy

**Response Success (200 OK):**
```json
{
  "scheduleId": 1,
  "status": "cancelled",
  "cancellationReason": "Khách hủy booking",
  "updatedAt": "2024-01-12T09:00:00"
}
```

**Response Error (400 Bad Request):**
```json
"Không thể hủy lịch đã hoàn thành hoặc đã hủy"
```

---

### 13. Đổi Lịch (Reschedule)
**Endpoint:** `PATCH /api/delivery-schedules/{id}/reschedule?newTime=2024-01-16T10:00:00`

**Mô tả:** Thay đổi thời gian dự kiến giao/nhận

**Path Parameters:**
- `id`: Schedule ID

**Query Parameters:**
- `newTime`: Thời gian mới (ISO 8601 format)

**Example:** `PATCH /api/delivery-schedules/1/reschedule?newTime=2024-01-16T10:00:00`

**Response Success (200 OK):**
```json
{
  "scheduleId": 1,
  "scheduledTime": "2024-01-16T10:00:00",
  "status": "scheduled",
  "updatedAt": "2024-01-12T14:30:00"
}
```

**Response Error (400 Bad Request):**
```json
"Chỉ có thể đổi lịch đang scheduled"
```
```json
"Tài xế đã có lịch trong khoảng thời gian mới"
```

---

## Status Definitions

### Schedule Status:
| Status | Mô tả | Có thể chuyển sang |
|--------|-------|---------------------|
| **scheduled** | Đã lên lịch, chưa bắt đầu | in_progress, cancelled |
| **in_progress** | Đang thực hiện giao/nhận | completed, delayed |
| **completed** | Hoàn thành (đúng giờ) | - |
| **delayed** | Hoàn thành nhưng trễ hẹn | - |
| **cancelled** | Đã hủy | - |

### Delivery Methods:
- **self_pickup**: Khách tự đến lấy xe tại địa điểm
- **home_delivery**: Tài xế giao xe tận nơi cho khách

---

## Business Rules

### 1. Tạo Lịch:
- ✅ Mỗi booking chỉ có tối đa 1 lịch pickup và 1 lịch return
- ✅ Booking phải có status = "confirmed" hoặc "pending"
- ✅ Thời gian pickup schedule phải <= booking.pickupDate
- ✅ Thời gian return schedule phải >= booking.returnDate
- ✅ Tài xế không được có lịch conflict (trong cùng khoảng thời gian ±2h)

### 2. Assign Driver:
- ✅ Chỉ assign cho lịch status = "scheduled"
- ✅ Check conflict: tài xế không có lịch khác trong khoảng ±2h
- ✅ Có thể tạo lịch không có driver, assign sau

### 3. Complete Delivery:
- ✅ Chỉ complete lịch status = "in_progress" hoặc "scheduled"
- ✅ Nếu trễ > 15 phút → status = "delayed"
- ✅ Pickup: lưu fuel_before, mileage_before, condition_before
- ✅ Return: lưu fuel_after, mileage_after, condition_after

### 4. Cancel/Reschedule:
- ✅ Chỉ cancel/reschedule lịch status = "scheduled"
- ✅ Không thể cancel lịch đã completed
- ✅ Reschedule phải check conflict driver

---

## Use Cases

### Use Case 1: Giao xe tận nơi (Home Delivery - Pickup)
```
1. Admin tạo lịch pickup:
   POST /api/delivery-schedules
   {
     "bookingId": 1,
     "scheduleType": "pickup",
     "scheduledTime": "2024-01-15T08:00:00",
     "location": "123 Nguyễn Văn Linh, TP HCM",
     "deliveryMethod": "home_delivery"
   }

2. Admin assign tài xế:
   PATCH /api/delivery-schedules/1/assign-driver?driverId=2

3. Tài xế đến nơi, bắt đầu:
   PATCH /api/delivery-schedules/1/start

4. Giao xe, chụp ảnh, ghi thông tin:
   PATCH /api/delivery-schedules/1/complete
   {
     "actualTime": "2024-01-15T08:15:00",
     "fuelLevel": 100,
     "mileage": 15000,
     "carCondition": "Tốt",
     "imageUrl": "http://..."
   }
```

### Use Case 2: Khách tự đến lấy (Self Pickup)
```
1. Tạo lịch:
   {
     "scheduleType": "pickup",
     "deliveryMethod": "self_pickup",
     "location": "Văn phòng DriveNow, 456 CMT8, Q10",
     ...
   }

2. Khách đến, nhân viên giao xe:
   PATCH /api/delivery-schedules/5/complete
   {
     "fuelLevel": 100,
     "mileage": 20000,
     ...
   }
```

### Use Case 3: Nhận xe khi kết thúc (Return)
```
1. Tạo lịch return:
   {
     "scheduleType": "return",
     "scheduledTime": "2024-01-18T18:00:00",
     ...
   }

2. Tài xế đến nhận xe:
   PATCH /api/delivery-schedules/2/start

3. Kiểm tra xe, chụp ảnh:
   PATCH /api/delivery-schedules/2/complete
   {
     "fuelLevel": 80,
     "mileage": 15350,
     "carCondition": "Có vết trầy nhẹ bên phải",
     "imageUrl": "http://...",
     "notes": "Cần rửa xe"
   }
```

### Use Case 4: Xử lý lịch trễ
```
1. Admin xem lịch trễ:
   GET /api/delivery-schedules/overdue
   
2. Gọi điện cho tài xế/khách kiểm tra

3. Nếu có vấn đề, đổi lịch:
   PATCH /api/delivery-schedules/7/reschedule?newTime=...
   
4. Hoặc hủy:
   PATCH /api/delivery-schedules/7/cancel?reason=...
```

---

## Testing Checklist

- [ ] Tạo lịch pickup cho booking
- [ ] Tạo lịch return cho booking
- [ ] Không thể tạo 2 lịch pickup cho cùng booking
- [ ] Assign tài xế cho lịch
- [ ] Check conflict khi assign driver
- [ ] Bắt đầu giao/nhận (start)
- [ ] Hoàn thành giao/nhận (complete)
- [ ] Complete với trễ > 15 phút → status = delayed
- [ ] Ghi nhận fuel, mileage, condition, images
- [ ] Hủy lịch với lý do
- [ ] Không thể hủy lịch completed
- [ ] Đổi lịch (reschedule)
- [ ] Xem lịch sắp đến (24h)
- [ ] Xem lịch trễ hẹn
- [ ] Lọc lịch theo status
- [ ] Xem lịch của tài xế

---

## Database Schema

### Table: delivery_schedules
```sql
CREATE TABLE delivery_schedules (
  schedule_id INT PRIMARY KEY AUTO_INCREMENT,
  booking_id INT NOT NULL,
  driver_id INT,
  schedule_type VARCHAR(20) NOT NULL, -- pickup, return
  scheduled_time DATETIME NOT NULL,
  actual_time DATETIME,
  location VARCHAR(255) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'scheduled',
  notes TEXT,
  delivery_method VARCHAR(50), -- self_pickup, home_delivery
  contact_person VARCHAR(100),
  contact_phone VARCHAR(20),
  fuel_level_before INT,
  fuel_level_after INT,
  mileage_before INT,
  mileage_after INT,
  car_condition_before TEXT,
  car_condition_after TEXT,
  image_url_before VARCHAR(500),
  image_url_after VARCHAR(500),
  delay_reason TEXT,
  cancellation_reason TEXT,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  
  FOREIGN KEY (booking_id) REFERENCES bookings(booking_id),
  FOREIGN KEY (driver_id) REFERENCES drivers(driver_id),
  
  UNIQUE KEY unique_booking_type (booking_id, schedule_type)
);

CREATE INDEX idx_driver_scheduled_time ON delivery_schedules(driver_id, scheduled_time);
CREATE INDEX idx_status ON delivery_schedules(status);
CREATE INDEX idx_scheduled_time ON delivery_schedules(scheduled_time);
```

---

## Integration với Frontend

### Driver App (Mobile):
```javascript
// Xem lịch của tài xế hôm nay
GET /api/delivery-schedules/driver/{driverId}/status?status=scheduled

// Bắt đầu giao xe
PATCH /api/delivery-schedules/{id}/start

// Hoàn thành với ảnh & thông tin
PATCH /api/delivery-schedules/{id}/complete
{
  fuelLevel: 100,
  mileage: 15000,
  carCondition: "...",
  imageUrl: "...", // Upload ảnh trước
  notes: "..."
}
```

### Admin Dashboard:
```javascript
// Lịch sắp đến (24h)
GET /api/delivery-schedules/upcoming

// Lịch trễ hẹn
GET /api/delivery-schedules/overdue

// Tất cả lịch pending
GET /api/delivery-schedules/status?status=scheduled

// Assign tài xế
PATCH /api/delivery-schedules/{id}/assign-driver?driverId=...
```

### Customer App:
```javascript
// Xem lịch giao/nhận của booking
GET /api/delivery-schedules/booking/{bookingId}

// Hiển thị: Tài xế sẽ giao xe lúc 08:00 ngày 15/01
// Thông tin tài xế, SĐT liên hệ
```

---

## Tổng kết

**Module này đã hoàn thành 13 APIs:**

| # | Method | Endpoint | Mô tả |
|---|--------|----------|-------|
| 1 | POST | `/api/delivery-schedules` | Tạo lịch giao/nhận |
| 2 | GET | `/api/delivery-schedules/{id}` | Chi tiết lịch |
| 3 | GET | `/api/delivery-schedules/booking/{bookingId}` | Lịch của booking |
| 4 | GET | `/api/delivery-schedules/driver/{driverId}` | Lịch của tài xế |
| 5 | GET | `/api/delivery-schedules/driver/{driverId}/status` | Lịch của tài xế theo status |
| 6 | GET | `/api/delivery-schedules/status` | Lịch theo status (Admin) |
| 7 | GET | `/api/delivery-schedules/upcoming` | Lịch sắp đến (24h) |
| 8 | GET | `/api/delivery-schedules/overdue` | Lịch trễ hẹn |
| 9 | PATCH | `/api/delivery-schedules/{id}/assign-driver` | Assign tài xế |
| 10 | PATCH | `/api/delivery-schedules/{id}/start` | Bắt đầu giao/nhận |
| 11 | PATCH | `/api/delivery-schedules/{id}/complete` | Hoàn thành |
| 12 | PATCH | `/api/delivery-schedules/{id}/cancel` | Hủy lịch |
| 13 | PATCH | `/api/delivery-schedules/{id}/reschedule` | Đổi lịch |

**Files created:**
- `DeliverySchedule.java` - Model entity (350+ lines)
- `DeliveryScheduleRepository.java` - Data access với nhiều query methods
- `DeliveryScheduleDTO.java` - Response DTO
- `DeliveryScheduleCreateRequest.java` - Create request DTO
- `DeliveryScheduleUpdateRequest.java` - Update request DTO
- `DeliveryScheduleService.java` - Business logic (400+ lines)
- `DeliveryScheduleController.java` - 13 REST APIs
- `DriverRepository.java` - Repository cho Driver

**Total APIs trong project: 69 endpoints** (56 + 13)
