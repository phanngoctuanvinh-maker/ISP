# BOOKING EXTENSION (GIA HẠN BOOKING) - FEATURE DOCUMENTATION

## 🎯 Mô tả tính năng

**Tình huống thực tế:** Khách hàng thuê xe từ 20/10 → 25/10 (5 ngày). Đến ngày 24/10, khách muốn gia hạn thêm 3 ngày nữa → trả xe ngày 28/10.

**Giải pháp:** API **Extend Booking** cho phép khách hàng gia hạn thời gian thuê xe mà không cần tạo booking mới.

---

## 📋 API Endpoint

### **PATCH /api/bookings/{id}/extend**

**Mô tả:** Gia hạn thời gian thuê xe (kéo dài returnDate)

**Request:**
```http
PATCH /api/bookings/1/extend
Content-Type: application/json

{
  "newReturnDate": "2025-10-28T18:00:00"
}
```

**Response Success:**
```json
{
  "success": true,
  "message": "Gia hạn booking thành công",
  "data": {
    "bookingId": 1,
    "customerId": 1,
    "customerName": "Nguyễn Văn A",
    "carId": 5,
    "carBrand": "Toyota",
    "carModel": "Camry",
    "pickupDate": "2025-10-20T09:00:00",
    "returnDate": "2025-10-28T18:00:00",  // ← Đã update
    "originalReturnDate": "2025-10-25T18:00:00",  // ← Ngày trả ban đầu
    "totalDays": 8,  // ← 5 + 3 ngày
    "totalPrice": 6400000,  // ← 800k × 8 ngày
    "extensionDays": 3,  // ← Số ngày gia hạn
    "extensionPrice": 2400000,  // ← 800k × 3 ngày (phụ thu)
    "isExtended": true,  // ← Đã gia hạn
    "status": "ongoing",
    "paymentStatus": "partially_paid",  // ← Cần trả thêm tiền gia hạn
    "paymentMethod": "bank_transfer",
    "createdAt": "2025-10-14T15:30:00",
    "updatedAt": "2025-10-24T10:15:00"  // ← Thời gian gia hạn
  }
}
```

**Response Error (Xe không available):**
```json
{
  "success": false,
  "message": "Cannot extend booking. Car is already booked by another customer for the extended period"
}
```

---

## 🔐 Business Rules (Quy tắc nghiệp vụ)

### ✅ **Điều kiện cho phép gia hạn:**

1. **Status hợp lệ:** Booking phải có status = `"confirmed"` hoặc `"ongoing"`
   - ❌ Không cho gia hạn nếu status = pending/completed/cancelled

2. **Ngày mới hợp lệ:**
   - `newReturnDate` phải **SAU** `returnDate` hiện tại
   - `newReturnDate` phải **TRONG TƯƠNG LAI**

3. **Xe phải còn trống:**
   - Kiểm tra không có booking nào khác đặt xe trong khoảng (`returnDate cũ` → `newReturnDate mới`)
   - Sử dụng method `isCarAvailable()` trong `BookingRepository`

4. **Tự động tính phụ thu:**
   - `extensionDays` = số ngày từ returnDate cũ → newReturnDate mới
   - `extensionPrice` = `pricePerDay` × `extensionDays`
   - `totalPrice` += `extensionPrice`
   - `totalDays` += `extensionDays`

5. **Payment status update:**
   - Nếu đã thanh toán (`paymentStatus = "paid"`), chuyển sang `"partially_paid"`
   - Khách cần trả thêm `extensionPrice`

---

## 📊 Database Changes

### **Bảng bookings - Thêm các columns:**

```sql
ALTER TABLE bookings ADD COLUMN original_return_date DATETIME;
ALTER TABLE bookings ADD COLUMN extension_days INT DEFAULT 0;
ALTER TABLE bookings ADD COLUMN extension_price DECIMAL(10,2) DEFAULT 0;
ALTER TABLE bookings ADD COLUMN is_extended BIT DEFAULT 0;
```

**Ý nghĩa:**
- `original_return_date`: Lưu ngày trả ban đầu (trước khi gia hạn lần đầu)
- `extension_days`: Tổng số ngày đã gia hạn (có thể gia hạn nhiều lần)
- `extension_price`: Tổng tiền phụ thu do gia hạn
- `is_extended`: Flag đánh dấu booking đã từng gia hạn

---

## 🔄 Workflow (Quy trình)

### **Scenario 1: Gia hạn lần đầu**

**Initial State:**
```json
{
  "bookingId": 1,
  "pickupDate": "2025-10-20T09:00:00",
  "returnDate": "2025-10-25T18:00:00",
  "totalDays": 5,
  "totalPrice": 4000000,  // 800k × 5 ngày
  "originalReturnDate": null,
  "extensionDays": 0,
  "extensionPrice": 0,
  "isExtended": false,
  "status": "ongoing",
  "paymentStatus": "paid"
}
```

**Request:** Gia hạn thêm 3 ngày
```http
PATCH /api/bookings/1/extend
{ "newReturnDate": "2025-10-28T18:00:00" }
```

**Updated State:**
```json
{
  "bookingId": 1,
  "pickupDate": "2025-10-20T09:00:00",
  "returnDate": "2025-10-28T18:00:00",  // ← Updated
  "totalDays": 8,  // ← 5 + 3
  "totalPrice": 6400000,  // ← 4M + 2.4M
  "originalReturnDate": "2025-10-25T18:00:00",  // ← Saved
  "extensionDays": 3,
  "extensionPrice": 2400000,  // ← 800k × 3
  "isExtended": true,
  "status": "ongoing",
  "paymentStatus": "partially_paid"  // ← Changed
}
```

---

### **Scenario 2: Gia hạn lần thứ 2**

**Current State:** (sau gia hạn lần 1)
```json
{
  "returnDate": "2025-10-28T18:00:00",
  "originalReturnDate": "2025-10-25T18:00:00",
  "extensionDays": 3,
  "extensionPrice": 2400000
}
```

**Request:** Gia hạn thêm 2 ngày nữa
```http
PATCH /api/bookings/1/extend
{ "newReturnDate": "2025-10-30T18:00:00" }
```

**Updated State:**
```json
{
  "returnDate": "2025-10-30T18:00:00",  // ← Updated
  "originalReturnDate": "2025-10-25T18:00:00",  // ← Giữ nguyên
  "extensionDays": 5,  // ← 3 + 2
  "extensionPrice": 4000000,  // ← 2.4M + 1.6M
  "totalDays": 10,  // ← 8 + 2
  "totalPrice": 8000000  // ← 6.4M + 1.6M
}
```

---

## 💡 Use Cases

### **Use Case 1: Khách gia hạn khi đang thuê xe**
```
1. Khách đang thuê xe (status = "ongoing")
2. Gọi API: PATCH /api/bookings/1/extend
3. Hệ thống kiểm tra:
   - Xe có available trong thời gian gia hạn không?
   - Tính tiền phụ thu
4. Update booking và trả về thông tin mới
5. Khách thanh toán thêm extensionPrice
```

### **Use Case 2: Khách gia hạn trước khi nhận xe**
```
1. Booking đã confirmed nhưng chưa bắt đầu
2. Khách muốn gia hạn trước
3. Hệ thống cho phép nếu xe vẫn available
4. Update booking với ngày trả mới
```

### **Use Case 3: Không cho phép gia hạn (xe đã được đặt)**
```
1. Khách muốn gia hạn từ 25/10 → 28/10
2. Hệ thống phát hiện có booking khác đã đặt xe từ 26/10
3. Trả về error: "Car is already booked..."
4. Khách cần tìm xe khác hoặc trả đúng hạn
```

---

## ⚠️ Error Handling

### **Common Errors:**

1. **Invalid Status:**
```json
{
  "success": false,
  "message": "Only confirmed or ongoing bookings can be extended"
}
```

2. **Invalid Date:**
```json
{
  "success": false,
  "message": "New return date must be after current return date"
}
```

3. **Car Not Available:**
```json
{
  "success": false,
  "message": "Cannot extend booking. Car is already booked by another customer for the extended period"
}
```

4. **Past Date:**
```json
{
  "success": false,
  "message": "New return date must be in the future"
}
```

---

## 🎨 Frontend Integration Example

```javascript
// Gia hạn booking
async function extendBooking(bookingId, newReturnDate) {
  try {
    const response = await fetch(`/api/bookings/${bookingId}/extend`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ newReturnDate })
    });
    
    const result = await response.json();
    
    if (result.success) {
      alert(`Gia hạn thành công! Cần trả thêm: ${result.data.extensionPrice.toLocaleString()} VNĐ`);
      // Hiển thị thông tin mới
      displayBookingDetails(result.data);
    } else {
      alert(`Lỗi: ${result.message}`);
    }
  } catch (error) {
    console.error('Error:', error);
  }
}

// Example usage
const bookingId = 1;
const newReturnDate = "2025-10-28T18:00:00";
extendBooking(bookingId, newReturnDate);
```

---

## 📈 Benefits (Lợi ích)

### **Cho khách hàng:**
✅ Linh hoạt thời gian thuê xe  
✅ Không cần tạo booking mới  
✅ Giữ nguyên lịch sử booking  
✅ Tiết kiệm thời gian  

### **Cho doanh nghiệp:**
✅ Tăng doanh thu (phụ thu gia hạn)  
✅ Giữ chân khách hàng  
✅ Tự động kiểm tra conflict  
✅ Tracking rõ ràng (originalReturnDate, extensionDays)  
✅ Quản lý payment tốt hơn (partially_paid)  

---

## 🔍 Testing Checklist

- [ ] Gia hạn thành công khi xe available
- [ ] Reject khi status không hợp lệ
- [ ] Reject khi newReturnDate < returnDate
- [ ] Reject khi xe đã được đặt bởi người khác
- [ ] Tính toán extensionDays và extensionPrice chính xác
- [ ] Update payment status đúng
- [ ] Lưu originalReturnDate ở lần gia hạn đầu tiên
- [ ] Gia hạn nhiều lần tích lũy đúng
- [ ] Kiểm tra timezone và date format

---

## 🎉 Summary

**Feature Extend Booking** là giải pháp hoàn hảo cho tình huống khách hàng muốn kéo dài thời gian thuê xe:

- ✅ **14 API endpoints** (13 cũ + 1 mới: `/extend`)
- ✅ Tự động tính phụ thu
- ✅ Kiểm tra conflict với booking khác
- ✅ Tracking đầy đủ (originalReturnDate, extensionDays, extensionPrice)
- ✅ Support gia hạn nhiều lần
- ✅ Payment status management
- ✅ Business rules nghiêm ngặt

**Ready for production!** 🚀
