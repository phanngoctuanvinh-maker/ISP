# BOOKING API DOCUMENTATION

## 📋 Tổng quan
BookingController quản lý toàn bộ quy trình đặt xe từ tạo booking, cập nhật, theo dõi trạng thái đến hoàn thành/hủy.

**Base URL:** `/api/bookings`

---

## 🚀 API Endpoints

### 1. **Tạo Booking Mới (Đặt Xe)**
**Endpoint:** `POST /api/bookings`

**Mô tả:** Khách hàng đặt xe với thông tin ngày nhận/trả, địa điểm giao xe

**Request Body:**
```json
{
  "customerId": 1,
  "carId": 5,
  "driverId": 3,  // Optional - có thể null nếu không thuê tài xế
  "pickupDate": "2025-10-20T09:00:00",
  "returnDate": "2025-10-25T18:00:00",
  "pickupLocation": "123 Đường ABC, Quận 1, TP.HCM",
  "returnLocation": "123 Đường ABC, Quận 1, TP.HCM",  // Optional - mặc định = pickupLocation
  "paymentMethod": "bank_transfer",  // cash, bank_transfer, credit_card, momo, zalopay
  "notes": "Cần xe sạch sẽ, đúng giờ"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Đặt xe thành công",
  "data": {
    "bookingId": 1,
    "customerId": 1,
    "customerName": "Nguyễn Văn A",
    "customerPhone": "0901234567",
    "carId": 5,
    "carBrand": "Toyota",
    "carModel": "Camry",
    "licensePlate": "30A-12345",
    "driverId": 3,
    "driverName": "Driver #3",
    "pickupDate": "2025-10-20T09:00:00",
    "returnDate": "2025-10-25T18:00:00",
    "pickupLocation": "123 Đường ABC, Quận 1, TP.HCM",
    "returnLocation": "123 Đường ABC, Quận 1, TP.HCM",
    "totalDays": 5,
    "totalPrice": 4000000,
    "status": "pending",
    "paymentStatus": "unpaid",
    "paymentMethod": "bank_transfer",
    "notes": "Cần xe sạch sẽ, đúng giờ",
    "createdAt": "2025-10-14T15:30:00",
    "updatedAt": "2025-10-14T15:30:00"
  }
}
```

**Validation Rules:**
- ✅ Customer ID, Car ID, Pickup Date, Return Date, Pickup Location là **bắt buộc**
- ✅ Return Date phải **sau** Pickup Date
- ✅ Pickup Date và Return Date phải **trong tương lai**
- ✅ Xe phải có status = **"available"**
- ✅ Xe không được đặt bởi người khác trong cùng khoảng thời gian
- ✅ Driver (nếu có) phải có status = **"active"**
- ✅ Tự động tính **totalDays** và **totalPrice** = pricePerDay × totalDays

---

### 2. **Cập Nhật Booking**
**Endpoint:** `PUT /api/bookings/{id}`

**Mô tả:** Cập nhật thông tin booking (chỉ khi status = "pending")

**Request Body:**
```json
{
  "driverId": 5,  // Thêm/đổi tài xế
  "pickupDate": "2025-10-21T10:00:00",
  "returnDate": "2025-10-26T17:00:00",
  "pickupLocation": "456 Đường XYZ, Quận 2, TP.HCM",
  "returnLocation": "789 Đường DEF, Quận 3, TP.HCM",
  "paymentMethod": "credit_card",
  "notes": "Thay đổi thời gian"
}
```

**Response:** Giống như Create Booking với thông tin đã update

**Lưu ý:**
- Chỉ cho phép update khi **status = "pending"**
- Nếu thay đổi ngày, hệ thống sẽ **tự động tính lại** totalDays và totalPrice
- Kiểm tra lại availability của xe với ngày mới

---

### 3. **Xem Chi Tiết Booking**
**Endpoint:** `GET /api/bookings/{id}`

**Response:**
```json
{
  "success": true,
  "message": "Lấy thông tin booking thành công",
  "data": { /* BookingDTO object */ }
}
```

---

### 4. **Lấy Tất Cả Bookings Của Khách Hàng**
**Endpoint:** `GET /api/bookings/customer/{customerId}`

**Response:**
```json
{
  "success": true,
  "message": "Lấy danh sách booking thành công",
  "data": [
    { /* BookingDTO 1 */ },
    { /* BookingDTO 2 */ }
  ]
}
```

---

### 5. **Lấy Bookings Sắp Tới**
**Endpoint:** `GET /api/bookings/customer/{customerId}/upcoming`

**Mô tả:** Lấy các booking có pickupDate > now và status IN ("pending", "confirmed")

**Response:** Array of BookingDTO

---

### 6. **Lấy Lịch Sử Booking**
**Endpoint:** `GET /api/bookings/customer/{customerId}/history`

**Mô tả:** Lấy các booking đã hoàn thành hoặc đã hủy (status IN ("completed", "cancelled"))

**Response:** Array of BookingDTO

---

### 7. **Lấy Tất Cả Bookings (Admin)**
**Endpoint:** `GET /api/bookings?status={status}`

**Query Parameters:**
- `status` (optional): pending, confirmed, ongoing, completed, cancelled

**Examples:**
- `GET /api/bookings` - Tất cả bookings
- `GET /api/bookings?status=pending` - Chỉ bookings đang chờ

**Response:** Array of BookingDTO

---

## 🔄 Quản Lý Trạng Thái Booking

### 8. **Xác Nhận Booking (Admin)**
**Endpoint:** `PATCH /api/bookings/{id}/confirm`

**Mô tả:** Admin xác nhận booking, chuyển status từ "pending" → "confirmed"

**Response:**
```json
{
  "success": true,
  "message": "Xác nhận booking thành công",
  "data": { /* Updated BookingDTO */ }
}
```

---

### 9. **Bắt Đầu Chuyến Đi**
**Endpoint:** `PATCH /api/bookings/{id}/start`

**Mô tả:** Bắt đầu chuyến đi, chuyển status từ "confirmed" → "ongoing"

**Side Effects:**
- ✅ Car status → "rented"

---

### 10. **Hoàn Thành Booking**
**Endpoint:** `PATCH /api/bookings/{id}/complete`

**Mô tả:** Hoàn thành chuyến đi, chuyển status từ "ongoing" → "completed"

**Side Effects:**
- ✅ Car status → "available"

---

### 11. **Hủy Booking**
**Endpoint:** `PATCH /api/bookings/{id}/cancel`

**Request Body:**
```json
{
  "cancellationReason": "Khách hàng thay đổi kế hoạch"
}
```

**Mô tả:** Hủy booking (không cho phép hủy nếu status = "completed" hoặc "cancelled")

**Side Effects:**
- ✅ Nếu đang ongoing, car status → "available"

---

### 12. **Gia Hạn Booking** ⭐ NEW
**Endpoint:** `PATCH /api/bookings/{id}/extend`

**Mô tả:** Khách hàng gia hạn thêm thời gian thuê xe (kéo dài returnDate)

**Request Body:**
```json
{
  "newReturnDate": "2025-10-28T18:00:00"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Gia hạn booking thành công",
  "data": {
    "bookingId": 1,
    "returnDate": "2025-10-28T18:00:00",
    "originalReturnDate": "2025-10-25T18:00:00",
    "totalDays": 8,
    "totalPrice": 6400000,
    "extensionDays": 3,
    "extensionPrice": 2400000,
    "isExtended": true,
    "paymentStatus": "partially_paid"
  }
}
```

**Business Rules:**
- ✅ Chỉ cho phép khi status = "confirmed" hoặc "ongoing"
- ✅ newReturnDate phải SAU returnDate hiện tại
- ✅ Kiểm tra xe có available trong khoảng gia hạn
- ✅ Tự động tính extensionDays và extensionPrice
- ✅ Nếu đã paid, chuyển sang "partially_paid"

**Chi tiết:** Xem file `BOOKING_EXTENSION_FEATURE.md`

---

### 13. **Cập Nhật Payment Status**
**Endpoint:** `PATCH /api/bookings/{id}/payment`

**Request Body:**
```json
{
  "paymentStatus": "paid"  // unpaid, paid, refunded
}
```

**Response:**
```json
{
  "success": true,
  "message": "Cập nhật payment status thành công",
  "data": { /* Updated BookingDTO */ }
}
```

---

## 🔍 Helper Endpoints

### 14. **Kiểm Tra Xe Có Sẵn Không**
**Endpoint:** `GET /api/bookings/check-availability`

**Query Parameters:**
- `carId`: ID của xe
- `pickupDate`: Ngày nhận (ISO 8601 format)
- `returnDate`: Ngày trả (ISO 8601 format)

**Example:**
```
GET /api/bookings/check-availability?carId=5&pickupDate=2025-10-20T09:00:00&returnDate=2025-10-25T18:00:00
```

**Response:**
```json
{
  "success": true,
  "message": "Xe có sẵn",
  "data": {
    "available": true
  }
}
```

---

## 📊 Booking Status Flow

```
pending (Đang chờ xác nhận)
   ↓
confirmed (Đã xác nhận)
   ↓
ongoing (Đang diễn ra)
   ↓
completed (Hoàn thành)

* Có thể chuyển từ pending/confirmed/ongoing → cancelled
```

## 💰 Payment Status

- **unpaid**: Chưa thanh toán
- **paid**: Đã thanh toán
- **refunded**: Đã hoàn tiền (khi hủy)

## 🎯 Use Cases

### Use Case 1: Khách hàng đặt xe
```
1. Frontend gọi GET /api/bookings/check-availability để kiểm tra xe có sẵn
2. Nếu available = true, gọi POST /api/bookings để tạo booking
3. Booking được tạo với status = "pending", paymentStatus = "unpaid"
```

### Use Case 2: Admin xác nhận và bắt đầu chuyến đi
```
1. Admin xem danh sách: GET /api/bookings?status=pending
2. Xác nhận: PATCH /api/bookings/{id}/confirm → status = "confirmed"
3. Khi đến giờ nhận xe: PATCH /api/bookings/{id}/start → status = "ongoing", car status = "rented"
```

### Use Case 3: Hoàn thành booking
```
1. Khi trả xe: PATCH /api/bookings/{id}/complete → status = "completed", car status = "available"
2. Cập nhật thanh toán: PATCH /api/bookings/{id}/payment với paymentStatus = "paid"
```

### Use Case 4: Khách hàng hủy booking
```
1. Gọi PATCH /api/bookings/{id}/cancel với cancellationReason
2. Status → "cancelled"
3. Nếu đã thanh toán, có thể update paymentStatus = "refunded"
```

---

## ⚠️ Error Handling

**Common Errors:**
- `400 Bad Request`: Validation failed, xe không available, status không hợp lệ
- `404 Not Found`: Booking/Customer/Car/Driver không tồn tại
- `500 Internal Server Error`: Lỗi server

**Error Response Format:**
```json
{
  "success": false,
  "message": "Car is not available for the selected dates"
}
```

---

## 📝 Notes

1. **Tự động tính giá:** Hệ thống tự động tính totalDays và totalPrice dựa trên pricePerDay của xe
2. **Validation nghiêm ngặt:** Kiểm tra xe có sẵn, ngày hợp lệ, status hợp lệ
3. **Side effects:** Một số API tự động cập nhật car status
4. **Date format:** Sử dụng ISO 8601 format: `2025-10-20T09:00:00`
5. **Driver optional:** Có thể đặt xe không cần tài xế (driverId = null)

---

## 🎉 Tổng kết

**BookingController** cung cấp **14 API endpoints** đầy đủ cho:
- ✅ Đặt xe với ngày nhận/trả, địa điểm
- ✅ Kiểm tra xe có sẵn
- ✅ Quản lý lifecycle: pending → confirmed → ongoing → completed
- ✅ Hủy booking với lý do
- ✅ **Gia hạn booking** (Extend) ⭐ NEW
- ✅ Quản lý payment status
- ✅ Xem lịch sử và bookings sắp tới
- ✅ Tự động tính giá theo số ngày thuê
