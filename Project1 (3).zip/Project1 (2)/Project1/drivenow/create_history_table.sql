-- Script tạo bảng History
-- Chạy script này trong SQL Server nếu muốn tạo bảng thủ công

CREATE TABLE history (
    history_id INT PRIMARY KEY IDENTITY(1,1),
    account_id INT NOT NULL,
    booking_id INT NULL,
    driver_id INT NULL,
    action VARCHAR(100) NOT NULL,
    description TEXT NULL,
    entity_type VARCHAR(50) NULL,
    entity_id INT NULL,
    ip_address VARCHAR(50) NULL,
    user_agent VARCHAR(255) NULL,
    status VARCHAR(20) NULL,
    metadata TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT GETDATE(),
    
    CONSTRAINT FK_history_account FOREIGN KEY (account_id) REFERENCES Account(account_id),
    CONSTRAINT FK_history_booking FOREIGN KEY (booking_id) REFERENCES bookings(booking_id),
    CONSTRAINT FK_history_driver FOREIGN KEY (driver_id) REFERENCES driver(driver_id)
);

-- Indexes để tăng performance
CREATE INDEX idx_history_account_id ON history(account_id);
CREATE INDEX idx_history_booking_id ON history(booking_id);
CREATE INDEX idx_history_action ON history(action);
CREATE INDEX idx_history_created_at ON history(created_at);
CREATE INDEX idx_history_entity ON history(entity_type, entity_id);

-- Thêm comment
EXEC sp_addextendedproperty 
    @name = N'MS_Description', 
    @value = N'Bảng lưu lịch sử hành động của users', 
    @level0type = N'SCHEMA', @level0name = N'dbo',
    @level1type = N'TABLE',  @level1name = N'history';
