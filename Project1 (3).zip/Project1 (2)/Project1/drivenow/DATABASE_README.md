# DATABASE SETUP - DRIVENOW

## 🗄️ Database Structure

### **Core Tables (Bắt buộc):**
- `Account` - Tài khoản người dùng
- `Customer` - Thông tin khách hàng
- `Driver` - Thông tin tài xế
- `Admin` - Thông tin admin
- `OTP` - Mã OTP xác thực
- `cars` - Thông tin xe
- `car_images` - Hình ảnh xe
- `bookings` - Đặt xe
- `price_configurations` - Cấu hình giá

---

## 🚀 Setup Instructions

### **Option 1: Automatic (Recommended)** ✅
JPA Hibernate sẽ **tự động tạo** tables khi bạn chạy Spring Boot app:

```bash
./mvnw.cmd spring-boot:run
```

**Cấu hình trong `application.properties`:**
```properties
spring.jpa.hibernate.ddl-auto=update
```

→ Hibernate sẽ tự động:
- Tạo tables nếu chưa có
- Thêm columns mới nếu có thay đổi Entity
- **KHÔNG XÓA** data cũ

---

### **Option 2: Manual SQL Script**

Nếu muốn kiểm soát hoàn toàn, chạy SQL scripts theo thứ tự:

#### **Bước 1: Setup Core Database**
```sql
-- Chạy file này trước
database_setup.sql
```

**Tạo:**
- Database `drivenow_db`
- Core tables (Account, Customer, Driver, Admin, OTP)

#### **Bước 2: Setup Extension Feature (Optional)**
```sql
-- Chỉ chạy nếu cần tính năng gia hạn booking
database_extension_migration.sql
```

**Thêm vào bảng `bookings`:**
- `original_return_date` - Ngày trả ban đầu
- `extension_days` - Số ngày gia hạn
- `extension_price` - Phụ thu
- `is_extended` - Flag đã gia hạn

---

## 📊 Database Diagram

```
Account (1) ──┬── (1) Customer
              ├── (1) Driver
              └── (1) Admin

Car (1) ────── (*) CarImage
Car (1) ────── (*) Booking
Customer (1) ─ (*) Booking
Driver (0..1) ─ (*) Booking
```

---

## 🔧 Table Structures

### **bookings Table**

#### **Core Fields (Bắt buộc):**
```sql
CREATE TABLE bookings (
    booking_id INT IDENTITY(1,1) PRIMARY KEY,
    customer_id INT NOT NULL,
    car_id INT NOT NULL,
    driver_id INT NULL,
    pickup_date DATETIME2 NOT NULL,
    return_date DATETIME2 NOT NULL,
    pickup_location NVARCHAR(255) NOT NULL,
    return_location NVARCHAR(255) NULL,
    total_days INT NOT NULL,
    total_price DECIMAL(10,2) NOT NULL,
    status NVARCHAR(20) NOT NULL DEFAULT 'pending',
    payment_status NVARCHAR(20) NULL DEFAULT 'unpaid',
    payment_method NVARCHAR(50) NULL,
    notes TEXT NULL,
    cancellation_reason TEXT NULL,
    created_at DATETIME2 DEFAULT GETDATE(),
    updated_at DATETIME2 DEFAULT GETDATE(),
    
    -- [EXTENSION FEATURE] - Optional columns
    original_return_date DATETIME2 NULL,
    extension_days INT DEFAULT 0 NULL,
    extension_price DECIMAL(10,2) DEFAULT 0 NULL,
    is_extended BIT DEFAULT 0 NULL,
    
    FOREIGN KEY (customer_id) REFERENCES Customer(customer_id),
    FOREIGN KEY (car_id) REFERENCES cars(car_id),
    FOREIGN KEY (driver_id) REFERENCES Driver(driver_id)
);
```

---

## 🎯 Migration Strategy

### **Kịch bản 1: Database mới**
1. ✅ Chạy Spring Boot app
2. ✅ JPA tự động tạo tất cả tables (bao gồm extension columns)
3. ✅ Done!

### **Kịch bản 2: Database đã có sẵn**
1. ⚠️ Bảng `bookings` đã tồn tại
2. 🔧 Chạy `database_extension_migration.sql`
3. ✅ Thêm extension columns vào bảng bookings
4. ✅ Done!

### **Kịch bản 3: Không cần Extension**
1. ✅ Chạy Spring Boot app như bình thường
2. ✅ Extension columns vẫn được tạo (nullable, không ảnh hưởng)
3. ✅ Đơn giản không gọi API `/extend`

---

## ⚠️ Important Notes

### **1. Spring Boot tự động update schema**
```properties
spring.jpa.hibernate.ddl-auto=update
```
- ✅ Tự động tạo tables mới
- ✅ Tự động thêm columns mới
- ✅ **KHÔNG XÓA** columns cũ
- ✅ **KHÔNG XÓA** data

### **2. Extension columns là nullable**
```sql
original_return_date DATETIME2 NULL
extension_days INT DEFAULT 0 NULL
extension_price DECIMAL(10,2) DEFAULT 0 NULL
is_extended BIT DEFAULT 0 NULL
```
→ Không ảnh hưởng đến bookings cũ

### **3. Backward compatible**
- Bookings cũ: Extension columns = NULL hoặc 0
- Bookings mới không gia hạn: Extension columns = NULL/0
- Bookings có gia hạn: Extension columns có giá trị

---

## 🔍 Verification Queries

### **Kiểm tra bảng bookings:**
```sql
SELECT 
    COLUMN_NAME,
    DATA_TYPE,
    IS_NULLABLE,
    COLUMN_DEFAULT
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'bookings'
ORDER BY ORDINAL_POSITION;
```

### **Kiểm tra extension columns:**
```sql
SELECT TOP 10
    booking_id,
    return_date,
    original_return_date,
    extension_days,
    extension_price,
    is_extended
FROM bookings
WHERE is_extended = 1;  -- Chỉ xem bookings đã gia hạn
```

### **Thống kê extension:**
```sql
-- Tổng số bookings đã gia hạn
SELECT 
    COUNT(*) as total_extended_bookings,
    SUM(extension_days) as total_extension_days,
    SUM(extension_price) as total_extension_revenue
FROM bookings
WHERE is_extended = 1;
```

---

## 🗑️ Rollback (Xóa Extension)

Nếu muốn xóa tính năng extension:

```sql
USE drivenow_db;
GO

ALTER TABLE bookings DROP COLUMN IF EXISTS original_return_date;
ALTER TABLE bookings DROP COLUMN IF EXISTS extension_days;
ALTER TABLE bookings DROP COLUMN IF EXISTS extension_price;
ALTER TABLE bookings DROP COLUMN IF EXISTS is_extended;
GO
```

**Lưu ý:** Data trong các columns này sẽ bị mất!

---

## 📦 Files Overview

| File | Purpose | When to use |
|------|---------|-------------|
| `database_setup.sql` | Core database setup | First time setup |
| `database_extension_migration.sql` | Add extension columns | If bookings table already exists |
| `DATABASE_README.md` | This file | Documentation |

---

## ✅ Quick Start

### **Recommended approach:**
```bash
# 1. Start Spring Boot
./mvnw.cmd spring-boot:run

# 2. JPA tự động tạo tất cả tables
# 3. Done!
```

### **Manual approach:**
```sql
-- 1. Core setup
USE master;
EXEC sp_executesql @stmt = N'CREATE DATABASE drivenow_db';
GO

USE drivenow_db;
-- Run database_setup.sql

-- 2. Extension (optional)
-- Run database_extension_migration.sql
```

---

## 🎉 Summary

✅ **Core tables:** Tự động tạo bởi JPA  
✅ **Extension columns:** Tự động tạo hoặc chạy migration script  
✅ **Backward compatible:** Không ảnh hưởng data cũ  
✅ **Rollback support:** Có script để xóa extension  
✅ **Production ready:** Tested và documented đầy đủ  

**Database sẵn sàng cho cả core và extension features!** 🚀
