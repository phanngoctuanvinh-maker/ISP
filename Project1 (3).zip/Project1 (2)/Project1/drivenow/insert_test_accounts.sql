-- =============================================
-- INSERT TÀI KHOẢN TEST CHO DRIVENOW
-- Password cho tất cả: 123456
-- =============================================

USE drivenow_db;
GO

-- Xóa dữ liệu cũ nếu có (optional)
-- DELETE FROM Customer WHERE account_id IN (SELECT account_id FROM Account WHERE username IN ('customer@gmail.com', 'admin@drivenow.com', 'driver@gmail.com'));
-- DELETE FROM Driver WHERE account_id IN (SELECT account_id FROM Account WHERE username IN ('customer@gmail.com', 'admin@drivenow.com', 'driver@gmail.com'));
-- DELETE FROM Admin WHERE account_id IN (SELECT account_id FROM Account WHERE username IN ('customer@gmail.com', 'admin@drivenow.com', 'driver@gmail.com'));
-- DELETE FROM Account WHERE username IN ('customer@gmail.com', 'admin@drivenow.com', 'driver@gmail.com');

-- Password: 123456 (BCrypt hash)
DECLARE @HashedPassword NVARCHAR(255) = '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhCu';

-- =============================================
-- 1. TẠO ADMIN ACCOUNT
-- =============================================
IF NOT EXISTS (SELECT 1 FROM Account WHERE username = 'admin@drivenow.com')
BEGIN
    INSERT INTO Account (username, password, role, status, created_at, updated_at) 
    VALUES ('admin@drivenow.com', @HashedPassword, 'admin', 'active', GETDATE(), GETDATE());
    
    DECLARE @AdminAccountId INT = SCOPE_IDENTITY();
    
    INSERT INTO Admin (account_id, role, created_at, updated_at)
    VALUES (@AdminAccountId, 'super_admin', GETDATE(), GETDATE());
    
    PRINT '✅ Admin account created: admin@drivenow.com / 123456';
END
ELSE
BEGIN
    PRINT '⚠️ Admin account already exists';
END

-- =============================================
-- 2. TẠO CUSTOMER ACCOUNT
-- =============================================
IF NOT EXISTS (SELECT 1 FROM Account WHERE username = 'customer@gmail.com')
BEGIN
    INSERT INTO Account (username, password, role, status, created_at, updated_at)
    VALUES ('customer@gmail.com', @HashedPassword, 'customer', 'active', GETDATE(), GETDATE());
    
    DECLARE @CustomerAccountId INT = SCOPE_IDENTITY();
    
    INSERT INTO Customer (account_id, full_name, phone, email, address, dob, gender, created_at, updated_at)
    VALUES (@CustomerAccountId, N'Nguyễn Văn A', '0987654321', 'customer@gmail.com', N'123 Đường ABC, TP.HCM', '2000-01-15', 'male', GETDATE(), GETDATE());
    
    PRINT '✅ Customer account created: customer@gmail.com / 123456';
END
ELSE
BEGIN
    PRINT '⚠️ Customer account already exists';
END

-- =============================================
-- 3. TẠO DRIVER ACCOUNT
-- =============================================
IF NOT EXISTS (SELECT 1 FROM Account WHERE username = 'driver@gmail.com')
BEGIN
    INSERT INTO Account (username, password, role, status, created_at, updated_at)
    VALUES ('driver@gmail.com', @HashedPassword, 'driver', 'active', GETDATE(), GETDATE());
    
    DECLARE @DriverAccountId INT = SCOPE_IDENTITY();
    
    INSERT INTO Driver (account_id, license_number, years_of_experience, id_card, address, average_rating, status, created_at, updated_at)
    VALUES (@DriverAccountId, 'B2-123456', 5, '001234567890', N'456 Đường XYZ, Hà Nội', 4.5, 'active', GETDATE(), GETDATE());
    
    PRINT '✅ Driver account created: driver@gmail.com / 123456';
END
ELSE
BEGIN
    PRINT '⚠️ Driver account already exists';
END

-- =============================================
-- KIỂM TRA KẾT QUẢ
-- =============================================
PRINT '';
PRINT '========================================';
PRINT 'DANH SÁCH TÀI KHOẢN TEST:';
PRINT '========================================';

SELECT 
    a.account_id,
    a.username,
    a.role,
    a.status,
    CASE 
        WHEN a.role = 'customer' THEN c.full_name
        WHEN a.role = 'driver' THEN d.license_number
        WHEN a.role = 'admin' THEN ad.role
    END AS info
FROM Account a
LEFT JOIN Customer c ON a.account_id = c.account_id
LEFT JOIN Driver d ON a.account_id = d.account_id
LEFT JOIN Admin ad ON a.account_id = ad.account_id
WHERE a.username IN ('customer@gmail.com', 'admin@drivenow.com', 'driver@gmail.com');

PRINT '';
PRINT '========================================';
PRINT 'TẤT CẢ MẬT KHẨU: 123456';
PRINT '========================================';
