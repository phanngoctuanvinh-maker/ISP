-- =============================================
-- ADMIN MANAGEMENT MIGRATION (OPTIONAL)
-- Thêm field rejection_reason nếu muốn tách riêng
-- với cancellation_reason
-- =============================================

-- Note: Hiện tại code đang dùng chung field cancellation_reason
-- Migration này là OPTIONAL, chỉ chạy nếu muốn tách riêng

USE drivenow_db;
GO

-- 1. Kiểm tra nếu column chưa tồn tại thì mới thêm
IF NOT EXISTS (
    SELECT 1 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_NAME = 'bookings' 
    AND COLUMN_NAME = 'rejection_reason'
)
BEGIN
    PRINT 'Adding rejection_reason column...';
    ALTER TABLE bookings 
    ADD rejection_reason NVARCHAR(MAX) NULL;
    PRINT 'Column rejection_reason added successfully!';
END
ELSE
BEGIN
    PRINT 'Column rejection_reason already exists.';
END
GO

-- 2. Kiểm tra nếu column chưa tồn tại thì mới thêm
IF NOT EXISTS (
    SELECT 1 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_NAME = 'bookings' 
    AND COLUMN_NAME = 'reschedule_reason'
)
BEGIN
    PRINT 'Adding reschedule_reason column...';
    ALTER TABLE bookings 
    ADD reschedule_reason NVARCHAR(MAX) NULL;
    PRINT 'Column reschedule_reason added successfully!';
END
ELSE
BEGIN
    PRINT 'Column reschedule_reason already exists.';
END
GO

-- 3. Kiểm tra kết quả
SELECT 
    COLUMN_NAME,
    DATA_TYPE,
    IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'bookings'
    AND COLUMN_NAME IN ('cancellation_reason', 'rejection_reason', 'reschedule_reason')
ORDER BY ORDINAL_POSITION;
GO

PRINT 'Migration completed!';
GO

-- =============================================
-- ROLLBACK (nếu cần xóa)
-- =============================================
/*
USE drivenow_db;
GO

-- Xóa column rejection_reason
IF EXISTS (
    SELECT 1 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_NAME = 'bookings' 
    AND COLUMN_NAME = 'rejection_reason'
)
BEGIN
    ALTER TABLE bookings DROP COLUMN rejection_reason;
    PRINT 'Column rejection_reason dropped.';
END

-- Xóa column reschedule_reason
IF EXISTS (
    SELECT 1 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_NAME = 'bookings' 
    AND COLUMN_NAME = 'reschedule_reason'
)
BEGIN
    ALTER TABLE bookings DROP COLUMN reschedule_reason;
    PRINT 'Column reschedule_reason dropped.';
END
GO
*/
