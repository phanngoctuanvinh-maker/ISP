# GROUP BOOKING API DOCUMENTATION

## Tổng quan
Module **Group Booking** cho phép khách hàng thuê nhiều xe cùng lúc (ví dụ: tour du lịch, đám cưới, sự kiện công ty) với giảm giá theo số lượng xe.

### Tính năng chính:
- ✅ Thuê nhiều xe cùng lúc cho cùng một khoảng thời gian
- ✅ Giảm giá tự động theo số lượng xe (3-4 xe: 5%, 5+ xe: 10%)
- ✅ Quản lý group booking (tạo, xem, hủy, xác nhận)
- ✅ Tự động tạo các booking riêng lẻ cho mỗi xe
- ✅ Hủy nhóm sẽ hủy tất cả bookings trong nhóm
- ✅ Tính toán tổng giá và giá sau giảm

### Bảng Discount:
| Số lượng xe | Giảm giá |
|-------------|----------|
| 2 xe        | 0%       |
| 3-4 xe      | 5%       |
| 5+ xe       | 10%      |

---

## API Endpoints

### 1. Tạo Group Booking Mới
**Endpoint:** `POST /api/group-bookings`

**Mô tả:** Tạo group booking mới để thuê nhiều xe cùng lúc. Hệ thống sẽ:
- Validate tất cả xe có sẵn trong khoảng thời gian yêu cầu
- Tính tổng giá cho tất cả xe
- Áp dụng giảm giá tự động theo số lượng xe
- Tạo các booking riêng lẻ cho mỗi xe

**Request Body:**
```json
{
  "customerId": 1,
  "groupName": "Tour Đà Lạt 3N2Đ",
  "pickupDate": "2024-01-15T08:00:00",
  "returnDate": "2024-01-18T18:00:00",
  "pickupLocation": "123 Nguyễn Văn Linh, Quận 7, TP HCM",
  "returnLocation": "123 Nguyễn Văn Linh, Quận 7, TP HCM",
  "carIds": [1, 3, 5, 7],
  "paymentMethod": "bank_transfer",
  "notes": "Tour du lịch công ty, cần tài xế có kinh nghiệm đường đèo",
  "discountPercentage": 12
}
```

**Field Description:**
- `customerId` (required): ID khách hàng
- `groupName` (optional): Tên nhóm thuê (mặc định: "Group Booking X cars")
- `pickupDate` (required): Ngày giờ nhận xe (phải > hiện tại)
- `returnDate` (required): Ngày giờ trả xe (phải > pickupDate)
- `pickupLocation` (required): Địa điểm nhận xe
- `returnLocation` (optional): Địa điểm trả xe (mặc định = pickupLocation)
- `carIds` (required): Mảng ID các xe muốn thuê (tối thiểu 2 xe)
- `paymentMethod` (optional): cash, credit_card, bank_transfer
- `notes` (optional): Ghi chú đặc biệt
- `discountPercentage` (optional): Admin có thể set discount tùy chỉnh

**Response Success (201 Created):**
```json
{
  "groupBookingId": 1,
  "customerId": 1,
  "customerName": "Nguyễn Văn A",
  "customerPhone": "0901234567",
  "groupName": "Tour Đà Lạt 3N2Đ",
  "pickupDate": "2024-01-15T08:00:00",
  "returnDate": "2024-01-18T18:00:00",
  "pickupLocation": "123 Nguyễn Văn Linh, Quận 7, TP HCM",
  "returnLocation": "123 Nguyễn Văn Linh, Quận 7, TP HCM",
  "totalCars": 4,
  "totalDays": 3,
  "totalPrice": 12000000.00,
  "discountPercentage": 12.00,
  "discountAmount": 1440000.00,
  "finalPrice": 10560000.00,
  "status": "pending",
  "paymentStatus": "unpaid",
  "paymentMethod": "bank_transfer",
  "notes": "Tour du lịch công ty, cần tài xế có kinh nghiệm đường đèo",
  "carIds": [1, 3, 5, 7],
  "createdAt": "2024-01-10T10:30:00",
  "updatedAt": "2024-01-10T10:30:00"
}
```

**Response Error (400 Bad Request):**
```json
"Xe Toyota Camry 2023 không có sẵn"
```
```json
"Xe Honda CR-V 2024 đã được đặt trong khoảng thời gian này"
```
```json
"Ngày trả xe phải sau ngày nhận xe"
```

---

### 2. Lấy Chi Tiết Group Booking
**Endpoint:** `GET /api/group-bookings/{id}`

**Mô tả:** Xem chi tiết một group booking cụ thể

**Path Parameters:**
- `id`: Group booking ID

**Response Success (200 OK):**
```json
{
  "groupBookingId": 1,
  "customerId": 1,
  "customerName": "Nguyễn Văn A",
  "customerPhone": "0901234567",
  "groupName": "Tour Đà Lạt 3N2Đ",
  "pickupDate": "2024-01-15T08:00:00",
  "returnDate": "2024-01-18T18:00:00",
  "pickupLocation": "123 Nguyễn Văn Linh, Quận 7, TP HCM",
  "returnLocation": "123 Nguyễn Văn Linh, Quận 7, TP HCM",
  "totalCars": 4,
  "totalDays": 3,
  "totalPrice": 12000000.00,
  "discountPercentage": 5.00,
  "discountAmount": 600000.00,
  "finalPrice": 11400000.00,
  "status": "confirmed",
  "paymentStatus": "paid",
  "paymentMethod": "bank_transfer",
  "carIds": [1, 3, 5, 7],
  "createdAt": "2024-01-10T10:30:00",
  "updatedAt": "2024-01-12T14:20:00"
}
```

**Response Error (404 Not Found):**
```json
"Không tìm thấy group booking với ID: 999"
```

---

### 3. Lấy Group Bookings Của Khách Hàng
**Endpoint:** `GET /api/group-bookings/customer/{customerId}`

**Mô tả:** Xem tất cả group bookings của một khách hàng (sắp xếp mới nhất trước)

**Path Parameters:**
- `customerId`: Customer ID

**Response Success (200 OK):**
```json
[
  {
    "groupBookingId": 3,
    "customerId": 1,
    "customerName": "Nguyễn Văn A",
    "customerPhone": "0901234567",
    "groupName": "Đám cưới Phú Quốc",
    "pickupDate": "2024-02-20T06:00:00",
    "returnDate": "2024-02-23T20:00:00",
    "totalCars": 5,
    "totalDays": 3,
    "totalPrice": 15000000.00,
    "discountPercentage": 10.00,
    "discountAmount": 1500000.00,
    "finalPrice": 13500000.00,
    "status": "confirmed",
    "paymentStatus": "paid",
    "carIds": [2, 4, 6, 8, 10],
    "createdAt": "2024-01-15T09:00:00",
    "updatedAt": "2024-01-16T11:30:00"
  },
  {
    "groupBookingId": 1,
    "customerId": 1,
    "customerName": "Nguyễn Văn A",
    "customerPhone": "0901234567",
    "groupName": "Tour Đà Lạt 3N2Đ",
    "pickupDate": "2024-01-15T08:00:00",
    "returnDate": "2024-01-18T18:00:00",
    "totalCars": 4,
    "totalDays": 3,
    "totalPrice": 12000000.00,
    "discountPercentage": 5.00,
    "discountAmount": 600000.00,
    "finalPrice": 11400000.00,
    "status": "completed",
    "paymentStatus": "paid",
    "carIds": [1, 3, 5, 7],
    "createdAt": "2024-01-10T10:30:00",
    "updatedAt": "2024-01-18T19:00:00"
  }
]
```

---

### 4. Lấy Group Bookings Theo Trạng Thái
**Endpoint:** `GET /api/group-bookings/status?status={status}`

**Mô tả:** Admin xem danh sách group bookings theo trạng thái

**Query Parameters:**
- `status`: pending, confirmed, in_progress, completed, cancelled

**Example:** `GET /api/group-bookings/status?status=pending`

**Response Success (200 OK):**
```json
[
  {
    "groupBookingId": 5,
    "customerId": 3,
    "customerName": "Trần Thị C",
    "customerPhone": "0903456789",
    "groupName": "Team Building Vũng Tàu",
    "pickupDate": "2024-01-25T07:00:00",
    "returnDate": "2024-01-26T22:00:00",
    "totalCars": 3,
    "totalDays": 2,
    "totalPrice": 6000000.00,
    "discountPercentage": 5.00,
    "discountAmount": 300000.00,
    "finalPrice": 5700000.00,
    "status": "pending",
    "paymentStatus": "unpaid",
    "carIds": [11, 12, 13],
    "createdAt": "2024-01-18T15:20:00",
    "updatedAt": "2024-01-18T15:20:00"
  }
]
```

---

### 5. Hủy Group Booking
**Endpoint:** `PATCH /api/group-bookings/{id}/cancel`

**Mô tả:** Hủy toàn bộ group booking (sẽ hủy tất cả bookings riêng lẻ trong nhóm). Không thể hủy nếu status = completed hoặc cancelled.

**Path Parameters:**
- `id`: Group booking ID

**Query Parameters:**
- `cancellationReason`: Lý do hủy

**Example:** `PATCH /api/group-bookings/1/cancel?cancellationReason=Khách%20thay%20đổi%20lịch%20trình`

**Response Success (200 OK):**
```json
{
  "groupBookingId": 1,
  "customerId": 1,
  "customerName": "Nguyễn Văn A",
  "groupName": "Tour Đà Lạt 3N2Đ",
  "totalCars": 4,
  "totalPrice": 12000000.00,
  "discountAmount": 600000.00,
  "finalPrice": 11400000.00,
  "status": "cancelled",
  "cancellationReason": "Khách thay đổi lịch trình",
  "updatedAt": "2024-01-12T16:45:00"
}
```

**Response Error (400 Bad Request):**
```json
"Không thể hủy group booking đã hoàn thành hoặc đã hủy"
```

---

### 6. Xác Nhận Group Booking (Admin)
**Endpoint:** `PATCH /api/group-bookings/{id}/confirm`

**Mô tả:** Admin xác nhận group booking (chuyển từ pending → confirmed). Sẽ tự động xác nhận tất cả bookings riêng lẻ trong nhóm.

**Path Parameters:**
- `id`: Group booking ID

**Response Success (200 OK):**
```json
{
  "groupBookingId": 1,
  "customerId": 1,
  "customerName": "Nguyễn Văn A",
  "groupName": "Tour Đà Lạt 3N2Đ",
  "totalCars": 4,
  "status": "confirmed",
  "updatedAt": "2024-01-12T09:30:00"
}
```

**Response Error (400 Bad Request):**
```json
"Chỉ có thể xác nhận group booking đang pending"
```

---

### 7. Cập Nhật Trạng Thái Thanh Toán (Admin)
**Endpoint:** `PATCH /api/group-bookings/{id}/payment-status`

**Mô tả:** Admin cập nhật trạng thái thanh toán cho group booking

**Path Parameters:**
- `id`: Group booking ID

**Query Parameters:**
- `paymentStatus`: paid, unpaid, partial

**Example:** `PATCH /api/group-bookings/1/payment-status?paymentStatus=paid`

**Response Success (200 OK):**
```json
{
  "groupBookingId": 1,
  "customerId": 1,
  "customerName": "Nguyễn Văn A",
  "groupName": "Tour Đà Lạt 3N2Đ",
  "totalCars": 4,
  "finalPrice": 11400000.00,
  "paymentStatus": "paid",
  "updatedAt": "2024-01-12T10:15:00"
}
```

---

## Status Flow

### Group Booking Status:
1. **pending** → Mới tạo, chờ xác nhận
2. **confirmed** → Admin đã xác nhận
3. **in_progress** → Đang trong chuyến đi
4. **completed** → Hoàn thành
5. **cancelled** → Đã hủy

### Payment Status:
- **unpaid**: Chưa thanh toán
- **partial**: Thanh toán một phần (đặt cọc)
- **paid**: Đã thanh toán đủ

---

## Business Rules

### 1. Tạo Group Booking:
- ✅ Tối thiểu 2 xe
- ✅ Tất cả xe phải có status = "available"
- ✅ Không có xe nào bị conflict trong khoảng thời gian yêu cầu
- ✅ returnDate phải > pickupDate
- ✅ pickupDate và returnDate phải là thời gian tương lai

### 2. Discount Calculation:
- Auto discount nếu không set discountPercentage:
  - 2 xe: 0% discount
  - 3-4 xe: 5% discount
  - 5+ xe: 10% discount
- Admin có thể set custom discount trong request

### 3. Cancellation:
- Chỉ có thể hủy group booking có status = pending hoặc confirmed
- Khi hủy group booking → tất cả bookings riêng lẻ cũng bị hủy
- Phải cung cấp cancellation reason

### 4. Relationship với Booking:
- Mỗi group booking tạo ra N bookings (N = số xe)
- Mỗi booking thuộc về 1 group booking (ManyToOne)
- Khi query group booking, có thể lấy danh sách carIds từ các bookings

---

## Use Cases

### Use Case 1: Tour du lịch công ty
```
Công ty A muốn thuê 5 xe cho tour Đà Lạt 3N2Đ:
- 3 xe SUV 7 chỗ (cho nhân viên)
- 2 xe sedan (cho giám đốc)

Discount: 10% (vì thuê 5 xe)
Tổng giá gốc: 15,000,000 VND
Giảm giá: 1,500,000 VND
Giá cuối: 13,500,000 VND
```

### Use Case 2: Đám cưới
```
Khách thuê 4 xe cho đám cưới:
- 2 xe hoa (Toyota Camry)
- 2 xe đưa khách (Ford Explorer)

Discount: 5% (vì thuê 4 xe)
Tổng giá gốc: 8,000,000 VND
Giảm giá: 400,000 VND
Giá cuối: 7,600,000 VND
```

### Use Case 3: Team building
```
Công ty B thuê 3 xe cho team building 1 ngày:
- 3 xe SUV 7 chỗ

Discount: 5% (vì thuê 3 xe)
Tổng giá gốc: 3,000,000 VND
Giảm giá: 150,000 VND
Giá cuối: 2,850,000 VND
```

---

## Testing Checklist

- [ ] Tạo group booking với 2 xe (0% discount)
- [ ] Tạo group booking với 4 xe (5% discount)
- [ ] Tạo group booking với 6 xe (10% discount)
- [ ] Tạo group booking với custom discount từ admin
- [ ] Validate xe không available → báo lỗi
- [ ] Validate xe đã có booking conflict → báo lỗi
- [ ] Validate returnDate < pickupDate → báo lỗi
- [ ] Hủy group booking → tất cả bookings bị hủy
- [ ] Xác nhận group booking → tất cả bookings được xác nhận
- [ ] Update payment status → tất cả bookings được update
- [ ] Xem danh sách group bookings của customer
- [ ] Xem group bookings theo status (pending, confirmed, etc.)

---

## Tổng kết

**Module này đã hoàn thành 7 APIs:**

| # | Method | Endpoint | Mô tả |
|---|--------|----------|-------|
| 1 | POST | `/api/group-bookings` | Tạo group booking mới |
| 2 | GET | `/api/group-bookings/{id}` | Lấy chi tiết group booking |
| 3 | GET | `/api/group-bookings/customer/{customerId}` | Lấy group bookings của customer |
| 4 | GET | `/api/group-bookings/status?status={status}` | Lấy group bookings theo status |
| 5 | PATCH | `/api/group-bookings/{id}/cancel` | Hủy group booking |
| 6 | PATCH | `/api/group-bookings/{id}/confirm` | Xác nhận group booking (Admin) |
| 7 | PATCH | `/api/group-bookings/{id}/payment-status` | Cập nhật payment status (Admin) |

**Files created:**
- `GroupBooking.java` - Model entity
- `GroupBookingRepository.java` - Data access
- `GroupBookingDTO.java` - Response DTO
- `GroupBookingCreateRequest.java` - Request DTO
- `GroupBookingService.java` - Business logic
- `GroupBookingController.java` - REST APIs
- `CustomerRepository.java` - Data access cho Customer
- Modified `Booking.java` - Added groupBooking relationship

**Total APIs trong project: 56 endpoints**
