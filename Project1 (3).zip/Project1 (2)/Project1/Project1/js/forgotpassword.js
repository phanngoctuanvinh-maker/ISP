// forgotpassword.js - Xử lý gửi yêu cầu lấy lại mật khẩu

document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('forgotPasswordForm');
    const messageDiv = document.getElementById('forgotPasswordMessage');

    form.addEventListener('submit', async function(e) {
        e.preventDefault();
        messageDiv.textContent = '';
        const email = document.getElementById('forgotEmail').value.trim();
        if (!email) {
            messageDiv.textContent = 'Vui lòng nhập email.';
            messageDiv.style.color = 'red';
            return;
        }
        try {
            await api.forgotPassword(email);
            messageDiv.textContent = 'Đã gửi mã OTP về email. Vui lòng kiểm tra email để lấy mã OTP.';
            messageDiv.style.color = 'green';
            form.reset();
        } catch (err) {
            messageDiv.textContent = err.message || 'Không gửi được yêu cầu.';
            messageDiv.style.color = 'red';
        }
    });
});
