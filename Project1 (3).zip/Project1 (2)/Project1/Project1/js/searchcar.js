document.addEventListener('DOMContentLoaded', () => {
    console.log('Search car page loaded');
    
    // Get URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const location = urlParams.get('location');
    const time = urlParams.get('time');
    const route = urlParams.get('route');
    
    // Display search info
    if (location) {
        const locationElement = document.querySelector('.search-info-item:first-child span');
        if (locationElement) {
            locationElement.textContent = location;
        }
    }
    
    if (time) {
        const timeElement = document.querySelector('.search-info-item:last-child span');
        if (timeElement) {
            timeElement.textContent = time;
        }
    }
    
    // Log search params
    console.log('Search params:', { location, time, route });
    
    // Filter tabs handling
    const filterTabs = document.querySelectorAll('.filter-tab');
    filterTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            // Remove active class from all tabs
            filterTabs.forEach(t => t.classList.remove('active'));
            // Add active class to clicked tab
            this.classList.add('active');
            
            // TODO: Filter cars based on selected tab
            console.log('Filter selected:', this.textContent.trim());
        });
    });
    
    // Car card click handler
    const carCards = document.querySelectorAll('.car-card-result');
    carCards.forEach(card => {
        card.addEventListener('click', function() {
            // TODO: Navigate to car detail page
            console.log('Car card clicked');
        });
    });
    
    // Xử lý filter tabs
    const carTypeModal = new bootstrap.Modal(document.getElementById('carTypeModal'));
    let selectedCarType = null;
    
    filterTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            // Remove active class from all tabs
            filterTabs.forEach(t => t.classList.remove('active'));
            
            // Add active class to clicked tab
            this.classList.add('active');
            
            // Get filter type from icon or text
            const tabText = this.textContent.trim();
            
            // Hiển thị modal nếu click vào "Loại Xe"
            if (tabText.includes('Loại Xe')) {
                carTypeModal.show();
            }
        });
    });
    
    // Xử lý chọn loại xe trong modal
    const carTypeItems = document.querySelectorAll('.car-type-item');
    
    carTypeItems.forEach(item => {
        item.addEventListener('click', function() {
            // Remove selected class from all items
            carTypeItems.forEach(i => i.classList.remove('selected'));
            
            // Add selected class to clicked item
            this.classList.add('selected');
            
            // Store selected car type
            selectedCarType = this.dataset.type;
        });
    });
    
    // Xử lý nút "Áp dụng"
    const applyBtn = document.getElementById('applyCarType');
    if (applyBtn) {
        applyBtn.addEventListener('click', function() {
            if (selectedCarType) {
                console.log('Selected car type:', selectedCarType);
                // TODO: Filter cars by selected type
                filterCarsByType(selectedCarType);
                carTypeModal.hide();
            }
        });
    }
});

// Function to filter cars by type
function filterCarsByType(carType) {
    console.log('Filtering cars by type:', carType);
    // TODO: Implement filtering logic
}
