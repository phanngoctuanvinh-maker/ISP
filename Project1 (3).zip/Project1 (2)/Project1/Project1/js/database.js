// Fake Database using localStorage

class FakeDatabase {
    constructor() {
        this.initDatabase();
    }

    // Khởi tạo database với dữ liệu mẫu
    initDatabase() {
        if (!localStorage.getItem('users')) {
            const defaultUsers = [
                {
                    id: 1,
                    name: 'Nguyễn Văn A',
                    phone: '0901234567',
                    password: '123456',
                    avatar: null,
                    createdAt: new Date().toISOString()
                },
                {
                    id: 2,
                    name: 'Trần Thị B',
                    phone: '0912345678',
                    password: '123456',
                    avatar: null,
                    createdAt: new Date().toISOString()
                },
                {
                    id: 3,
                    name: 'Lê Văn C',
                    phone: '0923456789',
                    password: '123456',
                    avatar: null,
                    createdAt: new Date().toISOString()
                },
                {
                    id: 4,
                    name: 'Phạm Minh D',
                    phone: '0934567890',
                    password: '123456',
                    avatar: null,
                    createdAt: new Date().toISOString()
                },
                {
                    id: 5,
                    name: 'Hoàng Thu E',
                    phone: '0945678901',
                    password: '123456',
                    avatar: null,
                    createdAt: new Date().toISOString()
                }
            ];
            localStorage.setItem('users', JSON.stringify(defaultUsers));
            console.log('✅ Database initialized with', defaultUsers.length, 'users');
        }
    }

    // Lấy tất cả users
    getAllUsers() {
        return JSON.parse(localStorage.getItem('users') || '[]');
    }

    // Tìm user theo phone
    findUserByPhone(phone) {
        const users = this.getAllUsers();
        return users.find(user => user.phone === phone);
    }

    // Đăng nhập bằng số điện thoại
    login(phone, password) {
        const user = this.findUserByPhone(phone);
        
        if (!user) {
            return { success: false, message: 'Số điện thoại không tồn tại!' };
        }

        if (user.password !== password) {
            return { success: false, message: 'Mật khẩu không chính xác!' };
        }

        // Không trả về password
        const { password: _, ...userWithoutPassword } = user;
        console.log('✅ Login successful:', userWithoutPassword);
        return { success: true, user: userWithoutPassword };
    }

    // Đăng ký
    register(userData) {
        const users = this.getAllUsers();

        // Kiểm tra phone đã tồn tại
        if (this.findUserByPhone(userData.phone)) {
            return { success: false, message: 'Số điện thoại đã được sử dụng!' };
        }

        // Tạo user mới
        const newUser = {
            id: users.length + 1,
            name: userData.name,
            phone: userData.phone,
            password: userData.password,
            referralCode: userData.referralCode || null,
            avatar: null,
            createdAt: new Date().toISOString()
        };

        users.push(newUser);
        localStorage.setItem('users', JSON.stringify(users));

        const { password: _, ...userWithoutPassword } = newUser;
        console.log('✅ Register successful:', userWithoutPassword);
        return { success: true, user: userWithoutPassword };
    }

    // Reset database về mặc định
    resetDatabase() {
        localStorage.removeItem('users');
        localStorage.removeItem('currentUser');
        this.initDatabase();
        console.log('✅ Database reset to default');
    }

    // Xem tất cả users (để debug)
    viewAllUsers() {
        const users = this.getAllUsers().map(user => {
            const { password: _, ...userWithoutPassword } = user;
            return userWithoutPassword;
        });
        console.table(users);
        return users;
    }

    // Xóa tất cả users
    clearAllUsers() {
        localStorage.removeItem('users');
        localStorage.removeItem('currentUser');
        console.log('✅ All users cleared');
    }
}

// Export instance
const db = new FakeDatabase();

// Debug helpers - Có thể gọi từ Console
window.dbHelpers = {
    viewUsers: () => db.viewAllUsers(),
    reset: () => db.resetDatabase(),
    clear: () => db.clearAllUsers(),
    getCurrentUser: () => {
        const user = localStorage.getItem('currentUser');
        if (user) {
            console.log('Current User:', JSON.parse(user));
            return JSON.parse(user);
        } else {
            console.log('No user logged in');
            return null;
        }
    },
    logout: () => {
        localStorage.removeItem('currentUser');
        console.log('✅ Logged out');
        location.reload();
    }
};

console.log('🗄️ Database loaded!');
console.log('📝 Available test accounts:');
console.log('   Phone: 0901234567 | Password: 123456 | Name: Nguyễn Văn A');
console.log('   Phone: 0912345678 | Password: 123456 | Name: Trần Thị B');
console.log('   Phone: 0923456789 | Password: 123456 | Name: Lê Văn C');
console.log('   Phone: 0934567890 | Password: 123456 | Name: Phạm Minh D');
console.log('   Phone: 0945678901 | Password: 123456 | Name: Hoàng Thu E');
console.log('');
console.log('🛠️ Debug commands (type in Console):');
console.log('   dbHelpers.viewUsers()      - Xem tất cả users');
console.log('   dbHelpers.getCurrentUser() - Xem user đang đăng nhập');
console.log('   dbHelpers.logout()         - Đăng xuất');
console.log('   dbHelpers.reset()          - Reset database');
console.log('   dbHelpers.clear()          - Xóa tất cả users');
