-- =====================================================
-- SCRIPT SỬA LỖI CONSTRAINT VÀ CHUYỂN ĐỔI SANG NVARCHAR
-- Fix: "object is dependent on column license_plate"
-- =====================================================

USE drivenow_db;
GO

PRINT N'🔧 BẮT ĐẦU SỬA LỖI...';
GO

-- Xóa dữ liệu cũ
DELETE FROM car_images;
DELETE FROM cars;
GO

-- DROP TẤT CẢ INDEXES (trừ primary key)
DECLARE @sql NVARCHAR(MAX) = N'';

SELECT @sql = @sql + N'DROP INDEX ' + QUOTENAME(i.name) + N' ON ' + QUOTENAME(OBJECT_SCHEMA_NAME(i.object_id)) + N'.' + QUOTENAME(OBJECT_NAME(i.object_id)) + N';' + CHAR(13)
FROM sys.indexes i
WHERE i.object_id = OBJECT_ID('cars')
  AND i.is_primary_key = 0
  AND i.is_unique_constraint = 0
  AND i.type > 0
  AND i.name IS NOT NULL;

IF LEN(@sql) > 0
BEGIN
    PRINT N'Dropping indexes...';
    EXEC sp_executesql @sql;
END
GO

-- DROP TẤT CẢ UNIQUE CONSTRAINTS
DECLARE @sqlConstraints NVARCHAR(MAX) = N'';

SELECT @sqlConstraints = @sqlConstraints + N'ALTER TABLE cars DROP CONSTRAINT ' + QUOTENAME(name) + N';' + CHAR(13)
FROM sys.key_constraints
WHERE parent_object_id = OBJECT_ID('cars')
  AND type = 'UQ';

IF LEN(@sqlConstraints) > 0
BEGIN
    PRINT N'Dropping constraints...';
    EXEC sp_executesql @sqlConstraints;
END
GO

PRINT N'✅ Đã xóa tất cả constraints và indexes';
GO

-- ALTER columns sang NVARCHAR
ALTER TABLE cars ALTER COLUMN brand NVARCHAR(100);
ALTER TABLE cars ALTER COLUMN model NVARCHAR(100);
ALTER TABLE cars ALTER COLUMN name NVARCHAR(200);
ALTER TABLE cars ALTER COLUMN color NVARCHAR(50);
ALTER TABLE cars ALTER COLUMN fuel_type NVARCHAR(50);
ALTER TABLE cars ALTER COLUMN transmission_type NVARCHAR(50);
ALTER TABLE cars ALTER COLUMN license_plate NVARCHAR(20);
ALTER TABLE cars ALTER COLUMN status NVARCHAR(50);
ALTER TABLE cars ALTER COLUMN location NVARCHAR(200);
ALTER TABLE cars ALTER COLUMN description NVARCHAR(MAX);
ALTER TABLE cars ALTER COLUMN image_url NVARCHAR(500);
ALTER TABLE cars ALTER COLUMN insurance_info NVARCHAR(500);

ALTER TABLE car_images ALTER COLUMN image_url NVARCHAR(500);
ALTER TABLE car_images ALTER COLUMN description NVARCHAR(255);
ALTER TABLE car_images ALTER COLUMN type NVARCHAR(50);
ALTER TABLE car_images ALTER COLUMN url NVARCHAR(500);
GO

PRINT N'✅ Đã chuyển sang NVARCHAR';
GO

-- Insert dữ liệu
INSERT INTO cars (
    brand, model, name, color, daily_rate, fuel_type, transmission_type, 
    seat_capacity, seats, year, mileage, license_plate, status, location, 
    description, image_url, price_per_day, insurance_info, created_at, updated_at
)
VALUES 
    (N'Toyota', N'Vios', N'Toyota Vios 2023', N'Trắng', 500000, N'Xăng', N'Số tự động', 5, 5, 2023, 15000, N'30A-12345', N'AVAILABLE', N'Hà Nội', N'Xe sedan tiết kiệm', N'https://i.ibb.co/toyota.jpg', 500000, N'Bảo hiểm toàn diện', GETDATE(), GETDATE()),
    (N'Honda', N'City', N'Honda City 2023', N'Đen', 550000, N'Xăng', N'Số tự động', 5, 5, 2023, 12000, N'30A-23456', N'AVAILABLE', N'Hà Nội', N'Xe sedan cao cấp', N'https://i.ibb.co/honda.jpg', 550000, N'Bảo hiểm vật chất', GETDATE(), GETDATE()),
    (N'Mazda', N'CX-5', N'Mazda CX-5 2023', N'Đỏ', 800000, N'Xăng', N'Số tự động', 7, 7, 2023, 10000, N'30A-34567', N'AVAILABLE', N'HCM', N'SUV 7 chỗ cao cấp', N'https://i.ibb.co/mazda.jpg', 800000, N'Bảo hiểm toàn diện', GETDATE(), GETDATE()),
    (N'Ford', N'Everest', N'Ford Everest 2023', N'Xám', 900000, N'Dầu diesel', N'Số tự động', 7, 7, 2023, 8000, N'30A-45678', N'AVAILABLE', N'HCM', N'SUV địa hình', N'https://i.ibb.co/ford.jpg', 900000, N'Bảo hiểm toàn diện', GETDATE(), GETDATE()),
    (N'VinFast', N'VF8', N'VinFast VF8 2024', N'Xanh', 1200000, N'Điện', N'Số tự động', 5, 5, 2024, 3000, N'30A-56789', N'AVAILABLE', N'Đà Nẵng', N'SUV điện cao cấp', N'https://i.ibb.co/vinfast.jpg', 1200000, N'Bảo hiểm VIP', GETDATE(), GETDATE()),
    (N'Kia', N'Morning', N'Kia Morning 2022', N'Vàng', 350000, N'Xăng', N'Số sàn', 4, 4, 2022, 25000, N'30A-67890', N'AVAILABLE', N'Đà Nẵng', N'Xe mini giá rẻ', N'https://i.ibb.co/kia.jpg', 350000, N'Bảo hiểm cơ bản', GETDATE(), GETDATE()),
    (N'Mitsubishi', N'Xpander', N'Xpander 2023', N'Bạc', 700000, N'Xăng', N'Số tự động', 7, 7, 2023, 18000, N'30A-78901', N'AVAILABLE', N'Cần Thơ', N'MPV 7 chỗ', N'https://i.ibb.co/mitsu.jpg', 700000, N'Bảo hiểm vật chất', GETDATE(), GETDATE()),
    (N'Hyundai', N'Accent', N'Hyundai Accent 2022', N'Trắng', 450000, N'Xăng', N'Số tự động', 5, 5, 2022, 22000, N'30A-89012', N'AVAILABLE', N'Nha Trang', N'Xe sedan giá tốt', N'https://i.ibb.co/hyundai.jpg', 450000, N'Bảo hiểm cơ bản', GETDATE(), GETDATE()),
    (N'Toyota', N'Fortuner', N'Toyota Fortuner 2023', N'Đen', 950000, N'Dầu diesel', N'Số tự động', 7, 7, 2023, 9000, N'30A-90123', N'AVAILABLE', N'Hải Phòng', N'SUV hạng sang', N'https://i.ibb.co/fortuner.jpg', 950000, N'Bảo hiểm toàn diện', GETDATE(), GETDATE()),
    (N'Honda', N'CR-V', N'Honda CR-V 2023', N'Xám', 850000, N'Xăng', N'Số tự động', 7, 7, 2023, 11000, N'30A-01234', N'AVAILABLE', N'Vũng Tàu', N'SUV thông minh', N'https://i.ibb.co/crv.jpg', 850000, N'Bảo hiểm toàn diện', GETDATE(), GETDATE());
GO

PRINT N'✅ Đã thêm 10 xe';
GO

SELECT id, brand, fuel_type, transmission_type FROM cars;
GO

PRINT N'🎉 HOÀN TẤT - Test API: http://localhost:8080/api/cars';
GO
