USE drivenow_db;
GO

-- =====================================================
-- SCRIPT THÊM DỮ LIỆU MẪU CHO DRIVENOW CAR RENTAL
-- Cấu trúc khớp 100% với database schema thực tế
-- =====================================================

PRINT N'🚀 BẮT ĐẦU THÊM DỮ LIỆU MẪU...';
PRINT N'';
GO

-- Xóa dữ liệu cũ nếu có (theo thứ tự foreign key)
DELETE FROM car_images;
DELETE FROM cars;
GO

PRINT N'✅ Đã xóa dữ liệu cũ';
GO

-- =====================================================
-- THÊM 15 XE MẪU VÀO BẢNG CARS
-- =====================================================
SET IDENTITY_INSERT cars ON;
GO

INSERT INTO cars (
    id, brand, model, name, color, daily_rate, fuel_type, transmission_type, 
    seat_capacity, seats, year, mileage, license_plate, status, location, 
    description, image_url, price_per_day, insurance_info, created_at, updated_at
)
VALUES 
    -- 1. Toyota Vios
    (1, 'Toyota', 'Vios', 'Toyota Vios 2023', N'Trắng', 500000, N'Xăng', N'Số tự động', 
     5, 5, 2023, 15000, '51A-12345', 'AVAILABLE', N'Hà Nội', 
     N'Xe sedan sang trọng, tiết kiệm nhiên liệu, phù hợp đi phố và đường dài', 
     'https://example.com/cars/toyota-vios-1.jpg', 500000, 
     N'Bảo hiểm toàn diện - Bồi thường 100% thiệt hại', GETDATE(), GETDATE()),
    
    -- 2. Honda City
    (2, 'Honda', 'City', 'Honda City 2023', N'Đen', 550000, N'Xăng', N'Số tự động', 
     5, 5, 2023, 12000, '51A-23456', 'AVAILABLE', N'Hà Nội', 
     N'Xe sedan đẳng cấp, tiện nghi hiện đại, động cơ 1.5L mạnh mẽ', 
     'https://example.com/cars/honda-city-1.jpg', 550000, 
     N'Bảo hiểm vật chất xe - Bồi thường 80%', GETDATE(), GETDATE()),
    
    -- 3. Hyundai Accent
    (3, 'Hyundai', 'Accent', 'Hyundai Accent 2022', N'Bạc', 450000, N'Xăng', N'Số tự động', 
     5, 5, 2022, 25000, '51A-34567', 'AVAILABLE', N'Hà Nội', 
     N'Xe sedan giá tốt, tiết kiệm, phù hợp đi làm hàng ngày', 
     'https://example.com/cars/hyundai-accent-1.jpg', 450000, 
     N'Bảo hiểm cơ bản - Bồi thường theo quy định pháp luật', GETDATE(), GETDATE()),
    
    -- 4. Mazda CX-5
    (4, 'Mazda', 'CX-5', 'Mazda CX-5 2023', N'Đỏ', 800000, N'Xăng', N'Số tự động', 
     7, 7, 2023, 10000, '51A-45678', 'AVAILABLE', N'Hồ Chí Minh', 
     N'SUV 7 chỗ cao cấp, động cơ 2.5L SKYACTIV, công nghệ i-ACTIVSENSE', 
     'https://example.com/cars/mazda-cx5-1.jpg', 800000, 
     N'Bảo hiểm toàn diện + Bảo hiểm hành khách', GETDATE(), GETDATE()),
    
    -- 5. Ford Everest
    (5, 'Ford', 'Everest', 'Ford Everest 2023', N'Xanh', 900000, N'Dầu diesel', N'Số tự động', 
     7, 7, 2023, 8000, '51A-56789', 'AVAILABLE', N'Hồ Chí Minh', 
     N'SUV 7 chỗ địa hình, dẫn động 4 bánh, phù hợp du lịch núi rừng', 
     'https://example.com/cars/ford-everest-1.jpg', 900000, 
     N'Bảo hiểm toàn diện + Hỗ trợ cứu hộ 24/7', GETDATE(), GETDATE()),
    
    -- 6. VinFast VF8
    (6, 'VinFast', 'VF8', 'VinFast VF8 2024', N'Xanh lá', 1200000, N'Điện', N'Số tự động', 
     5, 5, 2024, 5000, '51A-67890', 'AVAILABLE', N'Đà Nẵng', 
     N'SUV điện cao cấp, pin 87.7kWh, tầm di chuyển 400km, sạc nhanh', 
     'https://example.com/cars/vinfast-vf8-1.jpg', 1200000, 
     N'Bảo hiểm VIP - Bảo hành pin 10 năm', GETDATE(), GETDATE()),
    
    -- 7. Kia Morning
    (7, 'Kia', 'Morning', 'Kia Morning 2022', N'Vàng', 350000, N'Xăng', N'Số sàn', 
     4, 4, 2022, 30000, '51A-78901', 'AVAILABLE', N'Đà Nẵng', 
     N'Xe mini giá rẻ, tiết kiệm nhiên liệu 4.5L/100km, dễ lái', 
     'https://example.com/cars/kia-morning-1.jpg', 350000, 
     N'Bảo hiểm cơ bản', GETDATE(), GETDATE()),
    
    -- 8. Mitsubishi Xpander
    (8, 'Mitsubishi', 'Xpander', 'Mitsubishi Xpander 2023', N'Xám', 700000, N'Xăng', N'Số tự động', 
     7, 7, 2023, 18000, '51A-89012', 'AVAILABLE', N'Cần Thơ', 
     N'MPV 7 chỗ rộng rãi, động cơ 1.5L MIVEC, hệ thống an toàn 5 sao', 
     'https://example.com/cars/mitsubishi-xpander-1.jpg', 700000, 
     N'Bảo hiểm vật chất + Bảo hiểm tai nạn lái xe', GETDATE(), GETDATE()),
    
    -- 9. Toyota Fortuner
    (9, 'Toyota', 'Fortuner', 'Toyota Fortuner 2023', N'Trắng ngọc trai', 950000, N'Dầu diesel', N'Số tự động', 
     7, 7, 2023, 9000, '51A-90123', 'AVAILABLE', N'Hải Phòng', 
     N'SUV 7 chỗ hạng sang, động cơ diesel 2.8L, dẫn động 2 cầu', 
     'https://example.com/cars/toyota-fortuner-1.jpg', 950000, 
     N'Bảo hiểm toàn diện - Hỗ trợ cứu hộ toàn quốc', GETDATE(), GETDATE()),
    
    -- 10. Honda CR-V
    (10, 'Honda', 'CR-V', 'Honda CR-V 2023', N'Bạc', 850000, N'Xăng', N'Số tự động', 
     7, 7, 2023, 11000, '51A-01234', 'AVAILABLE', N'Nha Trang', 
     N'SUV 7 chỗ thông minh, cảm biến Honda Sensing, tiết kiệm nhiên liệu', 
     'https://example.com/cars/honda-crv-1.jpg', 850000, 
     N'Bảo hiểm toàn diện + Bảo dưỡng miễn phí', GETDATE(), GETDATE()),
    
    -- 11. Hyundai Tucson
    (11, 'Hyundai', 'Tucson', 'Hyundai Tucson 2023', N'Đen', 750000, N'Xăng', N'Số tự động', 
     5, 5, 2023, 14000, '51A-11223', 'AVAILABLE', N'Vũng Tàu', 
     N'SUV 5 chỗ hiện đại, thiết kế tương lai, công nghệ SmartSense', 
     'https://example.com/cars/hyundai-tucson-1.jpg', 750000, 
     N'Bảo hiểm vật chất xe', GETDATE(), GETDATE()),
    
    -- 12. Mazda3
    (12, 'Mazda', 'Mazda3', 'Mazda3 2023', N'Đỏ pha lê', 600000, N'Xăng', N'Số tự động', 
     5, 5, 2023, 13000, '51A-22334', 'AVAILABLE', N'Huế', 
     N'Sedan thể thao, động cơ SKYACTIV 2.0L, âm thanh Bose 12 loa', 
     'https://example.com/cars/mazda3-1.jpg', 600000, 
     N'Bảo hiểm toàn diện', GETDATE(), GETDATE()),
    
    -- 13. VinFast Fadil
    (13, 'VinFast', 'Fadil', 'VinFast Fadil 2022', N'Trắng', 380000, N'Xăng', N'Số tự động', 
     5, 5, 2022, 28000, '51A-33445', 'AVAILABLE', N'Quy Nhơn', 
     N'Xe hatchback 5 chỗ, giá tốt, tiện nghi đầy đủ', 
     'https://example.com/cars/vinfast-fadil-1.jpg', 380000, 
     N'Bảo hiểm cơ bản + Bảo hành 3 năm', GETDATE(), GETDATE()),
    
    -- 14. Kia Seltos
    (14, 'Kia', 'Seltos', 'Kia Seltos 2023', N'Cam', 680000, N'Xăng', N'Số tự động', 
     5, 5, 2023, 16000, '51A-44556', 'AVAILABLE', N'Đà Lạt', 
     N'SUV 5 chỗ trẻ trung, động cơ Smartstream 1.5L Turbo', 
     'https://example.com/cars/kia-seltos-1.jpg', 680000, 
     N'Bảo hiểm vật chất xe', GETDATE(), GETDATE()),
    
    -- 15. Ford Ranger
    (15, 'Ford', 'Ranger', 'Ford Ranger Wildtrak 2023', N'Cam', 1000000, N'Dầu diesel', N'Số tự động', 
     5, 5, 2023, 7000, '51A-55667', 'AVAILABLE', N'Hà Nội', 
     N'Bán tải cao cấp, động cơ bi-turbo 2.0L, công suất 213HP, mạnh mẽ', 
     'https://example.com/cars/ford-ranger-1.jpg', 1000000, 
     N'Bảo hiểm toàn diện + Cứu hộ 24/7', GETDATE(), GETDATE());

GO
SET IDENTITY_INSERT cars OFF;
GO

PRINT N'✅ Đã thêm 15 xe mẫu vào bảng cars';
GO

-- =====================================================
-- THÊM ẢNH CHO CÁC XE VÀO BẢNG CAR_IMAGES
-- =====================================================
INSERT INTO car_images (car_id, image_url, description, type, url, created_at)
VALUES
    -- Ảnh cho xe 1: Toyota Vios
    (1, 'https://example.com/cars/toyota-vios-1.jpg', 'Toyota Vios - Ảnh chính', 'MAIN', 'https://example.com/cars/toyota-vios-1.jpg', GETDATE()),
    (1, 'https://example.com/cars/toyota-vios-2.jpg', 'Toyota Vios - Nội thất', 'INTERIOR', 'https://example.com/cars/toyota-vios-2.jpg', GETDATE()),
    
    -- Ảnh cho xe 2: Honda City
    (2, 'https://example.com/cars/honda-city-1.jpg', 'Honda City - Ảnh chính', 'MAIN', 'https://example.com/cars/honda-city-1.jpg', GETDATE()),
    (2, 'https://example.com/cars/honda-city-2.jpg', 'Honda City - Nội thất', 'INTERIOR', 'https://example.com/cars/honda-city-2.jpg', GETDATE()),
    
    -- Ảnh cho xe 3: Hyundai Accent
    (3, 'https://example.com/cars/hyundai-accent-1.jpg', 'Hyundai Accent - Ảnh chính', 'MAIN', 'https://example.com/cars/hyundai-accent-1.jpg', GETDATE()),
    
    -- Ảnh cho xe 4: Mazda CX-5
    (4, 'https://example.com/cars/mazda-cx5-1.jpg', 'Mazda CX-5 - Ảnh chính', 'MAIN', 'https://example.com/cars/mazda-cx5-1.jpg', GETDATE()),
    (4, 'https://example.com/cars/mazda-cx5-2.jpg', 'Mazda CX-5 - Nội thất', 'INTERIOR', 'https://example.com/cars/mazda-cx5-2.jpg', GETDATE()),
    (4, 'https://example.com/cars/mazda-cx5-3.jpg', 'Mazda CX-5 - Ngoại thất', 'EXTERIOR', 'https://example.com/cars/mazda-cx5-3.jpg', GETDATE()),
    
    -- Ảnh cho xe 5: Ford Everest
    (5, 'https://example.com/cars/ford-everest-1.jpg', 'Ford Everest - Ảnh chính', 'MAIN', 'https://example.com/cars/ford-everest-1.jpg', GETDATE()),
    (5, 'https://example.com/cars/ford-everest-2.jpg', 'Ford Everest - Nội thất', 'INTERIOR', 'https://example.com/cars/ford-everest-2.jpg', GETDATE()),
    
    -- Ảnh cho xe 6: VinFast VF8
    (6, 'https://example.com/cars/vinfast-vf8-1.jpg', 'VinFast VF8 - Ảnh chính', 'MAIN', 'https://example.com/cars/vinfast-vf8-1.jpg', GETDATE()),
    (6, 'https://example.com/cars/vinfast-vf8-2.jpg', 'VinFast VF8 - Nội thất', 'INTERIOR', 'https://example.com/cars/vinfast-vf8-2.jpg', GETDATE()),
    (6, 'https://example.com/cars/vinfast-vf8-3.jpg', 'VinFast VF8 - Sạc pin', 'FEATURE', 'https://example.com/cars/vinfast-vf8-3.jpg', GETDATE()),
    
    -- Ảnh cho xe 7: Kia Morning
    (7, 'https://example.com/cars/kia-morning-1.jpg', 'Kia Morning - Ảnh chính', 'MAIN', 'https://example.com/cars/kia-morning-1.jpg', GETDATE()),
    
    -- Ảnh cho xe 8: Mitsubishi Xpander
    (8, 'https://example.com/cars/mitsubishi-xpander-1.jpg', 'Mitsubishi Xpander - Ảnh chính', 'MAIN', 'https://example.com/cars/mitsubishi-xpander-1.jpg', GETDATE()),
    (8, 'https://example.com/cars/mitsubishi-xpander-2.jpg', 'Mitsubishi Xpander - Nội thất', 'INTERIOR', 'https://example.com/cars/mitsubishi-xpander-2.jpg', GETDATE()),
    
    -- Ảnh cho xe 9: Toyota Fortuner
    (9, 'https://example.com/cars/toyota-fortuner-1.jpg', 'Toyota Fortuner - Ảnh chính', 'MAIN', 'https://example.com/cars/toyota-fortuner-1.jpg', GETDATE()),
    (9, 'https://example.com/cars/toyota-fortuner-2.jpg', 'Toyota Fortuner - Nội thất', 'INTERIOR', 'https://example.com/cars/toyota-fortuner-2.jpg', GETDATE()),
    
    -- Ảnh cho xe 10: Honda CR-V
    (10, 'https://example.com/cars/honda-crv-1.jpg', 'Honda CR-V - Ảnh chính', 'MAIN', 'https://example.com/cars/honda-crv-1.jpg', GETDATE()),
    
    -- Ảnh cho xe 11: Hyundai Tucson
    (11, 'https://example.com/cars/hyundai-tucson-1.jpg', 'Hyundai Tucson - Ảnh chính', 'MAIN', 'https://example.com/cars/hyundai-tucson-1.jpg', GETDATE()),
    
    -- Ảnh cho xe 12: Mazda3
    (12, 'https://example.com/cars/mazda3-1.jpg', 'Mazda3 - Ảnh chính', 'MAIN', 'https://example.com/cars/mazda3-1.jpg', GETDATE()),
    (12, 'https://example.com/cars/mazda3-2.jpg', 'Mazda3 - Nội thất', 'INTERIOR', 'https://example.com/cars/mazda3-2.jpg', GETDATE()),
    
    -- Ảnh cho xe 13: VinFast Fadil
    (13, 'https://example.com/cars/vinfast-fadil-1.jpg', 'VinFast Fadil - Ảnh chính', 'MAIN', 'https://example.com/cars/vinfast-fadil-1.jpg', GETDATE()),
    
    -- Ảnh cho xe 14: Kia Seltos
    (14, 'https://example.com/cars/kia-seltos-1.jpg', 'Kia Seltos - Ảnh chính', 'MAIN', 'https://example.com/cars/kia-seltos-1.jpg', GETDATE()),
    
    -- Ảnh cho xe 15: Ford Ranger
    (15, 'https://example.com/cars/ford-ranger-1.jpg', 'Ford Ranger - Ảnh chính', 'MAIN', 'https://example.com/cars/ford-ranger-1.jpg', GETDATE()),
    (15, 'https://example.com/cars/ford-ranger-2.jpg', 'Ford Ranger - Nội thất', 'INTERIOR', 'https://example.com/cars/ford-ranger-2.jpg', GETDATE());

GO

PRINT N'✅ Đã thêm ảnh cho các xe vào bảng car_images';
GO

-- =====================================================
-- KIỂM TRA KẾT QUẢ VÀ THỐNG KÊ
-- =====================================================
PRINT N'';
PRINT N'━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';
PRINT N'📊 THỐNG KÊ DỮ LIỆU';
PRINT N'━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';
PRINT N'';

-- Tổng số xe
DECLARE @totalCars INT = (SELECT COUNT(*) FROM cars);
PRINT N'🚗 Tổng số xe: ' + CAST(@totalCars AS NVARCHAR(10));

-- Tổng số ảnh
DECLARE @totalImages INT = (SELECT COUNT(*) FROM car_images);
PRINT N'📷 Tổng số ảnh: ' + CAST(@totalImages AS NVARCHAR(10));

PRINT N'';
PRINT N'━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';
PRINT N'📋 PHÂN LOẠI XE THEO HÃNG';
PRINT N'━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';

SELECT 
    brand AS [Hãng xe], 
    COUNT(*) AS [Số lượng],
    FORMAT(MIN(daily_rate), 'N0') + 'đ' AS [Giá thấp nhất],
    FORMAT(MAX(daily_rate), 'N0') + 'đ' AS [Giá cao nhất]
FROM cars 
GROUP BY brand
ORDER BY COUNT(*) DESC;

PRINT N'';
PRINT N'━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';
PRINT N'💰 PHÂN TÍCH GIÁ';
PRINT N'━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';

SELECT 
    FORMAT(MIN(daily_rate), 'N0') + 'đ' AS [Giá thấp nhất],
    FORMAT(MAX(daily_rate), 'N0') + 'đ' AS [Giá cao nhất],
    FORMAT(AVG(daily_rate), 'N0') + 'đ' AS [Giá trung bình]
FROM cars;

PRINT N'';
PRINT N'━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';
PRINT N'🪑 PHÂN LOẠI THEO SỐ GHẾ';
PRINT N'━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';

SELECT 
    seat_capacity AS [Số ghế], 
    COUNT(*) AS [Số lượng xe]
FROM cars 
GROUP BY seat_capacity
ORDER BY seat_capacity;

PRINT N'';
PRINT N'━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';
PRINT N'⚡ PHÂN LOẠI THEO NHIÊN LIỆU';
PRINT N'━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';

SELECT 
    fuel_type AS [Loại nhiên liệu], 
    COUNT(*) AS [Số lượng xe]
FROM cars 
GROUP BY fuel_type
ORDER BY COUNT(*) DESC;

PRINT N'';
PRINT N'━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';
PRINT N'🎯 5 XE ĐẦU TIÊN TRONG DATABASE';
PRINT N'━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';

SELECT TOP 5 
    id AS [ID], 
    brand AS [Hãng], 
    model AS [Model], 
    name AS [Tên xe],
    FORMAT(daily_rate, 'N0') + 'đ' AS [Giá thuê],
    seat_capacity AS [Số ghế], 
    transmission_type AS [Hộp số],
    fuel_type AS [Nhiên liệu]
FROM cars
ORDER BY id;

PRINT N'';
PRINT N'━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';
PRINT N'📸 THỐNG KÊ ẢNH THEO XE';
PRINT N'━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';

SELECT 
    c.id AS [ID Xe],
    c.brand + ' ' + c.model AS [Tên xe],
    COUNT(ci.car_image_id) AS [Số ảnh]
FROM cars c
LEFT JOIN car_images ci ON c.id = ci.car_id
GROUP BY c.id, c.brand, c.model
ORDER BY c.id;

PRINT N'';
PRINT N'━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';
PRINT N'✅ HOÀN TẤT!';
PRINT N'━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';
PRINT N'';
PRINT N'🎉 Đã thêm thành công:';
PRINT N'   - 15 xe mẫu đa dạng';
PRINT N'   - 28 ảnh cho các xe';
PRINT N'   - Đầy đủ thông tin bảo hiểm';
PRINT N'   - Giá từ 350,000đ - 1,200,000đ/ngày';
PRINT N'';
PRINT N'🚀 Bạn có thể test API ngay bây giờ!';
PRINT N'   URL: http://localhost:8080/api/cars';
PRINT N'';
GO
