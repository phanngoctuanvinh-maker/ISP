# 🧪 TESTCASE - DriveNow Car Search API

**Project**: DriveNow Car Rental System  
**Module**: Car Search & Filter  
**Date**: October 19, 2025  
**Tester**: ___________________  
**Environment**: http://localhost:8080

---

## 📋 PRE-CONDITIONS
- [x] Server đang chạy trên port 8080
- [x] Database có 10 xe test data
- [x] Postman hoặc browser sẵn sàng

---

## TEST SUITE 1: GET ALL CARS

### TC-001: Lấy toàn bộ danh sách xe
**Endpoint**: `GET http://localhost:8080/api/cars`

**Steps**:
1. Mở Postman
2. Tạo request GET với URL trên
3. Click "Send"

**Expected Result**:
- Status: `200 OK`
- Response body chứa:
  ```json
  {
    "data": [array of 10 cars],
    "total": 10,
    "page": 0,
    "size": 10
  }
  ```
- Mỗi car object có các fields: `id`, `brand`, `model`, `name`, `color`, `dailyRate`, `fuelType`, `transmissionType`, `seatCapacity`, `year`, `status`, `location`

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

**Notes**: ______________________________________

---

## TEST SUITE 2: SEARCH BASIC

### TC-002: Search tất cả xe (không filter)
**Endpoint**: `GET http://localhost:8080/api/cars/search`

**Steps**:
1. Send GET request không có query params

**Expected Result**:
- Status: `200 OK`
- Trả về 10 xe
- Tất cả xe có `status = "AVAILABLE"`

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

### TC-003: Search theo brand Toyota
**Endpoint**: `GET http://localhost:8080/api/cars/search?brand=Toyota`

**Steps**:
1. Add query param: `brand=Toyota`
2. Send request

**Expected Result**:
- Status: `200 OK`
- Trả về **2 xe**: Toyota Vios, Toyota Fortuner
- Tất cả xe có `brand = "Toyota"`

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

### TC-004: Search theo brand Honda
**Endpoint**: `GET http://localhost:8080/api/cars/search?brand=Honda`

**Expected Result**:
- Trả về **2 xe**: Honda City, Honda CR-V
- `brand = "Honda"`

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

### TC-005: Search theo brand VinFast
**Endpoint**: `GET http://localhost:8080/api/cars/search?brand=VinFast`

**Expected Result**:
- Trả về **1 xe**: VinFast VF8
- `brand = "VinFast"`

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

### TC-006: Search brand không tồn tại
**Endpoint**: `GET http://localhost:8080/api/cars/search?brand=BMW`

**Expected Result**:
- Status: `200 OK`
- `data = []` (empty array)
- `total = 0`

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

## TEST SUITE 3: FILTER BY FUEL TYPE

### TC-007: Search xe điện
**Endpoint**: `GET http://localhost:8080/api/cars/search?fuelType=Điện`

**Expected Result**:
- Trả về **1 xe**: VinFast VF8 2024
- `fuelType = "Điện"`
- `pricePerDay = 1200000`

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

### TC-008: Search xe xăng
**Endpoint**: `GET http://localhost:8080/api/cars/search?fuelType=Xăng`

**Expected Result**:
- Trả về **7 xe**
- Tất cả có `fuelType = "Xăng"`
- Bao gồm: Toyota Vios, Honda City, Mazda CX-5, Kia Morning, Mitsubishi Xpander, Hyundai Accent, Honda CR-V

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

### TC-009: Search xe dầu diesel
**Endpoint**: `GET http://localhost:8080/api/cars/search?fuelType=Dầu diesel`

**Expected Result**:
- Trả về **2 xe**: Ford Everest, Toyota Fortuner
- `fuelType = "Dầu diesel"`

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

## TEST SUITE 4: FILTER BY TRANSMISSION

### TC-010: Search số tự động
**Endpoint**: `GET http://localhost:8080/api/cars/search?transmissionType=Số tự động`

**Expected Result**:
- Trả về **9 xe**
- Tất cả có `transmissionType = "Số tự động"`

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

### TC-011: Search số sàn
**Endpoint**: `GET http://localhost:8080/api/cars/search?transmissionType=Số sàn`

**Expected Result**:
- Trả về **1 xe**: Kia Morning 2022
- `transmissionType = "Số sàn"`
- `pricePerDay = 350000`

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

## TEST SUITE 5: FILTER BY SEAT CAPACITY

### TC-012: Search xe 4 chỗ
**Endpoint**: `GET http://localhost:8080/api/cars/search?seatCapacity=4`

**Expected Result**:
- Trả về **1 xe**: Kia Morning
- `seatCapacity = 4`

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

### TC-013: Search xe 5 chỗ
**Endpoint**: `GET http://localhost:8080/api/cars/search?seatCapacity=5`

**Expected Result**:
- Trả về **4 xe**: Toyota Vios, Honda City, VinFast VF8, Hyundai Accent
- Tất cả có `seatCapacity = 5`

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

### TC-014: Search xe 7 chỗ
**Endpoint**: `GET http://localhost:8080/api/cars/search?seatCapacity=7`

**Expected Result**:
- Trả về **5 xe**: Mazda CX-5, Ford Everest, Mitsubishi Xpander, Toyota Fortuner, Honda CR-V
- Tất cả có `seatCapacity = 7`

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

## TEST SUITE 6: FILTER BY PRICE RANGE

### TC-015: Search xe dưới 500k
**Endpoint**: `GET http://localhost:8080/api/cars/search?maxPrice=500000`

**Expected Result**:
- Trả về **3 xe**: Kia Morning (350k), Hyundai Accent (450k), Toyota Vios (500k)
- Tất cả có `pricePerDay ≤ 500000`

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

### TC-016: Search xe từ 400k-600k
**Endpoint**: `GET http://localhost:8080/api/cars/search?minPrice=400000&maxPrice=600000`

**Expected Result**:
- Trả về **3 xe**: Hyundai Accent (450k), Toyota Vios (500k), Honda City (550k)
- `400000 ≤ pricePerDay ≤ 600000`

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

### TC-017: Search xe từ 700k-900k
**Endpoint**: `GET http://localhost:8080/api/cars/search?minPrice=700000&maxPrice=900000`

**Expected Result**:
- Trả về **4 xe**: Mitsubishi Xpander (700k), Mazda CX-5 (800k), Honda CR-V (850k), Ford Everest (900k)

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

### TC-018: Search xe trên 1 triệu
**Endpoint**: `GET http://localhost:8080/api/cars/search?minPrice=1000000`

**Expected Result**:
- Trả về **1 xe**: VinFast VF8 (1.2M)

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

## TEST SUITE 7: COMBINED FILTERS

### TC-019: Toyota + Xăng + Tự động
**Endpoint**: `GET http://localhost:8080/api/cars/search?brand=Toyota&fuelType=Xăng&transmissionType=Số tự động`

**Expected Result**:
- Trả về **1 xe**: Toyota Vios
- Thỏa mãn cả 3 điều kiện

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

### TC-020: 7 chỗ + dưới 800k
**Endpoint**: `GET http://localhost:8080/api/cars/search?seatCapacity=7&maxPrice=800000`

**Expected Result**:
- Trả về **2 xe**: Mitsubishi Xpander (700k), Mazda CX-5 (800k)

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

### TC-021: Điện + 5 chỗ
**Endpoint**: `GET http://localhost:8080/api/cars/search?fuelType=Điện&seatCapacity=5`

**Expected Result**:
- Trả về **1 xe**: VinFast VF8

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

## TEST SUITE 8: ADVANCED FILTER (POST)

### TC-022: Filter nhiều brands + price range
**Endpoint**: `POST http://localhost:8080/api/cars/filter`

**Request Body**:
```json
{
  "brands": ["Toyota", "Honda"],
  "minPrice": 400000,
  "maxPrice": 900000,
  "fuelTypes": ["Xăng"],
  "transmissionTypes": ["Số tự động"]
}
```

**Expected Result**:
- Trả về **3-4 xe**: Toyota Vios, Honda City, Honda CR-V (có thể có thêm)
- Tất cả thỏa mãn: brand in [Toyota, Honda], price 400k-900k, xăng, tự động

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

### TC-023: Filter theo năm sản xuất
**Endpoint**: `POST http://localhost:8080/api/cars/filter`

**Request Body**:
```json
{
  "minYear": 2023,
  "maxYear": 2024
}
```

**Expected Result**:
- Trả về **9 xe** (tất cả trừ Kia Morning 2022 và Hyundai Accent 2022)
- `2023 ≤ year ≤ 2024`

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

### TC-024: Empty filter
**Endpoint**: `POST http://localhost:8080/api/cars/filter`

**Request Body**:
```json
{}
```

**Expected Result**:
- Trả về **10 xe** (tất cả)

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

## TEST SUITE 9: GET SINGLE CAR

### TC-025: Get car by valid ID
**Endpoint**: `GET http://localhost:8080/api/cars/1`

**Expected Result**:
- Status: `200 OK`
- Trả về thông tin chi tiết xe ID=1 (Toyota Vios)
- Có đầy đủ fields: `id`, `brand`, `model`, `name`, `description`, etc.

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

### TC-026: Get car by ID = 5
**Endpoint**: `GET http://localhost:8080/api/cars/5`

**Expected Result**:
- Trả về VinFast VF8
- `id = 5`, `brand = "VinFast"`

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

### TC-027: Get car by invalid ID
**Endpoint**: `GET http://localhost:8080/api/cars/999`

**Expected Result**:
- Status: `404 Not Found`
- Message: "Car not found with id: 999"

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

## TEST SUITE 10: GET BRANDS

### TC-028: Get all brands
**Endpoint**: `GET http://localhost:8080/api/cars/brands`

**Expected Result**:
- Status: `200 OK`
- Trả về array **8 brands**: `["Toyota", "Honda", "Mazda", "Ford", "VinFast", "Kia", "Mitsubishi", "Hyundai"]`
- Không có duplicate

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

## TEST SUITE 11: COUNT BY BRAND

### TC-029: Count Toyota
**Endpoint**: `GET http://localhost:8080/api/cars/count/Toyota`

**Expected Result**:
- Status: `200 OK`
- Response: `{ "count": 2 }`

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

### TC-030: Count Honda
**Endpoint**: `GET http://localhost:8080/api/cars/count/Honda`

**Expected Result**:
- `{ "count": 2 }`

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

### TC-031: Count VinFast
**Endpoint**: `GET http://localhost:8080/api/cars/count/VinFast`

**Expected Result**:
- `{ "count": 1 }`

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

### TC-032: Count brand không tồn tại
**Endpoint**: `GET http://localhost:8080/api/cars/count/BMW`

**Expected Result**:
- `{ "count": 0 }`

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

## TEST SUITE 12: PAGINATION

### TC-033: Page 0, Size 5
**Endpoint**: `GET http://localhost:8080/api/cars/search?page=0&size=5`

**Expected Result**:
- Trả về **5 xe đầu tiên**
- `page = 0`, `size = 5`, `totalPages = 2`

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

### TC-034: Page 1, Size 5
**Endpoint**: `GET http://localhost:8080/api/cars/search?page=1&size=5`

**Expected Result**:
- Trả về **5 xe tiếp theo**
- `page = 1`, `size = 5`

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

## TEST SUITE 13: SORTING

### TC-035: Sort by price ASC
**Endpoint**: `GET http://localhost:8080/api/cars/search?sortBy=pricePerDay&sortOrder=asc`

**Expected Result**:
- Xe đầu tiên: Kia Morning (350k)
- Xe cuối cùng: VinFast VF8 (1.2M)
- Prices tăng dần: 350k → 450k → 500k → ... → 1.2M

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

### TC-036: Sort by price DESC
**Endpoint**: `GET http://localhost:8080/api/cars/search?sortBy=pricePerDay&sortOrder=desc`

**Expected Result**:
- Xe đầu tiên: VinFast VF8 (1.2M)
- Xe cuối cùng: Kia Morning (350k)
- Prices giảm dần

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

### TC-037: Sort by year DESC
**Endpoint**: `GET http://localhost:8080/api/cars/search?sortBy=year&sortOrder=desc`

**Expected Result**:
- Xe đầu tiên: VinFast VF8 (2024)
- Xe cuối cùng: Kia Morning hoặc Hyundai Accent (2022)

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

## TEST SUITE 14: ERROR HANDLING

### TC-038: Invalid query param type
**Endpoint**: `GET http://localhost:8080/api/cars/search?seatCapacity=abc`

**Expected Result**:
- Status: `400 Bad Request` hoặc bỏ qua param

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

### TC-039: Invalid JSON body (POST)
**Endpoint**: `POST http://localhost:8080/api/cars/filter`

**Request Body**: `{ invalid json }`

**Expected Result**:
- Status: `400 Bad Request`
- Message về JSON parse error

**Actual Result**: __________________

**Status**: [ ] PASS  [ ] FAIL

---

## 📊 TEST SUMMARY

| Metric | Value |
|--------|-------|
| **Total Testcases** | 39 |
| **Pass** | ___ |
| **Fail** | ___ |
| **Blocked** | ___ |
| **Pass Rate** | ___% |

---

## 🐛 BUGS FOUND

| Bug ID | TC ID | Severity | Description | Status |
|--------|-------|----------|-------------|--------|
| BUG-001 | TC-___ | High/Medium/Low | _________________ | Open/Fixed |
| BUG-002 | TC-___ | High/Medium/Low | _________________ | Open/Fixed |

---

## ✅ SIGN-OFF

**Tester**: ___________________  
**Date**: ___________________  
**Result**: [ ] PASS  [ ] FAIL  
**Comments**: _______________________________________________
