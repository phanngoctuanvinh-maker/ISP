-- Script sửa lỗi - Thêm dữ liệu xe vào database
-- Chạy script này trong SQL Server Management Studio

USE drivenow_db;
GO

-- Kiểm tra tên cột thực tế trong bảng cars
SELECT COLUMN_NAME, DATA_TYPE 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'cars'
ORDER BY ORDINAL_POSITION;
GO

-- Xóa dữ liệu cũ (nếu có)
DELETE FROM car_images;
DELETE FROM cars;
GO

-- Thêm dữ liệu xe (SỬA LẠI TÊN CỘT)
-- Bỏ các cột không tồn tại: transmission, insurance_included
INSERT INTO cars (brand, model, name, color, daily_rate, fuel_type, seat_capacity, year, mileage, license_plate, status, location, description, image_url, price_per_day, created_at, updated_at)
VALUES 
    ('Toyota', 'Vios', 'Toyota Vios 2023', N'Trắng', 500000, N'Xăng', 5, 2023, 15000, '51A-12345', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', N'Xe sedan sang trọng, tiết kiệm nhiên liệu, số tự động', '../car/car/OIP.webp', 500000, GETDATE(), GETDATE()),
    ('Honda', 'City', 'Honda City 2023', N'Đen', 550000, N'Xăng', 5, 2023, 12000, '51A-23456', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', N'Xe sedan đẳng cấp, tiện nghi hiện đại, số tự động', '../car/car/OIP.webp', 550000, GETDATE(), GETDATE()),
    ('Hyundai', 'Accent', 'Hyundai Accent 2022', N'Bạc', 450000, N'Xăng', 5, 2022, 25000, '51A-34567', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', N'Xe sedan giá tốt, phù hợp đi phố, số tự động', '../car/car/OIP.webp', 450000, GETDATE(), GETDATE()),
    ('Mazda', 'CX-5', 'Mazda CX-5 2023', N'Đỏ', 800000, N'Xăng', 7, 2023, 10000, '51A-45678', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', N'SUV 7 chỗ cao cấp, động cơ mạnh mẽ, số tự động', '../car/car/OIP.webp', 800000, GETDATE(), GETDATE()),
    ('Ford', 'Everest', 'Ford Everest 2023', N'Xanh', 900000, N'Dầu diesel', 7, 2023, 8000, '51A-56789', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', N'SUV 7 chỗ địa hình, mạnh mẽ, số tự động', '../car/car/OIP.webp', 900000, GETDATE(), GETDATE()),
    ('VinFast', 'VF8', 'VinFast VF8 2024', N'Xanh', 1200000, N'Điện', 5, 2024, 5000, '51A-67890', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', N'SUV điện cao cấp, thân thiện môi trường, số tự động', '../car/car/OIP.webp', 1200000, GETDATE(), GETDATE()),
    ('Kia', 'Morning', 'Kia Morning 2022', N'Vàng', 350000, N'Xăng', 4, 2022, 30000, '51A-78901', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', N'Xe mini giá rẻ, tiết kiệm, số sàn', '../car/car/OIP.webp', 350000, GETDATE(), GETDATE()),
    ('Toyota', 'Innova', 'Toyota Innova 2023', N'Bạc', 700000, N'Xăng', 7, 2023, 18000, '51A-89012', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', N'MPV 7 chỗ gia đình, rộng rãi, số tự động', '../car/car/OIP.webp', 700000, GETDATE(), GETDATE()),
    ('Mitsubishi', 'Xpander', 'Mitsubishi Xpander 2023', N'Trắng', 600000, N'Xăng', 7, 2023, 14000, '51A-90123', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', N'MPV 7 chỗ tiện dụng, số tự động', '../car/car/OIP.webp', 600000, GETDATE(), GETDATE()),
    ('Ford', 'Ranger', 'Ford Ranger 2023', N'Đen', 1000000, N'Dầu diesel', 5, 2023, 12000, '51A-01234', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', N'Bán tải mạnh mẽ, địa hình, số tự động', '../car/car/OIP.webp', 1000000, GETDATE(), GETDATE()),
    ('Honda', 'CR-V', 'Honda CR-V 2023', N'Trắng', 850000, N'Xăng', 7, 2023, 9000, '51A-11111', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', N'SUV 7 chỗ sang trọng, số tự động', '../car/car/OIP.webp', 850000, GETDATE(), GETDATE()),
    ('Mazda', 'CX-8', 'Mazda CX-8 2023', N'Xanh', 950000, N'Dầu diesel', 7, 2023, 11000, '51A-22222', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', N'SUV 7 chỗ cao cấp nhất, số tự động', '../car/car/OIP.webp', 950000, GETDATE(), GETDATE()),
    ('Toyota', 'Camry', 'Toyota Camry 2024', N'Đen', 1100000, N'Xăng', 5, 2024, 5000, '51A-33333', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', N'Sedan hạng sang, cao cấp, số tự động', '../car/car/OIP.webp', 1100000, GETDATE(), GETDATE()),
    ('Honda', 'Accord', 'Honda Accord 2024', N'Bạc', 1050000, N'Xăng', 5, 2024, 6000, '51A-44444', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', N'Sedan cao cấp, sang trọng, số tự động', '../car/car/OIP.webp', 1050000, GETDATE(), GETDATE()),
    ('VinFast', 'Lux A2.0', 'VinFast Lux A2.0 2023', N'Đỏ', 800000, N'Xăng', 5, 2023, 10000, '51A-55555', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', N'Sedan Việt Nam, chất lượng cao, số tự động', '../car/car/OIP.webp', 800000, GETDATE(), GETDATE());

PRINT N'✅ Đã thêm 15 xe mẫu vào bảng cars';
GO

-- =====================================================
-- SCRIPT SỬA LỖI TIẾNG VIỆT: ĐỔI VARCHAR SANG NVARCHAR
-- Chạy script này trong SSMS để fix lỗi font tiếng Việt
-- =====================================================

USE drivenow_db;
GO

PRINT N'🔧 BẮT ĐẦU CHUYỂN ĐỔI VARCHAR → NVARCHAR...';
PRINT N'';
GO

-- XÓA DỮ LIỆU CŨ (nếu có lỗi font)
DELETE FROM car_images;
DELETE FROM cars;
GO

PRINT N'✅ Đã xóa dữ liệu cũ';
GO

-- SỬA CẤU TRÚC BẢNG CARS
PRINT N'🔧 Đang sửa cấu trúc bảng cars...';

ALTER TABLE cars ALTER COLUMN brand NVARCHAR(100);
ALTER TABLE cars ALTER COLUMN model NVARCHAR(100);
ALTER TABLE cars ALTER COLUMN name NVARCHAR(200);
ALTER TABLE cars ALTER COLUMN color NVARCHAR(50);
ALTER TABLE cars ALTER COLUMN fuel_type NVARCHAR(50);
ALTER TABLE cars ALTER COLUMN transmission_type NVARCHAR(50);
ALTER TABLE cars ALTER COLUMN license_plate NVARCHAR(20);
ALTER TABLE cars ALTER COLUMN status NVARCHAR(50);
ALTER TABLE cars ALTER COLUMN location NVARCHAR(200);
ALTER TABLE cars ALTER COLUMN description NVARCHAR(MAX);
ALTER TABLE cars ALTER COLUMN image_url NVARCHAR(500);
ALTER TABLE cars ALTER COLUMN insurance_info NVARCHAR(500);

GO

PRINT N'✅ Đã sửa xong bảng cars';
GO

-- SỬA CẤU TRÚC BẢNG CAR_IMAGES
PRINT N'🔧 Đang sửa cấu trúc bảng car_images...';

ALTER TABLE car_images ALTER COLUMN image_url NVARCHAR(500);
ALTER TABLE car_images ALTER COLUMN description NVARCHAR(255);
ALTER TABLE car_images ALTER COLUMN type NVARCHAR(50);
ALTER TABLE car_images ALTER COLUMN url NVARCHAR(500);

GO

PRINT N'✅ Đã sửa xong bảng car_images';
PRINT N'';
GO

-- THÊM LẠI DỮ LIỆU VỚI TIẾNG VIỆT ĐÚNG
PRINT N'📝 Đang thêm lại dữ liệu với tiếng Việt có dấu...';
GO

INSERT INTO cars (
    brand, model, name, color, daily_rate, fuel_type, transmission_type, 
    seat_capacity, seats, year, mileage, license_plate, status, location, 
    description, image_url, price_per_day, insurance_info, created_at, updated_at
)
VALUES 
    -- Xe 1: Toyota Vios
    (N'Toyota', N'Vios', N'Toyota Vios 2023', N'Trắng', 500000, N'Xăng', N'Số tự động', 
     5, 5, 2023, 15000, N'30A-12345', N'AVAILABLE', N'Hà Nội', 
     N'Xe sedan tiết kiệm nhiên liệu, phù hợp đi phố và đường dài', 
     N'https://i.ibb.co/toyota-vios.jpg', 500000, 
     N'Bảo hiểm toàn diện - Bồi thường 100%', GETDATE(), GETDATE()),
    
    -- Xe 2: Honda City
    (N'Honda', N'City', N'Honda City 2023', N'Đen', 550000, N'Xăng', N'Số tự động', 
     5, 5, 2023, 12000, N'30A-23456', N'AVAILABLE', N'Hà Nội', 
     N'Xe sedan cao cấp, tiện nghi hiện đại, động cơ mạnh mẽ', 
     N'https://i.ibb.co/honda-city.jpg', 550000, 
     N'Bảo hiểm vật chất xe - Bồi thường 80%', GETDATE(), GETDATE()),
    
    -- Xe 3: Mazda CX-5
    (N'Mazda', N'CX-5', N'Mazda CX-5 2023', N'Đỏ', 800000, N'Xăng', N'Số tự động', 
     7, 7, 2023, 10000, N'30A-34567', N'AVAILABLE', N'Hồ Chí Minh', 
     N'SUV 7 chỗ cao cấp, động cơ 2.5L SKYACTIV, công nghệ i-ACTIVSENSE', 
     N'https://i.ibb.co/mazda-cx5.jpg', 800000, 
     N'Bảo hiểm toàn diện + Bảo hiểm hành khách', GETDATE(), GETDATE()),
    
    -- Xe 4: Ford Everest
    (N'Ford', N'Everest', N'Ford Everest 2023', N'Xám', 900000, N'Dầu diesel', N'Số tự động', 
     7, 7, 2023, 8000, N'30A-45678', N'AVAILABLE', N'Hồ Chí Minh', 
     N'SUV 7 chỗ địa hình, dẫn động 4 bánh, phù hợp du lịch núi rừng', 
     N'https://i.ibb.co/ford-everest.jpg', 900000, 
     N'Bảo hiểm toàn diện + Hỗ trợ cứu hộ 24/7', GETDATE(), GETDATE()),
    
    -- Xe 5: VinFast VF8 (Điện)
    (N'VinFast', N'VF8', N'VinFast VF8 2024', N'Xanh lá', 1200000, N'Điện', N'Số tự động', 
     5, 5, 2024, 3000, N'30A-56789', N'AVAILABLE', N'Đà Nẵng', 
     N'SUV điện cao cấp, pin 87.7kWh, tầm di chuyển 400km, sạc nhanh', 
     N'https://i.ibb.co/vinfast-vf8.jpg', 1200000, 
     N'Bảo hiểm VIP - Bảo hành pin 10 năm', GETDATE(), GETDATE()),
    
    -- Xe 6: Kia Morning
    (N'Kia', N'Morning', N'Kia Morning 2022', N'Vàng', 350000, N'Xăng', N'Số sàn', 
     4, 4, 2022, 25000, N'30A-67890', N'AVAILABLE', N'Đà Nẵng', 
     N'Xe mini giá rẻ, tiết kiệm nhiên liệu 4.5L/100km, dễ lái trong phố', 
     N'https://i.ibb.co/kia-morning.jpg', 350000, 
     N'Bảo hiểm cơ bản theo quy định pháp luật', GETDATE(), GETDATE()),
    
    -- Xe 7: Mitsubishi Xpander
    (N'Mitsubishi', N'Xpander', N'Mitsubishi Xpander 2023', N'Bạc', 700000, N'Xăng', N'Số tự động', 
     7, 7, 2023, 18000, N'30A-78901', N'AVAILABLE', N'Cần Thơ', 
     N'MPV 7 chỗ rộng rãi, động cơ 1.5L MIVEC, an toàn 5 sao ASEAN NCAP', 
     N'https://i.ibb.co/mitsubishi-xpander.jpg', 700000, 
     N'Bảo hiểm vật chất + Bảo hiểm tai nạn lái xe', GETDATE(), GETDATE()),
    
    -- Xe 8: Hyundai Accent
    (N'Hyundai', N'Accent', N'Hyundai Accent 2022', N'Trắng', 450000, N'Xăng', N'Số tự động', 
     5, 5, 2022, 22000, N'30A-89012', N'AVAILABLE', N'Nha Trang', 
     N'Xe sedan giá tốt, tiết kiệm, phù hợp đi làm hàng ngày', 
     N'https://i.ibb.co/hyundai-accent.jpg', 450000, 
     N'Bảo hiểm cơ bản - Bồi thường theo quy định', GETDATE(), GETDATE()),
    
    -- Xe 9: Toyota Fortuner
    (N'Toyota', N'Fortuner', N'Toyota Fortuner 2023', N'Đen', 950000, N'Dầu diesel', N'Số tự động', 
     7, 7, 2023, 9000, N'30A-90123', N'AVAILABLE', N'Hải Phòng', 
     N'SUV 7 chỗ hạng sang, động cơ diesel 2.8L, dẫn động 2 cầu, mạnh mẽ', 
     N'https://i.ibb.co/toyota-fortuner.jpg', 950000, 
     N'Bảo hiểm toàn diện - Hỗ trợ cứu hộ toàn quốc', GETDATE(), GETDATE()),
    
    -- Xe 10: Honda CR-V
    (N'Honda', N'CR-V', N'Honda CR-V 2023', N'Xám', 850000, N'Xăng', N'Số tự động', 
     7, 7, 2023, 11000, N'30A-01234', N'AVAILABLE', N'Vũng Tàu', 
     N'SUV 7 chỗ thông minh, cảm biến Honda Sensing, tiết kiệm nhiên liệu', 
     N'https://i.ibb.co/honda-crv.jpg', 850000, 
     N'Bảo hiểm toàn diện + Bảo dưỡng miễn phí 1 năm', GETDATE(), GETDATE());

GO

PRINT N'✅ Đã thêm 10 xe với tiếng Việt có dấu chính xác';
GO

-- KIỂM TRA KẾT QUẢ
PRINT N'';
PRINT N'━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';
PRINT N'📊 KIỂM TRA DỮ LIỆU TIẾNG VIỆT';
PRINT N'━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';
PRINT N'';

SELECT 
    id,
    brand AS N'Hãng',
    model AS N'Model',
    name AS N'Tên xe',
    color AS N'Màu',
    fuel_type AS N'Nhiên liệu',
    transmission_type AS N'Hộp số',
    seats AS N'Số ghế',
    FORMAT(daily_rate, 'N0') + N'đ' AS N'Giá thuê',
    location AS N'Địa điểm',
    status AS N'Trạng thái'
FROM cars
ORDER BY id;

GO

PRINT N'';
PRINT N'━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';
PRINT N'✅ HOÀN TẤT!';
PRINT N'━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';
PRINT N'';
PRINT N'🎉 Đã sửa xong lỗi font tiếng Việt!';
PRINT N'📝 Tất cả VARCHAR đã được chuyển sang NVARCHAR';
PRINT N'✅ Dữ liệu tiếng Việt hiển thị chính xác: "Dầu diesel", "Số tự động"';
PRINT N'';
PRINT N'🚀 Test API ngay: http://localhost:8080/api/cars';
PRINT N'';
GO
INSERT INTO car_images (car_id, image_url, description, type, url, created_at)
SELECT id, image_url, CONCAT(name, ' - Main Image'), 'MAIN', image_url, GETDATE()
FROM cars;

PRINT N'✅ Đã thêm ảnh cho các xe';
GO

-- Kiểm tra kết quả
SELECT COUNT(*) AS TotalCars FROM cars;
SELECT COUNT(*) AS TotalImages FROM car_images;
PRINT N'';
PRINT N'📊 Danh sách 5 xe đầu tiên:';
SELECT TOP 5 id, brand, model, name, daily_rate, fuel_type, seat_capacity, year, status FROM cars;
GO

PRINT N'';
PRINT N'✅ HOÀN TẤT! Bạn có thể test API ngay bây giờ.';
GO
