USE drivenow_db;
GO

-- Xóa dữ liệu cũ nếu có
DELETE FROM car_images;
DELETE FROM cars;
GO

-- Thêm dữ liệu xe mẫu (15 xe)
INSERT INTO cars (
    brand, model, name, color, daily_rate, fuel_type, transmission_type, 
    seat_capacity, seats, year, mileage, license_plate, status, location, 
    description, image_url, price_per_day, insurance_info, created_at, updated_at
)
VALUES 
    -- 1. Toyota Vios
    ('Toyota', 'Vios', 'Toyota Vios 2023', N'Trắng', 500000, N'Xăng', N'Số tự động', 
     5, 5, 2023, 15000, '51A-12345', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', 
     N'Xe sedan sang trọng, tiết kiệm nhiên liệu', '../car/car/OIP.webp', 500000, N'Bảo hiểm toàn diện', GETDATE(), GETDATE()),
    
    -- 2. Honda City
    ('Honda', 'City', 'Honda City 2023', N'Đen', 550000, N'Xăng', N'Số tự động', 
     5, 5, 2023, 12000, '51A-23456', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', 
     N'Xe sedan đẳng cấp, tiện nghi hiện đại', '../car/car/OIP.webp', 550000, N'Bảo hiểm vật chất', GETDATE(), GETDATE()),
    
    -- 3. Hyundai Accent
    ('Hyundai', 'Accent', 'Hyundai Accent 2022', N'Bạc', 450000, N'Xăng', N'Số tự động', 
     5, 5, 2022, 25000, '51A-34567', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', 
     N'Xe sedan giá tốt, phù hợp đi phố', '../car/car/OIP.webp', 450000, N'Bảo hiểm cơ bản', GETDATE(), GETDATE()),
    
    -- 4. Mazda CX-5
    ('Mazda', 'CX-5', 'Mazda CX-5 2023', N'Đỏ', 800000, N'Xăng', N'Số tự động', 
     7, 7, 2023, 10000, '51A-45678', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', 
     N'SUV 7 chỗ cao cấp, động cơ mạnh mẽ', '../car/car/OIP.webp', 800000, N'Bảo hiểm toàn diện', GETDATE(), GETDATE()),
    
    -- 5. Ford Everest
    ('Ford', 'Everest', 'Ford Everest 2023', N'Xanh', 900000, N'Dầu diesel', N'Số tự động', 
     7, 7, 2023, 8000, '51A-56789', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', 
     N'SUV 7 chỗ địa hình, mạnh mẽ', '../car/car/OIP.webp', 900000, N'Bảo hiểm toàn diện', GETDATE(), GETDATE()),
    
    -- 6. VinFast VF8
    ('VinFast', 'VF8', 'VinFast VF8 2024', N'Xanh', 1200000, N'Điện', N'Số tự động', 
     5, 5, 2024, 5000, '51A-67890', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', 
     N'SUV điện cao cấp, thân thiện môi trường', '../car/car/OIP.webp', 1200000, N'Bảo hiểm VIP', GETDATE(), GETDATE()),
    
    -- 7. Kia Morning
    ('Kia', 'Morning', 'Kia Morning 2022', N'Vàng', 350000, N'Xăng', N'Số sàn', 
     4, 4, 2022, 30000, '51A-78901', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', 
     N'Xe mini giá rẻ, tiết kiệm', '../car/car/OIP.webp', 350000, N'Bảo hiểm cơ bản', GETDATE(), GETDATE()),
    
    -- 8. Toyota Innova
    ('Toyota', 'Innova', 'Toyota Innova 2023', N'Bạc', 700000, N'Xăng', N'Số tự động', 
     7, 7, 2023, 18000, '51A-89012', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', 
     N'MPV 7 chỗ gia đình, rộng rãi', '../car/car/OIP.webp', 700000, N'Bảo hiểm toàn diện', GETDATE(), GETDATE()),
    
    -- 9. Mitsubishi Xpander
    ('Mitsubishi', 'Xpander', 'Mitsubishi Xpander 2023', N'Trắng', 600000, N'Xăng', N'Số tự động', 
     7, 7, 2023, 14000, '51A-90123', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', 
     N'MPV 7 chỗ tiện dụng', '../car/car/OIP.webp', 600000, N'Bảo hiểm vật chất', GETDATE(), GETDATE()),
    
    -- 10. Ford Ranger
    ('Ford', 'Ranger', 'Ford Ranger 2023', N'Đen', 1000000, N'Dầu diesel', N'Số tự động', 
     5, 5, 2023, 12000, '51A-01234', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', 
     N'Bán tải mạnh mẽ, địa hình', '../car/car/OIP.webp', 1000000, N'Bảo hiểm toàn diện', GETDATE(), GETDATE()),
    
    -- 11. Honda CR-V
    ('Honda', 'CR-V', 'Honda CR-V 2023', N'Trắng', 850000, N'Xăng', N'Số tự động', 
     7, 7, 2023, 9000, '51A-11111', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', 
     N'SUV 7 chỗ sang trọng', '../car/car/OIP.webp', 850000, N'Bảo hiểm toàn diện', GETDATE(), GETDATE()),
    
    -- 12. Mazda CX-8
    ('Mazda', 'CX-8', 'Mazda CX-8 2023', N'Xanh', 950000, N'Dầu diesel', N'Số tự động', 
     7, 7, 2023, 11000, '51A-22222', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', 
     N'SUV 7 chỗ cao cấp nhất', '../car/car/OIP.webp', 950000, N'Bảo hiểm VIP', GETDATE(), GETDATE()),
    
    -- 13. Toyota Camry
    ('Toyota', 'Camry', 'Toyota Camry 2024', N'Đen', 1100000, N'Xăng', N'Số tự động', 
     5, 5, 2024, 5000, '51A-33333', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', 
     N'Sedan hạng sang, cao cấp', '../car/car/OIP.webp', 1100000, N'Bảo hiểm VIP', GETDATE(), GETDATE()),
    
    -- 14. Honda Accord
    ('Honda', 'Accord', 'Honda Accord 2024', N'Bạc', 1050000, N'Xăng', N'Số tự động', 
     5, 5, 2024, 6000, '51A-44444', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', 
     N'Sedan cao cấp, sang trọng', '../car/car/OIP.webp', 1050000, N'Bảo hiểm toàn diện', GETDATE(), GETDATE()),
    
    -- 15. VinFast Lux A2.0
    ('VinFast', 'Lux A2.0', 'VinFast Lux A2.0 2023', N'Đỏ', 800000, N'Xăng', N'Số tự động', 
     5, 5, 2023, 10000, '51A-55555', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', 
     N'Sedan Việt Nam, chất lượng cao', '../car/car/OIP.webp', 800000, N'Bảo hiểm toàn diện', GETDATE(), GETDATE());

PRINT N'✅ Đã thêm 15 xe mẫu vào bảng cars';
GO

-- Thêm ảnh cho các xe
INSERT INTO car_images (car_id, image_url, description, type, url, created_at)
SELECT id, image_url, CONCAT(name, ' - Main Image'), 'MAIN', image_url, GETDATE()
FROM cars;

PRINT N'✅ Đã thêm ảnh cho các xe';
GO

-- Kiểm tra kết quả
PRINT N'';
PRINT N'📊 THỐNG KÊ DỮ LIỆU:';
PRINT N'==================';

SELECT COUNT(*) AS [Tổng số xe] FROM cars;

PRINT N'';
PRINT N'📋 Số xe theo hãng:';
SELECT brand AS [Hãng xe], COUNT(*) AS [Số lượng] 
FROM cars 
GROUP BY brand
ORDER BY COUNT(*) DESC;

PRINT N'';
PRINT N'💰 Khoảng giá:';
SELECT 
    MIN(daily_rate) AS [Giá thấp nhất],
    MAX(daily_rate) AS [Giá cao nhất],
    AVG(daily_rate) AS [Giá trung bình]
FROM cars;

PRINT N'';
PRINT N'🚗 5 xe đầu tiên:';
SELECT TOP 5 id, brand, model, name, daily_rate, seat_capacity, transmission_type, fuel_type
FROM cars
ORDER BY id;

GO

PRINT N'';
PRINT N'✅ HOÀN TẤT! Bạn có thể test API ngay bây giờ!';
GO
