-- =====================================================
-- THÊM 10 XE MẪU VÀO DATABASE (CHỈ INSERT DATA)
-- Chạy file này trong SQL Server Management Studio
-- =====================================================

USE [drivenow_db]
GO

PRINT N'🚗 Đang thêm dữ liệu xe mẫu...';
GO

-- Xóa dữ liệu cũ nếu có (tùy chọn)
-- DELETE FROM [dbo].[car_images];
-- DELETE FROM [dbo].[cars];
-- GO

INSERT INTO [dbo].[cars] (
    brand, model, name, color, daily_rate, 
    fuel_type, transmission_type, seat_capacity, seats, 
    year, mileage, license_plate, status, location, 
    description, image_url, price_per_day, insurance_info, 
    created_at, updated_at
)
VALUES 
    -- 1. Toyota Vios
    (N'Toyota', N'Vios', N'Toyota Vios 2023 - Trắng Ngọc Trai', N'Trắng', 500000, 
     N'Xăng', N'Số tự động', 5, 5, 
     2023, 15000, N'30A-12345', N'AVAILABLE', N'Hà Nội', 
     N'Xe sedan tiết kiệm nhiên liệu, phù hợp đi phố và du lịch gia đình. Xe được bảo dưỡng định kỳ, nội thất sạch sẽ.', 
     N'https://i.ibb.co/toyota-vios.jpg', 500000, N'Bảo hiểm toàn diện - Miễn thường 100%', 
     GETDATE(), GETDATE()),

    -- 2. Honda City
    (N'Honda', N'City', N'Honda City 2023 - Đen Ánh Kim', N'Đen', 550000, 
     N'Xăng', N'Số tự động', 5, 5, 
     2023, 12000, N'30A-23456', N'AVAILABLE', N'Hà Nội', 
     N'Xe sedan cao cấp với tiện nghi hiện đại: màn hình cảm ứng 8 inch, camera lùi, cảm biến áp suất lốp.', 
     N'https://i.ibb.co/honda-city.jpg', 550000, N'Bảo hiểm vật chất xe + Bảo hiểm người ngồi trên xe', 
     GETDATE(), GETDATE()),

    -- 3. Mazda CX-5
    (N'Mazda', N'CX-5', N'Mazda CX-5 2023 - Đỏ Soul', N'Đỏ', 800000, 
     N'Xăng', N'Số tự động', 7, 7, 
     2023, 10000, N'30A-34567', N'AVAILABLE', N'Hồ Chí Minh', 
     N'SUV 7 chỗ cao cấp, động cơ Skyactiv 2.0L mạnh mẽ. Trang bị hệ thống an toàn i-Activsense với 6 túi khí.', 
     N'https://i.ibb.co/mazda-cx5.jpg', 800000, N'Bảo hiểm toàn diện + Hỗ trợ cứu hộ 24/7', 
     GETDATE(), GETDATE()),

    -- 4. Ford Everest
    (N'Ford', N'Everest', N'Ford Everest 2023 Titanium - Xám Bạc', N'Xám', 900000, 
     N'Dầu diesel', N'Số tự động', 7, 7, 
     2023, 8000, N'30A-45678', N'AVAILABLE', N'Hồ Chí Minh', 
     N'SUV 7 chỗ địa hình cao cấp, dẫn động 4 bánh (4WD). Động cơ diesel 2.0L Bi-Turbo, tiết kiệm nhiên liệu trên đường trường.', 
     N'https://i.ibb.co/ford-everest.jpg', 900000, N'Bảo hiểm toàn diện + Cứu hộ 24/7 + Bảo hiểm tai nạn 200 triệu', 
     GETDATE(), GETDATE()),

    -- 5. VinFast VF8
    (N'VinFast', N'VF8', N'VinFast VF8 Eco 2024 - Xanh Ngọc Bích', N'Xanh lá', 1200000, 
     N'Điện', N'Số tự động', 5, 5, 
     2024, 3000, N'30A-56789', N'AVAILABLE', N'Đà Nẵng', 
     N'SUV điện cao cấp 100% pin 87.7kWh, tầm hoạt động 400km. Sạc nhanh 70% trong 31 phút. Không khí thải, thân thiện môi trường.', 
     N'https://i.ibb.co/vinfast-vf8.jpg', 1200000, N'Bảo hiểm VIP - Bảo hành pin 10 năm/160.000km + Bảo hành xe 7 năm', 
     GETDATE(), GETDATE()),

    -- 6. Kia Morning
    (N'Kia', N'Morning', N'Kia Morning 2022 - Vàng Chanh', N'Vàng', 350000, 
     N'Xăng', N'Số sàn', 4, 4, 
     2022, 25000, N'30A-67890', N'AVAILABLE', N'Đà Nẵng', 
     N'Xe mini nhỏ gọn, giá rẻ nhất! Tiết kiệm nhiên liệu chỉ 4L/100km. Phù hợp đi trong thành phố, dễ đỗ xe.', 
     N'https://i.ibb.co/kia-morning.jpg', 350000, N'Bảo hiểm cơ bản - Bảo hiểm bắt buộc xe cơ giới', 
     GETDATE(), GETDATE()),

    -- 7. Mitsubishi Xpander
    (N'Mitsubishi', N'Xpander', N'Mitsubishi Xpander 2023 - Bạc Thạch Anh', N'Bạc', 700000, 
     N'Xăng', N'Số tự động', 7, 7, 
     2023, 18000, N'30A-78901', N'AVAILABLE', N'Cần Thơ', 
     N'MPV 7 chỗ rộng rãi, hàng ghế thứ 3 dành cho người lớn. Phù hợp gia đình đông người, đi du lịch dài ngày.', 
     N'https://i.ibb.co/mitsubishi-xpander.jpg', 700000, N'Bảo hiểm vật chất + Bảo hiểm thân vỏ 80%', 
     GETDATE(), GETDATE()),

    -- 8. Hyundai Accent
    (N'Hyundai', N'Accent', N'Hyundai Accent 2022 - Trắng Kem', N'Trắng', 450000, 
     N'Xăng', N'Số tự động', 5, 5, 
     2022, 22000, N'30A-89012', N'AVAILABLE', N'Nha Trang', 
     N'Xe sedan giá tốt, tiết kiệm xăng. Nội thất hiện đại với màn hình 8 inch, kết nối Apple CarPlay và Android Auto.', 
     N'https://i.ibb.co/hyundai-accent.jpg', 450000, N'Bảo hiểm cơ bản + Bảo hiểm người ngồi trên xe', 
     GETDATE(), GETDATE()),

    -- 9. Toyota Fortuner
    (N'Toyota', N'Fortuner', N'Toyota Fortuner 2023 Legender - Đen Thể Thao', N'Đen', 950000, 
     N'Dầu diesel', N'Số tự động', 7, 7, 
     2023, 9000, N'30A-90123', N'AVAILABLE', N'Hải Phòng', 
     N'SUV 7 chỗ hạng sang, dẫn động 2 cầu số tự động. Động cơ diesel 2.8L mạnh mẽ 204 mã lực, phù hợp địa hình núi non.', 
     N'https://i.ibb.co/toyota-fortuner.jpg', 950000, N'Bảo hiểm toàn diện + Cứu hộ VIP 24/7 + Xe thay thế khi sửa chữa', 
     GETDATE(), GETDATE()),

    -- 10. Honda CR-V
    (N'Honda', N'CR-V', N'Honda CR-V 2023 Sensing - Xám Hiện Đại', N'Xám', 850000, 
     N'Xăng', N'Số tự động', 7, 7, 
     2023, 11000, N'30A-01234', N'AVAILABLE', N'Vũng Tàu', 
     N'SUV 7 chỗ thông minh với Honda Sensing (cảnh báo lệch làn, phanh tự động khẩn cấp, ga tự động thích ứng). Động cơ VTEC Turbo 1.5L.', 
     N'https://i.ibb.co/honda-crv.jpg', 850000, N'Bảo hiểm toàn diện + Bảo hiểm Honda Care + Cứu hộ 24/7', 
     GETDATE(), GETDATE());
GO

PRINT N'✅ Đã thêm 10 xe thành công!';
PRINT N'';
PRINT N'📊 Thống kê:';
SELECT 
    COUNT(*) as [Tổng số xe],
    COUNT(CASE WHEN fuel_type = N'Xăng' THEN 1 END) as [Xe xăng],
    COUNT(CASE WHEN fuel_type = N'Dầu diesel' THEN 1 END) as [Xe diesel],
    COUNT(CASE WHEN fuel_type = N'Điện' THEN 1 END) as [Xe điện],
    COUNT(CASE WHEN transmission_type = N'Số tự động' THEN 1 END) as [Số tự động],
    COUNT(CASE WHEN transmission_type = N'Số sàn' THEN 1 END) as [Số sàn]
FROM [dbo].[cars];
GO

PRINT N'';
PRINT N'🎯 Test API ngay tại: http://localhost:8080/api/cars';
GO
