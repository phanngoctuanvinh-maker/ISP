-- =====================================================
-- SCRIPT ĐƠN GIẢN: DROP VÀ TẠO LẠI BẢNG VỚI NVARCHAR
-- Cách này chắc chắn 100% không bị lỗi constraint
-- =====================================================

USE drivenow_db;
GO

PRINT N'🔧 BẮT ĐẦU TẠO LẠI BẢNG...';
GO

-- DROP bảng cũ theo đúng thứ tự (child trước, parent sau)
-- Bước 1: DROP bảng con (car_images) trước
IF OBJECT_ID('dbo.car_images', 'U') IS NOT NULL
BEGIN
    DROP TABLE dbo.car_images;
    PRINT N'✅ Đã xóa bảng car_images';
END
GO

-- Bước 2: DROP bảng cha (cars) sau
IF OBJECT_ID('dbo.cars', 'U') IS NOT NULL
BEGIN
    DROP TABLE dbo.cars;
    PRINT N'✅ Đã xóa bảng cars';
END
GO

-- TẠO LẠI BẢNG CARS với NVARCHAR
CREATE TABLE cars (
    id BIGINT IDENTITY(1,1) PRIMARY KEY,
    brand NVARCHAR(100),
    model NVARCHAR(100),
    name NVARCHAR(200),
    color NVARCHAR(50),
    daily_rate DECIMAL(10,2),
    fuel_type NVARCHAR(50),
    transmission_type NVARCHAR(50),
    seat_capacity INT,
    seats INT,
    year INT,
    mileage INT,
    license_plate NVARCHAR(20),
    status NVARCHAR(50),
    location NVARCHAR(200),
    description NVARCHAR(MAX),
    image_url NVARCHAR(500),
    price_per_day DECIMAL(10,2),
    insurance_info NVARCHAR(500),
    created_at DATETIME2,
    updated_at DATETIME2
);
GO

PRINT N'✅ Đã tạo bảng cars với NVARCHAR';
GO

-- TẠO LẠI BẢNG CAR_IMAGES
CREATE TABLE car_images (
    car_image_id BIGINT IDENTITY(1,1) PRIMARY KEY,
    car_id BIGINT,
    image_url NVARCHAR(500),
    description NVARCHAR(255),
    type NVARCHAR(50),
    url NVARCHAR(500),
    created_at DATETIME2,
    FOREIGN KEY (car_id) REFERENCES cars(id) ON DELETE CASCADE
);
GO

PRINT N'✅ Đã tạo bảng car_images với NVARCHAR';
GO

-- INSERT DỮ LIỆU
PRINT N'📝 Đang thêm dữ liệu...';
GO

INSERT INTO cars (brand, model, name, color, daily_rate, fuel_type, transmission_type, seat_capacity, seats, year, mileage, license_plate, status, location, description, image_url, price_per_day, insurance_info, created_at, updated_at)
VALUES 
    (N'Toyota', N'Vios', N'Toyota Vios 2023', N'Trắng', 500000, N'Xăng', N'Số tự động', 5, 5, 2023, 15000, N'30A-12345', N'AVAILABLE', N'Hà Nội', N'Xe sedan tiết kiệm nhiên liệu', N'https://i.ibb.co/toyota-vios.jpg', 500000, N'Bảo hiểm toàn diện', GETDATE(), GETDATE()),
    (N'Honda', N'City', N'Honda City 2023', N'Đen', 550000, N'Xăng', N'Số tự động', 5, 5, 2023, 12000, N'30A-23456', N'AVAILABLE', N'Hà Nội', N'Xe sedan cao cấp, tiện nghi hiện đại', N'https://i.ibb.co/honda-city.jpg', 550000, N'Bảo hiểm vật chất xe', GETDATE(), GETDATE()),
    (N'Mazda', N'CX-5', N'Mazda CX-5 2023', N'Đỏ', 800000, N'Xăng', N'Số tự động', 7, 7, 2023, 10000, N'30A-34567', N'AVAILABLE', N'Hồ Chí Minh', N'SUV 7 chỗ cao cấp, động cơ mạnh mẽ', N'https://i.ibb.co/mazda-cx5.jpg', 800000, N'Bảo hiểm toàn diện', GETDATE(), GETDATE()),
    (N'Ford', N'Everest', N'Ford Everest 2023', N'Xám', 900000, N'Dầu diesel', N'Số tự động', 7, 7, 2023, 8000, N'30A-45678', N'AVAILABLE', N'Hồ Chí Minh', N'SUV 7 chỗ địa hình, dẫn động 4 bánh', N'https://i.ibb.co/ford-everest.jpg', 900000, N'Bảo hiểm toàn diện + cứu hộ 24/7', GETDATE(), GETDATE()),
    (N'VinFast', N'VF8', N'VinFast VF8 2024', N'Xanh lá', 1200000, N'Điện', N'Số tự động', 5, 5, 2024, 3000, N'30A-56789', N'AVAILABLE', N'Đà Nẵng', N'SUV điện cao cấp, pin 87.7kWh, tầm 400km', N'https://i.ibb.co/vinfast-vf8.jpg', 1200000, N'Bảo hiểm VIP - Bảo hành pin 10 năm', GETDATE(), GETDATE()),
    (N'Kia', N'Morning', N'Kia Morning 2022', N'Vàng', 350000, N'Xăng', N'Số sàn', 4, 4, 2022, 25000, N'30A-67890', N'AVAILABLE', N'Đà Nẵng', N'Xe mini giá rẻ, tiết kiệm nhiên liệu', N'https://i.ibb.co/kia-morning.jpg', 350000, N'Bảo hiểm cơ bản', GETDATE(), GETDATE()),
    (N'Mitsubishi', N'Xpander', N'Mitsubishi Xpander 2023', N'Bạc', 700000, N'Xăng', N'Số tự động', 7, 7, 2023, 18000, N'30A-78901', N'AVAILABLE', N'Cần Thơ', N'MPV 7 chỗ rộng rãi, phù hợp gia đình', N'https://i.ibb.co/mitsubishi-xpander.jpg', 700000, N'Bảo hiểm vật chất', GETDATE(), GETDATE()),
    (N'Hyundai', N'Accent', N'Hyundai Accent 2022', N'Trắng', 450000, N'Xăng', N'Số tự động', 5, 5, 2022, 22000, N'30A-89012', N'AVAILABLE', N'Nha Trang', N'Xe sedan giá tốt, phù hợp đi làm', N'https://i.ibb.co/hyundai-accent.jpg', 450000, N'Bảo hiểm cơ bản', GETDATE(), GETDATE()),
    (N'Toyota', N'Fortuner', N'Toyota Fortuner 2023', N'Đen', 950000, N'Dầu diesel', N'Số tự động', 7, 7, 2023, 9000, N'30A-90123', N'AVAILABLE', N'Hải Phòng', N'SUV 7 chỗ hạng sang, dẫn động 2 cầu', N'https://i.ibb.co/toyota-fortuner.jpg', 950000, N'Bảo hiểm toàn diện', GETDATE(), GETDATE()),
    (N'Honda', N'CR-V', N'Honda CR-V 2023', N'Xám', 850000, N'Xăng', N'Số tự động', 7, 7, 2023, 11000, N'30A-01234', N'AVAILABLE', N'Vũng Tàu', N'SUV 7 chỗ thông minh, Honda Sensing', N'https://i.ibb.co/honda-crv.jpg', 850000, N'Bảo hiểm toàn diện', GETDATE(), GETDATE());
GO

PRINT N'✅ Đã thêm 10 xe thành công!';
GO

-- KIỂM TRA KẾT QUẢ
PRINT N'';
PRINT N'━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';
PRINT N'📊 DỮ LIỆU TIẾNG VIỆT';
PRINT N'━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';
GO

SELECT 
    id,
    brand AS N'Hãng',
    model AS N'Model',
    fuel_type AS N'Nhiên liệu',
    transmission_type AS N'Hộp số',
    seats AS N'Ghế',
    FORMAT(daily_rate, 'N0') + N'đ' AS N'Giá thuê',
    location AS N'Địa điểm'
FROM cars
ORDER BY id;
GO

PRINT N'';
PRINT N'━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';
PRINT N'✅ HOÀN TẤT!';
PRINT N'━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';
PRINT N'';
PRINT N'🎉 Tất cả đã OK!';
PRINT N'✅ Tiếng Việt hiển thị chính xác: "Dầu diesel", "Số tự động", "Hà Nội"';
PRINT N'';
PRINT N'🚀 Test API ngay: http://localhost:8080/api/cars';
PRINT N'';
GO
