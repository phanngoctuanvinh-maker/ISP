USE drivenow_db;
GO

-- =====================================================
-- THÊM NHANH 10 XE ĐỂ TEST API
-- =====================================================

PRINT N'🚀 Đang thêm xe vào database...';
GO

-- Thêm 10 xe mẫu
INSERT INTO cars (
    brand, model, name, color, daily_rate, fuel_type, transmission_type, 
    seat_capacity, seats, year, mileage, license_plate, status, location, 
    description, image_url, price_per_day, insurance_info, created_at, updated_at
)
VALUES 
    -- 1. Toyota Vios
    ('Toyota', 'Vios', 'Toyota Vios 2023', N'Trắng', 500000, N'Xăng', N'Số tự động', 
     5, 5, 2023, 15000, '30A-12345', 'AVAILABLE', N'Hà Nội', 
     N'Xe sedan tiết kiệm nhiên liệu, phù hợp đi phố', 
     'https://i.ibb.co/123/toyota-vios.jpg', 500000, 
     N'Bảo hiểm toàn diện', GETDATE(), GETDATE()),
    
    -- 2. Honda City
    ('Honda', 'City', 'Honda City 2023', N'Đen', 550000, N'Xăng', N'Số tự động', 
     5, 5, 2023, 12000, '30A-23456', 'AVAILABLE', N'Hà Nội', 
     N'Xe sedan cao cấp, tiện nghi hiện đại', 
     'https://i.ibb.co/456/honda-city.jpg', 550000, 
     N'Bảo hiểm vật chất', GETDATE(), GETDATE()),
    
    -- 3. Mazda CX-5 (7 chỗ)
    ('Mazda', 'CX-5', 'Mazda CX-5 2023', N'Đỏ', 800000, N'Xăng', N'Số tự động', 
     7, 7, 2023, 10000, '30A-34567', 'AVAILABLE', N'Hồ Chí Minh', 
     N'SUV 7 chỗ cao cấp, động cơ mạnh mẽ', 
     'https://i.ibb.co/789/mazda-cx5.jpg', 800000, 
     N'Bảo hiểm toàn diện', GETDATE(), GETDATE()),
    
    -- 4. Ford Everest (7 chỗ)
    ('Ford', 'Everest', 'Ford Everest 2023', N'Xám', 900000, N'Dầu diesel', N'Số tự động', 
     7, 7, 2023, 8000, '30A-45678', 'AVAILABLE', N'Hồ Chí Minh', 
     N'SUV 7 chỗ địa hình, dẫn động 4 bánh', 
     'https://i.ibb.co/abc/ford-everest.jpg', 900000, 
     N'Bảo hiểm toàn diện + cứu hộ 24/7', GETDATE(), GETDATE()),
    
    -- 5. VinFast VF8 (Xe điện)
    ('VinFast', 'VF8', 'VinFast VF8 2024', N'Xanh', 1200000, N'Điện', N'Số tự động', 
     5, 5, 2024, 3000, '30A-56789', 'AVAILABLE', N'Đà Nẵng', 
     N'SUV điện cao cấp, pin 87.7kWh, tầm 400km', 
     'https://i.ibb.co/def/vinfast-vf8.jpg', 1200000, 
     N'Bảo hiểm VIP + bảo hành pin 10 năm', GETDATE(), GETDATE()),
    
    -- 6. Kia Morning (4 chỗ)
    ('Kia', 'Morning', 'Kia Morning 2022', N'Vàng', 350000, N'Xăng', N'Số sàn', 
     4, 4, 2022, 25000, '30A-67890', 'AVAILABLE', N'Đà Nẵng', 
     N'Xe mini giá rẻ, tiết kiệm nhiên liệu', 
     'https://i.ibb.co/ghi/kia-morning.jpg', 350000, 
     N'Bảo hiểm cơ bản', GETDATE(), GETDATE()),
    
    -- 7. Mitsubishi Xpander (7 chỗ)
    ('Mitsubishi', 'Xpander', 'Mitsubishi Xpander 2023', N'Bạc', 700000, N'Xăng', N'Số tự động', 
     7, 7, 2023, 18000, '30A-78901', 'AVAILABLE', N'Cần Thơ', 
     N'MPV 7 chỗ rộng rãi, phù hợp gia đình', 
     'https://i.ibb.co/jkl/mitsubishi-xpander.jpg', 700000, 
     N'Bảo hiểm vật chất', GETDATE(), GETDATE()),
    
    -- 8. Hyundai Accent
    ('Hyundai', 'Accent', 'Hyundai Accent 2022', N'Trắng', 450000, N'Xăng', N'Số tự động', 
     5, 5, 2022, 22000, '30A-89012', 'AVAILABLE', N'Nha Trang', 
     N'Xe sedan giá tốt, phù hợp đi làm', 
     'https://i.ibb.co/mno/hyundai-accent.jpg', 450000, 
     N'Bảo hiểm cơ bản', GETDATE(), GETDATE()),
    
    -- 9. Toyota Fortuner (7 chỗ, Diesel)
    ('Toyota', 'Fortuner', 'Toyota Fortuner 2023', N'Đen', 950000, N'Dầu diesel', N'Số tự động', 
     7, 7, 2023, 9000, '30A-90123', 'AVAILABLE', N'Hải Phòng', 
     N'SUV 7 chỗ hạng sang, dẫn động 2 cầu', 
     'https://i.ibb.co/pqr/toyota-fortuner.jpg', 950000, 
     N'Bảo hiểm toàn diện', GETDATE(), GETDATE()),
    
    -- 10. Honda CR-V (7 chỗ)
    ('Honda', 'CR-V', 'Honda CR-V 2023', N'Xám', 850000, N'Xăng', N'Số tự động', 
     7, 7, 2023, 11000, '30A-01234', 'AVAILABLE', N'Vũng Tàu', 
     N'SUV 7 chỗ thông minh, Honda Sensing', 
     'https://i.ibb.co/stu/honda-crv.jpg', 850000, 
     N'Bảo hiểm toàn diện', GETDATE(), GETDATE());

GO

PRINT N'✅ Đã thêm 10 xe thành công!';
GO

-- Kiểm tra kết quả
PRINT N'';
PRINT N'📊 TỔNG KẾT:';
PRINT N'━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';

DECLARE @totalCars INT = (SELECT COUNT(*) FROM cars);
PRINT N'🚗 Tổng số xe trong database: ' + CAST(@totalCars AS NVARCHAR(10));

PRINT N'';
PRINT N'📋 Phân loại theo hãng:';
SELECT 
    brand AS [Hãng], 
    COUNT(*) AS [Số lượng],
    FORMAT(MIN(daily_rate), 'N0') + 'đ' AS [Giá thấp nhất],
    FORMAT(MAX(daily_rate), 'N0') + 'đ' AS [Giá cao nhất]
FROM cars 
GROUP BY brand
ORDER BY COUNT(*) DESC;

PRINT N'';
PRINT N'🪑 Phân loại theo số ghế:';
SELECT 
    seats AS [Số ghế], 
    COUNT(*) AS [Số xe]
FROM cars 
GROUP BY seats
ORDER BY seats;

PRINT N'';
PRINT N'⚡ Phân loại theo nhiên liệu:';
SELECT 
    fuel_type AS [Loại nhiên liệu], 
    COUNT(*) AS [Số xe]
FROM cars 
GROUP BY fuel_type;

PRINT N'';
PRINT N'💰 Thống kê giá:';
SELECT 
    FORMAT(MIN(daily_rate), 'N0') + 'đ' AS [Giá thấp nhất],
    FORMAT(MAX(daily_rate), 'N0') + 'đ' AS [Giá cao nhất],
    FORMAT(AVG(daily_rate), 'N0') + 'đ' AS [Giá trung bình]
FROM cars;

PRINT N'';
PRINT N'━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';
PRINT N'✅ HOÀN TẤT - SẴN SÀNG TEST API!';
PRINT N'🚀 Test ngay: http://localhost:8080/api/cars';
PRINT N'━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';
GO
