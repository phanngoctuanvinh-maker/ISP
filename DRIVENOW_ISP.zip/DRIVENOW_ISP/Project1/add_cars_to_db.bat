@echo off
chcp 65001 > nul
echo ================================================
echo 🚀 THÊM DỮ LIỆU XE VÀO DATABASE
echo ================================================
echo.

REM Thay đổi thông tin kết nối database của bạn ở đây
set SERVER=localhost
set DATABASE=drivenow_db
set USERNAME=sa
set PASSWORD=your_password

echo 📌 Đang kết nối đến SQL Server...
echo    Server: %SERVER%
echo    Database: %DATABASE%
echo.

REM Chạy SQL script
sqlcmd -S %SERVER% -d %DATABASE% -U %USERNAME% -P %PASSWORD% -i "quick_add_cars.sql"

if %ERRORLEVEL% EQU 0 (
    echo.
    echo ================================================
    echo ✅ THÀNH CÔNG!
    echo ================================================
    echo.
    echo 🎉 Đã thêm 10 xe vào database!
    echo.
    echo 🚀 Bây giờ bạn có thể test API:
    echo    http://localhost:8080/api/cars
    echo.
) else (
    echo.
    echo ================================================
    echo ❌ LỖI!
    echo ================================================
    echo.
    echo 💡 Hãy kiểm tra:
    echo    1. SQL Server đã chạy chưa
    echo    2. Thông tin kết nối đúng chưa
    echo    3. Database drivenow_db đã tạo chưa
    echo.
)

pause
