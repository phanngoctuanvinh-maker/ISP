# 🚀 HƯỚNG DẪN THÊM DỮ LIỆU XE VÀO DATABASE

## 📋 CÓ 3 CÁCH ĐỂ THÊM DỮ LIỆU:

---

## ✅ **CÁCH 1: SỬ DỤNG SQL SERVER MANAGEMENT STUDIO (SSMS) - KHUYÊN DÙNG**

### Bước 1: Mở SSMS
- Mở SQL Server Management Studio
- Kết nối đến server của bạn

### Bước 2: Mở file SQL
1. Nhấn `Ctrl + O` hoặc `File` → `Open` → `File...`
2. Chọn file: `quick_add_cars.sql`
3. Hoặc copy toàn bộ nội dung file `quick_add_cars.sql` và paste vào New Query

### Bước 3: Chọn database
- Trong dropdown phía trên, chọn database: **`drivenow_db`**

### Bước 4: Chạy script
- Nhấn `F5` hoặc nút **Execute**
- Chờ script chạy xong

### Bước 5: Kiểm tra kết quả
```sql
-- Kiểm tra số xe đã thêm
SELECT COUNT(*) AS TotalCars FROM cars;

-- Xem danh sách xe
SELECT id, brand, model, name, daily_rate, seats FROM cars;
```

---

## ✅ **CÁCH 2: SỬ DỤNG POWERSHELL SCRIPT**

### Bước 1: Cấu hình thông tin kết nối
Mở file `add_cars_to_db.ps1` và sửa các thông tin sau:

```powershell
$server = "localhost"          # Tên server SQL của bạn
$database = "drivenow_db"      # Tên database
$username = "sa"               # Username SQL
$password = "your_password"    # Mật khẩu SQL
```

### Bước 2: Chạy PowerShell script
1. Nhấn chuột phải vào file `add_cars_to_db.ps1`
2. Chọn **"Run with PowerShell"**
3. Hoặc mở PowerShell và chạy:
```powershell
cd e:\DriveNowPorject\DRIVENOW_ISP\DRIVENOW_ISP\Project1
.\add_cars_to_db.ps1
```

---

## ✅ **CÁCH 3: SỬ DỤNG BATCH FILE (.bat)**

### Bước 1: Cấu hình thông tin kết nối
Mở file `add_cars_to_db.bat` và sửa các dòng sau:

```batch
set SERVER=localhost
set DATABASE=drivenow_db
set USERNAME=sa
set PASSWORD=your_password
```

### Bước 2: Chạy Batch file
- Double-click vào file `add_cars_to_db.bat`
- Script sẽ tự động chạy và thêm dữ liệu

---

## 📊 **DỮ LIỆU SẼ ĐƯỢC THÊM:**

Script sẽ thêm **10 xe** vào database với thông tin:

| STT | Hãng | Model | Số ghế | Giá/ngày | Nhiên liệu | Hộp số |
|-----|------|-------|--------|----------|------------|--------|
| 1 | Toyota | Vios | 5 | 500,000đ | Xăng | Tự động |
| 2 | Honda | City | 5 | 550,000đ | Xăng | Tự động |
| 3 | Mazda | CX-5 | 7 | 800,000đ | Xăng | Tự động |
| 4 | Ford | Everest | 7 | 900,000đ | Dầu diesel | Tự động |
| 5 | VinFast | VF8 | 5 | 1,200,000đ | Điện | Tự động |
| 6 | Kia | Morning | 4 | 350,000đ | Xăng | Sàn |
| 7 | Mitsubishi | Xpander | 7 | 700,000đ | Xăng | Tự động |
| 8 | Hyundai | Accent | 5 | 450,000đ | Xăng | Tự động |
| 9 | Toyota | Fortuner | 7 | 950,000đ | Dầu diesel | Tự động |
| 10 | Honda | CR-V | 7 | 850,000đ | Xăng | Tự động |

### Đặc điểm:
✅ **Số ghế**: 4, 5, 7 chỗ  
✅ **Giá**: 350,000đ → 1,200,000đ  
✅ **Nhiên liệu**: Xăng, Dầu diesel, Điện  
✅ **Hộp số**: Tự động, Sàn  

---

## 🧪 **TEST API SAU KHI THÊM DỮ LIỆU:**

### 1. Lấy tất cả xe
```
GET http://localhost:8080/api/cars
```

### 2. Tìm kiếm theo hãng
```
GET http://localhost:8080/api/cars/search?brand=Toyota
```

### 3. Lọc theo số ghế
```
GET http://localhost:8080/api/cars/search?seats=7
```

### 4. Lọc theo khoảng giá
```
GET http://localhost:8080/api/cars/search?minPrice=500000&maxPrice=800000
```

### 5. Lọc xe điện
```
GET http://localhost:8080/api/cars/search?fuelType=Điện
```

### 6. Lọc nâng cao (POST)
```
POST http://localhost:8080/api/cars/filter
Content-Type: application/json

{
  "brand": "Toyota",
  "minPrice": 500000,
  "maxPrice": 1000000,
  "minSeatCapacity": 5,
  "maxSeatCapacity": 7
}
```

---

## ❗ **XỬ LÝ LỖI:**

### Lỗi: "Cannot open database 'drivenow_db'"
**Nguyên nhân:** Database chưa được tạo  
**Giải pháp:** Chạy script tạo database trước:
```sql
CREATE DATABASE drivenow_db;
GO
```

### Lỗi: "Login failed for user 'sa'"
**Nguyên nhân:** Username hoặc password sai  
**Giải pháp:** Kiểm tra lại username và password SQL Server

### Lỗi: "sqlcmd is not recognized"
**Nguyên nhân:** Chưa cài đặt SQL Server Command Line Tools  
**Giải pháp:** Sử dụng SSMS (Cách 1) thay vì PowerShell/Batch

### Script chạy nhưng không có dữ liệu
**Nguyên nhân:** Có thể đã chạy script nhiều lần  
**Giải pháp:** Kiểm tra bằng query:
```sql
SELECT COUNT(*) FROM cars;
```

---

## 📝 **LƯU Ý:**

1. ✅ Server backend phải đang chạy ở port `8080`
2. ✅ Database `drivenow_db` phải đã được tạo
3. ✅ Bảng `cars` phải đã được tạo (do JPA tự động tạo khi start server)
4. ✅ Nếu muốn thêm lại dữ liệu, xóa dữ liệu cũ trước:
```sql
DELETE FROM car_images;
DELETE FROM cars;
```

---

## 🎯 **SAU KHI THÊM DỮ LIỆU:**

1. ✅ Mở Postman
2. ✅ Import collection: `DriveNow_Car_Search_API.postman_collection.json`
3. ✅ Test các endpoint trong collection
4. ✅ Xem kết quả trả về từ API

---

## 💡 **MẸO:**

- Sử dụng **CÁCH 1 (SSMS)** nếu bạn chưa quen với command line
- File `quick_add_cars.sql` có thể chỉnh sửa để thêm/bớt xe theo ý muốn
- Có thể chạy script nhiều lần (sẽ thêm thêm xe mới mỗi lần chạy)
- Nếu muốn reset database, xóa toàn bộ dữ liệu rồi chạy lại

---

**Chúc bạn thành công! 🚀**
