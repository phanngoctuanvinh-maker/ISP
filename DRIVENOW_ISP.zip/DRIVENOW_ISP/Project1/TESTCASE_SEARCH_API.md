# 🧪 TESTCASE CHI TIẾT - DriveNow Car Search API
**Base URL**: `http://localhost:8080`  
**Date**: October 19, 2025  
**Total Endpoints**: 12

---

## 📋 **DANH SÁCH TESTCASE**

### **Module 1: Get All Cars**
| TC ID | Endpoint | Method | Description | Expected Result |
|-------|----------|--------|-------------|-----------------|
| TC-001 | `/api/cars` | GET | Lấy toàn bộ danh sách xe | Status 200, trả về array 10 xe |

---

### **Module 2: Basic Search (GET với Query Parameters)**

| TC ID | Endpoint | Method | Description | Query Params | Expected Result |
|-------|----------|--------|-------------|--------------|-----------------|
| TC-002 | `/api/cars/search` | GET | Search tất cả xe | (empty) | Status 200, 10 xe |
| TC-003 | `/api/cars/search` | GET | Filter theo brand Toyota | `?brand=Toyota` | Status 200, 2 xe Toyota (Vios, Fortuner) |
| TC-004 | `/api/cars/search` | GET | Filter theo brand Honda | `?brand=Honda` | Status 200, 2 xe Honda (City, CR-V) |
| TC-005 | `/api/cars/search` | GET | Filter xe điện | `?fuelType=Điện` | Status 200, 1 xe (VinFast VF8) |
| TC-006 | `/api/cars/search` | GET | Filter xe xăng | `?fuelType=Xăng` | Status 200, 7 xe xăng |
| TC-007 | `/api/cars/search` | GET | Filter xe dầu diesel | `?fuelType=Dầu diesel` | Status 200, 2 xe diesel |
| TC-008 | `/api/cars/search` | GET | Filter số tự động | `?transmissionType=Số tự động` | Status 200, 9 xe |
| TC-009 | `/api/cars/search` | GET | Filter số sàn | `?transmissionType=Số sàn` | Status 200, 1 xe (Kia Morning) |
| TC-010 | `/api/cars/search` | GET | Filter 5 chỗ | `?seatCapacity=5` | Status 200, 4 xe 5 chỗ |
| TC-011 | `/api/cars/search` | GET | Filter 7 chỗ | `?seatCapacity=7` | Status 200, 6 xe 7 chỗ |
| TC-012 | `/api/cars/search` | GET | Filter 4 chỗ | `?seatCapacity=4` | Status 200, 1 xe (Kia Morning) |

---

### **Module 3: Price Range Filter**

| TC ID | Endpoint | Method | Description | Query Params | Expected Result |
|-------|----------|--------|-------------|--------------|-----------------|
| TC-013 | `/api/cars/search` | GET | Xe dưới 500k | `?maxPrice=500000` | Status 200, 2 xe (Morning, Accent) |
| TC-014 | `/api/cars/search` | GET | Xe từ 400k-600k | `?minPrice=400000&maxPrice=600000` | Status 200, 3 xe |
| TC-015 | `/api/cars/search` | GET | Xe từ 700k-900k | `?minPrice=700000&maxPrice=900000` | Status 200, 4 xe |
| TC-016 | `/api/cars/search` | GET | Xe trên 1 triệu | `?minPrice=1000000` | Status 200, 1 xe (VinFast VF8) |

---

### **Module 4: Combined Filters**

| TC ID | Endpoint | Method | Description | Query Params | Expected Result |
|-------|----------|--------|-------------|--------------|-----------------|
| TC-017 | `/api/cars/search` | GET | Toyota + Xăng + Tự động | `?brand=Toyota&fuelType=Xăng&transmissionType=Số tự động` | Status 200, 1 xe (Vios) |
| TC-018 | `/api/cars/search` | GET | 7 chỗ + dưới 800k | `?seatCapacity=7&maxPrice=800000` | Status 200, 2 xe |
| TC-019 | `/api/cars/search` | GET | Điện + 5 chỗ | `?fuelType=Điện&seatCapacity=5` | Status 200, 1 xe (VF8) |
| TC-020 | `/api/cars/search` | GET | SUV giá cao | `?brand=Ford&minPrice=800000` | Status 200, 1 xe (Everest) |

---

### **Module 5: Advanced Filter (POST với JSON Body)**

| TC ID | Endpoint | Method | Description | Request Body | Expected Result |
|-------|----------|--------|-------------|--------------|-----------------|
| TC-021 | `/api/cars/filter` | POST | Filter nhiều brands | `{"brands": ["Toyota", "Honda"]}` | Status 200, 4 xe |
| TC-022 | `/api/cars/filter` | POST | Filter price range + fuel | `{"minPrice": 500000, "maxPrice": 900000, "fuelTypes": ["Xăng"]}` | Status 200, 5 xe |
| TC-023 | `/api/cars/filter` | POST | Filter transmission + seats | `{"transmissionTypes": ["Số tự động"], "seatCapacities": [7]}` | Status 200, 5 xe |
| TC-024 | `/api/cars/filter` | POST | Complex filter tất cả | `{"brands": ["Toyota", "Honda"], "minPrice": 400000, "maxPrice": 900000, "fuelTypes": ["Xăng"], "transmissionTypes": ["Số tự động"], "seatCapacities": [5, 7]}` | Status 200, 3-4 xe |
| TC-025 | `/api/cars/filter` | POST | Filter theo năm | `{"minYear": 2023, "maxYear": 2024}` | Status 200, 9 xe |
| TC-026 | `/api/cars/filter` | POST | Empty filter | `{}` | Status 200, 10 xe |

---

### **Module 6: Get Single Car**

| TC ID | Endpoint | Method | Description | Path Param | Expected Result |
|-------|----------|--------|-------------|------------|-----------------|
| TC-027 | `/api/cars/{id}` | GET | Get xe ID 1 | `id=1` | Status 200, thông tin Toyota Vios |
| TC-028 | `/api/cars/{id}` | GET | Get xe ID 5 | `id=5` | Status 200, thông tin VinFast VF8 |
| TC-029 | `/api/cars/{id}` | GET | Get xe không tồn tại | `id=999` | Status 404 |

---

### **Module 7: Get Brands**

| TC ID | Endpoint | Method | Description | Expected Result |
|-------|----------|--------|-------------|-----------------|
| TC-030 | `/api/cars/brands` | GET | Lấy danh sách brands | Status 200, array 8 brands: ["Toyota", "Honda", "Mazda", "Ford", "VinFast", "Kia", "Mitsubishi", "Hyundai"] |

---

### **Module 8: Count By Brand**

| TC ID | Endpoint | Method | Description | Path Param | Expected Result |
|-------|----------|--------|-------------|------------|-----------------|
| TC-031 | `/api/cars/count/{brand}` | GET | Đếm xe Toyota | `brand=Toyota` | Status 200, count: 2 |
| TC-032 | `/api/cars/count/{brand}` | GET | Đếm xe Honda | `brand=Honda` | Status 200, count: 2 |
| TC-033 | `/api/cars/count/{brand}` | GET | Đếm xe VinFast | `brand=VinFast` | Status 200, count: 1 |
| TC-034 | `/api/cars/count/{brand}` | GET | Brand không tồn tại | `brand=BMW` | Status 200, count: 0 |

---

### **Module 9: Pagination**

| TC ID | Endpoint | Method | Description | Query Params | Expected Result |
|-------|----------|--------|-------------|--------------|-----------------|
| TC-035 | `/api/cars/search` | GET | Page 0, size 5 | `?page=0&size=5` | Status 200, 5 xe đầu, totalPages=2 |
| TC-036 | `/api/cars/search` | GET | Page 1, size 5 | `?page=1&size=5` | Status 200, 5 xe tiếp theo |
| TC-037 | `/api/cars/search` | GET | Page 0, size 20 | `?page=0&size=20` | Status 200, tất cả 10 xe |

---

### **Module 10: Sorting**

| TC ID | Endpoint | Method | Description | Query Params | Expected Result |
|-------|----------|--------|-------------|--------------|-----------------|
| TC-038 | `/api/cars/search` | GET | Sort by price ASC | `?sortBy=pricePerDay&sortOrder=asc` | Status 200, xe rẻ nhất đầu tiên (Morning 350k) |
| TC-039 | `/api/cars/search` | GET | Sort by price DESC | `?sortBy=pricePerDay&sortOrder=desc` | Status 200, xe đắt nhất đầu tiên (VF8 1.2M) |
| TC-040 | `/api/cars/search` | GET | Sort by year DESC | `?sortBy=year&sortOrder=desc` | Status 200, xe mới nhất đầu tiên (2024) |

---

## 🎯 **EXPECTED DATA SUMMARY**

Sau khi chạy SQL, database có:
- **Tổng số xe**: 10
- **Brands**: Toyota (2), Honda (2), Mazda (1), Ford (1), VinFast (1), Kia (1), Mitsubishi (1), Hyundai (1)
- **Fuel Types**: Xăng (7), Dầu diesel (2), Điện (1)
- **Transmission**: Số tự động (9), Số sàn (1)
- **Seats**: 4 chỗ (1), 5 chỗ (4), 7 chỗ (5)
- **Price Range**: 350k - 1.2M VND

---

## 📝 **SAMPLE REQUESTS**

### **1. Get All Cars**
```http
GET http://localhost:8080/api/cars
```

### **2. Search Toyota**
```http
GET http://localhost:8080/api/cars/search?brand=Toyota
```

### **3. Filter Electric Cars**
```http
GET http://localhost:8080/api/cars/search?fuelType=Điện
```

### **4. Advanced Filter (POST)**
```http
POST http://localhost:8080/api/cars/filter
Content-Type: application/json

{
  "brands": ["Toyota", "Honda"],
  "minPrice": 400000,
  "maxPrice": 800000,
  "fuelTypes": ["Xăng"],
  "transmissionTypes": ["Số tự động"],
  "seatCapacities": [5, 7]
}
```

### **5. Get Car By ID**
```http
GET http://localhost:8080/api/cars/1
```

### **6. Get All Brands**
```http
GET http://localhost:8080/api/cars/brands
```

### **7. Count Toyota**
```http
GET http://localhost:8080/api/cars/count/Toyota
```

---

## ✅ **PASS CRITERIA**

Mỗi testcase PASS khi:
- ✅ HTTP Status Code = 200 (hoặc 404 cho TC-029)
- ✅ Response format đúng JSON
- ✅ Số lượng kết quả đúng như expected
- ✅ Dữ liệu trả về có đầy đủ fields: id, brand, model, name, color, dailyRate, fuelType, transmissionType, seatCapacity, year, status, location, description
- ✅ Response time < 500ms
- ✅ Không có SQL error hoặc exception

---

## 🚨 **FAIL SCENARIOS**

| Scenario | Expected Behavior |
|----------|-------------------|
| Server chưa chạy | ECONNREFUSED |
| Database chưa có dữ liệu | Status 200, data: [] |
| Invalid car ID | Status 404 |
| Invalid query params | Status 200, bỏ qua params lỗi |
| Malformed JSON body | Status 400 |

---

## 📊 **TEST EXECUTION CHECKLIST**

- [ ] 1. Chạy file `insert_test_cars.sql` trong SQL Server Management Studio
- [ ] 2. Verify database có đủ 10 xe: `SELECT COUNT(*) FROM cars;`
- [ ] 3. Khởi động Spring Boot server: Port 8080
- [ ] 4. Import Postman collection: `DriveNow_Car_Search_API.postman_collection.json`
- [ ] 5. Run toàn bộ collection hoặc test từng request
- [ ] 6. Check response format, status code, data accuracy
- [ ] 7. Test edge cases: empty results, invalid IDs, boundary values
- [ ] 8. Performance test: Response time < 500ms

---

## 🎓 **TEST REPORT TEMPLATE**

| TC ID | Status | Response Time | Notes |
|-------|--------|---------------|-------|
| TC-001 | ✅ PASS | 234ms | 10 cars returned |
| TC-002 | ✅ PASS | 189ms | All cars |
| TC-003 | ✅ PASS | 156ms | 2 Toyota cars |
| ... | ... | ... | ... |

**Total**: 40 testcases  
**Pass**: __  
**Fail**: __  
**Pass Rate**: __%

---

**🎯 Mục tiêu**: 100% testcases PASS! 🚀
