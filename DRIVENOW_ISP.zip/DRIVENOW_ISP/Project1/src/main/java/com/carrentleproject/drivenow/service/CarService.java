package com.carrentleproject.drivenow.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.carrentleproject.drivenow.dao.CarDAO;
import com.carrentleproject.drivenow.dto.CarResponseDTO;
import com.carrentleproject.drivenow.dto.CarSearchRequest;
import com.carrentleproject.drivenow.model.Car;
import com.carrentleproject.drivenow.model.CarImage;

@Service
@Transactional
public class CarService {
    
    @Autowired
    private CarDAO carDAO;
    
    /**
     * Tìm kiếm xe với các bộ lọc
     */
    public Map<String, Object> searchCars(CarSearchRequest request) {
        Page<Car> carPage = carDAO.searchCars(request);
        
        List<CarResponseDTO> carDTOs = carPage.getContent().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
        
        Map<String, Object> response = new HashMap<>();
        response.put("cars", carDTOs);
        response.put("currentPage", carPage.getNumber());
        response.put("totalItems", carPage.getTotalElements());
        response.put("totalPages", carPage.getTotalPages());
        
        return response;
    }
    
    /**
     * Lấy chi tiết xe theo ID
     */
    public CarResponseDTO getCarById(Long id) {
        Car car = carDAO.findById(id);
        if (car == null) {
            throw new RuntimeException("Không tìm thấy xe với ID: " + id);
        }
        return convertToDTO(car);
    }
    
    /**
     * Lấy tất cả xe
     */
    public List<CarResponseDTO> getAllCars() {
        List<Car> cars = carDAO.findAll();
        return cars.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }
    
    /**
     * Tạo xe mới
     */
    public CarResponseDTO createCar(Car car) {
        Car savedCar = carDAO.save(car);
        return convertToDTO(savedCar);
    }
    
    /**
     * Cập nhật xe
     */
    public CarResponseDTO updateCar(Long id, Car carDetails) {
        Car car = carDAO.findById(id);
        if (car == null) {
            throw new RuntimeException("Không tìm thấy xe với ID: " + id);
        }
        
        // Update fields
        car.setBrand(carDetails.getBrand());
        car.setModel(carDetails.getModel());
        car.setName(carDetails.getName());
        car.setColor(carDetails.getColor());
        car.setDailyRate(carDetails.getDailyRate());
        car.setFuelType(carDetails.getFuelType());
        car.setTransmissionType(carDetails.getTransmissionType());
        car.setSeatCapacity(carDetails.getSeatCapacity());
        car.setSeats(carDetails.getSeats());
        car.setYear(carDetails.getYear());
        car.setMileage(carDetails.getMileage());
        car.setLicensePlate(carDetails.getLicensePlate());
        car.setStatus(carDetails.getStatus());
        car.setLocation(carDetails.getLocation());
        car.setDescription(carDetails.getDescription());
        car.setImageUrl(carDetails.getImageUrl());
        car.setPricePerDay(carDetails.getPricePerDay());
        car.setInsuranceInfo(carDetails.getInsuranceInfo());
        
        Car updatedCar = carDAO.update(car);
        return convertToDTO(updatedCar);
    }
    
    /**
     * Xóa xe
     */
    public void deleteCar(Long id) {
        carDAO.delete(id);
    }
    
    /**
     * Lấy tất cả brand
     */
    public List<String> getAllBrands() {
        return carDAO.getAllBrands();
    }
    
    /**
     * Đếm số xe theo brand
     */
    public Long countByBrand(String brand) {
        return carDAO.countByBrand(brand);
    }
    
    /**
     * Convert Car entity to CarResponseDTO
     */
    private CarResponseDTO convertToDTO(Car car) {
        CarResponseDTO dto = new CarResponseDTO();
        dto.setId(car.getId());
        dto.setBrand(car.getBrand());
        dto.setModel(car.getModel());
        dto.setName(car.getName());
        dto.setColor(car.getColor());
        dto.setDailyRate(car.getDailyRate());
        dto.setFuelType(car.getFuelType());
        dto.setTransmissionType(car.getTransmissionType());
        dto.setSeatCapacity(car.getSeatCapacity());
        dto.setSeats(car.getSeats());
        dto.setYear(car.getYear());
        dto.setMileage(car.getMileage());
        dto.setLicensePlate(car.getLicensePlate());
        dto.setStatus(car.getStatus());
        dto.setLocation(car.getLocation());
        dto.setDescription(car.getDescription());
        dto.setImageUrl(car.getImageUrl());
        dto.setPricePerDay(car.getPricePerDay());
        dto.setInsuranceInfo(car.getInsuranceInfo());
        
        // Get all images
        if (car.getCarImages() != null) {
            List<String> imageUrls = car.getCarImages().stream()
                    .map(CarImage::getImageUrl)
                    .collect(Collectors.toList());
            dto.setImageUrls(imageUrls);
        }
        
        return dto;
    }
}
