package com.carrentleproject.drivenow.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import com.carrentleproject.drivenow.dto.CarSearchRequest;
import com.carrentleproject.drivenow.model.Car;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Order;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;

@Repository
public class CarDAO {
    
    @PersistenceContext
    private EntityManager entityManager;
    
    /**
     * Tìm kiếm và lọc xe theo nhiều tiêu chí
     */
    public Page<Car> searchCars(CarSearchRequest request) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Car> query = cb.createQuery(Car.class);
        Root<Car> car = query.from(Car.class);
        
        List<Predicate> predicates = new ArrayList<>();
        
        // Filter by location
        if (request.getLocation() != null && !request.getLocation().isEmpty()) {
            predicates.add(cb.like(cb.lower(car.get("location")), "%" + request.getLocation().toLowerCase() + "%"));
        }
        
        // Filter by brand
        if (request.getBrand() != null && !request.getBrand().isEmpty()) {
            predicates.add(cb.equal(cb.lower(car.get("brand")), request.getBrand().toLowerCase()));
        }
        
        // Filter by transmission
        if (request.getTransmission() != null && !request.getTransmission().isEmpty() 
                && !request.getTransmission().equalsIgnoreCase("Tất cả")) {
            predicates.add(cb.equal(car.get("transmissionType"), request.getTransmission()));
        }
        
        // Filter by fuel type
        if (request.getFuelType() != null && !request.getFuelType().isEmpty()
                && !request.getFuelType().equalsIgnoreCase("Tất cả")) {
            predicates.add(cb.equal(car.get("fuelType"), request.getFuelType()));
        }
        
        // Filter by seat capacity range (Advanced filter)
        if (request.getMinSeatCapacity() != null) {
            predicates.add(cb.greaterThanOrEqualTo(car.get("seatCapacity"), request.getMinSeatCapacity()));
        }
        if (request.getMaxSeatCapacity() != null) {
            predicates.add(cb.lessThanOrEqualTo(car.get("seatCapacity"), request.getMaxSeatCapacity()));
        }
        
        // Filter by price range (Advanced filter)
        if (request.getMinPrice() != null) {
            predicates.add(cb.greaterThanOrEqualTo(car.get("dailyRate"), request.getMinPrice()));
        }
        if (request.getMaxPrice() != null) {
            predicates.add(cb.lessThanOrEqualTo(car.get("dailyRate"), request.getMaxPrice()));
        }
        
        // Filter by year
        if (request.getMinYear() != null) {
            predicates.add(cb.greaterThanOrEqualTo(car.get("year"), request.getMinYear()));
        }
        if (request.getMaxYear() != null) {
            predicates.add(cb.lessThanOrEqualTo(car.get("year"), request.getMaxYear()));
        }
        
        // Only show available cars
        predicates.add(cb.equal(car.get("status"), "AVAILABLE"));
        
        // Combine all predicates
        // ✅ Fix: Suppress warning - toArray(new T[0]) is actually optimal in modern Java
        //noinspection ToArrayCallWithZeroLengthArrayArgument
        query.where(cb.and(predicates.toArray(new Predicate[0])));
        
        // Sorting
        if (request.getSortBy() != null && !request.getSortBy().isEmpty()) {
            Order order;
            if ("desc".equalsIgnoreCase(request.getSortOrder())) {
                order = cb.desc(car.get(request.getSortBy()));
            } else {
                order = cb.asc(car.get(request.getSortBy()));
            }
            query.orderBy(order);
        } else {
            // Default sorting by daily rate ascending
            query.orderBy(cb.asc(car.get("dailyRate")));
        }
        
        // Execute query
        TypedQuery<Car> typedQuery = entityManager.createQuery(query);
        
        // Pagination
        // ✅ Fix: Sử dụng auto-unboxing an toàn với kiểm tra null trước
        Integer pageValue = request.getPage();
        Integer sizeValue = request.getSize();
        int page = (pageValue != null) ? pageValue : 0;
        int size = (sizeValue != null) ? sizeValue : 12;
        Pageable pageable = PageRequest.of(page, size);
        
        int totalRows = typedQuery.getResultList().size();
        typedQuery.setFirstResult(page * size);
        typedQuery.setMaxResults(size);
        
        List<Car> cars = typedQuery.getResultList();
        
        return new PageImpl<>(cars, pageable, totalRows);
    }
    
    /**
     * Tìm xe theo ID
     */
    public Car findById(Long id) {
        return entityManager.find(Car.class, id);
    }
    
    /**
     * Lấy tất cả xe
     */
    public List<Car> findAll() {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Car> query = cb.createQuery(Car.class);
        Root<Car> car = query.from(Car.class);
        query.select(car);
        return entityManager.createQuery(query).getResultList();
    }
    
    /**
     * Lưu xe mới
     */
    public Car save(Car car) {
        entityManager.persist(car);
        return car;
    }
    
    /**
     * Cập nhật xe
     */
    public Car update(Car car) {
        return entityManager.merge(car);
    }
    
    /**
     * Xóa xe
     */
    public void delete(Long id) {
        Car car = findById(id);
        if (car != null) {
            entityManager.remove(car);
        }
    }
    
    /**
     * Lấy tất cả brand không trùng lặp
     */
    public List<String> getAllBrands() {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<String> query = cb.createQuery(String.class);
        Root<Car> car = query.from(Car.class);
        query.select(car.get("brand")).distinct(true);
        return entityManager.createQuery(query).getResultList();
    }
    
    /**
     * Đếm số xe theo brand
     */
    public Long countByBrand(String brand) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Long> query = cb.createQuery(Long.class);
        Root<Car> car = query.from(Car.class);
        query.select(cb.count(car));
        query.where(cb.equal(cb.lower(car.get("brand")), brand.toLowerCase()));
        return entityManager.createQuery(query).getSingleResult();
    }
}
