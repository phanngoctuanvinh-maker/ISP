
package com.carrentleproject.drivenow.controller;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.carrentleproject.drivenow.dto.CarResponseDTO;
import com.carrentleproject.drivenow.dto.CarSearchRequest;
import com.carrentleproject.drivenow.service.CarService;

@RestController
@RequestMapping("/api/cars")
public class SearchController {

    @Autowired
    private CarService carService;

    /**
     * API tìm kiếm xe với các bộ lọc
     * GET /api/cars/search
     */
    @GetMapping("/search")
    public ResponseEntity<Map<String, Object>> searchCars(
            @RequestParam(required = false) String location,
            @RequestParam(required = false) String startTime,
            @RequestParam(required = false) String endTime,
            @RequestParam(required = false) String carType,
            @RequestParam(required = false) String brand,
            @RequestParam(required = false) String transmission,
            @RequestParam(required = false) String fuelType,
            @RequestParam(required = false) Integer seatCapacity,
            @RequestParam(required = false) BigDecimal minPrice,
            @RequestParam(required = false) BigDecimal maxPrice,
            @RequestParam(required = false) Integer minMileage,
            @RequestParam(required = false) Integer maxMileage,
            @RequestParam(required = false) Integer minYear,
            @RequestParam(required = false) Integer maxYear,
            @RequestParam(required = false) String sortBy,
            @RequestParam(required = false) String sortOrder,
            @RequestParam(defaultValue = "0") Integer page,
            @RequestParam(defaultValue = "12") Integer size) {
        try {
            CarSearchRequest request = new CarSearchRequest();
            request.setLocation(location);
            request.setStartTime(startTime);
            request.setEndTime(endTime);
            request.setCarType(carType);
            request.setBrand(brand);
            request.setTransmission(transmission);
            request.setFuelType(fuelType);
            // ✅ Fix: Sử dụng minSeatCapacity/maxSeatCapacity thay vì setSeatCapacity
            if (seatCapacity != null) {
                request.setMinSeatCapacity(seatCapacity);
                request.setMaxSeatCapacity(seatCapacity);
            }
            request.setMinPrice(minPrice);
            request.setMaxPrice(maxPrice);
            // ✅ Fix: Bỏ minMileage/maxMileage vì CarSearchRequest không có fields này
            // Nếu cần filter theo mileage, phải thêm vào CarSearchRequest và CarDAO
            request.setMinYear(minYear);
            request.setMaxYear(maxYear);
            request.setSortBy(sortBy);
            request.setSortOrder(sortOrder);
            request.setPage(page);
            request.setSize(size);

            Map<String, Object> response = carService.searchCars(request);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Lỗi khi tìm kiếm xe: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }

    /**
     * API lọc xe theo loại (POST với body)
     * POST /api/cars/filter
     */
    @PostMapping("/filter")
    public ResponseEntity<Map<String, Object>> filterCars(@RequestBody CarSearchRequest request) {
        try {
            Map<String, Object> response = carService.searchCars(request);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Lỗi khi lọc xe: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }

    /**
     * API lấy chi tiết xe theo ID
     * GET /api/cars/{id}
     */
    @GetMapping("/{id}")
    public ResponseEntity<Map<String, Object>> getCarById(@PathVariable Long id) {
        try {
            CarResponseDTO car = carService.getCarById(id);
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", car);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Không tìm thấy xe: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
        }
    }

    /**
     * API lấy tất cả xe
     * GET /api/cars
     */
    @GetMapping
    public ResponseEntity<Map<String, Object>> getAllCars() {
        try {
            List<CarResponseDTO> cars = carService.getAllCars();
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", cars);
            response.put("total", cars.size());
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Lỗi khi lấy danh sách xe: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }

    /**
     * API lấy danh sách hãng xe
     * GET /api/cars/brands
     */
    @GetMapping("/brands")
    public ResponseEntity<Map<String, Object>> getAllBrands() {
        try {
            List<String> brands = carService.getAllBrands();
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", brands);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Lỗi khi lấy danh sách hãng: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }

    /**
     * API đếm số xe theo hãng
     * GET /api/cars/count/{brand}
     */
    @GetMapping("/count/{brand}")
    public ResponseEntity<Map<String, Object>> countByBrand(@PathVariable String brand) {
        try {
            Long count = carService.countByBrand(brand);
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("brand", brand);
            response.put("count", count);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Lỗi khi đếm xe: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }
}
