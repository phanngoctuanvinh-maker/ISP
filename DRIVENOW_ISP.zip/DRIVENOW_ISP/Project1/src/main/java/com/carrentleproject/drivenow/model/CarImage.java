package com.carrentleproject.drivenow.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "car_images")
public class CarImage {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "car_image_id")
    private Long carImageId;
    
    @Column(name = "car_id")
    private Long carId;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "car_id", insertable = false, updatable = false)
    private Car car;
    
    @Column(name = "image_url", length = 500, columnDefinition = "NVARCHAR(500)")
    private String imageUrl;
    
    @Column(name = "description", length = 255, columnDefinition = "NVARCHAR(255)")
    private String description;
    
    @Column(name = "type", length = 50, columnDefinition = "NVARCHAR(50)")
    private String type; // MAIN, INTERIOR, EXTERIOR, etc.
    
    @Column(name = "url", length = 500, columnDefinition = "NVARCHAR(500)")
    private String url;
    
    @Column(name = "created_at")
    private LocalDateTime createdAt;
    
    // Constructors
    public CarImage() {
        this.createdAt = LocalDateTime.now();
    }
    
    public CarImage(Long carId, String imageUrl) {
        this();
        this.carId = carId;
        this.imageUrl = imageUrl;
    }
    
    // Getters and Setters
    public Long getCarImageId() {
        return carImageId;
    }
    
    public void setCarImageId(Long carImageId) {
        this.carImageId = carImageId;
    }
    
    public Long getCarId() {
        return carId;
    }
    
    public void setCarId(Long carId) {
        this.carId = carId;
    }
    
    public Car getCar() {
        return car;
    }
    
    public void setCar(Car car) {
        this.car = car;
    }
    
    public String getImageUrl() {
        return imageUrl;
    }
    
    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public String getType() {
        return type;
    }
    
    public void setType(String type) {
        this.type = type;
    }
    
    public String getUrl() {
        return url;
    }
    
    public void setUrl(String url) {
        this.url = url;
    }
    
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
