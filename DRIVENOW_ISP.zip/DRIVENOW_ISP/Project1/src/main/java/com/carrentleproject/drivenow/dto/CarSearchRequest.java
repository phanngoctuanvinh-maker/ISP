package com.carrentleproject.drivenow.dto;

import java.math.BigDecimal;

public class CarSearchRequest {
    
    private String location;
    private String startTime;
    private String endTime;
    
    // Basic filter (Bộ lọc bên ngoài - Filter tabs)
    private String carType; // mini, sedan, suv-5, suv-7, mpv, pickup, minivan
    private String brand; // toyota, hyundai, kia, vinfast, mitsubishi, mazda, ford, honda
    private String transmission; // Tất cả, Số tự động, Số sàn
    private String fuelType; // Tất cả, Xăng, Dầu diesel, Điện, Xăng & điện
    private Boolean electricOnly; // Xe Điện
    private Boolean hybridOnly; // Xe Xăng & Điện
    
    // Advanced filter (Bộ lọc nâng cao - Modal)
    private String sortBy; // Sắp xếp: Tối ưu, Mới nhất
    private BigDecimal minPrice; // Mức giá min
    private BigDecimal maxPrice; // Mức giá max
    private Integer minDistance; // Khoảng cách min (km)
    private Integer maxDistance; // Khoảng cách max (km)
    private Integer minSeatCapacity; // Số chỗ min
    private Integer maxSeatCapacity; // Số chỗ max
    private Integer minYear; // Năm sản xuất min
    private Integer maxYear; // Năm sản xuất max
    private BigDecimal minDeliveryFee; // Phí đưa đón min
    private BigDecimal maxDeliveryFee; // Phí đưa đón max
    private BigDecimal minFuelConsumption; // Mức tiêu thụ nhiên liệu min
    private BigDecimal maxFuelConsumption; // Mức tiêu thụ nhiên liệu max
    
    // Features (Tính năng)
    private Boolean hasMap; // Bản đồ
    private Boolean hasBluetooth; // Bluetooth
    private Boolean hasCamera360; // Camera 360
    
    // Sorting (Sắp xếp)
    private String sortOrder; // asc, desc
    
    // Pagination
    private Integer page = 0;
    private Integer size = 12;
    
    // Constructors
    public CarSearchRequest() {
    }
    
    // Getters and Setters
    public String getLocation() {
        return location;
    }
    
    public void setLocation(String location) {
        this.location = location;
    }
    
    public String getStartTime() {
        return startTime;
    }
    
    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }
    
    public String getEndTime() {
        return endTime;
    }
    
    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }
    
    public String getCarType() {
        return carType;
    }
    
    public void setCarType(String carType) {
        this.carType = carType;
    }
    
    public String getBrand() {
        return brand;
    }
    
    public void setBrand(String brand) {
        this.brand = brand;
    }
    
    public String getTransmission() {
        return transmission;
    }
    
    public void setTransmission(String transmission) {
        this.transmission = transmission;
    }
    
    public String getFuelType() {
        return fuelType;
    }
    
    public void setFuelType(String fuelType) {
        this.fuelType = fuelType;
    }
    
    public Boolean getElectricOnly() {
        return electricOnly;
    }
    
    public void setElectricOnly(Boolean electricOnly) {
        this.electricOnly = electricOnly;
    }
    
    public Boolean getHybridOnly() {
        return hybridOnly;
    }
    
    public void setHybridOnly(Boolean hybridOnly) {
        this.hybridOnly = hybridOnly;
    }
    
    public Integer getMinDistance() {
        return minDistance;
    }
    
    public void setMinDistance(Integer minDistance) {
        this.minDistance = minDistance;
    }
    
    public Integer getMaxDistance() {
        return maxDistance;
    }
    
    public void setMaxDistance(Integer maxDistance) {
        this.maxDistance = maxDistance;
    }
    
    public Integer getMinSeatCapacity() {
        return minSeatCapacity;
    }
    
    public void setMinSeatCapacity(Integer minSeatCapacity) {
        this.minSeatCapacity = minSeatCapacity;
    }
    
    public Integer getMaxSeatCapacity() {
        return maxSeatCapacity;
    }
    
    public void setMaxSeatCapacity(Integer maxSeatCapacity) {
        this.maxSeatCapacity = maxSeatCapacity;
    }
    
    public BigDecimal getMinDeliveryFee() {
        return minDeliveryFee;
    }
    
    public void setMinDeliveryFee(BigDecimal minDeliveryFee) {
        this.minDeliveryFee = minDeliveryFee;
    }
    
    public BigDecimal getMaxDeliveryFee() {
        return maxDeliveryFee;
    }
    
    public void setMaxDeliveryFee(BigDecimal maxDeliveryFee) {
        this.maxDeliveryFee = maxDeliveryFee;
    }
    
    public BigDecimal getMinPrice() {
        return minPrice;
    }
    
    public void setMinPrice(BigDecimal minPrice) {
        this.minPrice = minPrice;
    }
    
    public BigDecimal getMaxPrice() {
        return maxPrice;
    }
    
    public void setMaxPrice(BigDecimal maxPrice) {
        this.maxPrice = maxPrice;
    }
    

    
    public Integer getMinYear() {
        return minYear;
    }
    
    public void setMinYear(Integer minYear) {
        this.minYear = minYear;
    }
    
    public Integer getMaxYear() {
        return maxYear;
    }
    
    public void setMaxYear(Integer maxYear) {
        this.maxYear = maxYear;
    }
    
    public BigDecimal getMinFuelConsumption() {
        return minFuelConsumption;
    }
    
    public void setMinFuelConsumption(BigDecimal minFuelConsumption) {
        this.minFuelConsumption = minFuelConsumption;
    }
    
    public BigDecimal getMaxFuelConsumption() {
        return maxFuelConsumption;
    }
    
    public void setMaxFuelConsumption(BigDecimal maxFuelConsumption) {
        this.maxFuelConsumption = maxFuelConsumption;
    }
    

    
    public Boolean getHasMap() {
        return hasMap;
    }
    
    public void setHasMap(Boolean hasMap) {
        this.hasMap = hasMap;
    }
    
    public Boolean getHasBluetooth() {
        return hasBluetooth;
    }
    
    public void setHasBluetooth(Boolean hasBluetooth) {
        this.hasBluetooth = hasBluetooth;
    }
    
    public Boolean getHasCamera360() {
        return hasCamera360;
    }
    
    public void setHasCamera360(Boolean hasCamera360) {
        this.hasCamera360 = hasCamera360;
    }
    
    public String getSortBy() {
        return sortBy;
    }
    
    public void setSortBy(String sortBy) {
        this.sortBy = sortBy;
    }
    
    public String getSortOrder() {
        return sortOrder;
    }
    
    public void setSortOrder(String sortOrder) {
        this.sortOrder = sortOrder;
    }
    
    public Integer getPage() {
        return page;
    }
    
    public void setPage(Integer page) {
        this.page = page;
    }
    
    public Integer getSize() {
        return size;
    }
    
    public void setSize(Integer size) {
        this.size = size;
    }
}
