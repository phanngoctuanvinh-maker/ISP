package com.carrentleproject.drivenow.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;

@Entity
@Table(name = "cars")
public class Car {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "brand", length = 100, columnDefinition = "NVARCHAR(100)")
    private String brand;
    
    @Column(name = "model", length = 100, columnDefinition = "NVARCHAR(100)")
    private String model;
    
    @Column(name = "name", length = 200, columnDefinition = "NVARCHAR(200)")
    private String name;
    
    @Column(name = "color", length = 50, columnDefinition = "NVARCHAR(50)")
    private String color;
    
    @Column(name = "daily_rate", precision = 10, scale = 2)
    private BigDecimal dailyRate;
    
    @Column(name = "fuel_type", length = 50, columnDefinition = "NVARCHAR(50)")
    private String fuelType; // Xăng, Dầu diesel, Điện, Xăng & điện
    
    @Column(name = "transmission_type", length = 50, columnDefinition = "NVARCHAR(50)")
    private String transmissionType; // Số tự động, Số sàn
    
    @Column(name = "seat_capacity")
    private Integer seatCapacity; // 4, 5, 7, 16 chỗ
    
    @Column(name = "seats")
    private Integer seats; // Trường bổ sung số ghế
    
    @Column(name = "year")
    private Integer year;
    
    @Column(name = "mileage")
    private Integer mileage; // Số km đã đi
    
    @Column(name = "license_plate", length = 20, columnDefinition = "NVARCHAR(20)")
    private String licensePlate;
    
    @Column(name = "status", length = 50, columnDefinition = "NVARCHAR(50)")
    private String status; // AVAILABLE, RENTED, MAINTENANCE
    
    @Column(name = "location", length = 200, columnDefinition = "NVARCHAR(200)")
    private String location;
    
    @Column(name = "description", columnDefinition = "NVARCHAR(MAX)")
    private String description;
    
    @Column(name = "image_url", length = 500, columnDefinition = "NVARCHAR(500)")
    private String imageUrl; // Ảnh chính
    
    @Column(name = "price_per_day", precision = 10, scale = 2)
    private BigDecimal pricePerDay;
    
    @Column(name = "insurance_info", length = 500, columnDefinition = "NVARCHAR(500)")
    private String insuranceInfo;
    
    @Column(name = "created_at")
    private LocalDateTime createdAt;
    
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    
    @OneToMany(mappedBy = "car", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<CarImage> carImages;
    
    // Constructors
    public Car() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }
    
    public Car(String brand, String model, String name, BigDecimal dailyRate) {
        this();
        this.brand = brand;
        this.model = model;
        this.name = name;
        this.dailyRate = dailyRate;
    }
    
    // Getters and Setters
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public String getBrand() {
        return brand;
    }
    
    public void setBrand(String brand) {
        this.brand = brand;
    }
    
    public String getModel() {
        return model;
    }
    
    public void setModel(String model) {
        this.model = model;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getColor() {
        return color;
    }
    
    public void setColor(String color) {
        this.color = color;
    }
    
    public BigDecimal getDailyRate() {
        return dailyRate;
    }
    
    public void setDailyRate(BigDecimal dailyRate) {
        this.dailyRate = dailyRate;
    }
    
    public String getFuelType() {
        return fuelType;
    }
    
    public void setFuelType(String fuelType) {
        this.fuelType = fuelType;
    }
    
    public String getTransmissionType() {
        return transmissionType;
    }
    
    public void setTransmissionType(String transmissionType) {
        this.transmissionType = transmissionType;
    }
    
    public Integer getSeatCapacity() {
        return seatCapacity;
    }
    
    public Integer getSeats() {
        return seats;
    }
    
    public void setSeats(Integer seats) {
        this.seats = seats;
    }
    
    public void setSeatCapacity(Integer seatCapacity) {
        this.seatCapacity = seatCapacity;
    }
    
    public Integer getYear() {
        return year;
    }
    
    public void setYear(Integer year) {
        this.year = year;
    }
    
    public Integer getMileage() {
        return mileage;
    }
    
    public void setMileage(Integer mileage) {
        this.mileage = mileage;
    }
    
    public String getLicensePlate() {
        return licensePlate;
    }
    
    public void setLicensePlate(String licensePlate) {
        this.licensePlate = licensePlate;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public String getLocation() {
        return location;
    }
    
    public void setLocation(String location) {
        this.location = location;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public String getImageUrl() {
        return imageUrl;
    }
    
    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
    
    public BigDecimal getPricePerDay() {
        return pricePerDay;
    }
    
    public void setPricePerDay(BigDecimal pricePerDay) {
        this.pricePerDay = pricePerDay;
    }
    
    public String getInsuranceInfo() {
        return insuranceInfo;
    }
    
    public void setInsuranceInfo(String insuranceInfo) {
        this.insuranceInfo = insuranceInfo;
    }
    
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
    
    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    public List<CarImage> getCarImages() {
        return carImages;
    }
    
    public void setCarImages(List<CarImage> carImages) {
        this.carImages = carImages;
    }
    
    @PreUpdate
    public void preUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
}
