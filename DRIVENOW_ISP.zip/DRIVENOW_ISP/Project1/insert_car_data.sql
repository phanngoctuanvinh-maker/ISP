-- Script để tạo bảng cars và car_images trong database
-- Chạy script này trong SQL Server Management Studio

USE drivenow_db;
GO

-- Tạo bảng cars nếu chưa tồn tại
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='cars' and xtype='U')
BEGIN
    CREATE TABLE cars (
        id BIGINT IDENTITY(1,1) PRIMARY KEY,
        brand NVARCHAR(100),
        model NVARCHAR(100),
        name NVARCHAR(200),
        color NVARCHAR(50),
        daily_rate DECIMAL(10,2),
        fuel_type NVARCHAR(50), -- Xăng, Dầu diesel, Điện, Xăng & điện
        transmission NVARCHAR(50), -- Số tự động, Số sàn
        seat_capacity INT, -- 4, 5, 7, 16 chỗ
        year INT,
        mileage INT,
        license_plate NVARCHAR(20),
        status NVARCHAR(50) DEFAULT 'AVAILABLE', -- AVAILABLE, RENTED, MAINTENANCE
        location NVARCHAR(200),
        description NVARCHAR(MAX),
        image_url NVARCHAR(500),
        price_per_day DECIMAL(10,2),
        insurance_included BIT DEFAULT 1,
        created_at DATETIME DEFAULT GETDATE(),
        updated_at DATETIME DEFAULT GETDATE()
    );
    PRINT 'Đã tạo bảng cars thành công';
END
ELSE
BEGIN
    PRINT 'Bảng cars đã tồn tại';
END
GO

-- Tạo bảng car_images nếu chưa tồn tại
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='car_images' and xtype='U')
BEGIN
    CREATE TABLE car_images (
        id BIGINT IDENTITY(1,1) PRIMARY KEY,
        car_id BIGINT NOT NULL,
        image_url NVARCHAR(500),
        description NVARCHAR(255),
        type NVARCHAR(50), -- MAIN, INTERIOR, EXTERIOR, etc.
        url NVARCHAR(500),
        created_at DATETIME DEFAULT GETDATE(),
        FOREIGN KEY (car_id) REFERENCES cars(id) ON DELETE CASCADE
    );
    PRINT 'Đã tạo bảng car_images thành công';
END
ELSE
BEGIN
    PRINT 'Bảng car_images đã tồn tại';
END
GO

-- Thêm dữ liệu mẫu vào bảng cars
INSERT INTO cars (brand, model, name, color, daily_rate, fuel_type, transmission, seat_capacity, year, mileage, license_plate, status, location, description, image_url, price_per_day, insurance_included)
VALUES 
    ('Toyota', 'Vios', 'Toyota Vios 2023', N'Trắng', 500000, N'Xăng', N'Số tự động', 5, 2023, 15000, '51A-12345', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', N'Xe sedan sang trọng, tiết kiệm nhiên liệu', '../car/car/OIP.webp', 500000, 1),
    ('Honda', 'City', 'Honda City 2023', N'Đen', 550000, N'Xăng', N'Số tự động', 5, 2023, 12000, '51A-23456', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', N'Xe sedan đẳng cấp, tiện nghi hiện đại', '../car/car/OIP.webp', 550000, 1),
    ('Hyundai', 'Accent', 'Hyundai Accent 2022', N'Bạc', 450000, N'Xăng', N'Số tự động', 5, 2022, 25000, '51A-34567', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', N'Xe sedan giá tốt, phù hợp đi phố', '../car/car/OIP.webp', 450000, 1),
    ('Mazda', 'CX-5', 'Mazda CX-5 2023', N'Đỏ', 800000, N'Xăng', N'Số tự động', 7, 2023, 10000, '51A-45678', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', N'SUV 7 chỗ cao cấp, động cơ mạnh mẽ', '../car/car/OIP.webp', 800000, 1),
    ('Ford', 'Everest', 'Ford Everest 2023', N'Xanh', 900000, N'Dầu diesel', N'Số tự động', 7, 2023, 8000, '51A-56789', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', N'SUV 7 chỗ địa hình, mạnh mẽ', '../car/car/OIP.webp', 900000, 1),
    ('VinFast', 'VF8', 'VinFast VF8 2024', N'Xanh', 1200000, N'Điện', N'Số tự động', 5, 2024, 5000, '51A-67890', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', N'SUV điện cao cấp, thân thiện môi trường', '../car/car/OIP.webp', 1200000, 1),
    ('Kia', 'Morning', 'Kia Morning 2022', N'Vàng', 350000, N'Xăng', N'Số sàn', 4, 2022, 30000, '51A-78901', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', N'Xe mini giá rẻ, tiết kiệm', '../car/car/OIP.webp', 350000, 1),
    ('Toyota', 'Innova', 'Toyota Innova 2023', N'Bạc', 700000, N'Xăng', N'Số tự động', 7, 2023, 18000, '51A-89012', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', N'MPV 7 chỗ gia đình, rộng rãi', '../car/car/OIP.webp', 700000, 1),
    ('Mitsubishi', 'Xpander', 'Mitsubishi Xpander 2023', N'Trắng', 600000, N'Xăng', N'Số tự động', 7, 2023, 14000, '51A-90123', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', N'MPV 7 chỗ tiện dụng', '../car/car/OIP.webp', 600000, 1),
    ('Ford', 'Ranger', 'Ford Ranger 2023', N'Đen', 1000000, N'Dầu diesel', N'Số tự động', 5, 2023, 12000, '51A-01234', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', N'Bán tải mạnh mẽ, địa hình', '../car/car/OIP.webp', 1000000, 1),
    ('Honda', 'CR-V', 'Honda CR-V 2023', N'Trắng', 850000, N'Xăng', N'Số tự động', 7, 2023, 9000, '51A-11111', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', N'SUV 7 chỗ sang trọng', '../car/car/OIP.webp', 850000, 1),
    ('Mazda', 'CX-8', 'Mazda CX-8 2023', N'Xanh', 950000, N'Dầu diesel', N'Số tự động', 7, 2023, 11000, '51A-22222', 'AVAILABLE', N'Nội Bài - Tân Sơn Nhất', N'SUV 7 chỗ cao cấp nhất', '../car/car/OIP.webp', 950000, 1);

PRINT N'Đã thêm 12 xe mẫu vào bảng cars';
GO

-- Thêm ảnh mẫu vào bảng car_images
INSERT INTO car_images (car_id, image_url, description, type, url)
VALUES 
    (1, '../car/car/OIP.webp', 'Toyota Vios - Main', 'MAIN', '../car/car/OIP.webp'),
    (1, '../car/car/OIP.webp', 'Toyota Vios - Interior', 'INTERIOR', '../car/car/OIP.webp'),
    (2, '../car/car/OIP.webp', 'Honda City - Main', 'MAIN', '../car/car/OIP.webp'),
    (3, '../car/car/OIP.webp', 'Hyundai Accent - Main', 'MAIN', '../car/car/OIP.webp'),
    (4, '../car/car/OIP.webp', 'Mazda CX-5 - Main', 'MAIN', '../car/car/OIP.webp'),
    (5, '../car/car/OIP.webp', 'Ford Everest - Main', 'MAIN', '../car/car/OIP.webp');

PRINT N'Đã thêm ảnh mẫu vào bảng car_images';
GO

-- Xem kết quả
SELECT * FROM cars;
SELECT * FROM car_images;
GO
