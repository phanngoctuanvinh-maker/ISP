# =====================================================
# THÊM DỮ LIỆU XE VÀO DATABASE
# =====================================================

Write-Host "================================================" -ForegroundColor Cyan
Write-Host "🚀 THÊM DỮ LIỆU XE VÀO DATABASE" -ForegroundColor Yellow
Write-Host "================================================" -ForegroundColor Cyan
Write-Host ""

# Thông tin kết nối - THAY ĐỔI THEO DATABASE CỦA BẠN
$server = "localhost"
$database = "drivenow_db"
$username = "sa"
$password = "your_password"

# Đường dẫn file SQL
$scriptPath = Join-Path $PSScriptRoot "quick_add_cars.sql"

Write-Host "📌 Thông tin kết nối:" -ForegroundColor Green
Write-Host "   Server: $server" -ForegroundColor White
Write-Host "   Database: $database" -ForegroundColor White
Write-Host "   Script: quick_add_cars.sql" -ForegroundColor White
Write-Host ""

# Kiểm tra file SQL có tồn tại không
if (-not (Test-Path $scriptPath)) {
    Write-Host "❌ Lỗi: Không tìm thấy file quick_add_cars.sql" -ForegroundColor Red
    Write-Host "   Đường dẫn: $scriptPath" -ForegroundColor Yellow
    pause
    exit
}

Write-Host "⏳ Đang thêm dữ liệu vào database..." -ForegroundColor Yellow
Write-Host ""

try {
    # Chạy SQL script bằng sqlcmd
    $result = sqlcmd -S $server -d $database -U $username -P $password -i $scriptPath 2>&1
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host "================================================" -ForegroundColor Cyan
        Write-Host "✅ THÀNH CÔNG!" -ForegroundColor Green
        Write-Host "================================================" -ForegroundColor Cyan
        Write-Host ""
        Write-Host "🎉 Đã thêm 10 xe vào database!" -ForegroundColor Green
        Write-Host ""
        Write-Host "📊 Kết quả:" -ForegroundColor Yellow
        Write-Host $result
        Write-Host ""
        Write-Host "🚀 Bây giờ bạn có thể test API:" -ForegroundColor Yellow
        Write-Host "   GET http://localhost:8080/api/cars" -ForegroundColor White
        Write-Host "   GET http://localhost:8080/api/cars/search?brand=Toyota" -ForegroundColor White
        Write-Host "   GET http://localhost:8080/api/cars/search?seats=7" -ForegroundColor White
        Write-Host ""
    } else {
        throw "SQL execution failed"
    }
} catch {
    Write-Host "================================================" -ForegroundColor Cyan
    Write-Host "❌ LỖI!" -ForegroundColor Red
    Write-Host "================================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "💡 Hãy kiểm tra:" -ForegroundColor Yellow
    Write-Host "   1. SQL Server đã chạy chưa" -ForegroundColor White
    Write-Host "   2. Thông tin kết nối (server, username, password) đúng chưa" -ForegroundColor White
    Write-Host "   3. Database 'drivenow_db' đã tạo chưa" -ForegroundColor White
    Write-Host "   4. sqlcmd đã cài đặt chưa (SQL Server Command Line Tools)" -ForegroundColor White
    Write-Host ""
    Write-Host "Chi tiết lỗi:" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host ""
}

Write-Host "================================================" -ForegroundColor Cyan
pause
