-- =====================================================
-- QUICK INSERT - 10 XE MẪU
-- Chạy script này trong SQL Server Management Studio
-- =====================================================

USE [drivenow_db]
GO

-- Xóa dữ liệu cũ (nếu có)
DELETE FROM [dbo].[car_images];
DELETE FROM [dbo].[cars];
GO

PRINT N'📝 Đang thêm 10 xe mẫu...';
GO

INSERT INTO [dbo].[cars] (brand, model, name, color, daily_rate, fuel_type, transmission_type, seat_capacity, seats, year, mileage, license_plate, status, location, description, image_url, price_per_day, insurance_info, created_at, updated_at)
VALUES 
(N'Toyota', N'Vios', N'Toyota Vios 2023', N'Trắng', 500000, N'Xăng', N'Số tự động', 5, 5, 2023, 15000, N'30A-12345', N'AVAILABLE', N'Hà Nội', N'Xe sedan tiết kiệm', N'https://i.ibb.co/1.jpg', 500000, N'Bảo hiểm toàn diện', GETDATE(), GETDATE()),
(N'Honda', N'City', N'Honda City 2023', N'Đen', 550000, N'Xăng', N'Số tự động', 5, 5, 2023, 12000, N'30A-23456', N'AVAILABLE', N'Hà Nội', N'Xe sedan cao cấp', N'https://i.ibb.co/2.jpg', 550000, N'Bảo hiểm vật chất', GETDATE(), GETDATE()),
(N'Mazda', N'CX-5', N'Mazda CX-5 2023', N'Đỏ', 800000, N'Xăng', N'Số tự động', 7, 7, 2023, 10000, N'30A-34567', N'AVAILABLE', N'Hồ Chí Minh', N'SUV 7 chỗ cao cấp', N'https://i.ibb.co/3.jpg', 800000, N'Bảo hiểm toàn diện', GETDATE(), GETDATE()),
(N'Ford', N'Everest', N'Ford Everest 2023', N'Xám', 900000, N'Dầu diesel', N'Số tự động', 7, 7, 2023, 8000, N'30A-45678', N'AVAILABLE', N'Hồ Chí Minh', N'SUV địa hình', N'https://i.ibb.co/4.jpg', 900000, N'Bảo hiểm VIP', GETDATE(), GETDATE()),
(N'VinFast', N'VF8', N'VinFast VF8 2024', N'Xanh lá', 1200000, N'Điện', N'Số tự động', 5, 5, 2024, 3000, N'30A-56789', N'AVAILABLE', N'Đà Nẵng', N'SUV điện 400km', N'https://i.ibb.co/5.jpg', 1200000, N'Bảo hiểm pin 10 năm', GETDATE(), GETDATE()),
(N'Kia', N'Morning', N'Kia Morning 2022', N'Vàng', 350000, N'Xăng', N'Số sàn', 4, 4, 2022, 25000, N'30A-67890', N'AVAILABLE', N'Đà Nẵng', N'Xe mini giá rẻ', N'https://i.ibb.co/6.jpg', 350000, N'Bảo hiểm cơ bản', GETDATE(), GETDATE()),
(N'Mitsubishi', N'Xpander', N'Mitsubishi Xpander 2023', N'Bạc', 700000, N'Xăng', N'Số tự động', 7, 7, 2023, 18000, N'30A-78901', N'AVAILABLE', N'Cần Thơ', N'MPV 7 chỗ rộng rãi', N'https://i.ibb.co/7.jpg', 700000, N'Bảo hiểm vật chất', GETDATE(), GETDATE()),
(N'Hyundai', N'Accent', N'Hyundai Accent 2022', N'Trắng', 450000, N'Xăng', N'Số tự động', 5, 5, 2022, 22000, N'30A-89012', N'AVAILABLE', N'Nha Trang', N'Sedan giá tốt', N'https://i.ibb.co/8.jpg', 450000, N'Bảo hiểm cơ bản', GETDATE(), GETDATE()),
(N'Toyota', N'Fortuner', N'Toyota Fortuner 2023', N'Đen', 950000, N'Dầu diesel', N'Số tự động', 7, 7, 2023, 9000, N'30A-90123', N'AVAILABLE', N'Hải Phòng', N'SUV hạng sang', N'https://i.ibb.co/9.jpg', 950000, N'Bảo hiểm toàn diện', GETDATE(), GETDATE()),
(N'Honda', N'CR-V', N'Honda CR-V 2023', N'Xám', 850000, N'Xăng', N'Số tự động', 7, 7, 2023, 11000, N'30A-01234', N'AVAILABLE', N'Vũng Tàu', N'SUV Honda Sensing', N'https://i.ibb.co/10.jpg', 850000, N'Bảo hiểm toàn diện', GETDATE(), GETDATE());
GO

PRINT N'✅ Thêm thành công 10 xe!';
PRINT N'';
SELECT 'Tổng số xe' as [Thông tin], COUNT(*) as [Số lượng] FROM [dbo].[cars]
UNION ALL
SELECT 'Xe xăng', COUNT(*) FROM [dbo].[cars] WHERE fuel_type = N'Xăng'
UNION ALL
SELECT 'Xe diesel', COUNT(*) FROM [dbo].[cars] WHERE fuel_type = N'Dầu diesel'
UNION ALL
SELECT 'Xe điện', COUNT(*) FROM [dbo].[cars] WHERE fuel_type = N'Điện'
UNION ALL
SELECT 'Số tự động', COUNT(*) FROM [dbo].[cars] WHERE transmission_type = N'Số tự động'
UNION ALL
SELECT 'Số sàn', COUNT(*) FROM [dbo].[cars] WHERE transmission_type = N'Số sàn';
GO

PRINT N'';
PRINT N'🎯 Bây giờ test API: http://localhost:8080/api/cars';
GO
