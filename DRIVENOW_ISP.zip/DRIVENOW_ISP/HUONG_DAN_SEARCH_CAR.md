# HƯỚNG DẪN SỬ DỤNG SEARCH CONTROLLER - TÌM KIẾM VÀ LỌC XE

## 📋 Tổng quan

SearchController cung cấp các API để tìm kiếm và lọc xe theo nhiều tiêu chí khác nhau:
- **Loại xe**: Mini, Sedan, SUV, MPV, Bán tải, Minivan
- **Hãng xe**: Toyota, Honda, Mazda, Ford, VinFast, Kia, Hyundai, Mitsubishi
- **Giá**: Lọc theo khoảng giá min-max
- **Số ghế**: 4, 5, 7, 16 chỗ
- **Bộ lọc nâng cao**: Năm sản xuất, số km đã đi, truyền động, nhiên liệu, v.v.

---

## 🗂️ Cấu trúc các file đã tạo

### 1. **Model Layer**
- `Car.java` - Entity chính chứa thông tin xe
- `CarImage.java` - Entity chứa ảnh của xe (nhiều ảnh cho 1 xe)

### 2. **DAO Layer**
- `CarDAO.java` - Repository xử lý truy vấn database với JPA Criteria API

### 3. **Service Layer**
- `CarService.java` - Business logic xử lý tìm kiếm và lọc xe

### 4. **Controller Layer**
- `SearchController.java` - REST API endpoints

### 5. **DTO Layer**
- `CarSearchRequest.java` - Request DTO chứa các tham số tìm kiếm
- `CarResponseDTO.java` - Response DTO trả về thông tin xe

---

## 🚀 Các API Endpoints

### 1. **Tìm kiếm xe (GET)**
```
GET /api/cars/search
```

**Query Parameters:**
- `location` (String): Địa điểm (vd: "Nội Bài", "Tân Sơn Nhất")
- `startTime` (String): Thời gian bắt đầu thuê
- `endTime` (String): Thời gian kết thúc thuê
- `carType` (String): Loại xe (mini, sedan, suv-5, suv-7, mpv, pickup, minivan)
- `brand` (String): Hãng xe (toyota, honda, mazda, ford, vinfast, kia, hyundai, mitsubishi)
- `transmission` (String): Truyền động (Số tự động, Số sàn)
- `fuelType` (String): Nhiên liệu (Xăng, Dầu diesel, Điện, Xăng & điện)
- `seatCapacity` (Integer): Số ghế (4, 5, 7, 16)
- `minPrice` (Decimal): Giá tối thiểu
- `maxPrice` (Decimal): Giá tối đa
- `minMileage` (Integer): Số km tối thiểu
- `maxMileage` (Integer): Số km tối đa
- `minYear` (Integer): Năm sản xuất tối thiểu
- `maxYear` (Integer): Năm sản xuất tối đa
- `sortBy` (String): Sắp xếp theo (dailyRate, year, mileage)
- `sortOrder` (String): Thứ tự (asc, desc)
- `page` (Integer): Trang hiện tại (default: 0)
- `size` (Integer): Số xe mỗi trang (default: 12)

**Ví dụ:**
```
GET http://localhost:8080/api/cars/search?location=Nội Bài&brand=toyota&minPrice=400000&maxPrice=600000&page=0&size=12
```

**Response:**
```json
{
  "cars": [
    {
      "id": 1,
      "brand": "Toyota",
      "model": "Vios",
      "name": "Toyota Vios 2023",
      "color": "Trắng",
      "dailyRate": 500000,
      "fuelType": "Xăng",
      "transmission": "Số tự động",
      "seatCapacity": 5,
      "year": 2023,
      "mileage": 15000,
      "status": "AVAILABLE",
      "location": "Nội Bài - Tân Sơn Nhất",
      "imageUrl": "../car/car/OIP.webp",
      "imageUrls": ["../car/car/OIP.webp", "../car/car/OIP2.webp"]
    }
  ],
  "currentPage": 0,
  "totalItems": 1,
  "totalPages": 1
}
```

---

### 2. **Lọc xe (POST với body)**
```
POST /api/cars/filter
Content-Type: application/json
```

**Request Body:**
```json
{
  "location": "Nội Bài",
  "brand": "toyota",
  "transmission": "Số tự động",
  "fuelType": "Xăng",
  "seatCapacity": 5,
  "minPrice": 400000,
  "maxPrice": 600000,
  "minYear": 2022,
  "maxYear": 2024,
  "sortBy": "dailyRate",
  "sortOrder": "asc",
  "page": 0,
  "size": 12
}
```

**Response:** Giống như API search

---

### 3. **Lấy chi tiết xe**
```
GET /api/cars/{id}
```

**Ví dụ:**
```
GET http://localhost:8080/api/cars/1
```

**Response:**
```json
{
  "success": true,
  "data": {
    "id": 1,
    "brand": "Toyota",
    "model": "Vios",
    "name": "Toyota Vios 2023",
    "dailyRate": 500000,
    "imageUrls": ["../car/car/OIP.webp"]
  }
}
```

---

### 4. **Lấy tất cả xe**
```
GET /api/cars
```

**Response:**
```json
{
  "success": true,
  "data": [...],
  "total": 12
}
```

---

### 5. **Lấy danh sách hãng xe**
```
GET /api/cars/brands
```

**Response:**
```json
{
  "success": true,
  "data": ["Toyota", "Honda", "Mazda", "Ford", "VinFast"]
}
```

---

### 6. **Đếm số xe theo hãng**
```
GET /api/cars/count/{brand}
```

**Ví dụ:**
```
GET http://localhost:8080/api/cars/count/toyota
```

**Response:**
```json
{
  "success": true,
  "brand": "toyota",
  "count": 2
}
```

---

## 📊 Database Schema

### Bảng `cars`
| Cột | Kiểu | Mô tả |
|-----|------|-------|
| id | BIGINT | Primary key |
| brand | NVARCHAR(100) | Hãng xe |
| model | NVARCHAR(100) | Model xe |
| name | NVARCHAR(200) | Tên xe |
| color | NVARCHAR(50) | Màu sắc |
| daily_rate | DECIMAL(10,2) | Giá thuê/ngày |
| fuel_type | NVARCHAR(50) | Loại nhiên liệu |
| transmission | NVARCHAR(50) | Truyền động |
| seat_capacity | INT | Số ghế |
| year | INT | Năm sản xuất |
| mileage | INT | Số km đã đi |
| status | NVARCHAR(50) | Trạng thái |
| location | NVARCHAR(200) | Địa điểm |
| image_url | NVARCHAR(500) | Ảnh chính |

### Bảng `car_images`
| Cột | Kiểu | Mô tả |
|-----|------|-------|
| id | BIGINT | Primary key |
| car_id | BIGINT | Foreign key to cars |
| image_url | NVARCHAR(500) | URL ảnh |
| type | NVARCHAR(50) | Loại ảnh |

---

## 🔧 Cách chạy

### 1. **Tạo database và thêm dữ liệu mẫu**
```sql
-- Chạy file: insert_car_data.sql trong SQL Server Management Studio
```

### 2. **Khởi động Spring Boot server**
```bash
cd Project1
.\mvnw.cmd spring-boot:run
```

### 3. **Test API với Postman hoặc Frontend**
- URL base: `http://localhost:8080`
- Các endpoint đã liệt kê ở trên

---

## 💻 Tích hợp với Frontend

### JavaScript Example (searchcar.js):

```javascript
// Tìm kiếm xe
async function searchCars(filters) {
    const params = new URLSearchParams();
    
    if (filters.location) params.append('location', filters.location);
    if (filters.brand) params.append('brand', filters.brand);
    if (filters.minPrice) params.append('minPrice', filters.minPrice);
    if (filters.maxPrice) params.append('maxPrice', filters.maxPrice);
    if (filters.transmission) params.append('transmission', filters.transmission);
    if (filters.fuelType) params.append('fuelType', filters.fuelType);
    if (filters.seatCapacity) params.append('seatCapacity', filters.seatCapacity);
    
    try {
        const response = await fetch(`http://localhost:8080/api/cars/search?${params}`);
        const data = await response.json();
        
        if (data.cars && data.cars.length > 0) {
            displayCars(data.cars);
        } else {
            console.log('Không tìm thấy xe');
        }
    } catch (error) {
        console.error('Lỗi:', error);
    }
}

// Hiển thị xe
function displayCars(cars) {
    const carGrid = document.querySelector('.cars-grid');
    carGrid.innerHTML = '';
    
    cars.forEach(car => {
        const carCard = `
            <div class="car-card-result">
                <div class="car-image-wrapper">
                    <img src="${car.imageUrl}" alt="${car.name}" class="car-result-img">
                </div>
                <div class="car-info">
                    <h3>${car.name}</h3>
                    <p>${car.transmission} - ${car.fuelType}</p>
                    <p class="price">${car.dailyRate.toLocaleString('vi-VN')}đ/ngày</p>
                </div>
            </div>
        `;
        carGrid.innerHTML += carCard;
    });
}

// Sử dụng
document.getElementById('applyCarBrand').addEventListener('click', () => {
    const selectedBrand = document.querySelector('.brand-card-item.selected')?.dataset.brand;
    searchCars({ brand: selectedBrand });
});
```

---

## ✅ Checklist hoàn thành

- [x] Tạo Car entity model
- [x] Tạo CarImage entity model
- [x] Tạo CarDAO với các phương thức tìm kiếm
- [x] Tạo CarService
- [x] Tạo SearchController với các API
- [x] Tạo DTO classes
- [x] Tạo SQL script thêm dữ liệu mẫu
- [ ] Test API endpoints
- [ ] Tích hợp với frontend

---

## 🎯 Các tính năng đã hoàn thành

1. ✅ Tìm kiếm xe theo địa điểm
2. ✅ Lọc xe theo hãng (Toyota, Honda, Mazda, Ford, VinFast, Kia, Hyundai, Mitsubishi)
3. ✅ Lọc xe theo loại (Mini, Sedan, SUV, MPV, Bán tải, Minivan)
4. ✅ Lọc xe theo số ghế (4, 5, 7, 16 chỗ)
5. ✅ Lọc xe theo giá (min-max)
6. ✅ Bộ lọc nâng cao: năm sản xuất, số km, truyền động, nhiên liệu
7. ✅ Sắp xếp kết quả (theo giá, năm, km)
8. ✅ Phân trang (pagination)
9. ✅ Xử lý nhiều ảnh cho một xe
10. ✅ API đếm số xe theo hãng

---

## 📞 Support

Nếu có lỗi, kiểm tra:
1. Database connection trong `application.properties`
2. Server đã chạy chưa (port 8080)
3. Dữ liệu đã được insert chưa
4. CORS đã được enable chưa

Server đang chạy tại: http://localhost:8080
API base URL: http://localhost:8080/api/cars
