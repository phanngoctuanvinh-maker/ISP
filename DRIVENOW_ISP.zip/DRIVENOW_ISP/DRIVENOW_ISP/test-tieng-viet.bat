@echo off
chcp 65001 >nul
echo ========================================
echo KIỂM TRA TIẾNG VIỆT - DRIVENOW
echo ========================================
echo.

echo [1/3] Kiểm tra Backend đang chạy...
curl -s http://localhost:8080/api/cars/all >nul 2>&1
if %errorlevel% neq 0 (
    echo ❌ Backend chưa chạy!
    echo    Hãy chạy: cd Project1 và .\start-backend.bat
    pause
    exit /b 1
)
echo ✅ Backend đang chạy

echo.
echo [2/3] Kiểm tra API trả về dữ liệu...
curl -s http://localhost:8080/api/cars/all -o test_response.json
if %errorlevel% neq 0 (
    echo ❌ Không thể gọi API
    pause
    exit /b 1
)
echo ✅ API hoạt động

echo.
echo [3/3] Kiểm tra tiếng Việt trong response...
findstr /C:"Xăng" test_response.json >nul
if %errorlevel% equ 0 (
    echo ✅ Tìm thấy "Xăng" - Tiếng Việt OK!
) else (
    echo ⚠️  Chưa tìm thấy "Xăng"
    echo    Có thể database chưa chạy script fix_vietnamese_encoding.sql
)

findstr /C:"Tự động" test_response.json >nul
if %errorlevel% equ 0 (
    echo ✅ Tìm thấy "Tự động" - Tiếng Việt OK!
) else (
    echo ⚠️  Chưa tìm thấy "Tự động"
)

echo.
echo ========================================
echo KẾT QUẢ
echo ========================================
echo File response: test_response.json
echo.
echo Bước tiếp theo:
echo 1. Nếu chưa có tiếng Việt, chạy fix_vietnamese_encoding.sql trong SSMS
echo 2. Restart backend: cd Project1; .\start-backend.bat
echo 3. Mở DriveNow/html/searchcar.html để test frontend
echo.

del test_response.json >nul 2>&1

pause
