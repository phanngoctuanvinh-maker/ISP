@echo off
chcp 65001 >nul
echo ========================================
echo KIỂM TRA VÀ SỬA DATABASE TIẾNG VIỆT
echo ========================================
echo.

echo [BƯỚC 1] Kiểm tra backend...
curl -s http://localhost:8080/api/cars/all >nul 2>&1
if %errorlevel% neq 0 (
    echo ❌ Backend chưa chạy!
    echo.
    echo Vui lòng chạy backend trước:
    echo cd Project1
    echo .\start-backend.bat
    echo.
    pause
    exit /b 1
)
echo ✅ Backend đang chạy
echo.

echo [BƯỚC 2] Lấy dữ liệu từ API...
curl -s http://localhost:8080/api/cars/all -o db_check.json 2>nul
if %errorlevel% neq 0 (
    echo ❌ Không thể gọi API
    pause
    exit /b 1
)
echo ✅ Đã lấy dữ liệu
echo.

echo [BƯỚC 3] Phân tích dữ liệu...
echo.

REM Kiểm tra tiếng Việt
findstr /C:"\"fuelType\": \"Xăng\"" db_check.json >nul 2>&1
if %errorlevel% equ 0 (
    echo ✅ Tìm thấy "Xăng" - Database đã là tiếng Việt!
    set VIETNAMESE=1
) else (
    echo ❌ Không tìm thấy "Xăng"
    set VIETNAMESE=0
)

findstr /C:"\"transmissionType\": \"Tự động\"" db_check.json >nul 2>&1
if %errorlevel% equ 0 (
    echo ✅ Tìm thấy "Tự động" - Database đã là tiếng Việt!
) else (
    echo ❌ Không tìm thấy "Tự động"
    set VIETNAMESE=0
)

REM Kiểm tra tiếng Anh
findstr /C:"\"fuelType\": \"Gasoline\"" db_check.json >nul 2>&1
if %errorlevel% equ 0 (
    echo ⚠️  Tìm thấy "Gasoline" - Database còn tiếng Anh!
    set ENGLISH=1
) else (
    set ENGLISH=0
)

findstr /C:"\"transmissionType\": \"Automatic\"" db_check.json >nul 2>&1
if %errorlevel% equ 0 (
    echo ⚠️  Tìm thấy "Automatic" - Database còn tiếng Anh!
    set ENGLISH=1
)

echo.
echo ========================================
echo KẾT QUẢ KIỂM TRA
echo ========================================
echo.

if %ENGLISH%==1 (
    echo 🔴 DATABASE ĐANG DÙNG TIẾNG ANH
    echo.
    echo Cần chạy script UPDATE để chuyển sang tiếng Việt:
    echo.
    echo CÁCH 1: Chạy SQL Script trong SSMS
    echo   1. Mở SQL Server Management Studio
    echo   2. Mở file: Project1\UPDATE_TO_VIETNAMESE.sql
    echo   3. Nhấn F5 ^(Execute^)
    echo   4. Restart backend
    echo.
    echo CÁCH 2: Nếu muốn reset toàn bộ database
    echo   1. Mở file: Project1\fix_vietnamese_encoding.sql
    echo   2. Chạy trong SSMS
    echo   3. Restart backend
    echo.
) else if %VIETNAMESE%==1 (
    echo 🟢 DATABASE ĐÃ LÀ TIẾNG VIỆT!
    echo.
    echo ✅ fuel_type: Xăng, Dầu diesel, Điện
    echo ✅ transmission_type: Tự động, Số sàn
    echo ✅ Không cần update thêm
    echo.
) else (
    echo 🟡 KHÔNG XÁC ĐỊNH ĐƯỢC TRẠNG THÁI
    echo.
    echo Có thể database trống hoặc chưa có dữ liệu.
    echo Xem file: db_check.json để kiểm tra chi tiết.
    echo.
)

echo File dữ liệu: db_check.json
echo.
echo ========================================

REM Hiển thị mẫu dữ liệu
echo.
echo MẪU DỮ LIỆU (3 xe đầu tiên):
echo.
powershell -Command "Get-Content db_check.json | ConvertFrom-Json | Select-Object -ExpandProperty cars | Select-Object -First 3 | Select-Object id, brand, name, fuelType, transmissionType, status | Format-Table -AutoSize"

echo.
pause
