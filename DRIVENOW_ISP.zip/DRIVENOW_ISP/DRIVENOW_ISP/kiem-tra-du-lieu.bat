@echo off
chcp 65001 >nul
echo ========================================
echo KIỂM TRA DỮ LIỆU TIẾNG VIỆT - DRIVENOW  
echo ========================================
echo.

echo ✅ Database đã được sửa sang NVARCHAR
echo ✅ Dữ liệu đã được update sang tiếng Việt
echo.

echo THÔNG TIN:
echo - Tổng: 30 xe
echo - Nhiên liệu: Xăng, Dầu diesel, Điện, Hybrid
echo - Hộp số: Tự động, Số sàn
echo - Trạng thái: Có sẵn
echo.

echo ========================================
echo CÁCH KIỂM TRA
echo ========================================
echo.

echo CÁCH 1: Mở frontend
echo   1. Mở file: DriveNow\html\searchcar.html
echo   2. Xem danh sách xe hiển thị tiếng Việt
echo.

echo CÁCH 2: Test API trong trình duyệt  
echo   Mở: http://localhost:8080/api/cars/all
echo   Tìm: "fuelType": "Xăng"
echo        "transmissionType": "Tự động"
echo.

echo CÁCH 3: Kiểm tra trong SQL
sqlcmd -S localhost -U sa -P 12345 -d drivenow_db -Q "SELECT TOP 3 id, brand, name, fuel_type, transmission_type, status FROM cars;" -W
echo.

echo ========================================
echo HOÀN THÀNH!
echo ========================================
echo.
echo ✅ Database đã đúng tiếng Việt
echo ✅ Backend cần restart để load dữ liệu mới
echo.
echo Nếu vẫn thấy ký tự lỗi:
echo 1. Stop backend (Ctrl+C trong terminal backend)
echo 2. Chạy lại: cd Project1; .\start-backend.bat
echo.

pause
