# 🇻🇳 HƯỚNG DẪN SỬA TIẾNG VIỆT CHO HỆ THỐNG DRIVENOW

## 📋 TỔNG QUAN

Đã sửa kiểu dữ liệu trong database và code để hỗ trợ **tiếng Việt đầy đủ**, hiển thị đúng chính tả.

---

## ✅ NHỮNG GÌ ĐÃ ĐƯỢC SỬA

### 1. **Database (SQL Server)**
- ✅ Thay đổi từ `VARCHAR` → `NVARCHAR` cho tất cả cột text
- ✅ Tăng độ dài các cột để chứa đủ tiếng Việt có dấu
- ✅ Thêm dữ liệu mẫu 30 xe với **tiếng Việt chuẩn**

**Các cột đã sửa:**
```sql
brand           VARCHAR(50)  → NVARCHAR(50)
model           VARCHAR(50)  → NVARCHAR(50)
name            VARCHAR(100) → NVARCHAR(100)
color           VARCHAR(30)  → NVARCHAR(50)
car_type        VARCHAR(50)  → NVARCHAR(50)
fuel_type       VARCHAR(20)  → NVARCHAR(50)
transmission_type VARCHAR(20) → NVARCHAR(50)
description     TEXT         → NVARCHAR(MAX)
image_url       VARCHAR(255) → NVARCHAR(500)
status          VARCHAR(20)  → NVARCHAR(50)
license_plate   VARCHAR(50)  → NVARCHAR(50)
insurance_info  VARCHAR(255) → NVARCHAR(500)
location        VARCHAR(100) → NVARCHAR(200)
```

### 2. **Backend (Java Spring Boot)**

#### File: `Car.java`
✅ Thêm `columnDefinition = "NVARCHAR(...)"` cho các cột:
```java
@Column(name = "brand", columnDefinition = "NVARCHAR(50)")
@Column(name = "fuel_type", columnDefinition = "NVARCHAR(50)")
@Column(name = "description", columnDefinition = "NVARCHAR(MAX)")
// ... và các cột khác
```

#### File: `application.properties`
✅ Thêm UTF-8 encoding:
```properties
spring.datasource.url=...;characterEncoding=UTF-8
spring.jpa.properties.hibernate.connection.characterEncoding=utf-8
spring.jpa.properties.hibernate.connection.useUnicode=true
```

### 3. **Dữ liệu tiếng Việt**

**File script:** `fix_vietnamese_encoding.sql`

**Ví dụ dữ liệu mới:**
- ❌ Cũ: `Gasoline`, `Automatic`, `Available`
- ✅ Mới: `Xăng`, `Tự động`, `Có sẵn`

**Dữ liệu đã được Việt hóa:**
- Nhiên liệu: `Xăng`, `Dầu diesel`, `Điện`, `Hybrid (Xăng + Điện)`
- Hộp số: `Tự động`, `Số sàn`
- Trạng thái: `Có sẵn`
- Loại xe: `Sedan`, `SUV`, `MPV`, `Minivan`, `Bán tải`, `Hatchback`, `SUV điện`
- Màu sắc: `Trắng`, `Đen`, `Đỏ`, `Xanh dương`, `Bạc`, `Xám`, v.v.
- Mô tả đầy đủ bằng tiếng Việt có dấu

---

## 🚀 CÁCH THỰC HIỆN

### **BƯỚC 1: Chạy Script SQL**

1. Mở **SQL Server Management Studio (SSMS)**
2. Kết nối đến server: `localhost` (username: `sa`, password: `12345`)
3. Mở file: `Project1/fix_vietnamese_encoding.sql`
4. Nhấn **Execute** (F5)

**Script sẽ:**
- ✅ Sửa cấu trúc bảng `cars` sang NVARCHAR
- ✅ Xóa dữ liệu cũ
- ✅ Thêm 30 xe mới với tiếng Việt đầy đủ

### **BƯỚC 2: Restart Backend**

```powershell
# Dừng server hiện tại (Ctrl+C trong terminal đang chạy)
# Sau đó chạy lại:
cd Project1
.\start-backend.bat
```

### **BƯỚC 3: Kiểm tra API**

Mở trình duyệt, test các endpoint:

```
http://localhost:8080/api/cars/all
```

**Kết quả mong đợi:**
```json
[
  {
    "id": 1,
    "brand": "Toyota",
    "model": "Vios",
    "name": "Toyota Vios 2024 - Trắng",
    "fuelType": "Xăng",
    "transmissionType": "Tự động",
    "status": "Có sẵn",
    "description": "Sedan tiết kiệm nhiên liệu, phù hợp đi phố..."
  }
]
```

### **BƯỚC 4: Kiểm tra Frontend**

1. Mở file: `DriveNow/html/searchcar.html`
2. Mở trong trình duyệt
3. Kiểm tra:
   - ✅ Tên xe hiển thị tiếng Việt
   - ✅ Màu sắc, nhiên liệu, hộp số đúng chính tả
   - ✅ Mô tả xe đầy đủ dấu
   - ✅ Filter hoạt động tốt

---

## 📊 DỮ LIỆU MẪU

### **30 xe đã được thêm:**

| Hãng | Số lượng |
|------|----------|
| Toyota | 6 |
| Honda | 5 |
| Mazda | 5 |
| Ford | 3 |
| Kia | 3 |
| Hyundai | 4 |
| VinFast | 3 (điện) |
| Mitsubishi | 1 (hybrid) |

### **Phân loại nhiên liệu:**
- 🔥 Xăng: 21 xe
- ⚫ Dầu diesel: 6 xe
- ⚡ Điện: 3 xe (VinFast)
- 🔋 Hybrid: 1 xe (Mitsubishi)

### **Phân loại hộp số:**
- ⚙️ Tự động: 28 xe
- 🎛️ Số sàn: 2 xe

---

## 🔧 TROUBLESHOOTING

### **Vấn đề 1: Hiển thị "????" thay vì tiếng Việt**

**Nguyên nhân:** Database chưa chạy script sửa NVARCHAR

**Giải pháp:**
```sql
-- Chạy lại script
USE drivenow_db;
GO
-- Kiểm tra kiểu dữ liệu
EXEC sp_help 'cars';
-- Phải thấy NVARCHAR, không phải VARCHAR
```

### **Vấn đề 2: Lỗi khi insert dữ liệu**

**Nguyên nhân:** Thiếu prefix `N` trước string tiếng Việt

**Giải pháp:**
```sql
-- ❌ SAI:
INSERT INTO cars (brand) VALUES ('Toyota');

-- ✅ ĐÚNG:
INSERT INTO cars (brand) VALUES (N'Toyota');
```

### **Vấn đề 3: Backend trả về null hoặc rỗng**

**Nguyên nhân:** Backend chưa restart sau khi sửa model

**Giải pháp:**
1. Stop backend (Ctrl+C)
2. Chạy lại: `.\start-backend.bat`

### **Vấn đề 4: Frontend hiển thị lỗi font**

**Nguyên nhân:** File HTML thiếu UTF-8 meta tag

**Giải pháp:**
```html
<!-- Thêm vào <head> -->
<meta charset="UTF-8">
```

---

## 📝 CHUẨN HÓA DỮ LIỆU

### **Nhiên liệu (fuel_type):**
- `Xăng`
- `Dầu diesel`
- `Điện`
- `Hybrid (Xăng + Điện)`

### **Hộp số (transmission_type):**
- `Tự động`
- `Số sàn`

### **Trạng thái (status):**
- `Có sẵn`
- `Đã thuê`
- `Bảo trì`

### **Loại xe (car_type):**
- `Sedan`
- `SUV`
- `MPV`
- `Minivan`
- `Bán tải`
- `Hatchback`
- `SUV điện`
- `Coupe`
- `Crossover`

---

## 🎯 KIỂM TRA CUỐI CÙNG

### **Checklist:**
- [ ] Chạy script `fix_vietnamese_encoding.sql` thành công
- [ ] Backend restart không có lỗi
- [ ] API `/api/cars/all` trả về tiếng Việt đúng
- [ ] Frontend hiển thị tên xe tiếng Việt
- [ ] Filter hoạt động với tiếng Việt
- [ ] Tìm kiếm xe hoạt động tốt
- [ ] Các ký tự đặc biệt (ă, â, ê, ô, ơ, ư, đ) hiển thị đúng

---

## 📚 TÀI LIỆU THAM KHẢO

### **Files đã sửa:**
1. ✅ `Project1/fix_vietnamese_encoding.sql` - Script sửa database
2. ✅ `Project1/src/main/java/com/carrentleproject/drivenow/model/Car.java`
3. ✅ `Project1/src/main/resources/application.properties`

### **Files liên quan cần kiểm tra:**
- `DriveNow/js/searchcar.js` - Logic tìm kiếm
- `DriveNow/html/searchcar.html` - Giao diện
- `DriveNow/css/searchcar.css` - Style

---

## 💡 LƯU Ý QUAN TRỌNG

### **Khi thêm xe mới:**
1. **Luôn dùng prefix `N`** trước string tiếng Việt:
   ```sql
   INSERT INTO cars (brand, fuel_type) 
   VALUES (N'Toyota', N'Xăng');
   ```

2. **Sử dụng từ chuẩn** từ danh sách ở trên

3. **Kiểm tra encoding** trong SSMS:
   - Tools → Options → Query Results → SQL Server → Results to Grid
   - Chọn: "Save results as Unicode"

### **Khi sửa code:**
1. File Java phải lưu với encoding **UTF-8**
2. HTML phải có `<meta charset="UTF-8">`
3. API response header: `Content-Type: application/json; charset=UTF-8`

---

## ✨ KẾT QUẢ

Sau khi hoàn thành, hệ thống sẽ:
- ✅ Hiển thị tên xe bằng tiếng Việt có dấu
- ✅ Filter theo nhiên liệu, hộp số bằng tiếng Việt
- ✅ Tìm kiếm hỗ trợ tiếng Việt
- ✅ Mô tả xe đầy đủ, dễ đọc
- ✅ Không còn ký tự lỗi (????, □□□)

---

**🎉 Chúc bạn thành công!**

📧 Nếu gặp vấn đề, kiểm tra lại từng bước trong hướng dẫn này.
