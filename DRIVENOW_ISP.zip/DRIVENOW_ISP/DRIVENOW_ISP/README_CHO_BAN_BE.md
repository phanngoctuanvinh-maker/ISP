# 🚀 HƯỚNG DẪN CHẠY PROJECT CHO BẠN BÈ

## ⚠️ LỖI THƯỜNG GẶP KHI GIẢI NÉN VÀ CHẠY

### Lỗi 1: "Refused to execute script... MIME type"
```
Refused to execute script from 'http://127.0.0.1:5500/ISP392-Font/api.js' 
because its MIME type ('text/html') is not executable
```

**Nguyên nhân:** Live Server đang mở sai folder hoặc đường dẫn file không đúng

**✅ CÁCH FIX:**

1. **MỞ ĐÚNG FOLDER:** 
   - Trong VS Code, chọn `File > Open Folder`
   - Chọn folder `DRIVENOW_ISP` (folder gốc)
   - **KHÔNG** mở folder con như `DriveNow`, `Project1`

2. **KIỂM TRA CẤU TRÚC:**
   ```
   DRIVENOW_ISP/
   ├── DriveNow/
   │   ├── html/
   │   │   └── searchcar.html    ← File HTML
   │   └── js/
   │       ├── searchcar.js       ← Script chính
   │       └── api.js             ← API config
   └── Project1/                  ← Backend Spring Boot
   ```

3. **CHẠY LIVE SERVER:**
   - Right-click vào `DriveNow/html/searchcar.html`
   - Chọn **"Open with Live Server"**

---

### Lỗi 2: "Car grid element not found"
```
Car grid element not found
```

**Nguyên nhân:** JavaScript chạy trước khi HTML load xong

**✅ ĐÃ FIX TRONG CODE** - Không cần làm gì thêm

---

## 📋 CHECKLIST TRƯỚC KHI CHẠY

### ✅ Phần 1: Setup Backend (Spring Boot)

1. **Cài đặt JDK 17:**
   - Download: https://adoptium.net/temurin/releases/
   - Chọn version 17, OS của bạn

2. **Cài đặt SQL Server:**
   - Đảm bảo SQL Server đang chạy
   - Port: 1433

3. **Tạo Database:**
   ```sql
   CREATE DATABASE drivenow_db;
   ```

4. **Chạy script insert data:**
   - Mở file: `Project1/insert_vietnamese_cars_FIXED.sql`
   - Chạy trong SQL Server Management Studio (SSMS) hoặc sqlcmd
   - Hoặc copy nội dung và chạy trong Azure Data Studio

5. **Update ảnh:**
   - Mở file: `Project1/update_car_images_online.sql`
   - Chạy script này để thêm ảnh Unsplash cho 30 xe

6. **Kiểm tra application.properties:**
   ```properties
   # File: Project1/src/main/resources/application.properties
   spring.datasource.url=jdbc:sqlserver://localhost:1433;databaseName=drivenow_db
   spring.datasource.username=sa
   spring.datasource.password=YOUR_PASSWORD   ← Đổi password của bạn!
   ```

7. **Start Backend:**
   ```cmd
   cd Project1
   mvnw.cmd spring-boot:run
   ```
   
   Hoặc double-click file: `Project1/start-backend.bat`

8. **Chờ backend khởi động:**
   - Đợi ~60 giây
   - Xem console xuất hiện: "Started DrivenowApplication"

9. **Test API:**
   - Mở browser: http://localhost:8080/api/cars/all
   - Phải thấy JSON với 30 xe

---

### ✅ Phần 2: Setup Frontend

1. **Cài VS Code Extension:**
   - Mở VS Code
   - Cài extension: **Live Server** (by Ritwick Dey)

2. **Mở đúng folder:**
   ```
   File > Open Folder > Chọn folder DRIVENOW_ISP
   ```

3. **Chạy Live Server:**
   - Click vào file: `DriveNow/html/searchcar.html`
   - Right-click → **Open with Live Server**
   - Browser sẽ tự mở: http://127.0.0.1:5500/DriveNow/html/searchcar.html

4. **Kiểm tra Console:**
   - Press `F12` để mở Developer Tools
   - Tab Console không có lỗi đỏ

---

## 🧪 TEST CHỨC NĂNG

### Test 1: Load tất cả xe
- Mở searchcar.html
- Phải thấy 30 xe hiển thị với ảnh

### Test 2: Lọc xe điện
- Click tab **"Xe Điện"**
- Phải hiển thị 3 xe VinFast:
  - VinFast VF5 Plus 2024
  - VinFast VF8 2024
  - VinFast VF9 2024

### Test 3: Lọc theo hãng
- Click tab **"Theo Hãng Xe"** 
- Chọn **Toyota**
- Phải hiển thị 6 xe Toyota

### Test 4: Tìm kiếm
- Nhập "Camry" vào ô tìm kiếm
- Phải hiển thị Toyota Camry

---

## 🆘 TROUBLESHOOTING

### Vấn đề: Backend không start

**Lỗi: "Failed to connect to database"**
```
✅ Fix:
1. Kiểm tra SQL Server đang chạy
2. Check username/password trong application.properties
3. Tạo database: CREATE DATABASE drivenow_db
```

**Lỗi: "Port 8080 already in use"**
```
✅ Fix:
1. Tắt các ứng dụng đang dùng port 8080
2. Hoặc đổi port trong application.properties:
   server.port=8081
```

### Vấn đề: Frontend không load xe

**Lỗi: "Failed to fetch"**
```
✅ Fix:
1. Kiểm tra backend đang chạy: http://localhost:8080/api/cars/all
2. Mở Console (F12), xem lỗi cụ thể
3. Check file api.js có đúng API_BASE_URL không
```

**Lỗi: Ảnh xe không hiển thị**
```
✅ Fix:
1. Kiểm tra có chạy script update_car_images_online.sql chưa
2. Kiểm tra internet connection (ảnh từ Unsplash)
```

### Vấn đề: Tiếng Việt bị lỗi font

**Ký tự hiển thị: "TrÃ¡ÂºÂ¯ng" thay vì "Trắng"**
```
✅ Fix:
1. Đã fix trong database - dùng NVARCHAR
2. Đã fix trong backend - dùng UTF-8 encoding
3. Nếu vẫn lỗi, xóa data và chạy lại script insert_vietnamese_cars_FIXED.sql
```

---

## 📞 LIÊN HỆ HỖ TRỢ

Nếu gặp vấn đề, check các file documentation:
- `HUONG_DAN_DAY_DU.md` - Hướng dẫn đầy đủ
- `GIAI_PHAP_FIX_XE_DIEN.md` - Fix lỗi xe điện
- `HUONG_DAN_CHAY.md` - Hướng dẫn chạy nhanh

---

## ✅ CHECKLIST CUỐI CÙNG

Trước khi nén và gửi cho bạn, đảm bảo:

- [ ] Đã test backend: http://localhost:8080/api/cars/all → Trả về 30 xe
- [ ] Đã test frontend: searchcar.html → Hiển thị 30 xe với ảnh
- [ ] Đã test xe điện: Click "Xe Điện" → Hiển thị 3 VinFast
- [ ] Đã bao gồm file README này
- [ ] Đã bao gồm các file SQL script trong folder Project1
- [ ] Đã update application.properties (xóa password thật nếu có)

---

**Ngày tạo:** 22/10/2025  
**Version:** 1.0  
**Backend:** Spring Boot 3.5.6 + SQL Server  
**Frontend:** HTML/CSS/JS + Bootstrap 5
