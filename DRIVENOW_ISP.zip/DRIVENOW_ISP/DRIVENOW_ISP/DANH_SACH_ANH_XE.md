# 📸 DANH SÁCH ẢNH XE - DRIVENOW

## ✅ Đã Cập Nhật: 30 Xe với Ảnh Online

### 🔗 Nguồn Ảnh: Unsplash (Miễn phí, Chất lượng cao)

---

## 🚗 TOYOTA (6 xe)

| ID | Tên Xe | Màu | Link Ảnh |
|----|--------|-----|----------|
| 1 | Toyota Vios 2024 | Trắng | https://images.unsplash.com/photo-1619767886558-efdc259cde1a?w=800 |
| 2 | Toyota Vios 2024 | Đen | https://images.unsplash.com/photo-1617531653332-bd46c24f2068?w=800 |
| 3 | Toyota Camry 2024 | Trắng ngọc trai | https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?w=800 |
| 4 | Toyota Fortuner 2024 | Bạc | https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?w=800 |
| 5 | Toyota Innova 2024 | Xám | https://images.unsplash.com/photo-1552519507-d9a0e1e4b800?w=800 |
| 6 | Toyota Corolla Cross 2024 | Đen | https://images.unsplash.com/photo-1609521263047-f8f205293f24?w=800 |

---

## 🚙 HONDA (6 xe)

| ID | Tên Xe | Màu | Link Ảnh |
|----|--------|-----|----------|
| 7 | Honda City 2024 | Trắng | https://images.unsplash.com/photo-1583121274602-3e2820c69888?w=800 |
| 8 | Honda City 2024 | Đỏ | https://images.unsplash.com/photo-1580273916550-e323be2ae537?w=800 |
| 9 | Honda Civic 2024 | Xanh dương | https://images.unsplash.com/photo-1590362891991-f776e747a588?w=800 |
| 10 | Honda CR-V 2024 | Trắng | https://images.unsplash.com/photo-1549399542-7e3f8b79c341?w=800 |
| 11 | Honda BR-V 2024 | Xám | https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=800 |
| 12 | Honda Accord 2024 | Đen | https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=800 |

---

## 🔴 MAZDA (5 xe)

| ID | Tên Xe | Màu | Link Ảnh |
|----|--------|-----|----------|
| 13 | Mazda 2 2024 | Bạc | https://images.unsplash.com/photo-1617814076367-b759c7d7e738?w=800 |
| 14 | Mazda 3 2024 | Đỏ pha lê | https://images.unsplash.com/photo-1614162692292-7ac56d7f1313?w=800 |
| 15 | Mazda CX-5 2024 | Đỏ pha lê | https://images.unsplash.com/photo-1609521263047-f8f205293f24?w=800 |
| 16 | Mazda CX-5 2024 | Trắng | https://images.unsplash.com/photo-1616422285623-13ff0162193c?w=800 |
| 17 | Mazda CX-8 2024 | Xanh dương | https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?w=800 |

---

## 🔵 FORD (3 xe)

| ID | Tên Xe | Màu | Link Ảnh |
|----|--------|-----|----------|
| 18 | Ford Ranger 2024 | Cam | https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?w=800 |
| 19 | Ford Everest 2024 | Đen | https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?w=800 |
| 20 | Ford Territory 2024 | Xanh lá | https://images.unsplash.com/photo-1581540222194-0def2dda95b8?w=800 |

---

## 🟢 KIA (3 xe)

| ID | Tên Xe | Màu | Link Ảnh |
|----|--------|-----|----------|
| 21 | Kia Seltos 2024 | Cam đồng | https://images.unsplash.com/photo-1609521263047-f8f205293f24?w=800 |
| 22 | Kia Sorento 2024 | Nâu | https://images.unsplash.com/photo-1549399542-7e3f8b79c341?w=800 |
| 23 | Kia Carnival 2024 | Trắng | https://images.unsplash.com/photo-1464219789935-c2d9d9aba644?w=800 |

---

## ⚪ HYUNDAI (4 xe)

| ID | Tên Xe | Màu | Link Ảnh |
|----|--------|-----|----------|
| 24 | Hyundai Accent 2024 | Trắng | https://images.unsplash.com/photo-1583121274602-3e2820c69888?w=800 |
| 25 | Hyundai Tucson 2024 | Xám | https://images.unsplash.com/photo-1606016159991-82b4b5e8c7fc?w=800 |
| 26 | Hyundai Santa Fe 2024 | Đen | https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?w=800 |
| 27 | Hyundai Stargazer 2024 | Bạc | https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=800 |

---

## ⚡ VINFAST (3 xe điện)

| ID | Tên Xe | Màu | Link Ảnh |
|----|--------|-----|----------|
| 28 | VinFast VF5 Plus 2024 | Xanh lá | https://images.unsplash.com/photo-1593941707882-a5bba14938c7?w=800 |
| 29 | VinFast VF8 2024 | Xanh dương | https://images.unsplash.com/photo-1617469767053-d3b523a0b982?w=800 |
| 30 | VinFast VF9 2024 | Đen | https://images.unsplash.com/photo-1609521263047-f8f205293f24?w=800 |

---

## 📝 Ghi Chú

- ✅ Tất cả ảnh đã được cập nhật vào database
- ✅ Link ảnh từ Unsplash - miễn phí, chất lượng cao
- ✅ Width: 800px - tối ưu cho web
- ✅ Không cần tải ảnh về máy
- ✅ Load nhanh, tiết kiệm dung lượng server

## 🔄 Cách Thay Đổi Ảnh

Nếu muốn thay ảnh, chạy lệnh SQL:

```sql
UPDATE cars 
SET image_url = N'https://link-anh-moi.com/image.jpg' 
WHERE id = [ID_XE];
```

## 🌐 Test

1. **Trang chính**: `DriveNow/html/searchcar.html`
2. **Trang test**: `Project1/test-vietnamese-data.html`
3. **API**: http://localhost:8080/api/cars/all

---

**Tạo bởi**: DriveNow System  
**Ngày**: 22/10/2025  
**Trạng thái**: ✅ Hoàn thành
