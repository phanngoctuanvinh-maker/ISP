# 🚗 HƯỚNG DẪN THÊM XE MỚI VÀO DATABASE

## 📋 MỤC LỤC
1. [Tổng quan hệ thống Search Car](#tổng-quan)
2. [Cấu trúc bảng Cars](#cấu-trúc-bảng)
3. [Cách thêm xe mới](#cách-thêm-xe-mới)
4. [Ví dụ thực tế](#ví-dụ-thực-tế)
5. [Kiểm tra kết quả](#kiểm-tra-kết-quả)

---

## 🎯 TỔNG QUAN HỆ THỐNG SEARCH CAR

### Frontend (searchcar.html + searchcar.js)
- **File HTML**: `DriveNow/html/searchcar.html`
- **File JS**: `DriveNow/js/searchcar.js`
- **API Base URL**: `http://localhost:8080/api/cars`

### Backend (Spring Boot)
- **Entity**: `com.carrentleproject.drivenow.model.Car`
- **Controller**: `com.carrentleproject.drivenow.controller.SearchCarController`
- **Service**: `com.carrentleproject.drivenow.service.SearchCarService`
- **Repository**: `com.carrentleproject.drivenow.dao.CarRepository`

### Các API đang hoạt động:
```
✅ GET  /api/cars/all                    - Lấy tất cả xe
✅ GET  /api/cars/by-type?seatCapacity=4 - Lọc theo số chỗ
✅ GET  /api/cars/by-brand?brand=Toyota  - Lọc theo hãng
✅ GET  /api/cars/by-transmission?type=Automatic - Lọc theo truyền động
✅ GET  /api/cars/electric               - Xe điện
✅ GET  /api/cars/hybrid                 - Xe hybrid
✅ GET  /api/cars/{id}                   - Chi tiết xe
✅ POST /api/cars/search                 - Tìm kiếm nâng cao
✅ POST /api/cars/advanced-filter        - Bộ lọc nâng cao
```

---

## 📊 CẤU TRÚC BẢNG CARS

### Các trường REQUIRED (Bắt buộc):
| Tên trường | Kiểu dữ liệu | Mô tả | Ví dụ |
|-----------|-------------|-------|-------|
| `brand` | NVARCHAR(50) | Hãng xe | Toyota, Honda, Mazda |
| `model` | NVARCHAR(50) | Dòng xe | Vios, City, CX-5 |
| `seat_capacity` | INT | Số chỗ ngồi | 4, 5, 7 |
| `price_per_day` | DECIMAL(10,2) | Giá thuê/ngày (VNĐ) | 450000, 650000 |

### Các trường OPTIONAL (Tùy chọn):
| Tên trường | Kiểu dữ liệu | Mô tả | Giá trị mặc định |
|-----------|-------------|-------|-----------------|
| `name` | NVARCHAR(100) | Tên đầy đủ | brand + model |
| `year` | INT | Năm sản xuất | 2024 |
| `color` | NVARCHAR(30) | Màu sắc | Trắng, Đen, Đỏ |
| `car_type` | NVARCHAR(50) | Loại xe | Sedan, SUV, MPV |
| `fuel_type` | NVARCHAR(50) | Loại nhiên liệu | Gasoline, Electric, Hybrid, Diesel |
| `transmission_type` | NVARCHAR(20) | Hộp số | Automatic, Manual |
| `description` | TEXT | Mô tả chi tiết | - |
| `mileage` | INT | Số km đã chạy | 0 |
| `image_url` | NVARCHAR(255) | Link ảnh xe | - |
| `status` | NVARCHAR(20) | Trạng thái | Available, Rented |
| `license_plate` | NVARCHAR(50) | Biển số xe | 30A-12345 |
| `insurance_info` | NVARCHAR(255) | Thông tin bảo hiểm | Bảo hiểm đầy đủ |
| `location` | NVARCHAR(100) | Vị trí xe | Hà Nội, TP.HCM |
| `daily_km_limit` | INT | Giới hạn km/ngày | 300 (NULL = không giới hạn) |
| `exceed_fee_per_km` | INT | Phí vượt km (VNĐ/km) | 5000 |
| `fuel_consumption` | DECIMAL(5,2) | Tiêu thụ nhiên liệu (L/100km) | 5.5 |

### Các trường tự động:
- `id` - Auto increment (Primary Key)
- `created_at` - Tự động khi insert (GETDATE())
- `updated_at` - Tự động khi update (GETDATE())
- `daily_rate` - Copy từ price_per_day (có thể NULL)

---

## 🔧 CÁCH THÊM XE MỚI

### Phương pháp 1: SQL INSERT trực tiếp (Khuyến nghị)

#### Template cơ bản:
```sql
INSERT INTO cars (
    brand, model, name, year, color, 
    car_type, seat_capacity, fuel_type, transmission_type,
    daily_rate, price_per_day, 
    description, mileage, image_url, status,
    license_plate, insurance_info, location,
    created_at, updated_at
) VALUES (
    'Toyota',                              -- brand *
    'Camry',                               -- model *
    'Toyota Camry 2024',                   -- name
    2024,                                  -- year
    'Trắng ngọc trai',                     -- color
    'Sedan',                               -- car_type
    5,                                     -- seat_capacity *
    'Gasoline',                            -- fuel_type
    'Automatic',                           -- transmission_type
    750000,                                -- daily_rate
    750000,                                -- price_per_day *
    'Sedan hạng D cao cấp, sang trọng',   -- description
    5000,                                  -- mileage
    'https://example.com/camry.jpg',      -- image_url
    'Available',                           -- status
    '30A-99999',                           -- license_plate
    'Bảo hiểm đầy đủ',                    -- insurance_info
    'Hà Nội',                              -- location
    GETDATE(),                             -- created_at
    GETDATE()                              -- updated_at
);
```

#### Template với Advanced Filter:
```sql
INSERT INTO cars (
    brand, model, name, year, color, 
    car_type, seat_capacity, fuel_type, transmission_type,
    price_per_day, description, image_url, status,
    license_plate, location,
    daily_km_limit, exceed_fee_per_km, fuel_consumption,
    created_at, updated_at
) VALUES (
    'Honda',                               -- brand *
    'Civic',                               -- model *
    'Honda Civic 2024',                    -- name
    2024,                                  -- year
    'Xanh dương',                          -- color
    'Sedan',                               -- car_type
    5,                                     -- seat_capacity *
    'Gasoline',                            -- fuel_type
    'Automatic',                           -- transmission_type
    680000,                                -- price_per_day *
    'Sedan thể thao, thiết kế trẻ trung', -- description
    'https://example.com/civic.jpg',      -- image_url
    'Available',                           -- status
    '30B-88888',                           -- license_plate
    'Hà Nội',                              -- location
    300,                                   -- daily_km_limit (km/ngày)
    5000,                                  -- exceed_fee_per_km (VNĐ/km)
    6.5,                                   -- fuel_consumption (L/100km)
    GETDATE(),                             -- created_at
    GETDATE()                              -- updated_at
);
```

### Phương pháp 2: Qua API (POST Request)

**Endpoint**: `POST http://localhost:8080/api/cars`

**Body (JSON)**:
```json
{
  "brand": "Toyota",
  "model": "Camry",
  "name": "Toyota Camry 2024",
  "year": 2024,
  "color": "Trắng",
  "carType": "Sedan",
  "seatCapacity": 5,
  "fuelType": "Gasoline",
  "transmissionType": "Automatic",
  "pricePerDay": 750000,
  "description": "Sedan cao cấp",
  "imageUrl": "https://example.com/camry.jpg",
  "status": "Available",
  "licensePlate": "30A-99999",
  "location": "Hà Nội"
}
```

---

## 📝 VÍ DỤ THỰC TẾ

### Ví dụ 1: Thêm Toyota Camry
```sql
INSERT INTO cars (
    brand, model, name, year, color, 
    car_type, seat_capacity, fuel_type, transmission_type,
    daily_rate, price_per_day, 
    description, mileage, image_url, status,
    license_plate, insurance_info, location,
    created_at, updated_at
) VALUES (
    'Toyota', 'Camry', 'Toyota Camry 2024', 2024, 'Trắng ngọc trai',
    'Sedan', 5, 'Gasoline', 'Automatic',
    750000, 750000,
    'Sedan hạng D cao cấp, êm ái, sang trọng, phù hợp đi công tác', 
    8000, 'https://example.com/toyota-camry.jpg', 'Available',
    '30A-77777', 'Bảo hiểm vật chất + bên thứ 3', 'Hà Nội',
    GETDATE(), GETDATE()
);
```

### Ví dụ 2: Thêm xe điện Mercedes EQS
```sql
INSERT INTO cars (
    brand, model, name, year, color, 
    car_type, seat_capacity, fuel_type, transmission_type,
    daily_rate, price_per_day, 
    description, mileage, image_url, status,
    license_plate, insurance_info, location,
    daily_km_limit, exceed_fee_per_km, fuel_consumption,
    created_at, updated_at
) VALUES (
    'Mercedes', 'EQS', 'Mercedes EQS 450 2024', 2024, 'Đen',
    'Sedan', 5, 'Electric', 'Automatic',
    2500000, 2500000,
    'Sedan điện hạng sang, tầm hoạt động 600km, sạc nhanh', 
    1000, 'https://example.com/mercedes-eqs.jpg', 'Available',
    '30A-11111', 'Bảo hiểm toàn diện + hỗ trợ sạc điện 24/7', 'Hà Nội',
    NULL, NULL, 0,
    GETDATE(), GETDATE()
);
```

### Ví dụ 3: Thêm nhiều xe cùng lúc
```sql
-- Thêm 5 xe Toyota Vios cùng lúc
INSERT INTO cars (
    brand, model, name, year, color, 
    car_type, seat_capacity, fuel_type, transmission_type,
    price_per_day, description, status, license_plate, location,
    created_at, updated_at
) VALUES 
('Toyota', 'Vios', 'Toyota Vios 2024 - Trắng', 2024, 'Trắng', 'Sedan', 4, 'Gasoline', 'Automatic', 450000, 'Sedan tiết kiệm', 'Available', '30A-10001', 'Hà Nội', GETDATE(), GETDATE()),
('Toyota', 'Vios', 'Toyota Vios 2024 - Đen', 2024, 'Đen', 'Sedan', 4, 'Gasoline', 'Automatic', 450000, 'Sedan tiết kiệm', 'Available', '30A-10002', 'Hà Nội', GETDATE(), GETDATE()),
('Toyota', 'Vios', 'Toyota Vios 2024 - Bạc', 2024, 'Bạc', 'Sedan', 4, 'Gasoline', 'Automatic', 450000, 'Sedan tiết kiệm', 'Available', '30A-10003', 'Hà Nội', GETDATE(), GETDATE()),
('Toyota', 'Vios', 'Toyota Vios 2024 - Đỏ', 2024, 'Đỏ', 'Sedan', 4, 'Gasoline', 'Automatic', 450000, 'Sedan tiết kiệm', 'Available', '30A-10004', 'Hà Nội', GETDATE(), GETDATE()),
('Toyota', 'Vios', 'Toyota Vios 2024 - Xanh', 2024, 'Xanh', 'Sedan', 4, 'Gasoline', 'Automatic', 450000, 'Sedan tiết kiệm', 'Available', '30A-10005', 'Hà Nội', GETDATE(), GETDATE());
```

### Ví dụ 4: Thêm xe với tất cả tính năng nâng cao
```sql
INSERT INTO cars (
    brand, model, name, year, color, 
    car_type, seat_capacity, fuel_type, transmission_type,
    daily_rate, price_per_day, 
    description, mileage, image_url, status,
    license_plate, insurance_info, location,
    daily_km_limit, exceed_fee_per_km, fuel_consumption,
    created_at, updated_at
) VALUES (
    'BMW', 'X5', 'BMW X5 2024', 2024, 'Xanh dương kim cương',
    'SUV', 7, 'Hybrid', 'Automatic',
    1800000, 1800000,
    'SUV hạng sang 7 chỗ, hybrid tiết kiệm, công nghệ cao, camera 360, ghế massage', 
    3000, 'https://example.com/bmw-x5.jpg', 'Available',
    '30A-00001', 'Bảo hiểm VIP + hỗ trợ 24/7 + đưa đón sân bay miễn phí', 'Hà Nội',
    250, 8000, 7.2,
    GETDATE(), GETDATE()
);
```

---

## ✅ KIỂM TRA KẾT QUẢ

### Bước 1: Kiểm tra trong Database
```sql
-- Xem tất cả xe vừa thêm
SELECT * FROM cars ORDER BY created_at DESC;

-- Xem xe theo hãng
SELECT * FROM cars WHERE brand = 'Toyota';

-- Xem xe theo số chỗ
SELECT * FROM cars WHERE seat_capacity = 5;

-- Xem xe điện
SELECT * FROM cars WHERE fuel_type = 'Electric';

-- Đếm số xe
SELECT COUNT(*) as total_cars FROM cars;

-- Thống kê theo hãng
SELECT brand, COUNT(*) as count 
FROM cars 
GROUP BY brand 
ORDER BY count DESC;
```

### Bước 2: Test API bằng Browser
```
http://localhost:8080/api/cars/all
http://localhost:8080/api/cars/by-brand?brand=Toyota
http://localhost:8080/api/cars/by-type?seatCapacity=5
http://localhost:8080/api/cars/electric
```

### Bước 3: Kiểm tra trên Frontend
1. Mở file: `DriveNow/html/searchcar.html`
2. Mở DevTools (F12) → Console
3. Xem log: "All cars loaded: {cars: Array(...)}"
4. Xe mới sẽ hiển thị trong grid

### Bước 4: Test Filter
1. Click vào "Loại Xe" → Chọn loại → Áp dụng
2. Click vào "Hãng Xe" → Chọn hãng → Áp dụng
3. Click vào "Xe Điện" → Xem xe điện
4. Click vào "Bộ Lọc" → Điều chỉnh tiêu chí → Áp dụng

---

## 🎨 DANH SÁCH CÁC LOẠI XE

### Theo seat_capacity và car_type:
| seat_capacity | car_type | Mô tả | Ví dụ |
|--------------|----------|-------|-------|
| 4 | Mini | Xe nhỏ gọn | Mazda 2, Kia Morning |
| 4 | Sedan | Xe sedan 4 chỗ | Toyota Vios, Honda City |
| 4 | Pickup | Xe bán tải | Ford Ranger |
| 5 | Sedan | Xe sedan 5 chỗ | Honda Civic, Toyota Camry |
| 5 | SUV | SUV gầm cao 5 chỗ | Honda CR-V, Mazda CX-5 |
| 7 | SUV | SUV gầm cao 7 chỗ | Toyota Fortuner, Ford Everest |
| 7 | MPV | MPV gầm thấp 7 chỗ | Toyota Innova, Mitsubishi Xpander |
| 7 | Minivan | Minivan cao cấp | Kia Carnival |

### Hãng xe phổ biến:
- **Nhật Bản**: Toyota, Honda, Mazda, Mitsubishi, Nissan, Suzuki
- **Hàn Quốc**: Hyundai, Kia
- **Việt Nam**: Vinfast
- **Mỹ**: Ford, Chevrolet
- **Đức**: Mercedes, BMW, Audi, Volkswagen

### Loại nhiên liệu (fuel_type):
- `Gasoline` - Xăng
- `Diesel` - Dầu Diesel
- `Electric` - Điện
- `Hybrid` - Xăng & Điện

### Loại hộp số (transmission_type):
- `Automatic` - Số tự động
- `Manual` - Số sàn

---

## 🚀 SCRIPT NHANH - SẴN SÀNG SỬ DỤNG

### Tạo file: `add_new_cars.sql`
Xem file `add_new_cars.sql` đã được tạo trong thư mục Project1.

### Cách sử dụng:
```powershell
# Chạy script SQL
cd "c:\Users\ACER\Desktop\Project  ISP\2110\DRIVENOW_ISP\DRIVENOW_ISP\Project1"

# Dùng sqlcmd
sqlcmd -S localhost -d drivenow_db -i add_new_cars.sql

# Hoặc copy paste vào SQL Server Management Studio và Execute
```

---

## 🔍 TROUBLESHOOTING

### Lỗi: "Cannot insert NULL into column 'seat_capacity'"
**Nguyên nhân**: Thiếu trường bắt buộc
**Giải pháp**: Đảm bảo có: brand, model, seat_capacity, price_per_day

### Lỗi: "Violation of UNIQUE KEY constraint 'license_plate'"
**Nguyên nhân**: Biển số xe bị trùng
**Giải pháp**: Đổi license_plate thành giá trị unique

### Xe không hiển thị trên frontend
**Kiểm tra**:
1. Status = 'Available'
2. Backend đang chạy (port 8080)
3. Clear cache browser (Ctrl + F5)
4. Kiểm tra Console log

### Lỗi CORS khi gọi API
**Giải pháp**: Đã có `@CrossOrigin(origins = "*")` trong Controller

---

## 📚 TÀI LIỆU THAM KHẢO

### Code liên quan:
- **Entity**: `Project1/src/main/java/com/carrentleproject/drivenow/model/Car.java`
- **Controller**: `Project1/src/main/java/com/carrentleproject/drivenow/controller/SearchCarController.java`
- **Service**: `Project1/src/main/java/com/carrentleproject/drivenow/service/SearchCarService.java`
- **Repository**: `Project1/src/main/java/com/carrentleproject/drivenow/dao/CarRepository.java`
- **Frontend JS**: `DriveNow/js/searchcar.js`
- **Frontend HTML**: `DriveNow/html/searchcar.html`

### Database Schema:
- **Setup**: `Project1/database_setup.sql`
- **Sample Data**: `Project1/insert_cars_NEW_STRUCTURE.sql`

---

## 💡 LƯU Ý QUAN TRỌNG

1. **Backup trước khi thêm**:
   ```sql
   -- Backup table
   SELECT * INTO cars_backup FROM cars;
   ```

2. **Kiểm tra trùng lặp**:
   ```sql
   SELECT license_plate, COUNT(*) 
   FROM cars 
   GROUP BY license_plate 
   HAVING COUNT(*) > 1;
   ```

3. **Xóa dữ liệu test**:
   ```sql
   -- Xóa xe test (cẩn thận!)
   DELETE FROM cars WHERE license_plate LIKE '%-TEST';
   ```

4. **Reset auto increment**:
   ```sql
   DBCC CHECKIDENT ('cars', RESEED, 0);
   ```

---

## 📞 HỖ TRỢ

Nếu gặp vấn đề, kiểm tra:
1. ✅ Database đang chạy
2. ✅ Spring Boot backend đang chạy (port 8080)
3. ✅ Dữ liệu đã insert đúng cấu trúc
4. ✅ Status = 'Available'
5. ✅ Browser không cache cũ (Ctrl + Shift + R)

**Happy Coding! 🚗💨**
