# ✅ HOÀN THIỆN CHỨC NĂNG THANH TOÁN

## 🎯 Những gì đã làm:

### 1. **Kết nối Booking → Payment**
- ✅ Sau khi booking thành công → redirect sang `payment.html?bookingId=X`
- ✅ Lưu booking data vào `sessionStorage` để payment page sử dụng
- ✅ Xóa alert thành công, chuyển thẳng sang payment

### 2. **Frontend Payment (payment.js)**
- ✅ Load booking data từ sessionStorage hoặc API
- ✅ Hiển thị thông tin đơn hàng, giá tiền, deposit (30%)
- ✅ Call API `/api/payment/create` để tạo payment VNPay
- ✅ Generate QR code từ payment URL
- ✅ Polling payment status mỗi 5 giây
- ✅ Auto redirect khi thanh toán thành công

### 3. **Backend Payment API**
- ✅ Entity `Payment` với table `vnpay_payments`
- ✅ Controller endpoints:
  - `POST /api/payment/create` - Tạo payment URL
  - `GET /api/payment/vnpay-return` - Callback từ VNPay
  - `GET /api/payment/order/{orderId}` - Lấy payment info
  - `GET /api/payment/user/{userId}` - Lấy payments của user
- ✅ `VNPayService` - Xử lý logic VNPay integration

### 4. **Backend Booking Update**
- ✅ Chuyển `payment_method` và `payment_status` từ @Transient sang @Column
- ✅ Thêm endpoint `PUT /api/bookings/{id}/payment` để update:
  - `paymentMethod` (vnpay, cash, etc.)
  - `paymentStatus` (pending, paid, failed)
  - `status` (confirmed sau khi paid)

---

## 🚀 CÁCH TEST:

### **Bước 1: Đặt xe**
1. Mở http://localhost:5500/DriveNow/html/cardetail.html?id=1
2. Đăng nhập: `quyenthedinh2@gmail.com` / `123456`
3. Điền form booking:
   - Start: 2025-10-27T15:00
   - End: 2025-10-30T17:00
   - Pickup: Số 173 Đường Cửa Thiềng, Phường 12, Quận 10, TP. HCM
   - Dropoff: (giống pickup)
4. Click "CHỌN THUÊ"
5. ✅ Sẽ redirect sang `payment.html?bookingId=X`

### **Bước 2: Xem payment page**
- ✅ Thông tin đơn hàng hiển thị
- ✅ Số tiền deposit (30% tổng tiền)
- ✅ QR code hiển thị
- ✅ Timer đếm ngược 15:00

### **Bước 3: Kiểm tra database**
```sql
-- Xem booking vừa tạo
SELECT booking_id, customer_id, car_id, status, payment_status, total_price 
FROM bookings 
ORDER BY created_at DESC;

-- Xem payment (nếu có)
SELECT * FROM vnpay_payments ORDER BY created_at DESC;
```

### **Bước 4: Test payment callback (Manual)**
Vì chưa có VNPay sandbox, có thể test bằng cách:

1. **Giả lập thanh toán thành công:**
```javascript
// Mở Console trong payment page, chạy:
fetch('http://127.0.0.1:5500/api/bookings/7/payment', {
    method: 'PUT',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
        paymentMethod: 'vnpay',
        paymentStatus: 'paid',
        status: 'confirmed'
    })
}).then(r => r.json()).then(console.log);
```

2. Sau 5 giây, page sẽ auto redirect về booking-detail

---

## 🔧 API ENDPOINTS:

### Payment APIs
```
POST   /api/payment/create
GET    /api/payment/vnpay-return
GET    /api/payment/order/{orderId}
GET    /api/payment/user/{userId}
GET    /api/payment/test
```

### Booking APIs (mới thêm)
```
PUT    /api/bookings/{id}/payment
Body: {
  "paymentMethod": "vnpay",
  "paymentStatus": "paid",
  "status": "confirmed"
}
```

---

## 📊 DATABASE SCHEMA:

### bookings table (đã update)
- `payment_method` VARCHAR - Phương thức thanh toán (vnpay, cash, card)
- `payment_status` VARCHAR - Trạng thái (pending, paid, failed)

### vnpay_payments table
- `id` BIGINT PK
- `order_id` VARCHAR UNIQUE
- `user_id` BIGINT
- `amount` NUMERIC
- `order_info` VARCHAR
- `transaction_no` VARCHAR
- `bank_code` VARCHAR
- `payment_status` VARCHAR
- `vnpay_response_code` VARCHAR
- `created_at` DATETIME2
- `updated_at` DATETIME2

---

## ⚠️ LƯU Ý:

### 1. **VNPay Configuration**
Cần config VNPay credentials trong `application.properties`:
```properties
vnpay.tmn-code=YOUR_TMN_CODE
vnpay.hash-secret=YOUR_HASH_SECRET
vnpay.payment-url=https://sandbox.vnpayment.vn/paymentv2/vpcpay.html
vnpay.return-url=http://localhost:5500/api/payment/vnpay-return
```

### 2. **CORS Settings**
API đã config `@CrossOrigin(origins = "*")` để frontend call được

### 3. **Payment Flow**
```
Booking → Payment Page → VNPay → Callback → Update Status → Success
   ↓           ↓            ↓         ↓          ↓           ↓
  DB        QR Code      Scan     API Call   DB Update   Redirect
```

---

## 🎉 TÍNH NĂNG HOÀN THIỆN:

✅ Booking thành công → redirect payment
✅ Hiển thị thông tin booking trong payment
✅ Tính deposit 30% tổng tiền
✅ Generate QR code
✅ Timer 15 phút
✅ VAT invoice form
✅ Payment API integration
✅ Auto check payment status
✅ Update booking khi paid
✅ Redirect khi thành công

---

## 📝 TEST CHECKLIST:

- [ ] Đặt xe thành công
- [ ] Redirect sang payment page
- [ ] Thông tin booking hiển thị đúng
- [ ] Số tiền deposit = 30% tổng tiền
- [ ] QR code hiển thị
- [ ] Timer chạy
- [ ] Form VAT hoạt động
- [ ] Call API payment/create thành công
- [ ] Update payment status thành công
- [ ] Auto redirect sau khi paid

---

🚀 **Server đang chạy trên port 8080!**
🌐 **Test ngay tại: http://localhost:5500/DriveNow/html/cardetail.html?id=1**
