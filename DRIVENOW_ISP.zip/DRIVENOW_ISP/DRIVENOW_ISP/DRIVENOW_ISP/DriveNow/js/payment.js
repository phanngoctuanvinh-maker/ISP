
const API_BASE_URL = 'http://localhost:8080/api';

let isOrderDetailsShown = false;
let timeLeft = 900;
let timerInterval;
let bookingData = {
    bookingId: null,
    customerName: '',
    customerPhone: '',
    carName: '',
    pickupDate: '',
    returnDate: '',
    totalPrice: 0,
    depositAmount: 0,
    hasVAT: false,
    companyName: '',
    companyAddress: '',
    taxCode: '',
    companyEmail: ''
};

// Load booking data on page load
window.addEventListener('DOMContentLoaded', () => {
    // Check if user is logged in - must parse to check properly
    const userDataStr = localStorage.getItem('userData');
    const currentUserStr = localStorage.getItem('currentUser');
    
    let userData = null;
    try {
        userData = userDataStr ? JSON.parse(userDataStr) : null;
        // Fallback to currentUser if userData not found
        if (!userData && currentUserStr) {
            userData = JSON.parse(currentUserStr);
        }
    } catch (e) {
        console.error('Error parsing user data:', e);
    }
    
    // Check if actually logged in (has accountId or username)
    if (!userData || (!userData.accountId && !userData.username)) {
        alert('Vui lòng đăng nhập để tiếp tục!');
        // Save current URL to return after login
        sessionStorage.setItem('returnUrl', window.location.href);
        window.location.href = 'login.html';
        return;
    }
    
    console.log('✅ User logged in:', userData);
    loadBookingData();
});

function loadBookingData() {
    // Get booking ID from URL
    const urlParams = new URLSearchParams(window.location.search);
    const bookingId = urlParams.get('bookingId');
    
    // Get booking from sessionStorage
    const pendingBooking = sessionStorage.getItem('pendingBooking');
    
    if (pendingBooking) {
        const booking = JSON.parse(pendingBooking);
        bookingData.bookingId = booking.id;
        bookingData.totalPrice = booking.totalPrice || 0;
        bookingData.depositAmount = Math.round(booking.totalPrice * 0.3); // 30% deposit
        
        // Display order info
        displayOrderInfo(booking);
        displayPriceSection(booking);
    } else if (bookingId) {
        // Fetch from API if not in session
        fetchBookingById(bookingId);
    }
}

async function fetchBookingById(bookingId) {
    try {
        const response = await fetch(`${API_BASE_URL}/bookings/${bookingId}`);
        if (response.ok) {
            const data = await response.json();
            const booking = data.booking;
            bookingData.bookingId = booking.bookingId;
            bookingData.totalPrice = booking.totalAmount || 0;
            bookingData.depositAmount = Math.round(booking.totalAmount * 0.3);
            displayOrderInfo(booking);
            displayPriceSection(booking);
        }
    } catch (error) {
        console.error('Error fetching booking:', error);
    }
}

function displayOrderInfo(booking) {
    const orderInfo = document.getElementById('orderInfo');
    if (orderInfo) {
        orderInfo.innerHTML = `
            <p><strong>Mã đặt xe:</strong> ${booking.id || booking.bookingId}</p>
            <p><strong>Thời gian:</strong> ${formatDateTime(booking.pickupDate || booking.startTime)} - ${formatDateTime(booking.returnDate || booking.endTime)}</p>
            <p><strong>Địa điểm:</strong> ${booking.pickupLocation || 'Chưa xác định'}</p>
        `;
    }
}

function displayPriceSection(booking) {
    const priceSection = document.getElementById('priceSection');
    const totalPrice = booking.totalPrice || booking.totalAmount || 0;
    const depositAmount = Math.round(totalPrice * 0.3);
    
    if (priceSection) {
        priceSection.innerHTML = `
            <div class="price-row">
                <span>Phí thuê xe</span>
                <span>${formatPrice(totalPrice)}</span>
            </div>
            <div class="price-row">
                <span>Phí bảo hiểm</span>
                <span>${formatPrice(booking.insuranceFee || 0)}</span>
            </div>
            <div class="price-row">
                <span>Giảm giá</span>
                <span>-${formatPrice(booking.discountAmount || 0)}</span>
            </div>
            <div class="price-row total">
                <span>Tổng cộng tiền thuê</span>
                <span>${formatPrice(totalPrice)}</span>
            </div>
            <div class="payment-steps">
                <h4>Các bước thanh toán</h4>
                <div class="step">
                    <span class="step-number">1</span>
                    <div>
                        <strong>Thanh toán giữ chỗ qua DriveNow</strong>
                        <p>30% tổng tiền = ${formatPrice(depositAmount)}</p>
                    </div>
                </div>
                <div class="step">
                    <span class="step-number">2</span>
                    <div>
                        <strong>Thanh toán khi nhận xe</strong>
                        <p>Tiền chặp: ${formatPrice(totalPrice - depositAmount)}<br>Số tiền sẽ thanh toán khi trả xe</p>
                    </div>
                </div>
            </div>
        `;
    }
    
    // Update payment steps detail
    const paymentSteps = document.getElementById('paymentSteps');
    if (paymentSteps) {
        paymentSteps.innerHTML = priceSection.querySelector('.payment-steps').innerHTML;
    }
}

function formatPrice(price) {
    return new Intl.NumberFormat('vi-VN').format(price) + 'đ';
}

function formatDateTime(dateStr) {
    if (!dateStr) return '-';
    const date = new Date(dateStr);
    return date.toLocaleString('vi-VN', {
        hour: '2-digit',
        minute: '2-digit',
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
    });
}

function handleConfirm() {
    const name = document.getElementById('customerName').value.trim();
    const phone = document.getElementById('customerPhone').value.trim();

    if (!name || !phone) {
        alert('Vui lòng điền đầy đủ thông tin!');
        return;
    }

    // Lưu thông tin vào bookingData
    bookingData.customerName = name;
    bookingData.customerPhone = phone;
    bookingData.hasVAT = document.getElementById('vatCheckbox').checked;

    if (bookingData.hasVAT) {
        const vatInputs = document.querySelectorAll('#vatForm input');
        bookingData.companyName = vatInputs[0].value.trim();
        bookingData.companyAddress = vatInputs[1].value.trim();
        bookingData.taxCode = vatInputs[2].value.trim();
        bookingData.companyEmail = vatInputs[3].value.trim();
        
        if (!bookingData.companyName || !bookingData.taxCode) {
            alert('Vui lòng điền đầy đủ thông tin VAT!');
            return;
        }
    }

    // Create payment
    createPayment();
}

async function createPayment() {
    let userData = null;
    try {
        const userDataStr = localStorage.getItem('userData') || localStorage.getItem('currentUser');
        userData = userDataStr ? JSON.parse(userDataStr) : null;
    } catch (e) {
        console.error('Error parsing user data:', e);
    }
    
    if (!userData || (!userData.accountId && !userData.id)) {
        alert('Vui lòng đăng nhập để tiếp tục!');
        window.location.href = 'login.html';
        return;
    }
    
    const userId = userData.accountId || userData.id;
    
    try {
        const paymentRequest = {
            userId: userId,
            amount: bookingData.depositAmount,
            orderInfo: `Dat coc thue xe - Booking #${bookingData.bookingId}`,
            bankCode: null // For QR all banks
        };
        
        console.log('Creating payment:', paymentRequest);
        
        const response = await fetch(`${API_BASE_URL}/payment/create`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(paymentRequest)
        });
        
        if (!response.ok) {
            throw new Error('Không thể tạo thanh toán');
        }
        
        const data = await response.json();
        
        if (data.success) {
            // Save payment URL and go to payment screen
            bookingData.paymentUrl = data.paymentUrl;
            goToPayment();
        } else {
            alert('Lỗi: ' + data.message);
        }
        
    } catch (error) {
        console.error('Payment error:', error);
        alert('Lỗi khi tạo thanh toán: ' + error.message);
    }
}

function showOrderDetails() {
    const orderDetails = document.getElementById('orderDetails');
    const confirmBtn = document.getElementById('confirmBtn');
    const terms = document.getElementById('terms');

    orderDetails.style.display = 'block';
    confirmBtn.textContent = 'Xác nhận';
    terms.style.display = 'block';
    isOrderDetailsShown = true;

    setTimeout(() => {
        orderDetails.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }, 300);
}

function goToPayment() {
    // Kiểm tra có dữ liệu không
    if (!bookingData.customerName || !bookingData.customerPhone) {
        alert('Vui lòng điền thông tin trước!');
        return;
    }

    // Chuyển màn hình
    document.getElementById('bookingScreen').classList.remove('active');
    document.getElementById('paymentScreen').classList.add('active');

    // Cập nhật số tiền deposit
    document.getElementById('depositAmount').textContent = formatPrice(bookingData.depositAmount);
    
    // Cập nhật thông tin khách hàng
    document.getElementById('paymentCustomerName').textContent = bookingData.customerName;
    document.getElementById('paymentCustomerPhone').textContent = bookingData.customerPhone;
    document.getElementById('rentalId').textContent = bookingData.bookingId || '-';
    
    // Get booking from session
    const pendingBooking = sessionStorage.getItem('pendingBooking');
    if (pendingBooking) {
        const booking = JSON.parse(pendingBooking);
        document.getElementById('paymentPickupDate').textContent = formatDateTime(booking.startTime);
        document.getElementById('paymentReturnDate').textContent = formatDateTime(booking.endTime);
        document.getElementById('paymentCarName').textContent = booking.carName || 'Xe đã chọn';
        document.getElementById('paymentCarType').textContent = booking.carName || '-';
        document.getElementById('paymentDateRange').textContent = 
            `${formatDate(booking.startTime)} - ${formatDate(booking.endTime)}`;
        
        // Update total price
        document.getElementById('totalPrice').innerHTML = `
            <div class="price-row total">
                <span>Tổng cộng tiền thuê xe</span>
                <span>${formatPrice(booking.totalPrice)}</span>
            </div>
        `;
        
        // Update payment steps
        document.getElementById('paymentStepsDetail').innerHTML = `
            <div class="step">
                <span class="step-number">1</span>
                <div>
                    <strong>Thanh toán giữ chỗ qua DriveNow</strong>
                    <p>30% tổng tiền = ${formatPrice(bookingData.depositAmount)}<br>Tiền này sẽ trừ vào tổng tiền thuê xe</p>
                </div>
            </div>
            <div class="step">
                <span class="step-number">2</span>
                <div>
                    <strong>Thanh toán khi nhận xe</strong>
                    <p>Tiền chặp: ${formatPrice(booking.totalPrice - bookingData.depositAmount)}<br>Số tiền sẽ thanh toán khi trả xe: ${formatPrice(booking.totalPrice)}</p>
                </div>
            </div>
        `;
    }

    // Generate QR Code
    generateQRCode();

    // Hiển thị thông tin VAT nếu có
    updateVATInfo();

    // Bắt đầu đếm ngược
    startTimer();
    
    // Start polling payment status
    startPaymentPolling();
    
    window.scrollTo(0, 0);
}

function generateQRCode() {
    const qrContainer = document.getElementById('qrCodeContainer');
    
    if (bookingData.paymentUrl) {
        // Use paymentUrl from VNPay to generate QR
        qrContainer.innerHTML = `
            <img src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(bookingData.paymentUrl)}" 
                 alt="QR Code" style="width: 200px; height: 200px;">
        `;
    } else {
        // Fallback: Generate QR with booking info
        const qrData = `Booking ${bookingData.bookingId} - ${formatPrice(bookingData.depositAmount)}`;
        qrContainer.innerHTML = `
            <img src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(qrData)}" 
                 alt="QR Code" style="width: 200px; height: 200px;">
        `;
    }
}

function formatDate(dateStr) {
    if (!dateStr) return '-';
    const date = new Date(dateStr);
    return date.toLocaleDateString('vi-VN');
}

function updateVATInfo() {
    const vatInfoSection = document.getElementById('vatInfoSection');

    if (bookingData.hasVAT && bookingData.companyName) {
        vatInfoSection.style.display = 'block';
        document.getElementById('paymentCompanyName').textContent = bookingData.companyName || '-';
        document.getElementById('paymentCompanyAddress').textContent = bookingData.companyAddress || '-';
        document.getElementById('paymentTaxCode').textContent = bookingData.taxCode || '-';
        document.getElementById('paymentCompanyEmail').textContent = bookingData.companyEmail || '-';
    } else {
        vatInfoSection.style.display = 'none';
    }
}

function goToBooking() {
    if (timerInterval) {
        clearInterval(timerInterval);
    }

    // Reset thời gian
    timeLeft = 900;

    document.getElementById('paymentScreen').classList.remove('active');
    document.getElementById('bookingScreen').classList.add('active');
    window.scrollTo(0, 0);
}

function startTimer() {
    const timeDisplay = document.getElementById('timeDisplay');

    timerInterval = setInterval(() => {
        const minutes = Math.floor(timeLeft / 60);
        const seconds = timeLeft % 60;
        timeDisplay.textContent = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;

        timeLeft--;

        if (timeLeft < 0) {
            clearInterval(timerInterval);
            alert('Hết thời gian giữ xe! Vui lòng đặt lại.');
            goToBooking();
            resetForm();
        }
    }, 1000);
}

function resetForm() {
    document.getElementById('customerName').value = '';
    document.getElementById('customerPhone').value = '';
    document.getElementById('vatCheckbox').checked = false;
    document.getElementById('vatForm').classList.remove('active');

    // Reset bookingData
    bookingData = {
        customerName: '',
        customerPhone: '',
        hasVAT: false,
        companyName: '',
        companyAddress: '',
        taxCode: '',
        companyEmail: ''
    };

    timeLeft = 900;
}

function toggleVATForm() {
    const checkbox = document.getElementById('vatCheckbox');
    const vatForm = document.getElementById('vatForm');

    if (checkbox.checked) {
        vatForm.classList.add('active');
    } else {
        vatForm.classList.remove('active');
    }
}

function updateProgress(currentStep, isPaymentSuccess = false) {
  const steps = document.querySelectorAll('.progress-step');
  
  steps.forEach((step, index) => {
    // Bỏ hết class trước
    step.classList.remove('active');

    // Nếu là bước cuối (thanh toán)
    if (index === steps.length - 1) {
      if (isPaymentSuccess) step.classList.add('active'); // Chỉ xanh khi thanh toán thành công
    } 
    // Còn lại, chỉ tích xanh khi đã qua bước đó
    else if (index < currentStep) {
      step.classList.add('active');
    }
  });
}

// Check payment status (simulate callback or poll)
async function checkPaymentStatus() {
    if (!bookingData.bookingId) return;
    
    try {
        const response = await fetch(`${API_BASE_URL}/bookings/${bookingData.bookingId}`);
        if (response.ok) {
            const data = await response.json();
            const booking = data.booking;
            
            if (booking.paymentStatus === 'paid') {
                clearInterval(timerInterval);
                updateProgress(4, true);
                alert('✅ Thanh toán thành công!\n\nĐơn hàng của bạn đã được xác nhận.');
                window.location.href = `booking-detail.html?id=${bookingData.bookingId}`;
            }
        }
    } catch (error) {
        console.error('Error checking payment:', error);
    }
}

// Poll payment status every 5 seconds when on payment screen
function startPaymentPolling() {
    const pollInterval = setInterval(() => {
        const paymentScreen = document.getElementById('paymentScreen');
        if (paymentScreen && paymentScreen.classList.contains('active')) {
            checkPaymentStatus();
        } else {
            clearInterval(pollInterval);
        }
    }, 5000);
}
