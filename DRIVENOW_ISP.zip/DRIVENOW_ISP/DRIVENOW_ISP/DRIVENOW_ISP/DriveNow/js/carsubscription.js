// Mapping from short codes to full city names
const cityMapping = {
    'hn': 'Hà Nội',
    'hcm': 'Hồ Chí Minh',
    'dn': 'Đà Nẵng',
    'hp': 'Hải Phòng',
    'ct': 'Cần Thơ',
    'bd': 'Bình Dương',
    'dn2': 'Đồng Nai',
    'kh': 'Khánh Hòa',
    'lc': 'Lâm Đồng',
    'vt': 'Vũng Tàu'
};

// Get city name from URL parameters or localStorage
function getCityName() {
    // Try to get from URL parameters first
    const urlParams = new URLSearchParams(window.location.search);
    let cityName = urlParams.get('city');
    
    // If not in URL, try localStorage
    if (!cityName) {
        cityName = localStorage.getItem('selectedCity');
    // DEBUG: Check if api and API_BASE_URL are available
    console.log('DEBUG: window.api =', window.api);
    try {
        console.log('DEBUG: API_BASE_URL =', API_BASE_URL);
    } catch (e) {
        console.error('DEBUG: API_BASE_URL is not defined!', e);
    }
    }
    
    // Decode URI component to get full city name
    if (cityName) {
        cityName = decodeURIComponent(cityName);
        
        // Check if it's a short code and convert to full name
        const lowerCityName = cityName.toLowerCase();
        if (cityMapping[lowerCityName]) {
            cityName = cityMapping[lowerCityName];
        }
    }
    
    // Default city if nothing is found
    return cityName || 'Chọn thành phố';
}

// Update city name in the page
function updateCityDisplay() {
    const cityName = getCityName();
    const cityDisplayElement = document.querySelector('.city-name');
    
    if (cityDisplayElement) {
        cityDisplayElement.textContent = cityName;
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    updateCityDisplay();

    // Handle car type selection
    document.querySelectorAll('.car-type-item').forEach(item => {
        item.addEventListener('click', () => {
            document.querySelectorAll('.car-type-item').forEach(i => i.classList.remove('active'));
            item.classList.add('active');
        });
    });

    // Handle brand selection
    document.querySelectorAll('.brand-card-item').forEach(item => {
        item.addEventListener('click', () => {
            document.querySelectorAll('.brand-card-item').forEach(i => i.classList.remove('active'));
            item.classList.add('active');
        });
    });
});

// Lấy tên thành phố từ URL hoặc localStorage
const urlParams = new URLSearchParams(window.location.search);
const cityFromUrl = urlParams.get('city');
const cityFromStorage = localStorage.getItem('selectedCity');
    
// Mapping tên thành phố đầy đủ (hỗ trợ cả chữ hoa và chữ thường)
const cityFullNames = {
    'Hà Nội': 'Hà Nội',
    'hà nội': 'Hà Nội',
    'HN': 'Hà Nội',
    'hn': 'Hà Nội',
    'Hồ Chí Minh': 'Hồ Chí Minh',
    'hồ chí minh': 'Hồ Chí Minh',
    'HCM': 'Hồ Chí Minh',
    'hcm': 'Hồ Chí Minh',
    'Đà Nẵng': 'Đà Nẵng',
    'đà nẵng': 'Đà Nẵng',
    'DN': 'Đà Nẵng',
    'dn': 'Đà Nẵng',
};

// Lấy tên thành phố (ưu tiên từ URL, sau đó localStorage)
let cityCode = cityFromUrl || cityFromStorage;
let cityName = 'Chọn thành phố';
    
// Nếu có cityCode, tìm trong mapping
if (cityCode) {
    // Thử tìm trực tiếp
    if (cityFullNames[cityCode]) {
        cityName = cityFullNames[cityCode];
    } 
    // Thử tìm với chữ thường
    else if (cityFullNames[cityCode.toLowerCase()]) {
        cityName = cityFullNames[cityCode.toLowerCase()];
    }
    // Nếu không tìm thấy, giữ nguyên cityCode
    else {
        cityName = cityCode;
    }
}

// Hiển thị tên thành phố
const cityNameElement = document.getElementById('cityName');
if (cityNameElement) {
    cityNameElement.textContent = cityName;
}

// Lưu tên đầy đủ vào localStorage để sử dụng sau
if (cityCode) {
    localStorage.setItem('selectedCity', cityCode);
    localStorage.setItem('selectedCityFullName', cityName);
}

// Xử lý nút back
const backBtn = document.querySelector('.back-btn');
if (backBtn) {
    backBtn.addEventListener('click', function() {
        window.history.back();
    });
}

// Xử lý filter buttons
const filterBtns = document.querySelectorAll('.filter-btn');
    
filterBtns.forEach(btn => {
    btn.addEventListener('click', function() {
        // Remove active class from all buttons
        filterBtns.forEach(b => b.classList.remove('active'));
        
        // Add active class to clicked button
        this.classList.add('active');
        
        // Lấy filter type
        const filterType = this.textContent.trim();
        console.log('Filter selected:', filterType);
        
        // TODO: Thêm logic lọc xe theo filter type
        filterCars(filterType);
    });
});

// Function to filter cars
// --- Lưu filter state ---
// Use page-scoped names to avoid clashing with other pages (e.g., searchcar.js)
let subscriptionSelectedCarType = null;
let subscriptionSelectedBrand = null;
let subscriptionSelectedTransmission = null;

// Gọi API backend lấy xe dài hạn với filter
async function loadLongTermCars() {
    const city = getCityName();
    const carGrid = document.querySelector('#car-grid');
    if (carGrid) carGrid.innerHTML = '<p>Đang tải danh sách xe...</p>';

    try {
        // Pass selected filters to API helper so backend receives them
        const options = {
            carType: subscriptionSelectedCarType,
            brand: subscriptionSelectedBrand,
            transmissionType: subscriptionSelectedTransmission,
            // seatCapacity and fuelType are available if you add UI controls for them
        };

        const response = await api.getSubscriptionCars(city, options);

        // Support both response shapes: { success, data: [...] } or { success, cars: [...] }
        const cars = (response && response.data) ? response.data : (response && response.cars) ? response.cars : [];

        if (response && response.success && cars && cars.length > 0) {
            displayCars(cars);
        } else {
            if (carGrid) carGrid.innerHTML = '<p>Không tìm thấy xe nào cho khu vực này.</p>';
        }
    } catch (error) {
        if (carGrid) carGrid.innerHTML = `<p class="error">Lỗi khi tải danh sách xe: ${error.message}</p>`;
    }
}

// Gọi lại API khi filter thay đổi
function filterCars(filterType) {
    // Xác định loại filter và cập nhật biến
    if (filterType === 'Tất cả') {
        // Reset filter state
        subscriptionSelectedCarType = null;
        subscriptionSelectedBrand = null;
        subscriptionSelectedTransmission = null;

        // Reset UI selections (remove active classes)
        document.querySelectorAll('.car-type-item').forEach(i => i.classList.remove('active'));
        document.querySelectorAll('.brand-card-item').forEach(i => i.classList.remove('active'));

        // Reset transmission radio to 'all'
        const allRadio = document.querySelector('input[name="transmissionOption"][value="all"]');
        if (allRadio) allRadio.checked = true;
    }

    // Có thể mở rộng cho các filter khác nếu cần
    loadLongTermCars();
}

// --- Gắn sự kiện cho filter modal ---
document.addEventListener('DOMContentLoaded', function() {
    // Car type
    document.querySelectorAll('.car-type-item').forEach(item => {
        item.addEventListener('click', () => {
            subscriptionSelectedCarType = item.dataset.type || null;
        });
    });
    // Brand
    document.querySelectorAll('.brand-card-item').forEach(item => {
        item.addEventListener('click', () => {
            subscriptionSelectedBrand = item.dataset.brand || null;
        });
    });
    // Transmission
    document.querySelectorAll('input[name="transmissionOption"]').forEach(radio => {
        radio.addEventListener('change', () => {
            const val = radio.value;
            if (val === 'all') subscriptionSelectedTransmission = null;
            else if (val === 'auto') subscriptionSelectedTransmission = 'Tự động';
            else if (val === 'manual') subscriptionSelectedTransmission = 'Số sàn';
        });
    });
    // Áp dụng filter khi đóng modal
    document.querySelectorAll('.btn-apply-full').forEach(btn => {
        btn.addEventListener('click', () => {
            loadLongTermCars();
        });
    });
    // Gọi API lần đầu khi trang load
    loadLongTermCars();
});

// Load cars for the selected city
async function loadCarsForCity(cityName) {
    console.log('Loading cars for city:', cityName);
    const carGrid = document.querySelector('.cars-grid');
    if (!carGrid) return;

    carGrid.innerHTML = '<p>Đang tải danh sách xe...</p>'; // Loading message

    try {
        const options = {
            carType: subscriptionSelectedCarType,
            brand: subscriptionSelectedBrand,
            transmissionType: subscriptionSelectedTransmission
        };
        const response = await api.getSubscriptionCars(cityName, options);
        if (response.success && response.data && response.data.length > 0) {
            displayCars(response.data);
        } else {
            carGrid.innerHTML = '<p>Không tìm thấy xe nào cho khu vực này.</p>';
        }
    } catch (error) {
        carGrid.innerHTML = `<p class="error">Lỗi khi tải danh sách xe: ${error.message}</p>`;
    }
}

// Function to display cars in the bootstrap grid like the search page
function displayCars(cars) {
    const carGrid = document.querySelector('#car-grid');
    if (!carGrid) return;

    carGrid.innerHTML = ''; // Clear loading message

    if (!cars || cars.length === 0) {
        carGrid.innerHTML = '<p>Không tìm thấy xe nào cho khu vực này.</p>';
        return;
    }

    cars.forEach(car => {
        // Normalize property names used by the search page
        const imageUrl = car.imageUrl || car.image_url || (car.images && car.images[0]) || '../assets/inmage/default-car.png';
        const price = car.pricePerDay || car.price_per_day || car.dailyRate || car.daily_rate || car.price || car.monthlyPrice || car.pricePerMonth || 0;
        const formattedPrice = new Intl.NumberFormat('vi-VN').format(price);
        const transmission = car.transmissionType || car.transmission || car.transmission_type || 'N/A';
        const fuelType = car.fuelType || car.fuel_type || car.fuel || 'N/A';
        const carName = car.name || ((car.brand || '') + ' ' + (car.model || '')).trim();
        const seatCapacity = car.seatCapacity || car.seat_capacity || car.seats || 'N/A';
        const location = car.location || car.city || 'Hà Nội';
        const status = car.status || car.availability || 'Available';
        const statusBadge = (status === 'Có sẵn' || status === 'Available' || status === 'Sẵn sàng') ? '<span class="car-badge available">Sẵn sàng</span>' : '';

        // Create bootstrap column wrapper to match layout
        const col = document.createElement('div');
        col.className = 'col';

        const card = document.createElement('div');
        card.className = 'car-card card border-0 shadow-sm h-100';

        card.innerHTML = `
            <div class="car-card-image position-relative">
                <img src="${imageUrl}" alt="${escapeHtml(carName)}" class="card-img-top" onerror="this.src='../assets/inmage/default-car.png'" />
                ${statusBadge}
            </div>
            <div class="card-body">
                <h5 class="card-title car-name">${escapeHtml(carName)}</h5>
                <div class="car-specs d-flex gap-3 mb-2">
                    <div class="spec-item"><i class="fas fa-users"></i> <span>${seatCapacity} chỗ</span></div>
                    <div class="spec-item"><i class="fas fa-cog"></i> <span>${escapeHtml(transmission)}</span></div>
                    <div class="spec-item"><i class="fas fa-gas-pump"></i> <span>${escapeHtml(fuelType)}</span></div>
                </div>
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <div class="car-price">
                        <div class="price-amount text-success fw-bold">${formattedPrice}₫</div>
                        <div class="price-unit text-muted">/ngày</div>
                    </div>
                    <button class="btn btn-success btn-rent" onclick="viewCarDetail(${car.id || car.carId || car._id || 0})">Thuê xe</button>
                </div>
            </div>
        `;

        col.appendChild(card);
        carGrid.appendChild(col);
    });
}

// small helper to avoid XSS when injecting names
function escapeHtml(unsafe) {
    if (!unsafe && unsafe !== 0) return '';
    return String(unsafe).replace(/[&<>"'`]/g, function (m) { return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":"&#39;","`":"&#96;"})[m]; });
}
