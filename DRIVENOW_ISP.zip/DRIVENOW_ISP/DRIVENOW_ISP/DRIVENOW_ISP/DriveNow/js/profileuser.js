// profileuser.js - Hiển thị thông tin khách hàng và xử lý click tên

const API_BASE_URL = 'http://localhost:8080';

document.addEventListener('DOMContentLoaded', async function() {
    // Kiểm tra đăng nhập từ localStorage
    let userData = localStorage.getItem('userData') || localStorage.getItem('currentUser');
    
    if (!userData) {
        alert('Vui lòng đăng nhập để xem thông tin tài khoản');
        window.location.href = 'login.html';
        return;
    }

    try {
        userData = JSON.parse(userData);
    } catch (e) {
        console.error('Lỗi parse userData:', e);
        window.location.href = 'login.html';
        return;
    }

    const accountId = userData.accountId || userData.id;
    if (!accountId) {
        console.error('Không tìm thấy accountId');
        window.location.href = 'login.html';
        return;
    }

    // Fetch dữ liệu từ backend
    try {
        const token = localStorage.getItem('token');
        const headers = {
            'Content-Type': 'application/json'
        };
        if (token) {
            headers['Authorization'] = `Bearer ${token}`;
        }

        const response = await fetch(`${API_BASE_URL}/api/accounts/${accountId}`, {
            method: 'GET',
            headers: headers
        });

        if (!response.ok) {
            throw new Error('Không thể tải thông tin tài khoản');
        }

        const accountData = await response.json();
        console.log('Account data from API:', accountData);

        // Hiển thị thông tin user
        displayUserInfo(accountData);

    } catch (error) {
        console.error('Lỗi khi tải thông tin:', error);
        // Fallback: hiển thị từ localStorage nếu API lỗi
        displayUserInfo(userData);
    }
});

function displayUserInfo(user) {
    // Hiển thị tên
    const fullName = user.fullName || user.name || user.username || 'Khách hàng';
    document.getElementById('profileName').textContent = fullName;

    // Hiển thị ngày tham gia
    let joinDate = '--/--/----';
    if (user.createdAt) {
        const date = new Date(user.createdAt);
        joinDate = `${date.getDate().toString().padStart(2, '0')}/${(date.getMonth() + 1).toString().padStart(2, '0')}/${date.getFullYear()}`;
    }
    document.getElementById('joinDate').textContent = joinDate;

    // Hiển thị ngày sinh
    let dob = '--/--/----';
    if (user.dob || user.dateOfBirth) {
        const dobValue = user.dob || user.dateOfBirth;
        const date = new Date(dobValue);
        dob = `${date.getDate().toString().padStart(2, '0')}/${(date.getMonth() + 1).toString().padStart(2, '0')}/${date.getFullYear()}`;
    }
    document.getElementById('dob').textContent = dob;

    // Hiển thị giới tính
    const genderMap = {
        'Male': 'Nam',
        'Female': 'Nữ',
        'Other': 'Khác',
        'male': 'Nam',
        'female': 'Nữ'
    };
    const gender = genderMap[user.gender] || user.gender || '---';
    document.getElementById('gender').textContent = gender;

    // Hiển thị số điện thoại
    const phone = user.phone || user.phoneNumber || user.sdt || user.mobile || '---';
    document.getElementById('phone').textContent = phone;

    // Hiển thị email
    const email = user.email || user.username || '---';
    document.getElementById('email').textContent = email;

    // Hiển thị avatar
    const avatarUrl = user.avatar || user.avatarUrl || '../assets/icons/user-avatar.svg';
    document.getElementById('avatarImg').src = avatarUrl;
}

// Khi nhấn vào tên khách hàng - sẽ setup sau khi load xong
setTimeout(() => {
    const profileNameEl = document.getElementById('profileName');
    if (profileNameEl) {
        profileNameEl.style.cursor = 'pointer';
        profileNameEl.addEventListener('click', function() {
            alert('Bạn đã nhấn vào tên khách hàng!');
            // Có thể mở modal chỉnh sửa thông tin ở đây
        });
    }
}, 100);

// Đăng xuất khi nhấn vào menu Đăng xuất
const logoutMenu = document.querySelector('.menu li:last-child');
if (logoutMenu) {
    logoutMenu.style.cursor = 'pointer';
    logoutMenu.addEventListener('click', function() {
        if (confirm('Bạn có chắc muốn đăng xuất?')) {
            localStorage.removeItem('token');
            localStorage.removeItem('userData');
            localStorage.removeItem('currentUser');
            window.location.href = 'homepage.html';
        }
    });
}

// Click logo DriveNow để về homepage
const logo = document.getElementById('logoDriveNow');
if (logo) {
    logo.addEventListener('click', function() {
        window.location.href = 'homepage.html';
    });
}

// Chuyển sang trang đổi mật khẩu khi nhấn menu Đổi mật khẩu
const menuItems = document.querySelectorAll('.menu li');
// Đổi mật khẩu là mục thứ 5 (bắt đầu từ 0)
if (menuItems[4]) {
    menuItems[4].style.cursor = 'pointer';
    menuItems[4].addEventListener('click', function() {
        window.location.href = 'changepassword.html';
    });
}
