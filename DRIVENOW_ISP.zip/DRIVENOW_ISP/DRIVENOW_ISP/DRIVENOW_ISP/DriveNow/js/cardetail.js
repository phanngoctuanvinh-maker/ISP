// ============================================
// CARDETAIL.JS - CHI TIẾT XE
// ============================================

const API_BASE_URL = 'http://localhost:8080/api';

// ============================================
// GLOBAL VARIABLES
// ============================================
let currentCar = null;
let bookingData = {
    startDate: null,
    startTime: null,
    endDate: null,
    endTime: null,
    pickupLocation: '',
    dropoffLocation: '',
    areaType: 'oneway', // local, intercity, oneway
    distanceKm: 0,
    // Các giá trị này sẽ được backend tính toán và trả về
    rentalDays: 0,
    rentalHours: 0,
    basePrice: 0,
    insuranceFee: 0,
    serviceFee: 0,
    exceedFee: 0,
    totalPrice: 0,
    allowedKm: null,
    extraKm: 0
};

// ============================================
// HELPER: CHECK LOGIN STATUS
// ============================================
function getCurrentUser() {
    // Thử lấy từ localStorage
    const currentUserStr = localStorage.getItem('currentUser');
    const token = localStorage.getItem('token');
    
    console.log('🔍 Checking login status...');
    console.log('Token:', token ? 'exists' : 'not found');
    console.log('CurrentUser:', currentUserStr ? 'exists' : 'not found');
    
    if (!currentUserStr || !token) {
        return null;
    }
    
    try {
        const user = JSON.parse(currentUserStr);
        console.log('✅ User data:', user);
        return user;
    } catch (error) {
        console.error('❌ Error parsing user data:', error);
        return null;
    }
}

function getUserId(user) {
    // Log toàn bộ để debug
    console.log('🔍 Trying to find user ID from:', JSON.stringify(user, null, 2));
    
    // Ưu tiên lấy customerId, nếu không có thì dùng accountId
    const possibleIds = [
        user?.customerId,       // Nếu backend đã trả customerId
        user?.customer_id,      // Snake case
        user?.id,               // Generic ID
        user?.accountId,        // Account ID (có thể dùng tạm)
        user?.account_id,       // Snake case
        user?.userId,
        user?.user?.id,
        user?.user?.customerId,
        user?.customer?.id,
        user?.customer?.customerId,
        user?.data?.id,
        user?.data?.customerId
    ];
    
    console.log('📋 Possible IDs found:', possibleIds.filter(id => id != null));
    
    // Lấy ID đầu tiên không null/undefined
    const foundId = possibleIds.find(id => id != null);
    
    if (foundId) {
        console.log('✅ Using ID:', foundId);
        console.log('⚠️ Note: Nếu dùng accountId, backend cần convert sang customerId');
        return foundId;
    }
    
    console.log('❌ No ID found in any field');
    return null;
}

// ============================================
// 1. LẤY THÔNG TIN XE TỪ URL
// ============================================
function getCarIdFromURL() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('id');
}

// ============================================
// 2. GỌI API LẤY CHI TIẾT XE
// ============================================
async function fetchCarDetail(carId) {
    try {
        const response = await fetch(`${API_BASE_URL}/cars/${carId}`);
        
        if (!response.ok) {
            throw new Error('Không tìm thấy xe');
        }
        
        const car = await response.json();
        return car;
    } catch (error) {
        console.error('Lỗi khi lấy thông tin xe:', error);
        alert('Không thể tải thông tin xe. Vui lòng thử lại!');
        return null;
    }
}

// ============================================
// 3. RENDER THÔNG TIN XE LÊN GIAO DIỆN
// ============================================
function renderCarDetail(car) {
    // Update title
    document.querySelector('.car-title').textContent = 
        `${car.brand} ${car.name} ${car.year || ''}`;
    
    // Update subtitle (location)
    document.querySelector('.car-subtitle').textContent = 
        `📍 ${car.location || 'Chưa cập nhật vị trí'} • ⭐ Đánh giá: Chưa có • Số chuyến: 0`;
    
    // Update price
    document.querySelector('.booking-price .price-value').textContent = 
        formatPrice(car.pricePerDay) + '/ngày';
    
    // Update features
    updateFeatures(car);
    
    // Update description
    document.querySelector('.car-section p').textContent = 
        car.description || 'Chưa có mô tả';
    
    // Update amenities (mock data - cần table riêng trong DB thật)
    updateAmenities(car);
    
    // Update images (mock - cần table car_images)
    updateImages(car);
    
    // Update booking info
    updateBookingInfo(car);
}

// ============================================
// 4. CẬP NHẬT ĐẶC ĐIỂM XE
// ============================================
function updateFeatures(car) {
    const featuresHTML = `
        <div class="feature-item">
            <i class="fas fa-cogs feature-icon"></i>
            <div>
                <span class="feature-label">Truyền động</span>
                <strong class="feature-value">${car.transmissionType || 'N/A'}</strong>
            </div>
        </div>
        <div class="feature-item">
            <i class="fas fa-chair feature-icon"></i>
            <div>
                <span class="feature-label">Số ghế</span>
                <strong class="feature-value">${car.seatCapacity || 'N/A'} chỗ</strong>
            </div>
        </div>
        <div class="feature-item">
            <i class="fas fa-gas-pump feature-icon"></i>
            <div>
                <span class="feature-label">Nhiên liệu</span>
                <strong class="feature-value">${car.fuelType || 'N/A'}</strong>
            </div>
        </div>
        <div class="feature-item">
            <i class="fas fa-car feature-icon"></i>
            <div>
                <span class="feature-label">Loại xe</span>
                <strong class="feature-value">${car.carType || 'N/A'}</strong>
            </div>
        </div>
        <div class="feature-item">
            <i class="fas fa-palette feature-icon"></i>
            <div>
                <span class="feature-label">Màu sắc</span>
                <strong class="feature-value">${car.color || 'N/A'}</strong>
            </div>
        </div>
        <div class="feature-item">
            <i class="fas fa-tachometer-alt feature-icon"></i>
            <div>
                <span class="feature-label">Số km đã đi</span>
                <strong class="feature-value">${car.mileage ? car.mileage.toLocaleString() + ' km' : 'N/A'}</strong>
            </div>
        </div>
    `;
    
    document.querySelector('.features-grid').innerHTML = featuresHTML;
}

// ============================================
// 5. CẬP NHẬT TIỆN NGHI
// ============================================
function updateAmenities(car) {
    // Mock amenities - trong thực tế cần table car_features
    const amenities = [
        { icon: 'fab fa-bluetooth-b', name: 'Bluetooth' },
        { icon: 'fas fa-camera-retro', name: 'Camera lùi' },
        { icon: 'fas fa-broadcast-tower', name: 'Cảm biến va chạm' },
        { icon: 'fas fa-tachometer-alt', name: 'Cảnh báo tốc độ' },
        { icon: 'fas fa-circle-notch', name: 'Lốp dự phòng' },
        { icon: 'fas fa-road', name: 'ETC' },
        { icon: 'fas fa-shield-alt', name: 'Túi khí an toàn' }
    ];
    
    const amenitiesHTML = amenities.map(amenity => 
        `<div class="amenity-item"><i class="${amenity.icon}"></i> ${amenity.name}</div>`
    ).join('');
    
    document.querySelector('.amenities-grid').innerHTML = amenitiesHTML;
}

// ============================================
// 6. CẬP NHẬT HÌNH ẢNH
// ============================================
function updateImages(car) {
    const imageUrl = car.imageUrl || '../assets/inmage/default-car.jpg';
    
    // Main image
    const mainGallery = document.querySelector('.image-gallery-main');
    mainGallery.style.backgroundImage = `url(${imageUrl})`;
    mainGallery.style.backgroundSize = 'cover';
    mainGallery.style.backgroundPosition = 'center';
    
    // Side images (giống main vì chưa có nhiều ảnh)
    const sideGalleries = document.querySelectorAll('.image-gallery-side');
    sideGalleries.forEach((gallery, index) => {
        if (index < 2) { // Chỉ 2 ảnh đầu
            gallery.style.backgroundImage = `url(${imageUrl})`;
            gallery.style.backgroundSize = 'cover';
            gallery.style.backgroundPosition = 'center';
        }
    });
}

// ============================================
// 7. CẬP NHẬT THÔNG TIN BOOKING
// ============================================
function updateBookingInfo(car) {
    // Store car globally
    currentCar = car;
    
    // Update km limit & exceed fee
    const infoSection = document.querySelector('.itinerary-info-section');
    
    if (car.dailyKmLimit && car.exceedFeePerKm) {
        infoSection.innerHTML = `
            <h6 class="section-subtitle">Thông tin lộ trình</h6>
            <div class="info-item">
                <span>Giới hạn km/ngày</span>
                <strong>${car.dailyKmLimit} km</strong>
            </div>
            <div class="info-item">
                <span>Phí vượt giới hạn</span>
                <strong>${formatPrice(car.exceedFeePerKm)}/km</strong>
            </div>
        `;
    } else if (!car.dailyKmLimit || car.dailyKmLimit === null) {
        infoSection.innerHTML = `
            <h6 class="section-subtitle">Thông tin lộ trình</h6>
            <div class="info-item">
                <span>Giới hạn km/ngày</span>
                <strong class="text-success">Không giới hạn</strong>
            </div>
            <div class="info-item">
                <span>Phí vượt giới hạn</span>
                <strong class="text-success">Miễn phí</strong>
            </div>
        `;
    }
    
    // Update fuel consumption
    if (car.fuelConsumption && car.fuelConsumption > 0) {
        const fuelInfo = `
            <div class="info-item mt-2">
                <span>Mức tiêu thụ nhiên liệu</span>
                <strong>${car.fuelConsumption} L/100km</strong>
            </div>
        `;
        infoSection.innerHTML += fuelInfo;
    }
}

// ============================================
// 8. ITINERARY LOGIC (GIỐNG CŨ)
// ============================================
function initializeItinerary() {
    const itineraryRadios = document.querySelectorAll('input[name="itinerary"]');
    const itineraryLocal = document.getElementById('itinerary-local');
    const itineraryIntercity = document.getElementById('itinerary-intercity');
    const itineraryNote = itineraryIntercity?.querySelector('.itinerary-note');
    const itineraryFees = document.getElementById('itinerary-info-fees');

    const notes = {
        local: 'Di chuyển nội thành hoặc lân cận, lộ trình tự do. <i class="far fa-question-circle"></i>',
        intercity: 'Di chuyển liên tỉnh, trả khách về lại điểm đón. <i class="far fa-question-circle"></i>',
        oneway: 'Di chuyển liên tỉnh, trả khách tại điểm đến. <i class="far fa-question-circle"></i>'
    };

    function updateItineraryView(selectedValue) {
        if (!itineraryLocal || !itineraryIntercity) return;
        
        if (selectedValue === 'local') {
            itineraryLocal.style.display = 'block';
            itineraryIntercity.style.display = 'none';
            if (itineraryFees) itineraryFees.style.display = 'none';
        } else {
            itineraryLocal.style.display = 'none';
            itineraryIntercity.style.display = 'block';
            if (itineraryFees) itineraryFees.style.display = 'block';
            if (itineraryNote) itineraryNote.innerHTML = notes[selectedValue];
        }
    }

    itineraryRadios.forEach(radio => {
        radio.addEventListener('change', function () {
            updateItineraryView(this.value);
        });
    });

    // Initial check
    const initialSelected = document.querySelector('input[name="itinerary"]:checked');
    if (initialSelected) {
        updateItineraryView(initialSelected.value);
    }
}

// ============================================
// 9. HELPER FUNCTIONS
// ============================================
function formatPrice(price) {
    if (!price) return '0đ';
    return new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND'
    }).format(price);
}

// ============================================
// 10. MAIN - KHỞI ĐỘNG TRANG
// ============================================
document.addEventListener('DOMContentLoaded', async function () {
    // Lấy ID từ URL
    const carId = getCarIdFromURL();
    
    if (!carId) {
        alert('Không tìm thấy ID xe!');
        window.location.href = 'searchcar.html';
        return;
    }
    
    // Fetch & Render car detail
    const car = await fetchCarDetail(carId);
    
    if (car) {
        renderCarDetail(car);
    }
    
    // Initialize itinerary logic
    initializeItinerary();
    
    // Add event listeners
    setupEventListeners();
});

// ============================================
// 11. TÍNH TOÁN GIÁ BOOKING (GỌI API BACKEND)
// ============================================

/**
 * Gọi API backend để tính giá booking
 */
async function calculateBookingPrice() {
    if (!currentCar) return;
    
    // Validate dates
    if (!bookingData.startDate || !bookingData.startTime || 
        !bookingData.endDate || !bookingData.endTime) {
        return;
    }
    
    // Prepare request
    const priceRequest = {
        carId: currentCar.id,
        startDate: formatDateTimeForAPI(bookingData.startDate, bookingData.startTime),
        endDate: formatDateTimeForAPI(bookingData.endDate, bookingData.endTime),
        pickupLocation: bookingData.pickupLocation,
        dropoffLocation: bookingData.dropoffLocation,
        areaType: bookingData.areaType,
        distanceKm: bookingData.distanceKm
    };
    
    try {
        // Gọi API backend
        const response = await fetch(`${API_BASE_URL}/bookings/calculate-price`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(priceRequest)
        });
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.message || 'Không thể tính giá');
        }
        
        const result = await response.json();
        const priceDetails = result.priceDetails;
        
        // Cập nhật bookingData với kết quả từ backend
        bookingData.rentalDays = priceDetails.rentalDays;
        bookingData.rentalHours = priceDetails.rentalHours;
        bookingData.basePrice = priceDetails.basePrice;
        bookingData.insuranceFee = priceDetails.insuranceFee;
        bookingData.serviceFee = priceDetails.serviceFee;
        bookingData.exceedFee = priceDetails.exceedFee;
        bookingData.totalPrice = priceDetails.totalPrice;
        bookingData.allowedKm = priceDetails.allowedKm;
        bookingData.extraKm = priceDetails.extraKm;
        bookingData.distanceKm = priceDetails.distanceKm;
        
        // Cập nhật UI
        updateCostSummary();
        updateRentalDuration();
        
    } catch (error) {
        console.error('Error calculating price:', error);
        // Hiển thị thông báo lỗi nhẹ
        alert('Không thể tính giá. Vui lòng thử lại!');
    }
}

function updateCostSummary() {
    const costSummary = document.querySelector('.cost-summary');
    if (!costSummary) return;
    
    costSummary.innerHTML = `
        <div class="cost-item">
            <span>Giá thuê (${bookingData.rentalDays} ngày) <i class="far fa-question-circle"></i></span>
            <span>${formatPrice(bookingData.basePrice)}</span>
        </div>
        <div class="cost-item">
            <span>Bảo hiểm thuê xe <i class="far fa-question-circle"></i></span>
            <span>${formatPrice(bookingData.insuranceFee)}</span>
        </div>
        <div class="cost-item">
            <span>Phí dịch vụ ${bookingData.distanceKm > 0 ? '(' + bookingData.distanceKm + ' km)' : ''} <i class="far fa-question-circle"></i></span>
            <span>${formatPrice(bookingData.serviceFee)}</span>
        </div>
        ${bookingData.exceedFee > 0 ? `
        <div class="cost-item text-warning">
            <span>Phí vượt giới hạn km <i class="far fa-question-circle"></i></span>
            <span>${formatPrice(bookingData.exceedFee)}</span>
        </div>
        ` : ''}
        <div class="cost-item promo-code">
            <span><i class="fas fa-tags"></i> Mã khuyến mãi</span>
            <i class="fas fa-chevron-right"></i>
        </div>
        <hr>
        <div class="cost-item total">
            <strong>Thành tiền</strong>
            <strong>${formatPrice(bookingData.totalPrice)}</strong>
        </div>
    `;
}

function updateRentalDuration() {
    const durationEl = document.querySelector('.rental-duration');
    if (!durationEl) return;
    
    if (bookingData.rentalHours > 0) {
        if (bookingData.rentalDays >= 1) {
            durationEl.textContent = `Thời gian thuê xe: ${bookingData.rentalDays} ngày (${bookingData.rentalHours} giờ)`;
        } else {
            durationEl.textContent = `Thời gian thuê xe: ${bookingData.rentalHours} giờ`;
        }
    }
}

// ============================================
// 12. TẠO BOOKING
// ============================================
async function createBooking() {
    // Validate
    if (!currentCar) {
        alert('Không tìm thấy thông tin xe!');
        return;
    }
    
    if (!bookingData.startDate || !bookingData.startTime || 
        !bookingData.endDate || !bookingData.endTime) {
        alert('Vui lòng chọn thời gian nhận và trả xe!');
        return;
    }
    
    if (bookingData.areaType !== 'local' && !bookingData.dropoffLocation) {
        alert('Vui lòng nhập điểm đến!');
        return;
    }
    
    // Get customer info from localStorage
    const currentUser = getCurrentUser();
    
    if (!currentUser) {
        console.log('❌ User not logged in');
        
        // Hiển thị thông báo chi tiết
        const hasToken = !!localStorage.getItem('token');
        const hasUser = !!localStorage.getItem('currentUser');
        
        let message = 'Vui lòng đăng nhập để đặt xe!\n\n';
        message += '🔍 Debug info:\n';
        message += `- Token: ${hasToken ? '✅ Có' : '❌ Không có'}\n`;
        message += `- User data: ${hasUser ? '✅ Có' : '❌ Không có'}\n`;
        
        if (hasUser) {
            message += '\n⚠️ Có user data nhưng không parse được. Vui lòng đăng nhập lại!';
            localStorage.removeItem('currentUser');
            localStorage.removeItem('token');
        }
        
        alert(message);
        
        // Redirect to login
        window.location.href = '../html/login.html?redirect=' + encodeURIComponent(window.location.href);
        return;
    }
    
    const customerId = getUserId(currentUser);
    
    if (!customerId) {
        console.error('❌ Cannot find user ID in:', currentUser);
        alert('Lỗi: Không tìm thấy ID người dùng!\n\nCấu trúc user data không đúng. Vui lòng đăng nhập lại.');
        localStorage.removeItem('currentUser');
        localStorage.removeItem('token');
        window.location.href = '../html/login.html?redirect=' + encodeURIComponent(window.location.href);
        return;
    }
    
    console.log('✅ User ID found:', customerId);
    
    // Prepare booking request - MUST match backend BookingRequest field names
    const bookingRequest = {
        customerId: parseInt(customerId),
        carId: parseInt(currentCar.id),
        startTime: formatDateTimeForAPI(bookingData.startDate, bookingData.startTime), // Backend uses startTime
        endTime: formatDateTimeForAPI(bookingData.endDate, bookingData.endTime),       // Backend uses endTime
        pickupLocation: bookingData.pickupLocation,
        dropoffLocation: bookingData.dropoffLocation || bookingData.pickupLocation,
        totalAmount: bookingData.totalPrice,  // Backend uses totalAmount
        basePrice: bookingData.basePrice,
        insuranceFee: bookingData.insuranceFee,
        transferFee: bookingData.serviceFee,  // Map serviceFee to transferFee
        status: 'pending'
    };
    
    console.log('Creating booking:', bookingRequest);
    
    // Show loading
    const rentButton = document.querySelector('.btn-rent');
    const originalText = rentButton.innerHTML;
    rentButton.disabled = true;
    rentButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang xử lý...';
    
    try {
        const response = await fetch(`${API_BASE_URL}/bookings`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(bookingRequest)
        });
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.message || 'Đặt xe thất bại!');
        }
        
        const booking = await response.json();
        
        // Save booking data to sessionStorage for payment page
        sessionStorage.setItem('pendingBooking', JSON.stringify(booking));
        
        // Redirect to payment page
        window.location.href = `payment.html?bookingId=${booking.id}`;
        
    } catch (error) {
        console.error('Booking error:', error);
        alert('❌ Lỗi: ' + error.message);
        
        // Restore button
        rentButton.disabled = false;
        rentButton.innerHTML = originalText;
    }
}

function formatDateTimeForAPI(dateStr, timeStr) {
    // Convert "16/10/2025" + "08:00" => "2025-10-16T08:00:00"
    const [day, month, year] = dateStr.split('/');
    return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}T${timeStr}:00`;
}

function getStatusText(status) {
    const statusMap = {
        'pending': 'Chờ xác nhận',
        'confirmed': 'Đã xác nhận',
        'completed': 'Hoàn thành',
        'cancelled': 'Đã hủy'
    };
    return statusMap[status] || status;
}

// ============================================
// 13. XỬ LÝ DATETIME PICKER
// ============================================
function setupDateTimePickers() {
    // Lấy date/time inputs
    const dateTimeInputs = document.querySelectorAll('.date-time-inputs span');
    
    if (dateTimeInputs.length >= 4) {
        const startDateEl = dateTimeInputs[0];
        const startTimeEl = dateTimeInputs[1];
        const endDateEl = dateTimeInputs[2];
        const endTimeEl = dateTimeInputs[3];
        
        // Set default values (hiện tại + 2 giờ)
        const now = new Date();
        const startDate = new Date(now);
        const endDate = new Date(now.getTime() + 2 * 60 * 60 * 1000); // +2 hours
        
        bookingData.startDate = formatDateDisplay(startDate);
        bookingData.startTime = formatTimeDisplay(startDate);
        bookingData.endDate = formatDateDisplay(endDate);
        bookingData.endTime = formatTimeDisplay(endDate);
        
        startDateEl.textContent = bookingData.startDate;
        startTimeEl.textContent = bookingData.startTime;
        endDateEl.textContent = bookingData.endDate;
        endTimeEl.textContent = bookingData.endTime;
        
        // Make them clickable (có thể dùng modal hoặc input type datetime-local)
        startDateEl.style.cursor = 'pointer';
        startTimeEl.style.cursor = 'pointer';
        endDateEl.style.cursor = 'pointer';
        endTimeEl.style.cursor = 'pointer';
        
        // Add click events (simplified - nên dùng datetime picker library)
        startDateEl.addEventListener('click', () => {
            const newDate = prompt('Nhập ngày nhận xe (dd/mm/yyyy):', bookingData.startDate);
            if (newDate && isValidDate(newDate)) {
                bookingData.startDate = newDate;
                startDateEl.textContent = newDate;
                calculateBookingPrice();
                checkBookingValidity();
            }
        });
        
        startTimeEl.addEventListener('click', () => {
            const newTime = prompt('Nhập giờ nhận xe (HH:MM):', bookingData.startTime);
            if (newTime && isValidTime(newTime)) {
                bookingData.startTime = newTime;
                startTimeEl.textContent = newTime;
                calculateBookingPrice();
                checkBookingValidity();
            }
        });
        
        endDateEl.addEventListener('click', () => {
            const newDate = prompt('Nhập ngày trả xe (dd/mm/yyyy):', bookingData.endDate);
            if (newDate && isValidDate(newDate)) {
                bookingData.endDate = newDate;
                endDateEl.textContent = newDate;
                calculateBookingPrice();
                checkBookingValidity();
            }
        });
        
        endTimeEl.addEventListener('click', () => {
            const newTime = prompt('Nhập giờ trả xe (HH:MM):', bookingData.endTime);
            if (newTime && isValidTime(newTime)) {
                bookingData.endTime = newTime;
                endTimeEl.textContent = newTime;
                calculateBookingPrice();
                checkBookingValidity();
            }
        });
        
        // Initial calculation
        calculateBookingPrice();
    }
}

function formatDateDisplay(date) {
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
}

function formatTimeDisplay(date) {
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    return `${hours}:${minutes}`;
}

function isValidDate(dateStr) {
    const regex = /^\d{2}\/\d{2}\/\d{4}$/;
    return regex.test(dateStr);
}

function isValidTime(timeStr) {
    const regex = /^\d{2}:\d{2}$/;
    return regex.test(timeStr);
}

// ============================================
// 14. XỬ LÝ LOCATION & ITINERARY
// ============================================
function setupLocationInputs() {
    const itineraryRadios = document.querySelectorAll('input[name="itinerary"]');
    const locationInput = document.querySelector('.location-input input');
    const pickupLocationEl = document.querySelectorAll('.location-info span')[0];
    
    // Set default pickup location from car
    if (currentCar && pickupLocationEl) {
        bookingData.pickupLocation = currentCar.location || 'Tân Sơn Nhất';
        pickupLocationEl.textContent = bookingData.pickupLocation;
    }
    
    // Handle itinerary change
    itineraryRadios.forEach(radio => {
        radio.addEventListener('change', function() {
            bookingData.areaType = this.value;
            calculateBookingPrice();
            checkBookingValidity();
        });
    });
    
    // Handle dropoff location input
    if (locationInput) {
        locationInput.addEventListener('input', function() {
            bookingData.dropoffLocation = this.value.trim();
            checkBookingValidity();
        });
        
        locationInput.addEventListener('blur', function() {
            // Estimate distance (mock - trong thực tế dùng Google Distance Matrix API)
            if (bookingData.dropoffLocation && bookingData.dropoffLocation !== bookingData.pickupLocation) {
                // Mock distance based on area type
                if (bookingData.areaType === 'local') {
                    bookingData.distanceKm = Math.floor(Math.random() * 20) + 5; // 5-25km
                } else if (bookingData.areaType === 'intercity') {
                    bookingData.distanceKm = Math.floor(Math.random() * 100) + 50; // 50-150km
                } else {
                    bookingData.distanceKm = Math.floor(Math.random() * 200) + 100; // 100-300km
                }
                
                calculateBookingPrice();
            }
        });
    }
}

function checkBookingValidity() {
    const rentButton = document.querySelector('.btn-rent');
    const warningMessage = document.querySelector('.warning-message');
    
    if (!rentButton) return;
    
    // Check if all required fields are filled
    let isValid = true;
    let message = '';
    
    if (!bookingData.startDate || !bookingData.startTime || 
        !bookingData.endDate || !bookingData.endTime) {
        isValid = false;
        message = 'Vui lòng chọn thời gian nhận và trả xe';
    } else if (bookingData.areaType !== 'local' && !bookingData.dropoffLocation) {
        isValid = false;
        message = 'Vui lòng nhập điểm đến';
    } else {
        message = '';
    }
    
    // Update button state
    rentButton.disabled = !isValid;
    
    // Update warning message
    if (warningMessage) {
        if (message) {
            warningMessage.innerHTML = `<i class="fas fa-exclamation-triangle me-1"></i> ${message}`;
            warningMessage.style.display = 'block';
        } else {
            warningMessage.style.display = 'none';
        }
    }
}

// ============================================
// 15. EVENT LISTENERS
// ============================================
function setupEventListeners() {
    // Nút "Chọn thuê"
    const rentButton = document.querySelector('.btn-rent');
    if (rentButton) {
        rentButton.addEventListener('click', function() {
            if (!rentButton.disabled) {
                createBooking();
            }
        });
    }
    
    // Setup date/time pickers
    setupDateTimePickers();
    
    // Setup location inputs
    setupLocationInputs();
    
    // Nút "Xem tất cả ảnh"
    const viewAllBtn = document.querySelector('.btn-view-all');
    if (viewAllBtn) {
        viewAllBtn.addEventListener('click', function() {
            alert('Chức năng xem ảnh đang được phát triển!');
            // TODO: Open image gallery modal
        });
    }
    
    // Nút "Báo cáo xe này"
    const reportLink = document.querySelector('.report-car-link a');
    if (reportLink) {
        reportLink.addEventListener('click', function(e) {
            e.preventDefault();
            alert('Chức năng báo cáo đang được phát triển!');
            // TODO: Open report modal
        });
    }
    
    // Nút share và favorite
    const shareBtn = document.querySelector('.car-actions .btn-icon:first-child');
    const favoriteBtn = document.querySelector('.car-actions .btn-icon:last-child');
    
    if (shareBtn) {
        shareBtn.addEventListener('click', function() {
            alert('Chức năng chia sẻ đang được phát triển!');
        });
    }
    
    if (favoriteBtn) {
        favoriteBtn.addEventListener('click', function() {
            this.querySelector('i').classList.toggle('far');
            this.querySelector('i').classList.toggle('fas');
            this.querySelector('i').classList.toggle('text-danger');
        });
    }
}
