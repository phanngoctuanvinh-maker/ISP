// ========================================
// ADVANCED FILTER - BỘ LỌC NÂNG CAO
// Xử lý tất cả các thanh kéo (range sliders) và filter logic
// ========================================

// State lưu trữ giá trị filter hiện tại
let advancedFilterState = {
    sortBy: 'optimal',
    minPrice: null,
    maxPrice: null,
    transmissionType: null,
    minDailyKmLimit: null,
    maxDailyKmLimit: null,
    minExceedFee: null,
    maxExceedFee: null,
    maxDistance: null,
    minSeatCapacity: null,
    maxSeatCapacity: null,
    minYear: null,
    maxYear: null,
    fuelType: null,
    minFuelConsumption: null,
    maxFuelConsumption: null,
    features: [],
    page: 0,
    size: 50
};

// ========================================
// INITIALIZATION
// ========================================

function initializeAdvancedFilter() {
    console.log("Initializing Advanced Filter...");
    
    // Initialize all range sliders
    initializePriceRange();
    initializeDistanceRange();
    initializeSeatsRange();
    initializeYearRange();
    initializeDeliveryFeeRange();
    initializeFuelConsumptionRange();
    
    // Initialize radio buttons
    initializeTransmissionRadios();
    initializeFuelTypeRadios();
    
    // Initialize checkboxes for features
    initializeFeaturesCheckboxes();
    
    // Initialize sort dropdown
    initializeSortDropdown();
    
    // Bind buttons
    bindAdvancedFilterButtons();
    
    console.log("Advanced Filter initialized!");
}

// ========================================
// RANGE SLIDERS
// ========================================

/**
 * Mức giá (Price Range)
 * Min: 0đ, Max: 20,000,000đ, Step: 50,000đ
 * DATA: 420K - 1.5M (thực tế hiện tại), max 20M để dự phòng xe cao cấp
 */
function initializePriceRange() {
    const slider = document.getElementById('price-range');
    const display = slider?.nextElementSibling;
    
    if (!slider || !display) return;
    
    // Update slider attributes
    slider.min = 0;
    slider.max = 20000000;  // 20 triệu
    slider.step = 50000;     // Step 50K
    
    slider.addEventListener('input', function() {
        const value = parseInt(this.value);
        
        if (value === 0) {
            display.textContent = 'Bất kì';
            advancedFilterState.minPrice = null;
            advancedFilterState.maxPrice = null;
        } else {
            const formatted = new Intl.NumberFormat('vi-VN').format(value);
            display.textContent = `Dưới ${formatted}đ`;
            advancedFilterState.minPrice = null;
            advancedFilterState.maxPrice = value;
        }
    });
    
    // Set initial value
    slider.value = 0;
    display.textContent = 'Bất kì';
}

/**
 * Khoảng cách (Distance Range)
 * Min: 0km, Max: 200km, Step: 5km
 */
function initializeDistanceRange() {
    const slider = document.getElementById('distance-range');
    const display = slider?.nextElementSibling;
    
    if (!slider || !display) return;
    
    slider.addEventListener('input', function() {
        const value = parseInt(this.value);
        
        if (value === 0) {
            display.textContent = 'Bất kì';
            advancedFilterState.maxDistance = null;
        } else {
            display.textContent = `Trong vòng ${value}km`;
            advancedFilterState.maxDistance = value;
        }
    });
    
    slider.value = 0;
    display.textContent = 'Bất kì';
}

/**
 * Số chỗ (Seat Capacity Range)
 * Min: 4, Max: 7, Step: 1
 * DATA: 4-7 chỗ (thực tế trong DB)
 */
function initializeSeatsRange() {
    const slider = document.getElementById('seats-range');
    const display = slider?.nextElementSibling;
    
    if (!slider || !display) return;
    
    // Update slider attributes
    slider.min = 0;
    slider.max = 7;
    slider.step = 1;
    
    slider.addEventListener('input', function() {
        const value = parseInt(this.value);
        
        if (value === 0) {
            display.textContent = 'Bất kì';
            advancedFilterState.minSeatCapacity = null;
            advancedFilterState.maxSeatCapacity = null;
        } else if (value === 7) {
            display.textContent = '7 chỗ';
            advancedFilterState.minSeatCapacity = 7;
            advancedFilterState.maxSeatCapacity = 7;
        } else {
            display.textContent = `${value} chỗ`;
            advancedFilterState.minSeatCapacity = value;
            advancedFilterState.maxSeatCapacity = value;
        }
    });
    
    slider.value = 0;
    display.textContent = 'Bất kì';
}

/**
 * Năm sản xuất (Year Range)
 * Min: 2000, Max: 2025, Step: 1
 * DATA: Tất cả xe đều là 2024 (nhưng user có thể filter)
 */
function initializeYearRange() {
    const slider = document.getElementById('year-range');
    const display = slider?.nextElementSibling;
    
    if (!slider || !display) return;
    
    // Set range 2000-2025, mặc định là 2000 (Bất kỳ)
    slider.min = 2000;
    slider.max = 2025;
    slider.step = 1;
    slider.value = 2000;
    
    slider.addEventListener('input', function() {
        const value = parseInt(this.value);
        
        if (value === 2000) {
            display.textContent = 'Bất kỳ';
            advancedFilterState.minYear = null;
            advancedFilterState.maxYear = null;
        } else {
            display.textContent = `Từ ${value} trở lên`;
            advancedFilterState.minYear = value;
            advancedFilterState.maxYear = null; // Không giới hạn max
        }
    });
    
    // Set initial value
    slider.value = 2000;
    display.textContent = 'Bất kỳ';
}

/**
 * Phí đưa đón (Delivery Fee Range)
 * MAPPING: Giới hạn km/ngày & Phí vượt km
 */
function initializeDeliveryFeeRange() {
    const slider = document.getElementById('delivery-fee-range');
    const display = slider?.nextElementSibling;
    
    if (!slider || !display) return;
    
    slider.addEventListener('input', function() {
        const value = parseInt(this.value);
        
        if (value === 0) {
            display.textContent = 'Miễn phí';
            advancedFilterState.minExceedFee = 0;
            advancedFilterState.maxExceedFee = 0;
        } else {
            const formatted = new Intl.NumberFormat('vi-VN').format(value);
            display.textContent = `Dưới ${formatted}đ/km`;
            advancedFilterState.minExceedFee = null;
            advancedFilterState.maxExceedFee = value;
        }
    });
    
    slider.value = 0;
    display.textContent = 'Miễn phí';
}

/**
 * Mức tiêu thụ nhiên liệu (Fuel Consumption Range)
 * Min: 0, Max: 25, Step: 1 (L/100km)
 * Logic: Giá trị slider = mức tiêu thụ tối đa
 */
function initializeFuelConsumptionRange() {
    const slider = document.getElementById('fuel-consumption-range');
    const display = slider?.nextElementSibling;
    
    if (!slider || !display) return;
    
    slider.addEventListener('input', function() {
        const value = parseInt(this.value);
        
        if (value >= 25) {
            display.textContent = 'Bất kì';
            advancedFilterState.minFuelConsumption = null;
            advancedFilterState.maxFuelConsumption = null;
        } else {
            display.textContent = `Dưới ${value}L/100km`;
            advancedFilterState.minFuelConsumption = null;
            advancedFilterState.maxFuelConsumption = value;
        }
    });
    
    slider.value = 25;
    display.textContent = 'Bất kì';
}

// ========================================
// RADIO BUTTONS
// ========================================

/**
 * Truyền động (Transmission Type)
 */
function initializeTransmissionRadios() {
    const radios = document.querySelectorAll('input[name="transmission"]');
    
    radios.forEach(radio => {
        radio.addEventListener('change', function() {
            if (this.value === 'all') {
                advancedFilterState.transmissionType = null;
            } else if (this.value === 'auto') {
                advancedFilterState.transmissionType = 'Tự động';
            } else if (this.value === 'manual') {
                advancedFilterState.transmissionType = 'Số sàn';
            }
        });
    });
}

/**
 * Nhiên liệu (Fuel Type)
 */
function initializeFuelTypeRadios() {
    const radios = document.querySelectorAll('input[name="fuel"]');
    
    radios.forEach(radio => {
        radio.addEventListener('change', function() {
            const fuelMap = {
                'fuel-all': null,
                'fuel-xang': 'Xăng',
                'fuel-diesel': 'Dầu diesel',
                'fuel-dien': 'Điện',
                'fuel-xangdien': 'Xăng & điện'
            };
            
            advancedFilterState.fuelType = fuelMap[this.id] || null;
        });
    });
}

// ========================================
// CHECKBOXES
// ========================================

/**
 * Tính năng (Features)
 */
function initializeFeaturesCheckboxes() {
    const checkboxes = [
        { id: 'feature-map', value: 'Bản đồ' },
        { id: 'feature-bluetooth', value: 'Bluetooth' },
        { id: 'feature-camera360', value: 'Camera 360' }
    ];
    
    checkboxes.forEach(({ id, value }) => {
        const checkbox = document.getElementById(id);
        if (checkbox) {
            checkbox.addEventListener('change', function() {
                if (this.checked) {
                    if (!advancedFilterState.features.includes(value)) {
                        advancedFilterState.features.push(value);
                    }
                } else {
                    advancedFilterState.features = advancedFilterState.features.filter(f => f !== value);
                }
            });
        }
    });
}

// ========================================
// DROPDOWN
// ========================================

/**
 * Sắp xếp (Sort By)
 */
function initializeSortDropdown() {
    const select = document.querySelector('#advancedFilterModal .form-select');
    
    if (select) {
        select.addEventListener('change', function() {
            const sortMap = {
                'Tối ưu': 'optimal',
                'Khoảng cách gần nhất': 'distance',
                'Giá thấp nhất': 'price_low',
                'Giá cao nhất': 'price_high',
                'Đánh giá tốt nhất': 'rating'
            };
            
            advancedFilterState.sortBy = sortMap[this.value] || 'optimal';
        });
    }
}

// ========================================
// BUTTONS
// ========================================

function bindAdvancedFilterButtons() {
    // Nút "Áp dụng"
    const applyBtn = document.getElementById('applyAdvancedFilter');
    if (applyBtn) {
        applyBtn.addEventListener('click', applyAdvancedFilter);
    }
    
    // Nút "Xóa bộ lọc"
    const clearBtn = document.getElementById('clearAdvancedFilter');
    if (clearBtn) {
        clearBtn.addEventListener('click', clearAdvancedFilter);
    }
}

// ========================================
// APPLY FILTER
// ========================================

async function applyAdvancedFilter() {
    console.log("Applying advanced filter with state:", advancedFilterState);
    
    try {
        // Show loading
        const carGrid = document.querySelector(".car-grid");
        if (carGrid) {
            carGrid.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i> Đang lọc...</div>';
        }
        
        // Call API
        const response = await fetch(`${API_BASE_URL}/cars/advanced-filter`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(advancedFilterState)
        });
        
        const data = await response.json();
        
        if (data.success) {
            console.log(`Advanced filter success: ${data.totalCars} cars found`);
            
            // Update current cars
            currentCars = data.cars || [];
            
            // Render cars
            renderCars(currentCars);
            
            // Close modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('advancedFilterModal'));
            if (modal) {
                modal.hide();
            }
            
            // Show success message
            showFilterSummary(data.totalCars);
        } else {
            throw new Error(data.message || 'Lỗi khi lọc xe');
        }
        
    } catch (error) {
        console.error("Error applying advanced filter:", error);
        showError("Không thể lọc xe: " + error.message);
    }
}

// ========================================
// CLEAR FILTER
// ========================================

function clearAdvancedFilter() {
    console.log("Clearing advanced filter...");
    
    // Reset state
    advancedFilterState = {
        sortBy: 'optimal',
        minPrice: null,
        maxPrice: null,
        transmissionType: null,
        minDailyKmLimit: null,
        maxDailyKmLimit: null,
        minExceedFee: null,
        maxExceedFee: null,
        maxDistance: null,
        minSeatCapacity: null,
        maxSeatCapacity: null,
        minYear: null,
        maxYear: null,
        fuelType: null,
        minFuelConsumption: null,
        maxFuelConsumption: null,
        features: [],
        page: 0,
        size: 50
    };
    
    // Reset UI
    resetAdvancedFilterUI();
    
    // Load all cars
    loadAllCars();
    
    // Close modal
    const modal = bootstrap.Modal.getInstance(document.getElementById('advancedFilterModal'));
    if (modal) {
        modal.hide();
    }
}

// ========================================
// UI HELPERS
// ========================================

function resetAdvancedFilterUI() {
    // Reset range sliders
    const priceSlider = document.getElementById('price-range');
    if (priceSlider) {
        priceSlider.value = 0;
        priceSlider.nextElementSibling.textContent = 'Bất kì';
    }
    
    const distanceSlider = document.getElementById('distance-range');
    if (distanceSlider) {
        distanceSlider.value = 0;
        distanceSlider.nextElementSibling.textContent = 'Bất kì';
    }
    
    const seatsSlider = document.getElementById('seats-range');
    if (seatsSlider) {
        seatsSlider.value = 0;
        seatsSlider.nextElementSibling.textContent = 'Bất kì';
    }
    
    const yearSlider = document.getElementById('year-range');
    if (yearSlider) {
        yearSlider.value = 2000;
        yearSlider.nextElementSibling.textContent = 'Bất kỳ';
    }
    
    const deliverySlider = document.getElementById('delivery-fee-range');
    if (deliverySlider) {
        deliverySlider.value = 0;
        deliverySlider.nextElementSibling.textContent = 'Miễn phí';
    }
    
    const fuelConsumptionSlider = document.getElementById('fuel-consumption-range');
    if (fuelConsumptionSlider) {
        fuelConsumptionSlider.value = 25;
        fuelConsumptionSlider.nextElementSibling.textContent = 'Bất kì';
    }
    
    // Reset radios
    const transAll = document.getElementById('trans-all');
    if (transAll) transAll.checked = true;
    
    const fuelAll = document.getElementById('fuel-all');
    if (fuelAll) fuelAll.checked = true;
    
    // Reset checkboxes
    document.querySelectorAll('#advancedFilterModal input[type="checkbox"]').forEach(cb => {
        cb.checked = false;
    });
    
    // Reset dropdown
    const sortDropdown = document.querySelector('#advancedFilterModal .form-select');
    if (sortDropdown) {
        sortDropdown.selectedIndex = 0;
    }
}

function showFilterSummary(totalCars) {
    // Optional: Show a toast or notification
    console.log(`Đã lọc: ${totalCars} xe phù hợp`);
}

// ========================================
// AUTO INITIALIZE
// ========================================

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeAdvancedFilter);
} else {
    initializeAdvancedFilter();
}
