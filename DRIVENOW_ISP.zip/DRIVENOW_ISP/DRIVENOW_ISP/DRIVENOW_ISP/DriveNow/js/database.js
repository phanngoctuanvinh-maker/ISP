// Stub database helper
// This file was missing and caused 404/mime errors in the browser.
// Add any shared mock data or helper functions here if needed.
console.log('database.js loaded (stub)');
window.database = window.database || {};
