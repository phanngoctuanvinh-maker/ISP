# 🎯 HƯỚNG DẪN HOÀN THIỆN HỆ THỐNG BOOKING - DRIVENOW

## 📋 TỔNG QUAN HỆ THỐNG

Dự án **DriveNow** là hệ thống cho thuê xe ô tô với đầy đủ chức năng:

### ✨ Các module chính:
- **Authentication**: Đăng nhập/Đăng ký (Google OAuth + JWT)
- **Car Management**: Quản lý xe, tìm kiếm nâng cao
- **Booking System**: Đặt xe (đơn lẻ & nhóm) ← **MODULE ĐANG HOÀN THIỆN**
- **Payment**: Tích hợp VNPay, MoMo
- **Deposit Management**: Quản lý đặt cọc
- **Promotion**: Khuyến mãi, mã giảm giá
- **Loyalty Points**: Tích điểm thành viên

---

## 🔧 CÁC BƯỚC THỰC HIỆN

### BƯỚC 1: Chạy Script SQL để sửa lại Database

```sql
-- Chạy file: Project1/FIX_BOOKING_COMPLETE.sql
```

**File này sẽ thực hiện:**
1. ✅ Rename bảng `bookingcar` → `booking_cars`
2. ✅ Thêm các cột còn thiếu
3. ✅ Tạo Foreign Key constraints
4. ✅ Thêm indexes để tăng hiệu suất
5. ✅ Tạo View và Stored Procedures
6. ✅ Thêm dữ liệu mẫu (5 xe)

**Cách chạy:**
1. Mở SQL Server Management Studio (SSMS)
2. Connect vào database `drivenow_db`
3. Open file `FIX_BOOKING_COMPLETE.sql`
4. Execute (F5)

---

### BƯỚC 2: Khởi động lại Spring Boot Application

```bash
# Stop application nếu đang chạy
Ctrl + C

# Clean và rebuild
mvn clean install -DskipTests

# Start application
mvn spring-boot:run
```

---

### BƯỚC 3: Test các API Booking

#### 3.1. Tạo Booking đơn lẻ

```bash
POST http://localhost:8080/api/bookings
Content-Type: application/json

{
  "customerId": 1,
  "carId": 1,
  "startTime": "2025-10-27T10:00:00",
  "endTime": "2025-10-29T10:00:00",
  "pickupLocation": "Sân bay Tân Sơn Nhất",
  "dropoffLocation": "Khách sạn Sheraton",
  "tripType": "noi_thanh",
  "oneWay": false,
  "basePrice": 500000,
  "totalAmount": 1000000
}
```

**Response:**
```json
{
  "success": true,
  "bookingId": 1,
  "message": "Booking created"
}
```

#### 3.2. Lấy thông tin Booking

```bash
GET http://localhost:8080/api/bookings/1
```

**Response:**
```json
{
  "success": true,
  "booking": {
    "bookingId": 1,
    "customerId": 1,
    "startTime": "2025-10-27T10:00:00",
    "endTime": "2025-10-29T10:00:00",
    "status": "pending",
    "totalAmount": 1000000,
    ...
  }
}
```

#### 3.3. Lấy danh sách Booking của Customer

```bash
GET http://localhost:8080/api/bookings/customer/1
```

#### 3.4. Lấy tất cả Bookings (có filter)

```bash
# Tất cả
GET http://localhost:8080/api/bookings

# Filter theo status
GET http://localhost:8080/api/bookings?status=pending
```

#### 3.5. Cập nhật trạng thái Booking

```bash
PUT http://localhost:8080/api/bookings/1/status
Content-Type: application/json

{
  "status": "confirmed"
}
```

**Các trạng thái hợp lệ:**
- `pending` - Chờ xác nhận
- `confirmed` - Đã xác nhận
- `completed` - Hoàn thành
- `cancelled` - Đã hủy

#### 3.6. Hủy Booking

```bash
PUT http://localhost:8080/api/bookings/1/cancel
```

**Lưu ý:** Khi hủy booking, trạng thái xe sẽ tự động chuyển về `available`

#### 3.7. Tạo Group Booking (nhiều xe)

```bash
POST http://localhost:8080/api/bookings/group
Content-Type: application/json

{
  "customerId": 1,
  "startTime": "2025-10-27T10:00:00",
  "endTime": "2025-10-29T10:00:00",
  "pickupLocation": "Văn phòng công ty",
  "dropoffLocation": "Sân bay",
  "tripType": "lien_tinh",
  "oneWay": true,
  "cars": [
    {
      "carId": 1,
      "startDate": "2025-10-27T10:00:00",
      "endDate": "2025-10-29T10:00:00",
      "priceAtBooking": 500000,
      "totalPrice": 1000000
    },
    {
      "carId": 2,
      "startDate": "2025-10-27T10:00:00",
      "endDate": "2025-10-29T10:00:00",
      "priceAtBooking": 800000,
      "totalPrice": 1600000
    }
  ],
  "basePrice": 1300000,
  "totalAmount": 2600000
}
```

---

## 📊 CẤU TRÚC DATABASE SAU KHI SỬA

### Bảng: `bookings`

```sql
CREATE TABLE bookings (
    booking_id INT IDENTITY(1,1) PRIMARY KEY,
    customer_id INT NOT NULL,
    driver_id INT NULL,
    start_time DATETIME NOT NULL,
    end_time DATETIME NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    pickup_location NVARCHAR(255),
    dropoff_location NVARCHAR(255),
    status NVARCHAR(20) DEFAULT 'pending',
    trip_type VARCHAR(100),
    one_way BIT,
    pickup_point VARCHAR(255),
    base_price DECIMAL(18,2),
    discount_amount DECIMAL(18,2),
    insurance_fee DECIMAL(18,2),
    transfer_fee DECIMAL(18,2),
    promo_code VARCHAR(100),
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME,
    
    FOREIGN KEY (customer_id) REFERENCES customer(customer_id),
    FOREIGN KEY (driver_id) REFERENCES driver(driver_id)
);
```

### Bảng: `booking_cars`

```sql
CREATE TABLE booking_cars (
    booking_car_id BIGINT IDENTITY(1,1) PRIMARY KEY,
    booking_id BIGINT NOT NULL,
    car_id BIGINT NOT NULL,
    start_date DATETIME2(7),
    end_date DATETIME2(7),
    price_at_booking DECIMAL(18,2),
    total_price DECIMAL(18,2),
    distance_km DECIMAL(10,2),
    allowed_km DECIMAL(10,2),
    service_fee DECIMAL(18,2),
    area_type VARCHAR(100),
    extra_km DECIMAL(10,2),
    created_at DATETIME2(7) DEFAULT SYSUTCDATETIME(),
    updated_at DATETIME2(7),
    
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE,
    FOREIGN KEY (car_id) REFERENCES cars(id)
);
```

---

## 🔄 LUỒNG HOẠT ĐỘNG HỆ THỐNG BOOKING

```
┌─────────────┐       ┌──────────────┐       ┌─────────────┐
│  Frontend   │──────▶│   Backend    │──────▶│  Database   │
│   (HTML/JS) │       │ (Spring Boot)│       │(SQL Server) │
└─────────────┘       └──────────────┘       └─────────────┘
      │                      │                       │
      │  1. Chọn xe         │                       │
      │──────────────────▶  │                       │
      │                      │  2. Check available  │
      │                      │─────────────────────▶│
      │                      │◀─────────────────────│
      │                      │  3. Tạo Booking      │
      │                      │─────────────────────▶│
      │                      │  4. Tạo BookingCar   │
      │                      │─────────────────────▶│
      │                      │  5. Update car status│
      │                      │─────────────────────▶│
      │◀──────────────────  │                       │
      │  6. Booking created  │                       │
      │                      │                       │
      │  7. Go to Payment   │                       │
      │──────────────────▶  │                       │
```

---

## 🎨 TÍCH HỢP FRONTEND

### Cập nhật file: `booking-with-payment.html`

```javascript
// Thêm function để tạo booking
async function createBooking(bookingData) {
    try {
        const response = await fetch('http://localhost:8080/api/bookings', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + localStorage.getItem('token')
            },
            body: JSON.stringify(bookingData)
        });
        
        const result = await response.json();
        
        if (result.success) {
            console.log('Booking created:', result.bookingId);
            // Chuyển sang bước thanh toán
            goToPayment(result.bookingId);
        } else {
            alert('Lỗi: ' + result.message);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Không thể kết nối đến server!');
    }
}

// Function xử lý thanh toán
function goToPayment(bookingId) {
    // Lưu bookingId vào localStorage
    localStorage.setItem('currentBookingId', bookingId);
    
    // Chuyển hướng hoặc hiển thị form thanh toán
    goToStep3();
}

// Function lấy thông tin booking
async function getBookingDetails(bookingId) {
    try {
        const response = await fetch(`http://localhost:8080/api/bookings/${bookingId}`, {
            headers: {
                'Authorization': 'Bearer ' + localStorage.getItem('token')
            }
        });
        
        const result = await response.json();
        
        if (result.success) {
            return result.booking;
        }
    } catch (error) {
        console.error('Error:', error);
    }
    return null;
}

// Function lấy lịch sử booking của khách hàng
async function getCustomerBookings(customerId) {
    try {
        const response = await fetch(`http://localhost:8080/api/bookings/customer/${customerId}`, {
            headers: {
                'Authorization': 'Bearer ' + localStorage.getItem('token')
            }
        });
        
        const result = await response.json();
        
        if (result.success) {
            displayBookings(result.bookings);
        }
    } catch (error) {
        console.error('Error:', error);
    }
}

// Function hiển thị danh sách bookings
function displayBookings(bookings) {
    const container = document.getElementById('bookingsContainer');
    
    if (bookings.length === 0) {
        container.innerHTML = '<p>Bạn chưa có booking nào!</p>';
        return;
    }
    
    const html = bookings.map(booking => `
        <div class="booking-card">
            <h4>Booking #${booking.bookingId}</h4>
            <p>Từ: ${new Date(booking.startTime).toLocaleString('vi-VN')}</p>
            <p>Đến: ${new Date(booking.endTime).toLocaleString('vi-VN')}</p>
            <p>Địa điểm nhận: ${booking.pickupLocation}</p>
            <p>Địa điểm trả: ${booking.dropoffLocation}</p>
            <p class="status ${booking.status}">${getStatusText(booking.status)}</p>
            <p class="total">Tổng: ${booking.totalAmount.toLocaleString()} VNĐ</p>
            <div class="actions">
                <button onclick="viewBooking(${booking.bookingId})">Chi tiết</button>
                ${booking.status === 'pending' ? 
                    `<button onclick="cancelBooking(${booking.bookingId})">Hủy</button>` : 
                    ''
                }
            </div>
        </div>
    `).join('');
    
    container.innerHTML = html;
}

// Function hủy booking
async function cancelBooking(bookingId) {
    if (!confirm('Bạn có chắc muốn hủy booking này?')) {
        return;
    }
    
    try {
        const response = await fetch(`http://localhost:8080/api/bookings/${bookingId}/cancel`, {
            method: 'PUT',
            headers: {
                'Authorization': 'Bearer ' + localStorage.getItem('token')
            }
        });
        
        const result = await response.json();
        
        if (result.success) {
            alert('Đã hủy booking thành công!');
            location.reload();
        } else {
            alert('Lỗi: ' + result.message);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Không thể hủy booking!');
    }
}

function getStatusText(status) {
    const statusMap = {
        'pending': 'Chờ xác nhận',
        'confirmed': 'Đã xác nhận',
        'completed': 'Hoàn thành',
        'cancelled': 'Đã hủy'
    };
    return statusMap[status] || status;
}
```

---

## ✅ CHECKLIST HOÀN THIỆN

### Backend ✅
- [x] Sửa Entity `BookingCar` (table name, columns)
- [x] Thêm methods vào `BookingRepository`
- [x] Thêm methods vào `BookingCarRepository`
- [x] Thêm methods vào `BookingService`
- [x] Thêm endpoints vào `BookingController`

### Database ✅
- [x] Rename bảng `bookingcar` → `booking_cars`
- [x] Thêm các cột còn thiếu
- [x] Tạo Foreign Keys
- [x] Tạo Indexes
- [x] Tạo Views và Stored Procedures
- [x] Thêm dữ liệu mẫu

### Frontend (CẦN LÀM)
- [ ] Tích hợp API tạo booking
- [ ] Hiển thị lịch sử booking
- [ ] Thêm function hủy booking
- [ ] Kết nối với Payment module

---

## 🚀 CHẠY THÀNH CÔNG

Sau khi hoàn thành, bạn có thể:

1. ✅ **Tạo booking đơn lẻ** (1 xe)
2. ✅ **Tạo group booking** (nhiều xe)
3. ✅ **Xem danh sách bookings**
4. ✅ **Xem chi tiết booking**
5. ✅ **Cập nhật trạng thái**
6. ✅ **Hủy booking**
7. ✅ **Check xe available** (tự động)
8. ✅ **Cập nhật status xe** (tự động)

---

## 📝 GHI CHÚ QUAN TRỌNG

### 1. Về Kiểu Dữ Liệu
- `booking_id` trong bảng `bookings`: **INT** (vì đã có dữ liệu)
- `booking_id` trong bảng `booking_cars`: **BIGINT** (để tương thích với Entity)
- SQL Server tự động cast INT → BIGINT khi join

### 2. Về Foreign Keys
- `ON DELETE CASCADE` cho `booking_cars` → `bookings`
- Khi xóa booking, tự động xóa các `booking_cars` liên quan

### 3. Về Status
- Car status: `available`, `rented`, `maintenance`
- Booking status: `pending`, `confirmed`, `completed`, `cancelled`

### 4. Về Validation
- Kiểm tra xe available trước khi book
- Kiểm tra thời gian trùng lặp
- Validate customer_id tồn tại

---

## 🆘 TROUBLESHOOTING

### Lỗi: "Table 'bookingcar' not found"
→ Chạy lại script SQL `FIX_BOOKING_COMPLETE.sql`

### Lỗi: "Cannot find symbol: method findByCustomerId"
→ Restart IDE và rebuild project

### Lỗi: "Foreign key constraint failed"
→ Xóa dữ liệu cũ hoặc sửa lại reference

### Lỗi: "Car already booked"
→ Kiểm tra overlap bookings, cancel booking cũ nếu cần

---

## 📞 HỖ TRỢ

Nếu gặp vấn đề, kiểm tra:
1. Database connection string trong `application.properties`
2. Port 8080 có bị chiếm không
3. SQL Server đang chạy
4. Đã chạy script SQL chưa

**Chúc bạn thành công! 🎉**
