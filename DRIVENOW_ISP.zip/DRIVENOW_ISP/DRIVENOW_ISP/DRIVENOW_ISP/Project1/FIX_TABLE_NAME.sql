-- =============================================
-- FIX BOOKING_CARS TABLE NAME
-- Rename table từ 'bookingcar' sang 'booking_cars'
-- =============================================

USE drivenow_db;
GO

-- Kiểm tra xem table bookingcar có tồn tại không
IF OBJECT_ID('dbo.bookingcar', 'U') IS NOT NULL
BEGIN
    PRINT '✅ Found table: bookingcar'
    
    -- Kiểm tra xem booking_cars đã tồn tại chưa
    IF OBJECT_ID('dbo.booking_cars', 'U') IS NOT NULL
    BEGIN
        PRINT '⚠️ Table booking_cars already exists! Dropping old bookingcar table...'
        DROP TABLE dbo.bookingcar;
        PRINT '✅ Dropped table: bookingcar'
    END
    ELSE
    BEGIN
        PRINT '🔄 Renaming bookingcar to booking_cars...'
        
        -- Drop foreign keys trước nếu có
        DECLARE @sql NVARCHAR(MAX) = '';
        SELECT @sql = @sql + 'ALTER TABLE dbo.bookingcar DROP CONSTRAINT ' + QUOTENAME(name) + '; '
        FROM sys.foreign_keys
        WHERE parent_object_id = OBJECT_ID('dbo.bookingcar');
        
        IF LEN(@sql) > 0
        BEGIN
            EXEC sp_executesql @sql;
            PRINT '✅ Dropped foreign keys'
        END
        
        -- Rename table
        EXEC sp_rename 'dbo.bookingcar', 'booking_cars';
        PRINT '✅ Renamed table to: booking_cars'
        
        -- Recreate foreign keys nếu cần
        IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_booking_cars_bookings')
        BEGIN
            ALTER TABLE dbo.booking_cars
            ADD CONSTRAINT FK_booking_cars_bookings
            FOREIGN KEY (booking_id) REFERENCES dbo.bookings(booking_id) ON DELETE CASCADE;
            PRINT '✅ Added FK: FK_booking_cars_bookings'
        END
        
        IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_booking_cars_cars')
        BEGIN
            ALTER TABLE dbo.booking_cars
            ADD CONSTRAINT FK_booking_cars_cars
            FOREIGN KEY (car_id) REFERENCES dbo.cars(id) ON DELETE CASCADE;
            PRINT '✅ Added FK: FK_booking_cars_cars'
        END
    END
END
ELSE
BEGIN
    PRINT '⚠️ Table bookingcar not found! Maybe already renamed to booking_cars.'
    
    IF OBJECT_ID('dbo.booking_cars', 'U') IS NOT NULL
    BEGIN
        PRINT '✅ Table booking_cars already exists.'
    END
    ELSE
    BEGIN
        PRINT '❌ ERROR: Neither bookingcar nor booking_cars exists!'
    END
END
GO

-- Verify kết quả
SELECT 
    name as TableName,
    create_date as CreatedDate
FROM sys.tables 
WHERE name IN ('bookingcar', 'booking_cars')
ORDER BY name;
GO

PRINT '✅ Script completed!'
