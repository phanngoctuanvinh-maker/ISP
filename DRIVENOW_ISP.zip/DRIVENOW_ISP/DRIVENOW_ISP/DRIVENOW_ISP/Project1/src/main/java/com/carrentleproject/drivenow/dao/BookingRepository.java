package com.carrentleproject.drivenow.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.carrentleproject.drivenow.model.Booking;

import java.util.List;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {
    
    /**
     * Find bookings by customer ID
     */
    List<Booking> findByCustomerId(Long customerId);
    
    /**
     * Find bookings by status
     */
    List<Booking> findByStatus(String status);
    
    /**
     * Find bookings by driver ID
     */
    List<Booking> findByDriverId(Long driverId);
}
