-- Migration V3: Create detailed booking_cars table to match DB diagram
-- Creates booking_cars with fields for per-car booking details and FK relations
-- Designed for Microsoft SQL Server

IF OBJECT_ID('dbo.booking_cars', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.booking_cars (
        booking_car_id BIGINT IDENTITY(1,1) PRIMARY KEY,
        booking_id BIGINT NOT NULL,
        car_id BIGINT NOT NULL,
        start_date DATETIME2 NULL,
        end_date DATETIME2 NULL,
        distance_km DECIMAL(10,2) NULL,
        allowed_km DECIMAL(10,2) NULL,
        price_at_booking DECIMAL(18,2) NULL,
        service_fee DECIMAL(18,2) NULL,
        area_type VARCHAR(100) NULL,
        extra_km DECIMAL(10,2) NULL,
        total_price DECIMAL(18,2) NULL,
        created_at DATETIME2 DEFAULT SYSUTCDATETIME(),
        updated_at DATETIME2 NULL
    );

    -- Add indexes for faster lookups
    CREATE INDEX IX_booking_cars_booking_id ON dbo.booking_cars(booking_id);
    CREATE INDEX IX_booking_cars_car_id ON dbo.booking_cars(car_id);

    -- Add foreign key constraints if referenced tables/columns exist
    IF OBJECT_ID('dbo.bookings','U') IS NOT NULL AND COL_LENGTH('dbo.bookings','id') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.booking_cars
        ADD CONSTRAINT FK_booking_cars_bookings FOREIGN KEY (booking_id)
            REFERENCES dbo.bookings(id);
    END

    IF OBJECT_ID('dbo.cars','U') IS NOT NULL AND (COL_LENGTH('dbo.cars','car_id') IS NOT NULL OR COL_LENGTH('dbo.cars','id') IS NOT NULL)
    BEGIN
        -- prefer car_id column if present, otherwise reference id
        IF COL_LENGTH('dbo.cars','car_id') IS NOT NULL
        BEGIN
            ALTER TABLE dbo.booking_cars
            ADD CONSTRAINT FK_booking_cars_cars FOREIGN KEY (car_id)
                REFERENCES dbo.cars(car_id);
        END
        ELSE
        BEGIN
            ALTER TABLE dbo.booking_cars
            ADD CONSTRAINT FK_booking_cars_cars FOREIGN KEY (car_id)
                REFERENCES dbo.cars(id);
        END
    END
END

PRINT 'V3__create_booking_cars_detailed.sql executed (no-op if booking_cars already exists)';
