-- V4__booking_cars_create_and_fks.sql
-- Safe create + diagnostic + FK creation for booking_cars
-- Run this in SSMS connected to your drivenow_db database.
-- Usage: set @forceClean = 1 to automatically DELETE orphan rows before adding FKs (destructive).

USE [drivenow_db];
GO
SET NOCOUNT ON;

DECLARE @forceClean BIT = 0;  -- set to 1 to AUTO-CLEAN orphan rows (destructive)
PRINT '--- V4: booking_cars create + FK installer (safe mode) ---';

-- 1) Show schema info for related tables
PRINT '1) Columns for booking_cars, bookings, cars';
SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH, NUMERIC_PRECISION, NUMERIC_SCALE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME IN ('booking_cars','bookings','cars')
ORDER BY TABLE_NAME, ORDINAL_POSITION;
GO

-- 2) Create booking_cars if not exists
IF OBJECT_ID('dbo.booking_cars','U') IS NULL
BEGIN
    PRINT '2) Creating table dbo.booking_cars';
    CREATE TABLE dbo.booking_cars (
        booking_car_id BIGINT IDENTITY(1,1) PRIMARY KEY,
        booking_id BIGINT NOT NULL,
        car_id BIGINT NOT NULL,
        start_date DATETIME2 NULL,
        end_date DATETIME2 NULL,
        distance_km DECIMAL(10,2) NULL,
        allowed_km DECIMAL(10,2) NULL,
        price_at_booking DECIMAL(18,2) NULL,
        service_fee DECIMAL(18,2) NULL,
        area_type VARCHAR(100) NULL,
        extra_km DECIMAL(10,2) NULL,
        total_price DECIMAL(18,2) NULL,
        created_at DATETIME2 DEFAULT SYSUTCDATETIME(),
        updated_at DATETIME2 NULL
    );

    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID('dbo.booking_cars') AND name = 'IX_booking_cars_booking_id')
    BEGIN
        CREATE INDEX IX_booking_cars_booking_id ON dbo.booking_cars(booking_id);
    END
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID('dbo.booking_cars') AND name = 'IX_booking_cars_car_id')
    BEGIN
        CREATE INDEX IX_booking_cars_car_id ON dbo.booking_cars(car_id);
    END
END
ELSE
BEGIN
    PRINT '2) dbo.booking_cars already exists - skipping CREATE';
END
GO

-- 3) Basic counts and sample
PRINT '3) booking_cars count and sample';
SELECT COUNT(*) AS booking_cars_count FROM dbo.booking_cars;
SELECT TOP (20) * FROM dbo.booking_cars ORDER BY booking_car_id DESC;
GO

-- 4) Determine PK column names for bookings and cars (try to obtain actual PK via sys.indexes)
DECLARE @bk_pk NVARCHAR(128) = NULL;
DECLARE @car_pk NVARCHAR(128) = NULL;

SELECT TOP 1 @bk_pk = c.name
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID('dbo.bookings') AND i.is_primary_key = 1;

SELECT TOP 1 @car_pk = c.name
FROM sys.indexes i2
JOIN sys.index_columns ic2 ON ic2.object_id = i2.object_id AND ic2.index_id = i2.index_id
JOIN sys.columns c2 ON c2.object_id = ic2.object_id AND c2.column_id = ic2.column_id
WHERE i2.object_id = OBJECT_ID('dbo.cars') AND i2.is_primary_key = 1;

-- Fallbacks if PK not found
IF @bk_pk IS NULL
BEGIN
    IF COL_LENGTH('dbo.bookings','id') IS NOT NULL SET @bk_pk = 'id';
    ELSE IF COL_LENGTH('dbo.bookings','booking_id') IS NOT NULL SET @bk_pk = 'booking_id';
END
IF @car_pk IS NULL
BEGIN
    IF COL_LENGTH('dbo.cars','car_id') IS NOT NULL SET @car_pk = 'car_id';
    ELSE IF COL_LENGTH('dbo.cars','id') IS NOT NULL SET @car_pk = 'id';
END

PRINT 'Detected bookings PK column: ' + ISNULL(@bk_pk,'<not found>');
PRINT 'Detected cars PK column: ' + ISNULL(@car_pk,'<not found>');
GO

-- 5) Check orphan booking references (dynamic because pk name is variable)
DECLARE @sql NVARCHAR(MAX);
DECLARE @orphanBookingCount INT = 0;
DECLARE @orphanCarCount INT = 0;

SET @sql = N'SELECT @cnt = COUNT(*) FROM dbo.booking_cars bc LEFT JOIN dbo.bookings b ON b.' + QUOTENAME(@bk_pk) + ' = bc.booking_id WHERE b.' + QUOTENAME(@bk_pk) + ' IS NULL';
IF @bk_pk IS NULL
BEGIN
    PRINT 'Cannot determine bookings PK column - skipping orphan booking check (will not add FK to bookings).';
END
ELSE
BEGIN
    EXEC sp_executesql @sql, N'@cnt INT OUTPUT', @cnt = @orphanBookingCount OUTPUT;
    PRINT 'Orphan booking_cars referencing nonexistent bookings: ' + CAST(@orphanBookingCount AS NVARCHAR(20));
END

-- 6) Check orphan car references; allow cars.car_id or cars.id join
IF @car_pk IS NULL
BEGIN
    PRINT 'Cannot determine cars PK column - skipping orphan car check (will not add FK to cars).';
END
ELSE
BEGIN
    SET @sql = N'SELECT @cnt = COUNT(*) FROM dbo.booking_cars bc LEFT JOIN dbo.cars c ON c.' + QUOTENAME(@car_pk) + ' = bc.car_id WHERE c.' + QUOTENAME(@car_pk) + ' IS NULL';
    EXEC sp_executesql @sql, N'@cnt INT OUTPUT', @cnt = @orphanCarCount OUTPUT;
    PRINT 'Orphan booking_cars referencing nonexistent cars: ' + CAST(@orphanCarCount AS NVARCHAR(20));
END
GO

-- 7) Optionally delete orphans if @forceClean = 1
IF @forceClean = 1
BEGIN
    IF @bk_pk IS NOT NULL AND @orphanBookingCount > 0
    BEGIN
        PRINT 'Force-clean enabled: deleting orphan booking_cars rows with missing bookings';
        SET @sql = N'DELETE bc FROM dbo.booking_cars bc LEFT JOIN dbo.bookings b ON b.' + QUOTENAME(@bk_pk) + ' = bc.booking_id WHERE b.' + QUOTENAME(@bk_pk) + ' IS NULL';
        EXEC sp_executesql @sql;
    END
    IF @car_pk IS NOT NULL AND @orphanCarCount > 0
    BEGIN
        PRINT 'Force-clean enabled: deleting orphan booking_cars rows with missing cars';
        SET @sql = N'DELETE bc FROM dbo.booking_cars bc LEFT JOIN dbo.cars c ON c.' + QUOTENAME(@car_pk) + ' = bc.car_id WHERE c.' + QUOTENAME(@car_pk) + ' IS NULL';
        EXEC sp_executesql @sql;
    END
END
ELSE
BEGIN
    IF @orphanBookingCount > 0 OR @orphanCarCount > 0
    BEGIN
        PRINT 'Detected orphan rows. Set @forceClean = 1 at top of this script to automatically remove them (destructive), OR manually reconcile booking_cars.booking_id and car_id values.';
    END
END
GO

-- 8) Try to add FK to bookings (dynamic SQL + TRY/CATCH)
IF @bk_pk IS NOT NULL
BEGIN
    IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_booking_cars_bookings')
    BEGIN
        SET @sql = N'ALTER TABLE dbo.booking_cars ADD CONSTRAINT FK_booking_cars_bookings FOREIGN KEY (booking_id) REFERENCES dbo.bookings(' + QUOTENAME(@bk_pk) + N')';
        BEGIN TRY
            EXEC sp_executesql @sql;
            PRINT 'Added FK_booking_cars_bookings -> dbo.bookings(' + @bk_pk + ')';
        END TRY
        BEGIN CATCH
            PRINT 'ERROR adding FK_booking_cars_bookings: ' + ERROR_MESSAGE();
            PRINT 'If this fails due to existing orphan rows or index problems, resolve orphans and ensure referenced column is indexed/PK.';
        END CATCH
    END
    ELSE
    BEGIN
        PRINT 'FK_booking_cars_bookings already exists - skipping';
    END
END
ELSE
BEGIN
    PRINT 'Skipping FK to bookings because bookings PK column could not be determined';
END
GO

-- 9) Try to add FK to cars (dynamic SQL + TRY/CATCH)
IF @car_pk IS NOT NULL
BEGIN
    IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_booking_cars_cars')
    BEGIN
        SET @sql = N'ALTER TABLE dbo.booking_cars ADD CONSTRAINT FK_booking_cars_cars FOREIGN KEY (car_id) REFERENCES dbo.cars(' + QUOTENAME(@car_pk) + N')';
        BEGIN TRY
            EXEC sp_executesql @sql;
            PRINT 'Added FK_booking_cars_cars -> dbo.cars(' + @car_pk + ')';
        END TRY
        BEGIN CATCH
            PRINT 'ERROR adding FK_booking_cars_cars: ' + ERROR_MESSAGE();
            PRINT 'If this fails, check orphan rows and referenced column types/indexes.';
        END CATCH
    END
    ELSE
    BEGIN
        PRINT 'FK_booking_cars_cars already exists - skipping';
    END
END
ELSE
BEGIN
    PRINT 'Skipping FK to cars because cars PK column could not be determined';
END
GO

-- 10) Show created FKs (if any)
PRINT '10) Current foreign keys on booking_cars (if any)';
SELECT fk.name AS fk_name,
       OBJECT_NAME(fk.parent_object_id) AS table_name,
       STUFF((SELECT ',' + COL_NAME(fc.parent_object_id, fc.parent_column_id)
              FROM sys.foreign_key_columns fc
              WHERE fc.constraint_object_id = fk.object_id
              FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,1,'') AS fk_columns,
       OBJECT_NAME(fk.referenced_object_id) AS referenced_table,
       STUFF((SELECT ',' + COL_NAME(fc.referenced_object_id, fc.referenced_column_id)
              FROM sys.foreign_key_columns fc
              WHERE fc.constraint_object_id = fk.object_id
              FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,1,'') AS referenced_columns
FROM sys.foreign_keys fk
WHERE OBJECT_NAME(fk.parent_object_id) = 'booking_cars';
GO

PRINT 'V4 script finished. If FK creation failed, copy the Messages output and paste here so I can iterate.';
GO
