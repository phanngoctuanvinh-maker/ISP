-- Migration: Add extra booking fields to bookings table
-- Run manually if Flyway not configured or place under flyway migrations directory

IF COL_LENGTH('bookings', 'trip_type') IS NULL
BEGIN
    ALTER TABLE bookings ADD trip_type VARCHAR(100) NULL;
END

IF COL_LENGTH('bookings', 'one_way') IS NULL
BEGIN
    ALTER TABLE bookings ADD one_way BIT NULL;
END

IF COL_LENGTH('bookings', 'pickup_point') IS NULL
BEGIN
    ALTER TABLE bookings ADD pickup_point VARCHAR(255) NULL;
END

IF COL_LENGTH('bookings', 'specific_pickup_address') IS NULL
BEGIN
    ALTER TABLE bookings ADD specific_pickup_address VARCHAR(500) NULL;
END

IF COL_LENGTH('bookings', 'allowed_km_per_day') IS NULL
BEGIN
    ALTER TABLE bookings ADD allowed_km_per_day INT NULL;
END

IF COL_LENGTH('bookings', 'exceed_fee_per_km') IS NULL
BEGIN
    ALTER TABLE bookings ADD exceed_fee_per_km DECIMAL(18,2) NULL;
END

IF COL_LENGTH('bookings', 'fuel_consumption') IS NULL
BEGIN
    ALTER TABLE bookings ADD fuel_consumption FLOAT NULL;
END

IF COL_LENGTH('bookings', 'insurance_fee') IS NULL
BEGIN
    ALTER TABLE bookings ADD insurance_fee DECIMAL(18,2) NULL;
END

IF COL_LENGTH('bookings', 'transfer_fee') IS NULL
BEGIN
    ALTER TABLE bookings ADD transfer_fee DECIMAL(18,2) NULL;
END

IF COL_LENGTH('bookings', 'promo_code') IS NULL
BEGIN
    ALTER TABLE bookings ADD promo_code VARCHAR(100) NULL;
END

IF COL_LENGTH('bookings', 'base_price') IS NULL
BEGIN
    ALTER TABLE bookings ADD base_price DECIMAL(18,2) NULL;
END

IF COL_LENGTH('bookings', 'discount_amount') IS NULL
BEGIN
    ALTER TABLE bookings ADD discount_amount DECIMAL(18,2) NULL;
END

PRINT 'Migration script completed (no-op if columns exist)';
