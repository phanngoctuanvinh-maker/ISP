-- Migration: Create booking_cars table if it doesn't exist (SQL Server)
-- Run this script manually if you don't use an automatic migration tool.

IF OBJECT_ID('dbo.booking_cars', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.booking_cars (
        booking_car_id BIGINT IDENTITY(1,1) PRIMARY KEY,
        booking_id BIGINT NULL,
        car_id BIGINT NULL,
        start_date DATETIME2 NULL,
        end_date DATETIME2 NULL,
        price_at_booking DECIMAL(18,2) NULL,
        total_price DECIMAL(18,2) NULL
    );
END

PRINT 'Ensure booking_cars table exists (no-op if already present)';
