-- V5__link_booking_cars_bookings_cars_car_images.sql
-- Purpose: add safe FK constraints linking booking_cars -> bookings, booking_cars -> cars,
-- and ensure car_images -> cars, plus create a view joining these tables for easy verification.
-- Run in SSMS connected to drivenow_db. This script is conservative: it checks for
-- existing constraints and orphan rows before making destructive changes.

USE [drivenow_db];
GO
SET NOCOUNT ON;

PRINT 'V5: Linking booking_cars to bookings, cars, and car_images (safe)';

-- Helper: detect pk columns for bookings and cars
DECLARE @bk_pk NVARCHAR(128) = NULL;
DECLARE @car_pk NVARCHAR(128) = NULL;

SELECT TOP 1 @bk_pk = c.name
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID('dbo.bookings') AND i.is_primary_key = 1;

SELECT TOP 1 @car_pk = c.name
FROM sys.indexes i2
JOIN sys.index_columns ic2 ON ic2.object_id = i2.object_id AND ic2.index_id = i2.index_id
JOIN sys.columns c2 ON c2.object_id = ic2.object_id AND c2.column_id = ic2.column_id
WHERE i2.object_id = OBJECT_ID('dbo.cars') AND i2.is_primary_key = 1;

-- Fallback common names
IF @bk_pk IS NULL
BEGIN
    IF COL_LENGTH('dbo.bookings','id') IS NOT NULL SET @bk_pk = 'id';
    ELSE IF COL_LENGTH('dbo.bookings','booking_id') IS NOT NULL SET @bk_pk = 'booking_id';
END
IF @car_pk IS NULL
BEGIN
    IF COL_LENGTH('dbo.cars','id') IS NOT NULL SET @car_pk = 'id';
    ELSE IF COL_LENGTH('dbo.cars','car_id') IS NOT NULL SET @car_pk = 'car_id';
END

PRINT 'Detected bookings PK column: ' + ISNULL(@bk_pk,'<not found>');
PRINT 'Detected cars PK column: ' + ISNULL(@car_pk,'<not found>');
GO

-- 1) Add FK booking_cars.booking_id -> bookings(<pk>)
IF OBJECT_ID('dbo.booking_cars','U') IS NULL
BEGIN
    PRINT 'booking_cars table does not exist - please run create script first (V3/V4).';
END
ELSE
BEGIN
    IF @bk_pk IS NOT NULL
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_booking_cars_bookings')
        BEGIN
            -- Check orphan rows
            DECLARE @cnt_orphan_booking INT = 0;
            DECLARE @sql NVARCHAR(MAX) = N'SELECT @cnt = COUNT(*) FROM dbo.booking_cars bc LEFT JOIN dbo.bookings b ON b.' + QUOTENAME(@bk_pk) + ' = bc.booking_id WHERE b.' + QUOTENAME(@bk_pk) + ' IS NULL';
            EXEC sp_executesql @sql, N'@cnt INT OUTPUT', @cnt = @cnt_orphan_booking OUTPUT;

            IF @cnt_orphan_booking = 0
            BEGIN
                BEGIN TRY
                    SET @sql = N'ALTER TABLE dbo.booking_cars ADD CONSTRAINT FK_booking_cars_bookings FOREIGN KEY (booking_id) REFERENCES dbo.bookings(' + QUOTENAME(@bk_pk) + N')';
                    EXEC sp_executesql @sql;
                    PRINT 'Added FK_booking_cars_bookings -> dbo.bookings(' + @bk_pk + ')';
                END TRY
                BEGIN CATCH
                    PRINT 'ERROR adding FK_booking_cars_bookings: ' + ERROR_MESSAGE();
                END CATCH
            END
            ELSE
            BEGIN
                PRINT 'Cannot add FK_booking_cars_bookings: found ' + CAST(@cnt_orphan_booking AS NVARCHAR(20)) + ' orphan booking_cars.booking_id values. Reconcile or run cleanup.';
            END
        END
        ELSE
        BEGIN
            PRINT 'FK_booking_cars_bookings already exists - skipping';
        END
    END
    ELSE
    BEGIN
        PRINT 'Skipping FK to bookings: bookings PK not detected';
    END
END
GO

-- 2) Add FK booking_cars.car_id -> cars(<pk>)
IF OBJECT_ID('dbo.booking_cars','U') IS NOT NULL
BEGIN
    IF @car_pk IS NOT NULL
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_booking_cars_cars')
        BEGIN
            DECLARE @cnt_orphan_car INT = 0;
            DECLARE @sql2 NVARCHAR(MAX) = N'SELECT @cnt = COUNT(*) FROM dbo.booking_cars bc LEFT JOIN dbo.cars c ON c.' + QUOTENAME(@car_pk) + ' = bc.car_id WHERE c.' + QUOTENAME(@car_pk) + ' IS NULL';
            EXEC sp_executesql @sql2, N'@cnt INT OUTPUT', @cnt = @cnt_orphan_car OUTPUT;

            IF @cnt_orphan_car = 0
            BEGIN
                BEGIN TRY
                    SET @sql2 = N'ALTER TABLE dbo.booking_cars ADD CONSTRAINT FK_booking_cars_cars FOREIGN KEY (car_id) REFERENCES dbo.cars(' + QUOTENAME(@car_pk) + N')';
                    EXEC sp_executesql @sql2;
                    PRINT 'Added FK_booking_cars_cars -> dbo.cars(' + @car_pk + ')';
                END TRY
                BEGIN CATCH
                    PRINT 'ERROR adding FK_booking_cars_cars: ' + ERROR_MESSAGE();
                END CATCH
            END
            ELSE
            BEGIN
                PRINT 'Cannot add FK_booking_cars_cars: found ' + CAST(@cnt_orphan_car AS NVARCHAR(20)) + ' orphan booking_cars.car_id values. Reconcile or run cleanup.';
            END
        END
        ELSE
        BEGIN
            PRINT 'FK_booking_cars_cars already exists - skipping';
        END
    END
    ELSE
    BEGIN
        PRINT 'Skipping FK to cars: cars PK not detected';
    END
END
GO

-- 3) Ensure car_images.car_id -> cars(<pk>) exists (useful for join)
IF OBJECT_ID('dbo.car_images','U') IS NOT NULL
BEGIN
    IF @car_pk IS NOT NULL
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_car_images_cars')
        BEGIN
            DECLARE @cnt_orphan_ci INT = 0;
            DECLARE @sql3 NVARCHAR(MAX) = N'SELECT @cnt = COUNT(*) FROM dbo.car_images ci LEFT JOIN dbo.cars c ON c.' + QUOTENAME(@car_pk) + ' = ci.car_id WHERE c.' + QUOTENAME(@car_pk) + ' IS NULL';
            EXEC sp_executesql @sql3, N'@cnt INT OUTPUT', @cnt = @cnt_orphan_ci OUTPUT;

            IF @cnt_orphan_ci = 0
            BEGIN
                BEGIN TRY
                    SET @sql3 = N'ALTER TABLE dbo.car_images ADD CONSTRAINT FK_car_images_cars FOREIGN KEY (car_id) REFERENCES dbo.cars(' + QUOTENAME(@car_pk) + N')';
                    EXEC sp_executesql @sql3;
                    PRINT 'Added FK_car_images_cars -> dbo.cars(' + @car_pk + ')';
                END TRY
                BEGIN CATCH
                    PRINT 'ERROR adding FK_car_images_cars: ' + ERROR_MESSAGE();
                END CATCH
            END
            ELSE
            BEGIN
                PRINT 'Cannot add FK_car_images_cars: found ' + CAST(@cnt_orphan_ci AS NVARCHAR(20)) + ' orphan car_images.car_id values. Reconcile or run cleanup.';
            END
        END
        ELSE
        BEGIN
            PRINT 'FK_car_images_cars already exists - skipping';
        END
    END
    ELSE
    BEGIN
        PRINT 'Skipping FK on car_images: cars PK not detected';
    END
END
ELSE
BEGIN
    PRINT 'car_images table not found - skipping car_images FK step';
END
GO

-- 4) Create a view joining the 3 tables for verification
-- It selects booking_cars columns + booking summary + car summary + a sample image_url (most recent)
IF OBJECT_ID('dbo.vw_booking_cars_full','V') IS NOT NULL
BEGIN
    DROP VIEW dbo.vw_booking_cars_full;
END
GO

CREATE VIEW dbo.vw_booking_cars_full AS
SELECT
    bc.booking_car_id,
    bc.booking_id,
    b.[id] AS booking_pk,
    b.[pickup_location],
    b.[return_location],
    b.[pickup_time],
    b.[return_time],
    bc.car_id,
    c.[id] AS car_pk,
    c.[name] AS car_name,
    c.[model] AS car_model,
    c.[license_plate],
    bc.start_date,
    bc.end_date,
    bc.price_at_booking,
    bc.total_price,
    -- sample image (most recent) for the car
    (SELECT TOP(1) ci.url FROM dbo.car_images ci WHERE ci.car_id = bc.car_id ORDER BY ci.created_at DESC) AS sample_image_url,
    bc.created_at,
    bc.updated_at
FROM dbo.booking_cars bc
LEFT JOIN dbo.bookings b ON b.[id] = bc.booking_id
LEFT JOIN dbo.cars c ON c.[id] = bc.car_id;
GO

PRINT 'V5 finished: FKs attempted and view dbo.vw_booking_cars_full created/dropped+created.\n';
PRINT 'If any FK step reported orphan rows, please paste the Messages output here so I can propose cleanup SQL.';
GO
