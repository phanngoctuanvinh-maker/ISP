-- =============================================
-- FIX COMPLETE DATABASE SCHEMA
-- Chạy script này trong SSMS để fix toàn bộ database
-- =============================================

USE drivenow_db;
GO

PRINT '========================================';
PRINT 'STARTING DATABASE FIX...';
PRINT '========================================';

-- =============================================
-- PART 1: RENAME COLUMNS IN BOOKINGS TABLE
-- =============================================
PRINT '';
PRINT '📋 PART 1: Fixing bookings table columns...';

-- 1. Rename 'id' → 'booking_id'
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'bookings' AND COLUMN_NAME = 'id')
BEGIN
    EXEC sp_rename 'dbo.bookings.id', 'booking_id', 'COLUMN';
    PRINT '  ✅ Renamed: id → booking_id';
END
ELSE
    PRINT '  ⚠️ Column "id" not found (may already be renamed)';

-- 2. Rename 'pickup_time' → 'start_time'
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'bookings' AND COLUMN_NAME = 'pickup_time')
BEGIN
    EXEC sp_rename 'dbo.bookings.pickup_time', 'start_time', 'COLUMN';
    PRINT '  ✅ Renamed: pickup_time → start_time';
END
ELSE
    PRINT '  ⚠️ Column "pickup_time" not found';

-- 3. Rename 'return_time' → 'end_time'
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'bookings' AND COLUMN_NAME = 'return_time')
BEGIN
    EXEC sp_rename 'dbo.bookings.return_time', 'end_time', 'COLUMN';
    PRINT '  ✅ Renamed: return_time → end_time';
END
ELSE
    PRINT '  ⚠️ Column "return_time" not found';

-- 4. Rename 'return_location' → 'dropoff_location'
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'bookings' AND COLUMN_NAME = 'return_location')
BEGIN
    EXEC sp_rename 'dbo.bookings.return_location', 'dropoff_location', 'COLUMN';
    PRINT '  ✅ Renamed: return_location → dropoff_location';
END
ELSE
    PRINT '  ⚠️ Column "return_location" not found';

-- 5. Add 'total_amount' column
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'bookings' AND COLUMN_NAME = 'total_amount')
BEGIN
    ALTER TABLE bookings ADD total_amount DECIMAL(18,2) NULL;
    -- Copy existing data from total_price
    UPDATE bookings SET total_amount = ISNULL(total_price, 0);
    PRINT '  ✅ Added column: total_amount';
END
ELSE
    PRINT '  ⚠️ Column "total_amount" already exists';

PRINT '  ✅ Part 1 completed!';
GO

-- =============================================
-- PART 2: ADD FOREIGN KEYS TO BOOKING_CARS
-- =============================================
PRINT '';
PRINT '🔗 PART 2: Adding foreign keys to booking_cars...';

-- 1. FK: booking_cars → bookings
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_booking_cars_bookings')
BEGIN
    ALTER TABLE dbo.booking_cars
    ADD CONSTRAINT FK_booking_cars_bookings
    FOREIGN KEY (booking_id) REFERENCES dbo.bookings(booking_id) ON DELETE CASCADE;
    PRINT '  ✅ Created FK: booking_cars.booking_id → bookings.booking_id (CASCADE)';
END
ELSE
    PRINT '  ⚠️ FK already exists: FK_booking_cars_bookings';

-- 2. FK: booking_cars → cars
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_booking_cars_cars')
BEGIN
    ALTER TABLE dbo.booking_cars
    ADD CONSTRAINT FK_booking_cars_cars
    FOREIGN KEY (car_id) REFERENCES dbo.cars(id) ON DELETE CASCADE;
    PRINT '  ✅ Created FK: booking_cars.car_id → cars.id (CASCADE)';
END
ELSE
    PRINT '  ⚠️ FK already exists: FK_booking_cars_cars';

PRINT '  ✅ Part 2 completed!';
GO

-- =============================================
-- PART 3: VERIFY RESULTS
-- =============================================
PRINT '';
PRINT '🔍 PART 3: Verifying changes...';
PRINT '';

-- Check bookings columns
PRINT '  📊 Bookings table columns:';
SELECT 
    '    - ' + COLUMN_NAME + ' (' + DATA_TYPE + ')' AS ColumnInfo
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'bookings' 
  AND COLUMN_NAME IN ('booking_id', 'start_time', 'end_time', 'dropoff_location', 'total_amount', 'customer_id')
ORDER BY COLUMN_NAME;

-- Check foreign keys
PRINT '';
PRINT '  🔗 Foreign keys on booking_cars:';
SELECT 
    '    - ' + fk.name + ': ' + 
    COL_NAME(fc.parent_object_id, fc.parent_column_id) + ' → ' +
    OBJECT_NAME(fk.referenced_object_id) + '.' +
    COL_NAME(fc.referenced_object_id, fc.referenced_column_id) AS FKInfo
FROM sys.foreign_keys AS fk
INNER JOIN sys.foreign_key_columns AS fc ON fk.object_id = fc.constraint_object_id
WHERE OBJECT_NAME(fk.parent_object_id) = 'booking_cars';

PRINT '';
PRINT '========================================';
PRINT '✅ DATABASE FIX COMPLETED SUCCESSFULLY!';
PRINT '========================================';
PRINT '';
PRINT '📝 Next steps:';
PRINT '   1. Restart Spring Boot application';
PRINT '   2. Refresh web page';
PRINT '   3. Try booking again';
PRINT '';
GO
