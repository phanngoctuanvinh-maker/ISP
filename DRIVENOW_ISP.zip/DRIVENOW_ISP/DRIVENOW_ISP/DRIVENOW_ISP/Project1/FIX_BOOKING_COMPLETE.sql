-- =============================================
-- FIX BOOKING SYSTEM - COMPLETE SOLUTION
-- Sửa lại database để khớp với schema mới
-- =============================================

USE [drivenow_db];
GO

PRINT '========================================';
PRINT 'BƯỚC 1: Xóa các ràng buộc cũ (nếu có)';
PRINT '========================================';

-- Xóa FK constraints cũ
IF EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_BookingCar_Bookings')
    ALTER TABLE [dbo].[bookingcar] DROP CONSTRAINT [FK_BookingCar_Bookings];

IF EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_BookingCar_Cars')
    ALTER TABLE [dbo].[bookingcar] DROP CONSTRAINT [FK_BookingCar_Cars];

IF EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_CarImage_BookingCar')
    ALTER TABLE [dbo].[carimage] DROP CONSTRAINT [FK_CarImage_BookingCar];

PRINT 'Đã xóa các ràng buộc cũ!';
GO

PRINT '========================================';
PRINT 'BƯỚC 2: Rename bảng bookingcar -> booking_cars';
PRINT '========================================';

-- Kiểm tra xem bảng booking_cars đã tồn tại chưa
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'booking_cars')
BEGIN
    -- Rename bảng
    EXEC sp_rename 'bookingcar', 'booking_cars';
    PRINT 'Đã đổi tên bảng bookingcar -> booking_cars';
END
ELSE
BEGIN
    PRINT 'Bảng booking_cars đã tồn tại, bỏ qua bước này';
END
GO

PRINT '========================================';
PRINT 'BƯỚC 3: Cập nhật cấu trúc bảng booking_cars';
PRINT '========================================';

-- Đảm bảo các cột có đúng tên và kiểu dữ liệu
IF COL_LENGTH('booking_cars', 'id') IS NOT NULL AND COL_LENGTH('booking_cars', 'car_id') IS NULL
BEGIN
    EXEC sp_rename 'booking_cars.id', 'car_id', 'COLUMN';
    PRINT 'Đã đổi tên cột id -> car_id trong booking_cars';
END

-- Thêm cột nếu chưa có
IF COL_LENGTH('booking_cars', 'distance_km') IS NULL
    ALTER TABLE booking_cars ADD distance_km DECIMAL(10, 2) NULL;

IF COL_LENGTH('booking_cars', 'allowed_km') IS NULL
    ALTER TABLE booking_cars ADD allowed_km DECIMAL(10, 2) NULL;

IF COL_LENGTH('booking_cars', 'service_fee') IS NULL
    ALTER TABLE booking_cars ADD service_fee DECIMAL(18, 2) NULL;

IF COL_LENGTH('booking_cars', 'area_type') IS NULL
    ALTER TABLE booking_cars ADD area_type VARCHAR(100) NULL;

IF COL_LENGTH('booking_cars', 'extra_km') IS NULL
    ALTER TABLE booking_cars ADD extra_km DECIMAL(10, 2) NULL;

IF COL_LENGTH('booking_cars', 'updated_at') IS NULL
    ALTER TABLE booking_cars ADD updated_at DATETIME2(7) NULL;

-- Xóa cột không cần thiết (nếu có)
IF COL_LENGTH('booking_cars', 'extra_fee') IS NOT NULL
BEGIN
    ALTER TABLE booking_cars DROP COLUMN extra_fee;
    PRINT 'Đã xóa cột extra_fee không cần thiết';
END

PRINT 'Đã cập nhật cấu trúc bảng booking_cars!';
GO

PRINT '========================================';
PRINT 'BƯỚC 4: Cập nhật kiểu dữ liệu cho các cột';
PRINT '========================================';

-- Đảm bảo booking_id là BIGINT
IF EXISTS (SELECT * FROM sys.columns WHERE name = 'booking_id' AND object_id = OBJECT_ID('booking_cars'))
BEGIN
    ALTER TABLE booking_cars ALTER COLUMN booking_id BIGINT NOT NULL;
END

-- Đảm bảo car_id là BIGINT
IF EXISTS (SELECT * FROM sys.columns WHERE name = 'car_id' AND object_id = OBJECT_ID('booking_cars'))
BEGIN
    ALTER TABLE booking_cars ALTER COLUMN car_id BIGINT NOT NULL;
END

-- Cập nhật kiểu dữ liệu cho bookings.booking_id
IF EXISTS (SELECT * FROM sys.columns WHERE name = 'booking_id' AND object_id = OBJECT_ID('bookings'))
BEGIN
    -- Chỉ thực hiện nếu chưa có dữ liệu hoặc dữ liệu ít
    DECLARE @rowCount INT;
    SELECT @rowCount = COUNT(*) FROM bookings;
    
    IF @rowCount < 100 -- Chỉ convert nếu có ít hơn 100 records
    BEGIN
        PRINT 'Cảnh báo: Không thể tự động convert booking_id sang BIGINT vì đã có constraint.';
        PRINT 'Bạn cần tạo lại bảng nếu muốn đổi sang BIGINT.';
    END
END

PRINT 'Đã cập nhật kiểu dữ liệu!';
GO

PRINT '========================================';
PRINT 'BƯỚC 5: Thêm Foreign Key Constraints';
PRINT '========================================';

-- FK: booking_cars.booking_id -> bookings.booking_id
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_booking_cars_bookings')
BEGIN
    ALTER TABLE booking_cars
    ADD CONSTRAINT FK_booking_cars_bookings 
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id)
    ON DELETE CASCADE;
    PRINT 'Đã thêm FK: booking_cars -> bookings';
END

-- FK: booking_cars.car_id -> cars.id
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_booking_cars_cars')
BEGIN
    ALTER TABLE booking_cars
    ADD CONSTRAINT FK_booking_cars_cars 
    FOREIGN KEY (car_id) REFERENCES cars(id)
    ON DELETE NO ACTION;
    PRINT 'Đã thêm FK: booking_cars -> cars';
END

PRINT 'Đã thêm các Foreign Key constraints!';
GO

PRINT '========================================';
PRINT 'BƯỚC 6: Cập nhật bảng carimage';
PRINT '========================================';

-- Rename bảng carimage -> car_images (chuẩn hóa tên)
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'car_images')
BEGIN
    IF EXISTS (SELECT * FROM sys.tables WHERE name = 'carimage')
    BEGIN
        EXEC sp_rename 'carimage', 'car_images';
        PRINT 'Đã đổi tên bảng carimage -> car_images';
    END
END

-- Cập nhật FK cho car_images
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'car_images')
BEGIN
    -- Xóa FK cũ nếu có
    IF EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_CarImage_BookingCar')
        ALTER TABLE car_images DROP CONSTRAINT FK_CarImage_BookingCar;
    
    -- Thêm FK mới
    IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_car_images_booking_cars')
    BEGIN
        ALTER TABLE car_images
        ADD CONSTRAINT FK_car_images_booking_cars
        FOREIGN KEY (booking_car_id) REFERENCES booking_cars(booking_car_id)
        ON DELETE CASCADE;
        PRINT 'Đã thêm FK: car_images -> booking_cars';
    END
END
GO

PRINT '========================================';
PRINT 'BƯỚC 7: Thêm Indexes để tăng hiệu suất';
PRINT '========================================';

-- Index cho booking_cars
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_booking_cars_booking_id' AND object_id = OBJECT_ID('booking_cars'))
    CREATE INDEX IX_booking_cars_booking_id ON booking_cars(booking_id);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_booking_cars_car_id' AND object_id = OBJECT_ID('booking_cars'))
    CREATE INDEX IX_booking_cars_car_id ON booking_cars(car_id);

-- Index cho bookings
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_bookings_customer_id' AND object_id = OBJECT_ID('bookings'))
    CREATE INDEX IX_bookings_customer_id ON bookings(customer_id);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_bookings_status' AND object_id = OBJECT_ID('bookings'))
    CREATE INDEX IX_bookings_status ON bookings(status);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_bookings_created_at' AND object_id = OBJECT_ID('bookings'))
    CREATE INDEX IX_bookings_created_at ON bookings(created_at);

PRINT 'Đã thêm các indexes!';
GO

PRINT '========================================';
PRINT 'BƯỚC 8: Thêm dữ liệu mẫu (nếu chưa có)';
PRINT '========================================';

-- Kiểm tra xem đã có dữ liệu chưa
DECLARE @carCount INT, @bookingCount INT;
SELECT @carCount = COUNT(*) FROM cars;
SELECT @bookingCount = COUNT(*) FROM bookings;

IF @carCount = 0
BEGIN
    PRINT 'Đang thêm dữ liệu xe mẫu...';
    
    INSERT INTO cars (brand, model, name, year, color, car_type, seat_capacity, fuel_type, 
                      transmission_type, price_per_day, daily_rate, status, license_plate,
                      daily_km_limit, exceed_fee_per_km, fuel_consumption, location, created_at)
    VALUES 
    (N'Toyota', N'Vios', N'Toyota Vios 2024', 2024, N'Trắng', N'Sedan', 5, N'Xăng', 
     N'Tự động', 500000, 500000, 'available', N'29A-12345',
     300, 5000, 6.5, N'TP. Hồ Chí Minh', GETDATE()),
    
    (N'Honda', N'CR-V', N'Honda CR-V 2024', 2024, N'Đen', N'SUV', 7, N'Xăng',
     N'Tự động', 800000, 800000, 'available', N'29B-67890',
     350, 5000, 7.8, N'TP. Hồ Chí Minh', GETDATE()),
    
    (N'Mercedes', N'E-Class', N'Mercedes E-Class 2024', 2024, N'Bạc', N'Sedan', 5, N'Xăng',
     N'Tự động', 1200000, 1200000, 'available', N'29C-11111',
     400, 8000, 8.5, N'TP. Hồ Chí Minh', GETDATE()),
    
    (N'Ford', N'Everest', N'Ford Everest 2024', 2024, N'Xanh', N'SUV', 7, N'Dầu',
     N'Tự động', 900000, 900000, 'available', N'29D-22222',
     350, 5000, 8.0, N'Hà Nội', GETDATE()),
    
    (N'Mazda', N'CX-5', N'Mazda CX-5 2024', 2024, N'Đỏ', N'SUV', 5, N'Xăng',
     N'Tự động', 700000, 700000, 'available', N'29E-33333',
     300, 5000, 7.2, N'Đà Nẵng', GETDATE());
    
    PRINT 'Đã thêm ' + CAST(@@ROWCOUNT AS VARCHAR) + ' xe mẫu!';
END
ELSE
BEGIN
    PRINT 'Đã có ' + CAST(@carCount AS VARCHAR) + ' xe trong database!';
END
GO

PRINT '========================================';
PRINT 'BƯỚC 9: Tạo View để truy vấn dễ dàng';
PRINT '========================================';

-- Drop view cũ nếu có
IF OBJECT_ID('vw_booking_details', 'V') IS NOT NULL
    DROP VIEW vw_booking_details;
GO

-- Tạo view mới
CREATE VIEW vw_booking_details AS
SELECT 
    b.booking_id,
    b.customer_id,
    c.full_name as customer_name,
    c.phone as customer_phone,
    c.email as customer_email,
    b.driver_id,
    b.start_time,
    b.end_time,
    b.pickup_location,
    b.dropoff_location,
    b.trip_type,
    b.one_way,
    b.status,
    b.base_price,
    b.discount_amount,
    b.total_amount,
    b.created_at,
    -- Thông tin xe (lấy xe đầu tiên nếu có nhiều xe)
    (SELECT TOP 1 car_id FROM booking_cars WHERE booking_id = b.booking_id) as car_id,
    (SELECT TOP 1 car.name FROM booking_cars bc 
     JOIN cars car ON bc.car_id = car.id 
     WHERE bc.booking_id = b.booking_id) as car_name,
    (SELECT TOP 1 car.license_plate FROM booking_cars bc 
     JOIN cars car ON bc.car_id = car.id 
     WHERE bc.booking_id = b.booking_id) as car_license_plate,
    -- Đếm số xe
    (SELECT COUNT(*) FROM booking_cars WHERE booking_id = b.booking_id) as car_count
FROM bookings b
LEFT JOIN customer c ON b.customer_id = c.customer_id;
GO

PRINT 'Đã tạo view vw_booking_details!';
GO

PRINT '========================================';
PRINT 'BƯỚC 10: Tạo Stored Procedures';
PRINT '========================================';

-- SP: Lấy danh sách bookings của customer
IF OBJECT_ID('sp_GetCustomerBookings', 'P') IS NOT NULL
    DROP PROCEDURE sp_GetCustomerBookings;
GO

CREATE PROCEDURE sp_GetCustomerBookings
    @customer_id INT
AS
BEGIN
    SELECT * FROM vw_booking_details
    WHERE customer_id = @customer_id
    ORDER BY created_at DESC;
END
GO

-- SP: Lấy chi tiết booking
IF OBJECT_ID('sp_GetBookingDetail', 'P') IS NOT NULL
    DROP PROCEDURE sp_GetBookingDetail;
GO

CREATE PROCEDURE sp_GetBookingDetail
    @booking_id INT
AS
BEGIN
    -- Thông tin booking
    SELECT * FROM vw_booking_details WHERE booking_id = @booking_id;
    
    -- Danh sách xe trong booking
    SELECT 
        bc.booking_car_id,
        bc.car_id,
        car.name as car_name,
        car.license_plate,
        car.brand,
        car.model,
        bc.start_date,
        bc.end_date,
        bc.price_at_booking,
        bc.total_price
    FROM booking_cars bc
    JOIN cars car ON bc.car_id = car.id
    WHERE bc.booking_id = @booking_id;
END
GO

PRINT 'Đã tạo các Stored Procedures!';
GO

PRINT '========================================';
PRINT 'HOÀN THÀNH! Kiểm tra kết quả';
PRINT '========================================';

-- Hiển thị thống kê
PRINT 'Thống kê database:';
SELECT 'Số xe' as Item, COUNT(*) as Count FROM cars
UNION ALL
SELECT 'Số booking', COUNT(*) FROM bookings
UNION ALL
SELECT 'Số booking_cars', COUNT(*) FROM booking_cars
UNION ALL
SELECT 'Số customer', COUNT(*) FROM customer;

PRINT '';
PRINT 'Cấu trúc bảng booking_cars:';
SELECT 
    COLUMN_NAME, 
    DATA_TYPE, 
    CHARACTER_MAXIMUM_LENGTH,
    IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'booking_cars'
ORDER BY ORDINAL_POSITION;

PRINT '';
PRINT 'Foreign Keys:';
SELECT 
    fk.name as FK_Name,
    OBJECT_NAME(fk.parent_object_id) as Table_Name,
    COL_NAME(fc.parent_object_id, fc.parent_column_id) as Column_Name,
    OBJECT_NAME(fk.referenced_object_id) as Referenced_Table,
    COL_NAME(fc.referenced_object_id, fc.referenced_column_id) as Referenced_Column
FROM sys.foreign_keys fk
JOIN sys.foreign_key_columns fc ON fk.object_id = fc.constraint_object_id
WHERE OBJECT_NAME(fk.parent_object_id) IN ('booking_cars', 'car_images')
ORDER BY fk.name;

PRINT '';
PRINT '✅ ĐÃ HOÀN THÀNH SỬA LẠI DATABASE!';
PRINT '✅ Bạn có thể chạy lại Spring Boot application!';
