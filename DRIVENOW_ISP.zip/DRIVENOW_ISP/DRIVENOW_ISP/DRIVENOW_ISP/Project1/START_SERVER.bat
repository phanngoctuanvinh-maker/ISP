@echo off
cd /d "%~dp0"
echo Starting Spring Boot Application...
call mvnw.cmd spring-boot:run
pause
