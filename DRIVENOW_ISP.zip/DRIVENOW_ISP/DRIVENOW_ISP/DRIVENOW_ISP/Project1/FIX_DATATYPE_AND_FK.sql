-- =============================================
-- FIX DATA TYPES AND ADD FOREIGN KEYS
-- =============================================

USE drivenow_db;
GO

PRINT '========================================';
PRINT 'FIXING DATA TYPES...';
PRINT '========================================';

-- 1. Change booking_cars.booking_id from BIGINT to INT
ALTER TABLE dbo.booking_cars
ALTER COLUMN booking_id INT NOT NULL;
PRINT '  ✅ Changed: booking_cars.booking_id from BIGINT to INT';

-- 2. Change booking_cars.car_id from BIGINT to INT
ALTER TABLE dbo.booking_cars
ALTER COLUMN car_id INT NOT NULL;
PRINT '  ✅ Changed: booking_cars.car_id from BIGINT to INT';

PRINT '';
PRINT '========================================';
PRINT 'ADDING FOREIGN KEYS...';
PRINT '========================================';

-- 3. FK: booking_cars → bookings
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_booking_cars_bookings')
BEGIN
    ALTER TABLE dbo.booking_cars
    ADD CONSTRAINT FK_booking_cars_bookings
    FOREIGN KEY (booking_id) REFERENCES dbo.bookings(booking_id) ON DELETE CASCADE;
    PRINT '  ✅ Created FK: booking_cars.booking_id → bookings.booking_id (CASCADE)';
END
ELSE
    PRINT '  ⚠️ FK already exists: FK_booking_cars_bookings';

-- 4. FK: booking_cars → cars
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_booking_cars_cars')
BEGIN
    ALTER TABLE dbo.booking_cars
    ADD CONSTRAINT FK_booking_cars_cars
    FOREIGN KEY (car_id) REFERENCES dbo.cars(id) ON DELETE CASCADE;
    PRINT '  ✅ Created FK: booking_cars.car_id → cars.id (CASCADE)';
END
ELSE
    PRINT '  ⚠️ FK already exists: FK_booking_cars_cars';

PRINT '';
PRINT '========================================';
PRINT '✅ ALL CHANGES COMPLETED SUCCESSFULLY!';
PRINT '========================================';
GO

-- Verify
PRINT '';
PRINT 'Verification:';
SELECT 
    fk.name AS ForeignKeyName,
    OBJECT_NAME(fk.parent_object_id) AS TableName,
    COL_NAME(fc.parent_object_id, fc.parent_column_id) AS ColumnName,
    OBJECT_NAME(fk.referenced_object_id) AS ReferencedTable,
    COL_NAME(fc.referenced_object_id, fc.referenced_column_id) AS ReferencedColumn
FROM sys.foreign_keys AS fk
INNER JOIN sys.foreign_key_columns AS fc ON fk.object_id = fc.constraint_object_id
WHERE OBJECT_NAME(fk.parent_object_id) = 'booking_cars';
GO
