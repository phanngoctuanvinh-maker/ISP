// Load environment variables from .env if present
try { require('dotenv').config(); } catch(e) { /* dotenv not installed or not needed */ }
const express = require('express');
const fetch = require('node-fetch');
const cors = require('cors');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());

// Serve static frontend so you can run one process for demo.
// Serve from the project root (DriveNow/) so the HTML's relative paths like "../css/..." resolve correctly.
const staticRoot = path.join(__dirname, '..');
app.use(express.static(staticRoot));
console.log('[ors-proxy] serving static files from', staticRoot);

// Ensure accessing / or /homepage.html returns the html/homepage.html file
app.get(['/', '/homepage.html'], (req, res) => {
  res.sendFile(path.join(staticRoot, 'html', 'homepage.html'));
});

const ORS_KEY = process.env.ORS_KEY || '';
if (!ORS_KEY) {
  console.warn('[ors-proxy] Warning: ORS_KEY environment variable is not set. You can set it in a .env file or using setx ORS_KEY "your_key"');
} else {
  // show masked key for verification
  console.log('[ors-proxy] ORS_KEY set (first 8 chars):', ORS_KEY.substr(0,8) + '...');
}

// Simple health check
app.get('/api/ors/health', (req, res) => res.json({ ok: true }));

// Reverse geocoding: accept query ?lat=...&lon=... and return a readable address.
app.get('/api/ors/reverse', async (req, res) => {
  try {
    const lat = req.query.lat;
    const lon = req.query.lon;
    if (!lat || !lon) return res.status(400).json({ error: 'lat and lon required' });

    // If ORS_KEY is provided, prefer OpenRouteService reverse geocode
    if (ORS_KEY) {
      const url = `https://api.openrouteservice.org/geocode/reverse?api_key=${encodeURIComponent(ORS_KEY)}&point.lat=${encodeURIComponent(lat)}&point.lon=${encodeURIComponent(lon)}`;
      const r = await fetch(url, { headers: { 'Accept': 'application/json' } });
      const json = await r.json();
      // Build a friendly address from common ORS properties
      let address = null;
      try {
        if (json && json.features && json.features[0] && json.features[0].properties) {
          const p = json.features[0].properties;
          // Prefer full label if available
          if (p.label) address = p.label;
          else {
            const parts = [];
            if (p.housenumber) parts.push(p.housenumber);
            if (p.street) parts.push(p.street);
            if (p.name && parts.length === 0) parts.push(p.name);
            if (p.locality) parts.push(p.locality);
            if (p.county) parts.push(p.county);
            if (p.region) parts.push(p.region);
            if (p.postcode) parts.push(p.postcode);
            if (p.country) parts.push(p.country);
            if (parts.length) address = parts.join(', ');
          }
        }
      } catch (e) { /* ignore */ }
      return res.status(r.status).json({ address: address || null, raw: json });
    }

    // Fallback to Nominatim (OpenStreetMap) if no ORS key
    const nomUrl = `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${encodeURIComponent(lat)}&lon=${encodeURIComponent(lon)}`;
    const r2 = await fetch(nomUrl, { headers: { 'Accept': 'application/json', 'User-Agent': 'DriveNow-Demo/1.0' } });
    const j2 = await r2.json();
    const address2 = j2 && (j2.display_name || null);
    return res.status(r2.status).json({ address: address2, raw: j2 });
  } catch (err) {
    console.error('[ors-proxy] reverse error', err && err.stack ? err.stack : err);
    res.status(500).json({ error: 'reverse proxy error' });
  }
});

// Forward geocoding / search: ?q=search text
app.get('/api/ors/search', async (req, res) => {
  try {
    const q = req.query.q;
    if (!q) return res.status(400).json({ error: 'q required' });

    if (ORS_KEY) {
      // Allow client to request a country preference via ?country=VN which we forward to ORS as boundary.country
      const country = req.query.country ? String(req.query.country).toUpperCase() : '';
      const countryParam = country ? `&boundary.country=${encodeURIComponent(country)}` : '';
      const url = `https://api.openrouteservice.org/geocode/search?api_key=${encodeURIComponent(ORS_KEY)}&text=${encodeURIComponent(q)}${countryParam}`;
      const r = await fetch(url, { headers: { 'Accept': 'application/json' } });
      const j = await r.json();
      // Map to simple candidates
      const candidates = (j && j.features || []).map(f => {
        const p = f.properties || {};
        const geom = f.geometry && f.geometry.coordinates;
        return { name: p.label || p.name || p.city || q, lon: geom && geom[0], lat: geom && geom[1], raw: f };
      });
      return res.status(r.status).json({ candidates });
    }

    // fallback to Nominatim search
    const nom = `https://nominatim.openstreetmap.org/search?format=jsonv2&q=${encodeURIComponent(q)}`;
    const r2 = await fetch(nom, { headers: { 'Accept': 'application/json', 'User-Agent': 'DriveNow-Demo/1.0' } });
    const j2 = await r2.json();
    const candidates2 = (j2 || []).map(item => ({ name: item.display_name, lat: parseFloat(item.lat), lon: parseFloat(item.lon), raw: item }));
    return res.status(r2.status).json({ candidates: candidates2 });
  } catch (err) {
    console.error('[ors-proxy] search error', err && err.stack ? err.stack : err);
    res.status(500).json({ error: 'search proxy error' });
  }
});

// Proxy directions request. Expects JSON body: { origin: {lat, lon}, destination: {lat, lon} }
app.post('/api/ors/directions', async (req, res) => {
  try {
    const { origin, destination } = req.body || {};
    if (!origin || !destination) return res.status(400).json({ error: 'origin and destination required' });

    // ORS expects [lon, lat]
    const body = { coordinates: [[origin.lon, origin.lat], [destination.lon, destination.lat]] };
    // If ORS key is not configured, return a light-weight mock response so demo still works
    if (!ORS_KEY) {
      // compute haversine distance (meters)
      function haversine(lat1, lon1, lat2, lon2) {
        function toRad(v){ return v * Math.PI / 180; }
        const R = 6371000; // meters
        const dLat = toRad(lat2 - lat1);
        const dLon = toRad(lon2 - lon1);
        const a = Math.sin(dLat/2) * Math.sin(dLat/2) + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon/2) * Math.sin(dLon/2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        return R * c;
      }
      const straight = haversine(origin.lat, origin.lon, destination.lat, destination.lon);
      // inflate to approximate driving distance
      const distanceMeters = Math.round(straight * 1.18);
      // assume average speed 50 km/h for duration estimate
      const durationSec = Math.round((distanceMeters/1000) / 50 * 3600);

      const geo = {
        type: 'FeatureCollection',
        features: [
          {
            type: 'Feature',
            properties: {
              summary: { distance: distanceMeters, duration: durationSec }
            },
            geometry: {
              type: 'LineString',
              coordinates: [ [origin.lon, origin.lat], [destination.lon, destination.lat] ]
            }
          }
        ]
      };
      return res.status(200).json(geo);
    }

    const resp = await fetch('https://api.openrouteservice.org/v2/directions/driving-car/geojson', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json, application/geo+json',
        'Authorization': ORS_KEY
      },
      body: JSON.stringify(body)
    });

    const text = await resp.text();
    // forward status and body
    res.status(resp.status).send(text);
  } catch (err) {
    console.error('[ors-proxy] error', err && err.stack ? err.stack : err);
    res.status(500).json({ error: 'internal proxy error' });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`[ors-proxy] listening on port ${port}`));
