// ============================================
// CARDETAIL.JS - CHI TIẾT XE
// ============================================

const API_BASE_URL = 'http://localhost:8080/api';

// ============================================
// 1. LẤY THÔNG TIN XE TỪ URL
// ============================================
function getCarIdFromURL() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('id');
}

// ============================================
// 2. GỌI API LẤY CHI TIẾT XE
// ============================================
async function fetchCarDetail(carId) {
    try {
        const response = await fetch(`${API_BASE_URL}/cars/${carId}`);
        
        if (!response.ok) {
            throw new Error('Không tìm thấy xe');
        }
        
        const car = await response.json();
        return car;
    } catch (error) {
        console.error('Lỗi khi lấy thông tin xe:', error);
        alert('Không thể tải thông tin xe. Vui lòng thử lại!');
        return null;
    }
}

// ============================================
// 3. RENDER THÔNG TIN XE LÊN GIAO DIỆN
// ============================================
function renderCarDetail(car) {
    // Update title
    document.querySelector('.car-title').textContent = 
        `${car.brand} ${car.name} ${car.year || ''}`;
    
    // Update subtitle (location)
    document.querySelector('.car-subtitle').textContent = 
        `📍 ${car.location || 'Chưa cập nhật vị trí'} • ⭐ Đánh giá: Chưa có • Số chuyến: 0`;
    
    // Update price
    document.querySelector('.booking-price .price-value').textContent = 
        formatPrice(car.pricePerDay) + '/ngày';
    
    // Update features
    updateFeatures(car);
    
    // Update description
    document.querySelector('.car-section p').textContent = 
        car.description || 'Chưa có mô tả';
    
    // Update amenities (mock data - cần table riêng trong DB thật)
    updateAmenities(car);
    
    // Update images (mock - cần table car_images)
    updateImages(car);
    
    // Update booking info
    updateBookingInfo(car);
}

// ============================================
// 4. CẬP NHẬT ĐẶC ĐIỂM XE
// ============================================
function updateFeatures(car) {
    const featuresHTML = `
        <div class="feature-item">
            <i class="fas fa-cogs feature-icon"></i>
            <div>
                <span class="feature-label">Truyền động</span>
                <strong class="feature-value">${car.transmissionType || 'N/A'}</strong>
            </div>
        </div>
        <div class="feature-item">
            <i class="fas fa-chair feature-icon"></i>
            <div>
                <span class="feature-label">Số ghế</span>
                <strong class="feature-value">${car.seatCapacity || 'N/A'} chỗ</strong>
            </div>
        </div>
        <div class="feature-item">
            <i class="fas fa-gas-pump feature-icon"></i>
            <div>
                <span class="feature-label">Nhiên liệu</span>
                <strong class="feature-value">${car.fuelType || 'N/A'}</strong>
            </div>
        </div>
        <div class="feature-item">
            <i class="fas fa-car feature-icon"></i>
            <div>
                <span class="feature-label">Loại xe</span>
                <strong class="feature-value">${car.carType || 'N/A'}</strong>
            </div>
        </div>
        <div class="feature-item">
            <i class="fas fa-palette feature-icon"></i>
            <div>
                <span class="feature-label">Màu sắc</span>
                <strong class="feature-value">${car.color || 'N/A'}</strong>
            </div>
        </div>
        <div class="feature-item">
            <i class="fas fa-tachometer-alt feature-icon"></i>
            <div>
                <span class="feature-label">Số km đã đi</span>
                <strong class="feature-value">${car.mileage ? car.mileage.toLocaleString() + ' km' : 'N/A'}</strong>
            </div>
        </div>
    `;
    
    document.querySelector('.features-grid').innerHTML = featuresHTML;
}

// ============================================
// 5. CẬP NHẬT TIỆN NGHI
// ============================================
function updateAmenities(car) {
    // Mock amenities - trong thực tế cần table car_features
    const amenities = [
        { icon: 'fab fa-bluetooth-b', name: 'Bluetooth' },
        { icon: 'fas fa-camera-retro', name: 'Camera lùi' },
        { icon: 'fas fa-broadcast-tower', name: 'Cảm biến va chạm' },
        { icon: 'fas fa-tachometer-alt', name: 'Cảnh báo tốc độ' },
        { icon: 'fas fa-circle-notch', name: 'Lốp dự phòng' },
        { icon: 'fas fa-road', name: 'ETC' },
        { icon: 'fas fa-shield-alt', name: 'Túi khí an toàn' }
    ];
    
    const amenitiesHTML = amenities.map(amenity => 
        `<div class="amenity-item"><i class="${amenity.icon}"></i> ${amenity.name}</div>`
    ).join('');
    
    document.querySelector('.amenities-grid').innerHTML = amenitiesHTML;
}

// ============================================
// 6. CẬP NHẬT HÌNH ẢNH
// ============================================
function updateImages(car) {
    const imageUrl = car.imageUrl || '../assets/inmage/default-car.jpg';
    
    // Main image
    const mainGallery = document.querySelector('.image-gallery-main');
    mainGallery.style.backgroundImage = `url(${imageUrl})`;
    mainGallery.style.backgroundSize = 'cover';
    mainGallery.style.backgroundPosition = 'center';
    
    // Side images (giống main vì chưa có nhiều ảnh)
    const sideGalleries = document.querySelectorAll('.image-gallery-side');
    sideGalleries.forEach((gallery, index) => {
        if (index < 2) { // Chỉ 2 ảnh đầu
            gallery.style.backgroundImage = `url(${imageUrl})`;
            gallery.style.backgroundSize = 'cover';
            gallery.style.backgroundPosition = 'center';
        }
    });
}

// ============================================
// 7. CẬP NHẬT THÔNG TIN BOOKING
// ============================================
function updateBookingInfo(car) {
    // Update km limit & exceed fee
    const infoSection = document.querySelector('.itinerary-info-section');
    
    if (car.dailyKmLimit && car.exceedFeePerKm) {
        infoSection.innerHTML = `
            <h6 class="section-subtitle">Thông tin lộ trình</h6>
            <div class="info-item">
                <span>Giới hạn km/ngày</span>
                <strong>${car.dailyKmLimit} km</strong>
            </div>
            <div class="info-item">
                <span>Phí vượt giới hạn</span>
                <strong>${formatPrice(car.exceedFeePerKm)}/km</strong>
            </div>
        `;
    } else if (!car.dailyKmLimit || car.dailyKmLimit === null) {
        infoSection.innerHTML = `
            <h6 class="section-subtitle">Thông tin lộ trình</h6>
            <div class="info-item">
                <span>Giới hạn km/ngày</span>
                <strong class="text-success">Không giới hạn</strong>
            </div>
            <div class="info-item">
                <span>Phí vượt giới hạn</span>
                <strong class="text-success">Miễn phí</strong>
            </div>
        `;
    }
    
    // Update fuel consumption
    if (car.fuelConsumption && car.fuelConsumption > 0) {
        const fuelInfo = `
            <div class="info-item mt-2">
                <span>Mức tiêu thụ nhiên liệu</span>
                <strong>${car.fuelConsumption} L/100km</strong>
            </div>
        `;
        infoSection.innerHTML += fuelInfo;
    }
}

// ============================================
// 8. ITINERARY LOGIC (GIỐNG CŨ)
// ============================================
function initializeItinerary() {
    const itineraryRadios = document.querySelectorAll('input[name="itinerary"]');
    const itineraryLocal = document.getElementById('itinerary-local');
    const itineraryIntercity = document.getElementById('itinerary-intercity');
    const itineraryNote = itineraryIntercity?.querySelector('.itinerary-note');
    const itineraryFees = document.getElementById('itinerary-info-fees');

    const notes = {
        local: 'Di chuyển nội thành hoặc lân cận, lộ trình tự do. <i class="far fa-question-circle"></i>',
        intercity: 'Di chuyển liên tỉnh, trả khách về lại điểm đón. <i class="far fa-question-circle"></i>',
        oneway: 'Di chuyển liên tỉnh, trả khách tại điểm đến. <i class="far fa-question-circle"></i>'
    };

    function updateItineraryView(selectedValue) {
        if (!itineraryLocal || !itineraryIntercity) return;
        
        if (selectedValue === 'local') {
            itineraryLocal.style.display = 'block';
            itineraryIntercity.style.display = 'none';
            if (itineraryFees) itineraryFees.style.display = 'none';
        } else {
            itineraryLocal.style.display = 'none';
            itineraryIntercity.style.display = 'block';
            if (itineraryFees) itineraryFees.style.display = 'block';
            if (itineraryNote) itineraryNote.innerHTML = notes[selectedValue];
        }
    }

    itineraryRadios.forEach(radio => {
        radio.addEventListener('change', function () {
            updateItineraryView(this.value);
        });
    });

    // Initial check
    const initialSelected = document.querySelector('input[name="itinerary"]:checked');
    if (initialSelected) {
        updateItineraryView(initialSelected.value);
    }
}

// ============================================
// 9. HELPER FUNCTIONS
// ============================================
function formatPrice(price) {
    if (!price) return '0đ';
    return new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND'
    }).format(price);
}

// ============================================
// 10. MAIN - KHỞI ĐỘNG TRANG
// ============================================
document.addEventListener('DOMContentLoaded', async function () {
    // Lấy ID từ URL
    const carId = getCarIdFromURL();
    
    if (!carId) {
        alert('Không tìm thấy ID xe!');
        window.location.href = 'searchcar.html';
        return;
    }
    
    // Fetch & Render car detail
    const car = await fetchCarDetail(carId);
    
    if (car) {
        renderCarDetail(car);
    }
    
    // Initialize itinerary logic
    initializeItinerary();
    
    // Add event listeners
    setupEventListeners();
});

// ============================================
// 11. EVENT LISTENERS
// ============================================
function setupEventListeners() {
    // Nút "Chọn thuê"
    const rentButton = document.querySelector('.btn-rent');
    if (rentButton) {
        rentButton.addEventListener('click', function() {
            if (!rentButton.disabled) {
                alert('Chức năng đặt xe đang được phát triển!');
                // TODO: Navigate to booking page
            }
        });
    }
    
    // Nút "Xem tất cả ảnh"
    const viewAllBtn = document.querySelector('.btn-view-all');
    if (viewAllBtn) {
        viewAllBtn.addEventListener('click', function() {
            alert('Chức năng xem ảnh đang được phát triển!');
            // TODO: Open image gallery modal
        });
    }
    
    // Nút "Báo cáo xe này"
    const reportLink = document.querySelector('.report-car-link a');
    if (reportLink) {
        reportLink.addEventListener('click', function(e) {
            e.preventDefault();
            alert('Chức năng báo cáo đang được phát triển!');
            // TODO: Open report modal
        });
    }
    
    // Nút share và favorite
    const shareBtn = document.querySelector('.car-actions .btn-icon:first-child');
    const favoriteBtn = document.querySelector('.car-actions .btn-icon:last-child');
    
    if (shareBtn) {
        shareBtn.addEventListener('click', function() {
            alert('Chức năng chia sẻ đang được phát triển!');
        });
    }
    
    if (favoriteBtn) {
        favoriteBtn.addEventListener('click', function() {
            this.querySelector('i').classList.toggle('far');
            this.querySelector('i').classList.toggle('fas');
            this.querySelector('i').classList.toggle('text-danger');
        });
    }
}
