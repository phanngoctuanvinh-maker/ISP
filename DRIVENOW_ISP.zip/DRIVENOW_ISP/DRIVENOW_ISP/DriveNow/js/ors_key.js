// This file intentionally exposes ORS key for local testing with Live Server.
// You asked to make the key public so the frontend can call ORS directly.
// If you later want to hide the key again, remove this file and use DriveNow/backend/.env instead.
window.ORS_KEY = "eyJvcmciOiI1YjNjZTM1OTc4NTExMTAwMDFjZjYyNDgiLCJpZCI6IjI1ZjNmMTM3OTg3ZjQzYzRhNDA5ODljZDk2MzAwMTJjIiwiaCI6Im11cm11cjY0In0=";
