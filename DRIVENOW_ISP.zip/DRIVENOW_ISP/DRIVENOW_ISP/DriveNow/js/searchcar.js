// ========================================
// DRIVENOW - SEARCH CAR PAGE  
// Updated: 2025-10-21
// New Structure: car_type + seat_capacity
// ========================================

const API_BASE_URL = "http://localhost:8080/api";
let currentCars = [];
let selectedCarType = null;
let selectedBrand = null;
let selectedTransmission = null;

// ========================================
// INITIALIZATION
// ========================================

document.addEventListener("DOMContentLoaded", function() {
    console.log("DriveNow Search Car Page Loaded");
    
    const urlParams = new URLSearchParams(window.location.search);
    const location = urlParams.get("location");
    const time = urlParams.get("time");
    
    displaySearchInfo(location, time);
    
    initializeFilterTabs();
    initializeCarTypeModal();
    initializeCarBrandModal();
    initializeTransmissionModal();
    
    loadAllCars();
});

function displaySearchInfo(location, time) {
    if (location) {
        const locationElement = document.querySelector(".search-info-item:first-child span");
        if (locationElement) {
            locationElement.textContent = location;
        }
    }
    if (time) {
        const timeElement = document.querySelector(".search-info-item:last-child span");
        if (timeElement) {
            timeElement.textContent = time;
        }
    }
}

// ========================================
// FILTER TABS
// ========================================

function initializeFilterTabs() {
    const filterTabs = document.querySelectorAll(".filter-tab");
    
    filterTabs.forEach(function(tab) {
        tab.addEventListener("click", function() {
            const tabText = tab.textContent.trim();
            console.log("Filter tab clicked:", tabText);
            
            // Remove active class from all tabs
            filterTabs.forEach(function(t) { t.classList.remove("active"); });
            
            // Add active class to clicked tab
            tab.classList.add("active");
            
            // Check if it's a modal button (don't load data yet, wait for modal apply)
            if (tabText.includes("Loại Xe") || tabText.includes("Hãng Xe") || tabText.includes("Truyền động") || 
                tabText.includes("Lo?i Xe") || tabText.includes("H�ng Xe") || tabText.includes("Truy?n d?ng")) {
                console.log("Modal button clicked - waiting for selection");
                return;
            }
            
            // Handle different filter types (direct action tabs)
            if (tabText === "Tất cả" || tabText === "T?t c?" || tabText.toLowerCase().includes("tất cả")) {
                console.log("Loading all cars...");
                loadAllCars();
            } else if (tabText.includes("Xăng") || tabText.includes("Hybrid") || tabText.includes("&") || tabText.toLowerCase().includes("hybrid")) {
                // Check Hybrid TRƯỚC Xe Điện vì "Xe Xăng &Điện" cũng chứa từ "Điện"
                console.log("Loading hybrid cars...");
                loadHybridCars();
            } else if (tabText.includes("Xe Điện") || tabText.includes("Xe �i?n") || tabText.toLowerCase().includes("điện")) {
                console.log("Loading electric cars...");
                loadElectricCars();
            }
        });
    });
}

// ========================================
// CAR TYPE MODAL
// ========================================

function initializeCarTypeModal() {
    const carTypeItems = document.querySelectorAll(".car-type-item");
    const applyBtn = document.getElementById("applyCarType");
    const modal = document.getElementById("carTypeModal");
    
    carTypeItems.forEach(function(item) {
        item.addEventListener("click", function() {
            carTypeItems.forEach(function(i) { i.classList.remove("selected"); });
            item.classList.add("selected");
            selectedCarType = item.getAttribute("data-type");
            console.log("Selected car type:", selectedCarType);
        });
    });
    
    if (applyBtn) {
        applyBtn.addEventListener("click", function() {
            if (selectedCarType) {
                console.log("Applying car type filter:", selectedCarType);
                filterCarsByType(selectedCarType);
                const bsModal = bootstrap.Modal.getInstance(modal);
                if (bsModal) { bsModal.hide(); }
            } else {
                alert("Vui l�ng ch?n lo?i xe");
            }
        });
    }
}

// ========================================
// CAR BRAND MODAL
// ========================================

function initializeCarBrandModal() {
    const brandItems = document.querySelectorAll(".brand-card-item");
    const applyBtn = document.getElementById("applyCarBrand");
    const modal = document.getElementById("carBrandModal");
    
    brandItems.forEach(function(item) {
        item.addEventListener("click", function() {
            brandItems.forEach(function(i) { i.classList.remove("selected"); });
            item.classList.add("selected");
            selectedBrand = item.getAttribute("data-brand");
            console.log("Selected brand:", selectedBrand);
        });
    });
    
    if (applyBtn) {
        applyBtn.addEventListener("click", function() {
            if (selectedBrand) {
                console.log("Applying brand filter:", selectedBrand);
                filterCarsByBrand(selectedBrand);
                const bsModal = bootstrap.Modal.getInstance(modal);
                if (bsModal) { bsModal.hide(); }
            } else {
                alert("Vui l�ng ch?n h�ng xe");
            }
        });
    }
}

// ========================================
// TRANSMISSION MODAL
// ========================================

function initializeTransmissionModal() {
    const applyBtn = document.getElementById("applyTransmission");
    const modal = document.getElementById("transmissionModal");
    
    if (applyBtn) {
        applyBtn.addEventListener("click", function() {
            const selectedRadio = document.querySelector("input[name=\"transmissionOption\"]:checked");
            if (selectedRadio) {
                selectedTransmission = selectedRadio.value;
                console.log("Applying transmission filter:", selectedTransmission);
                if (selectedTransmission === "all") {
                    loadAllCars();
                } else {
                    filterCarsByTransmission(selectedTransmission);
                }
                const bsModal = bootstrap.Modal.getInstance(modal);
                if (bsModal) { bsModal.hide(); }
            }
        });
    }
}

// ========================================
// HELPER FUNCTIONS
// ========================================

function setActiveFilterTab(tabText) {
    const filterTabs = document.querySelectorAll(".filter-tab");
    filterTabs.forEach(function(tab) {
        const text = tab.textContent.trim();
        const isMatch = text === tabText || 
                       text.toLowerCase().includes(tabText.toLowerCase()) ||
                       (tabText === "Tất cả" && (text === "T?t c?" || text.toLowerCase().includes("tất cả")));
        
        if (isMatch) {
            tab.classList.add("active");
        } else {
            tab.classList.remove("active");
        }
    });
}

function resetAllFilters() {
    // Reset variables
    selectedCarType = null;
    selectedBrand = null;
    selectedTransmission = null;
    
    // Reset visual selections in modals
    document.querySelectorAll(".car-type-item.selected").forEach(function(item) {
        item.classList.remove("selected");
    });
    document.querySelectorAll(".brand-card-item.selected").forEach(function(item) {
        item.classList.remove("selected");
    });
    document.querySelectorAll(".transmission-item.selected").forEach(function(item) {
        item.classList.remove("selected");
    });
    
    // Set "Tất cả" tab as active
    setActiveFilterTab("Tất cả");
    
    console.log("All filters reset");
}

async function loadAllCars() {
    try {
        console.log("Loading all cars...");
        
        // Reset all filters
        resetAllFilters();
        
        const response = await fetch(API_BASE_URL + "/cars/all");
        if (!response.ok) { throw new Error("HTTP error! status: " + response.status); }
        const data = await response.json();
        console.log("All cars loaded:", data);
        if (data.success && data.cars) {
            currentCars = data.cars;
            renderCars(data.cars);
        } else {
            showError("Không thể tải dữ liệu xe");
        }
    } catch (error) {
        console.error("Error loading all cars:", error);
        showError("Lỗi khi tải danh sách xe: " + error.message);
    }
}

async function loadElectricCars() {
    try {
        console.log("Loading electric cars...");
        const response = await fetch(API_BASE_URL + "/cars/electric");
        if (!response.ok) { throw new Error("HTTP error! status: " + response.status); }
        const data = await response.json();
        console.log("Electric cars loaded:", data);
        if (data.success && data.cars) {
            currentCars = data.cars;
            renderCars(data.cars);
        } else {
            showError("Kh�ng t�m th?y xe di?n");
        }
    } catch (error) {
        console.error("Error loading electric cars:", error);
        showError("L?i khi t?i xe di?n: " + error.message);
    }
}

async function loadHybridCars() {
    try {
        console.log("Loading hybrid cars...");
        const response = await fetch(API_BASE_URL + "/cars/hybrid");
        if (!response.ok) { throw new Error("HTTP error! status: " + response.status); }
        const data = await response.json();
        console.log("Hybrid cars loaded:", data);
        if (data.success && data.cars) {
            currentCars = data.cars;
            renderCars(data.cars);
        } else {
            showError("Kh�ng t�m th?y xe hybrid");
        }
    } catch (error) {
        console.error("Error loading hybrid cars:", error);
        showError("L?i khi t?i xe hybrid: " + error.message);
    }
}

async function filterCarsByType(carType) {
    try {
        console.log("Filtering by car type:", carType);
        
        // Map từ data-type HTML sang car_type trong database
        let carTypeParam;
        switch(carType) {
            case "mini":
                carTypeParam = "Mini";
                break;
            case "sedan":
                carTypeParam = "Sedan";
                break;
            case "pickup":
                carTypeParam = "Pickup";
                break;
            case "cuv-5":
                carTypeParam = "CUV";
                break;
            case "suv-7":
                carTypeParam = "SUV";
                break;
            case "mpv":
                carTypeParam = "MPV";
                break;
            case "minivan":
                carTypeParam = "Minivan";
                break;
            default: 
                console.error("Unknown car type:", carType); 
                alert("Loại xe không hợp lệ"); 
                return;
        }
        
        console.log("Fetching cars with type:", carTypeParam);
        const response = await fetch(API_BASE_URL + "/cars/by-type?carType=" + carTypeParam);
        if (!response.ok) { throw new Error("HTTP error! status: " + response.status); }
        const data = await response.json();
        console.log("Cars with type " + carTypeParam + " loaded:", data);
        if (data.success && data.cars) {
            currentCars = data.cars;
            renderCars(data.cars);
        } else {
            showError("Không tìm thấy xe loại " + carTypeParam);
        }
    } catch (error) {
        console.error("Error filtering by car type:", error);
        showError("Lỗi khi lọc xe theo loại: " + error.message);
    }
}

async function filterCarsByBrand(brand) {
    try {
        console.log("Filtering by brand:", brand);
        const response = await fetch(API_BASE_URL + "/cars/by-brand?brand=" + brand);
        if (!response.ok) { throw new Error("HTTP error! status: " + response.status); }
        const data = await response.json();
        console.log("Cars by brand loaded:", data);
        if (data.success && data.cars) {
            currentCars = data.cars;
            renderCars(data.cars);
        } else {
            showError("Kh�ng t�m th?y xe " + brand);
        }
    } catch (error) {
        console.error("Error filtering by brand:", error);
        showError("L?i khi l?c xe theo h�ng: " + error.message);
    }
}

async function filterCarsByTransmission(transmission) {
    try {
        console.log("Filtering by transmission:", transmission);
        let transmissionType = transmission === "auto" ? "Automatic" : transmission === "manual" ? "Manual" : null;
        if (!transmissionType) { loadAllCars(); return; }
        const response = await fetch(API_BASE_URL + "/cars/by-transmission?type=" + transmissionType);
        if (!response.ok) { throw new Error("HTTP error! status: " + response.status); }
        const data = await response.json();
        console.log("Cars by transmission loaded:", data);
        if (data.success && data.cars) {
            currentCars = data.cars;
            renderCars(data.cars);
        } else {
            showError("Kh�ng t�m th?y xe " + transmissionType);
        }
    } catch (error) {
        console.error("Error filtering by transmission:", error);
        showError("L?i khi l?c xe theo truy?n d?ng: " + error.message);
    }
}

// ========================================
// RENDER FUNCTIONS
// ========================================

function renderCars(cars) {
    const carGrid = document.querySelector(".car-grid");
    if (!carGrid) { console.error("Car grid element not found"); return; }
    carGrid.innerHTML = "";
    if (!cars || cars.length === 0) {
        carGrid.innerHTML = "<div class=\"no-cars-message\"><p>Kh�ng t�m th?y xe ph� h?p</p></div>";
        return;
    }
    cars.forEach(function(car) { carGrid.appendChild(createCarCard(car)); });
    console.log("Rendered " + cars.length + " cars");
}

function createCarCard(car) {
    const card = document.createElement("div");
    card.className = "car-card";
    const imageUrl = car.imageUrl || car.image_url || "../assets/inmage/default-car.png";
    const price = car.pricePerDay || car.price_per_day || car.dailyRate || car.daily_rate || 0;
    const formattedPrice = new Intl.NumberFormat("vi-VN").format(price);
    const transmission = car.transmissionType || car.transmission_type || "N/A";
    const transmissionText = transmission === "Automatic" ? "S? t? d?ng" : transmission === "Manual" ? "S? s�n" : transmission;
    const fuelType = car.fuelType || car.fuel_type || "N/A";
    const fuelText = fuelType === "Electric" ? "�i?n" : fuelType === "Hybrid" ? "Xang & �i?n" : fuelType === "Gasoline" ? "Xang" : fuelType === "Diesel" ? "D?u" : fuelType;
    const carName = car.name || (car.brand + " " + car.model);
    const seatCapacity = car.seatCapacity || car.seat_capacity || "N/A";
    const location = car.location || "H� N?i";
    const status = car.status || "Available";
    const statusBadge = status === "Available" ? '<span class="car-badge available">Sẵn sàng</span>' : "";
    
    card.innerHTML = '<div class="car-card-image">' +
        '<img src="' + imageUrl + '" alt="' + carName + '" onerror="this.src=\'../assets/inmage/default-car.png\'">' +
        statusBadge +
        '</div>' +
        '<div class="car-card-content">' +
        '<h3 class="car-name">' + carName + '</h3>' +
        '<div class="car-specs">' +
        '<div class="spec-item"><i class="fas fa-users"></i><span>' + seatCapacity + ' chỗ</span></div>' +
        '<div class="spec-item"><i class="fas fa-cog"></i><span>' + transmissionText + '</span></div>' +
        '<div class="spec-item"><i class="fas fa-gas-pump"></i><span>' + fuelText + '</span></div>' +
        '</div>' +
        '<div class="car-location"><i class="fas fa-map-marker-alt"></i><span>' + location + '</span></div>' +
        '<div class="car-footer">' +
        '<div class="car-price">' +
        '<span class="price-amount">' + formattedPrice + '₫</span>' +
        '<span class="price-unit">/ngày</span>' +
        '</div>' +
        '<button class="btn btn-rent" onclick="viewCarDetail(' + car.id + ')">Thuê xe</button>' +
        '</div>' +
        '</div>';
    
    return card;
}

// ========================================
// UTILITY FUNCTIONS
// ========================================

function viewCarDetail(carId) {
    console.log("View car detail:", carId);
    window.location.href = "cardetail.html?id=" + carId;
}

function showError(message) {
    const carGrid = document.querySelector(".car-grid");
    if (carGrid) {
        carGrid.innerHTML = "<div class=\"error-message\"><i class=\"fas fa-exclamation-circle\"></i><p>" + message + "</p></div>";
    }
    console.error(message);
}
