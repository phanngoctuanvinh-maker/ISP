# PowerShell helper to start dev environment (proxy + static server) in a new window
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
Set-Location $scriptDir
Write-Host "Installing backend dependencies (only the first run)..."
npm --prefix backend install
if ($LASTEXITCODE -ne 0) {
  Write-Host "npm install (backend) failed. Open a shell to inspect the errors." -ForegroundColor Red
  exit $LASTEXITCODE
}
Write-Host "Installing dev tools (live-server, concurrently) into backend (only the first run)..."
npm --prefix backend install --no-save concurrently live-server
if ($LASTEXITCODE -ne 0) {
  Write-Host "npm install dev tools failed." -ForegroundColor Red
  exit $LASTEXITCODE
}
Write-Host "Starting dev servers (backend proxy + static server) in a new window..."
# Start in a new window so user can close this one without killing servers
Start-Process -FilePath "cmd.exe" -ArgumentList "/c npm --prefix backend run dev" -WorkingDirectory $scriptDir -WindowStyle Normal
Write-Host "Dev servers launched in a new window."