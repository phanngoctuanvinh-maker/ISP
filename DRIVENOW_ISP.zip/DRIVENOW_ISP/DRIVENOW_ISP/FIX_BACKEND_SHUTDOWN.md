# 🔧 FIX LỖI BACKEND - HƯỚNG DẪN

## ❌ VẤN ĐỀ

Backend khởi động thành công nhưng bị shutdown ngay sau đó:
```
Started DrivenowApplication in 6.928 seconds
Commencing graceful shutdown... ← BỊ TẮT NGAY!
```

---

## ✅ NGUYÊN NHÂN

1. **Có nhiều Java processes đang chạy** → Conflict
2. **Maven bị terminate giữa chừng** → Ctrl+C hoặc command bị ngắt
3. **Port 8080 có thể bị chiếm** → Process khác đang dùng

---

## 🚀 GIẢI PHÁP (ĐÃ FIX)

### Bước 1: Kill tất cả Java processes
```powershell
Stop-Process -Name java -Force
```

### Bước 2: Verify port 8080 trống
```powershell
netstat -ano | findstr :8080
```
Kết quả: Phải TRỐNG (không có output)

### Bước 3: Start backend trong window mới
```powershell
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd 'c:\Users\ACER\Desktop\Project  ISP\2110\FILE SEARCH CO BAN\DRIVENOW_ISP\DRIVENOW_ISP\Project1' ; .\mvnw.cmd spring-boot:run"
```

### Bước 4: Đợi backend khởi động (10-15 giây)
Quan sát window mới, đợi thấy dòng:
```
Started DrivenowApplication in X.XXX seconds
Tomcat started on port 8080 (http)
```

### Bước 5: Test API
```powershell
curl http://localhost:8080/api/cars/1
```

**Expected Result:**
```json
{
  "id": 1,
  "brand": "Toyota",
  "name": "Toyota Vios 2024 - Trắng",
  "pricePerDay": 450000.00,
  ...
}
```

---

## 🧪 TEST TRANG WEB

### Cách 1: Trang test tự động
```
http://127.0.0.1:5500/DriveNow/html/test-backend.html
```
- Tự động test backend khi load
- 4 test cases với buttons
- Hiển thị kết quả trực quan

### Cách 2: Test cardetail trực tiếp
```
http://127.0.0.1:5500/DriveNow/html/cardetail.html?id=1
http://127.0.0.1:5500/DriveNow/html/cardetail.html?id=34  (VinFast)
```

### Cách 3: Test từ searchcar
```
http://127.0.0.1:5500/DriveNow/html/searchcar.html
→ Click "Thuê xe" trên bất kỳ xe nào
→ Chuyển sang cardetail.html?id=X
```

---

## 📋 CHECKLIST FIX

- [x] Kill Java processes
- [x] Verify port 8080 trống
- [x] Start backend trong window mới
- [x] Backend chạy thành công (port 8080)
- [x] API `/api/cars/1` response OK
- [x] Tạo test page (test-backend.html)
- [x] Test cardetail.html?id=1
- [x] Test cardetail.html?id=34 (VinFast)

---

## 🐛 NẾU VẪN LỖI

### Lỗi 1: Port 8080 already in use
```powershell
# Tìm process đang dùng port 8080
netstat -ano | findstr :8080

# Output example:
#   TCP    0.0.0.0:8080    0.0.0.0:0    LISTENING    12345
#                                                     ↑ PID

# Kill process theo PID
Stop-Process -Id 12345 -Force
```

### Lỗi 2: Database connection failed
```
Error: Cannot connect to SQL Server localhost:1433
```
**Fix:**
1. Mở SQL Server Management Studio
2. Check SQL Server service đang chạy
3. Test connection: `localhost, 1433` với Windows Authentication

### Lỗi 3: Maven compile error
```powershell
# Clean và rebuild
cd Project1
.\mvnw.cmd clean compile
.\mvnw.cmd spring-boot:run
```

### Lỗi 4: Java version mismatch
```
Error: Java 17 required
```
**Fix:**
```powershell
java -version  # Check Java version
# Phải là Java 17+
```

---

## 🎯 KẾT QUẢ SAU KHI FIX

### ✅ Backend Status:
```
✅ Java process: RUNNING (1 process)
✅ Port 8080: LISTENING
✅ Tomcat: Started
✅ Database: Connected (HikariPool-1)
✅ API: Responding
```

### ✅ API Endpoints Working:
```
✅ GET  /api/cars/all          → 30 cars
✅ GET  /api/cars/1            → Toyota Vios
✅ GET  /api/cars/34           → VinFast VF5
✅ POST /api/cars/search       → Filter works
✅ POST /api/cars/advanced-filter → Advanced filter works
```

### ✅ Frontend Working:
```
✅ searchcar.html              → Loads OK
✅ cardetail.html?id=1         → Loads Toyota
✅ cardetail.html?id=34        → Loads VinFast (Electric)
✅ test-backend.html           → All tests PASS
```

---

## 📞 SUPPORT

### Quick Commands:

**Start Backend:**
```powershell
cd "c:\Users\ACER\Desktop\Project  ISP\2110\FILE SEARCH CO BAN\DRIVENOW_ISP\DRIVENOW_ISP\Project1"
.\mvnw.cmd spring-boot:run
```

**Kill Backend:**
```powershell
Stop-Process -Name java -Force
```

**Check Status:**
```powershell
# Check Java processes
Get-Process | Where-Object {$_.ProcessName -like "*java*"}

# Check port 8080
netstat -ano | findstr :8080

# Test API
curl http://localhost:8080/api/cars/1
```

---

**Date Fixed:** 22/10/2025  
**Status:** ✅ RESOLVED  
**Method:** Kill Java processes + Start in new window
