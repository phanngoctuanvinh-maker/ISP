# 📚 TÓM TẮT CẤU TRÚC HỆ THỐNG SEARCH CAR - DRIVENOW

## 🏗️ KIẾN TRÚC TỔNG QUAN

```
┌─────────────────────────────────────────────────────────────┐
│                        FRONTEND                             │
│  searchcar.html + searchcar.js + searchcar.css             │
│                     (Port: File System)                     │
└────────────────────────┬────────────────────────────────────┘
                         │ HTTP Request
                         │ GET/POST
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                    SPRING BOOT BACKEND                      │
│                      (Port: 8080)                           │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐  │
│  │         SearchCarController.java                    │  │
│  │  @RestController @RequestMapping("/api/cars")       │  │
│  │                                                      │  │
│  │  • GET  /all                                        │  │
│  │  • GET  /by-type?seatCapacity=4                     │  │
│  │  • GET  /by-brand?brand=Toyota                      │  │
│  │  • GET  /by-transmission?type=Automatic             │  │
│  │  • GET  /electric                                   │  │
│  │  • GET  /hybrid                                     │  │
│  │  • GET  /{id}                                       │  │
│  │  • POST /search                                     │  │
│  │  • POST /advanced-filter                            │  │
│  └──────────────────┬──────────────────────────────────┘  │
│                     │                                      │
│                     ▼                                      │
│  ┌─────────────────────────────────────────────────────┐  │
│  │         SearchCarService.java                       │  │
│  │  @Service                                            │  │
│  │                                                      │  │
│  │  • searchCars(filterType, brand, transmission...)   │  │
│  │  • getAllCars()                                     │  │
│  │  • getAvailableBrands()                             │  │
│  │  • getTransmissionTypes()                           │  │
│  │  • getCarById(id)                                   │  │
│  └──────────────────┬──────────────────────────────────┘  │
│                     │                                      │
│                     ▼                                      │
│  ┌─────────────────────────────────────────────────────┐  │
│  │         CarRepository.java                          │  │
│  │  @Repository extends JpaRepository<Car, Long>       │  │
│  │                                                      │  │
│  │  • findByBrandIgnoreCase(brand)                     │  │
│  │  • findByTransmissionTypeIgnoreCase(type)           │  │
│  │  • findBySeatCapacity(capacity)                     │  │
│  │  • findElectricCars()                               │  │
│  │  • findHybridCars()                                 │  │
│  │  • searchCars(brand, transmission, fuel, seats)     │  │
│  └──────────────────┬──────────────────────────────────┘  │
│                     │                                      │
└─────────────────────┼──────────────────────────────────────┘
                      │ JPA/Hibernate
                      ▼
┌─────────────────────────────────────────────────────────────┐
│                   SQL SERVER DATABASE                       │
│                     drivenow_db                             │
│                                                             │
│  Table: cars                                                │
│  ├── id (PK, AUTO_INCREMENT)                               │
│  ├── brand (Toyota, Honda, Mazda...)                       │
│  ├── model (Vios, City, CX-5...)                           │
│  ├── name (Toyota Vios 2024)                               │
│  ├── seat_capacity (4, 5, 7)                               │
│  ├── fuel_type (Gasoline, Electric, Hybrid, Diesel)        │
│  ├── transmission_type (Automatic, Manual)                 │
│  ├── price_per_day (VNĐ)                                   │
│  ├── car_type (Sedan, SUV, MPV, Pickup, Minivan)          │
│  ├── status (Available, Rented, Maintenance)               │
│  ├── location (Hà Nội, TP.HCM...)                          │
│  ├── daily_km_limit (km/day)                               │
│  ├── exceed_fee_per_km (VNĐ/km)                            │
│  ├── fuel_consumption (L/100km)                            │
│  └── ... (20+ columns total)                               │
└─────────────────────────────────────────────────────────────┘
```

---

## 📂 CẤU TRÚC FILE

```
DRIVENOW_ISP/
│
├── DriveNow/                           # Frontend
│   ├── html/
│   │   └── searchcar.html              # Giao diện tìm kiếm xe
│   ├── js/
│   │   └── searchcar.js                # Logic frontend (API calls, render)
│   └── css/
│       └── searchcar.css               # Styling
│
└── Project1/                           # Backend (Spring Boot)
    ├── src/main/java/com/carrentleproject/drivenow/
    │   ├── model/
    │   │   └── Car.java                # Entity (JPA)
    │   ├── controller/
    │   │   └── SearchCarController.java # REST API endpoints
    │   ├── service/
    │   │   └── SearchCarService.java   # Business logic
    │   └── dao/
    │       └── CarRepository.java      # Database queries (JPA)
    │
    ├── database_setup.sql              # Tạo database & tables
    ├── insert_cars_NEW_STRUCTURE.sql   # Insert dữ liệu mẫu
    ├── add_new_cars.sql                # Script thêm xe mới (25+ xe)
    └── QUICK_ADD_CAR_TEMPLATE.sql      # Template thêm từng xe
```

---

## 🔄 LUỒNG DỮ LIỆU

### 1. Khi user mở trang search car:

```javascript
// searchcar.js
document.addEventListener("DOMContentLoaded", function() {
    loadAllCars(); // Tự động load xe khi trang load
});

async function loadAllCars() {
    const response = await fetch("http://localhost:8080/api/cars/all");
    const data = await response.json();
    renderCars(data.cars); // Hiển thị xe lên grid
}
```

### 2. Backend xử lý request:

```java
// SearchCarController.java
@GetMapping("/all")
public ResponseEntity<SearchCarResponse> getAllCars() {
    List<Car> cars = searchCarService.getAllCars();
    return ResponseEntity.ok(new SearchCarResponse(true, "...", cars));
}

// SearchCarService.java
public List<Car> getAllCars() {
    return carRepository.findAll(); // Query database
}
```

### 3. Database trả về dữ liệu:

```sql
SELECT * FROM cars WHERE status = 'Available';
```

### 4. Backend gửi JSON response:

```json
{
  "success": true,
  "message": "Tìm thấy 30 xe",
  "cars": [
    {
      "id": 1,
      "brand": "Toyota",
      "model": "Vios",
      "name": "Toyota Vios 2024",
      "seatCapacity": 4,
      "fuelType": "Gasoline",
      "transmissionType": "Automatic",
      "pricePerDay": 450000,
      "imageUrl": "...",
      "status": "Available",
      "location": "Hà Nội"
    },
    // ... more cars
  ]
}
```

### 5. Frontend render xe:

```javascript
function renderCars(cars) {
    cars.forEach(car => {
        const card = createCarCard(car);
        carGrid.appendChild(card);
    });
}
```

---

## 🎯 CÁC API ENDPOINTS

### 1. Lấy tất cả xe
```
GET http://localhost:8080/api/cars/all
Response: {success, message, cars[]}
```

### 2. Lọc theo số chỗ (loại xe)
```
GET http://localhost:8080/api/cars/by-type?seatCapacity=4
Response: {success, message, cars[]} - Chỉ xe 4 chỗ
```

### 3. Lọc theo hãng xe
```
GET http://localhost:8080/api/cars/by-brand?brand=Toyota
Response: {success, message, cars[]} - Chỉ xe Toyota
```

### 4. Lọc theo hộp số
```
GET http://localhost:8080/api/cars/by-transmission?type=Automatic
Response: {success, message, cars[]} - Chỉ xe số tự động
```

### 5. Lọc xe điện
```
GET http://localhost:8080/api/cars/electric
Response: {success, message, cars[]} - Chỉ xe Electric
```

### 6. Lọc xe hybrid
```
GET http://localhost:8080/api/cars/hybrid
Response: {success, message, cars[]} - Chỉ xe Hybrid
```

### 7. Chi tiết xe
```
GET http://localhost:8080/api/cars/{id}
Response: Car object
```

### 8. Tìm kiếm nâng cao
```
POST http://localhost:8080/api/cars/search
Body: {filterType, brand, transmissionType, seatCapacity, fuelType}
Response: {success, message, cars[]}
```

### 9. Bộ lọc nâng cao
```
POST http://localhost:8080/api/cars/advanced-filter
Body: {sortBy, minPrice, maxPrice, transmissionType, minSeatCapacity, ...}
Response: {success, message, cars[], totalCars}
```

---

## 📊 BẢNG CARS - CẤU TRÚC

### Các trường REQUIRED (Bắt buộc):
| Trường | Kiểu | Mô tả |
|--------|------|-------|
| `brand` | VARCHAR(50) | Hãng xe |
| `model` | VARCHAR(50) | Dòng xe |
| `seat_capacity` | INT | Số chỗ ngồi |
| `price_per_day` | DECIMAL(10,2) | Giá thuê/ngày |

### Các trường OPTIONAL (Tùy chọn):
| Trường | Kiểu | Mô tả |
|--------|------|-------|
| `name` | VARCHAR(100) | Tên đầy đủ |
| `year` | INT | Năm sản xuất |
| `color` | VARCHAR(30) | Màu sắc |
| `car_type` | VARCHAR(50) | Loại xe |
| `fuel_type` | VARCHAR(50) | Nhiên liệu |
| `transmission_type` | VARCHAR(20) | Hộp số |
| `image_url` | VARCHAR(255) | Link ảnh |
| `status` | VARCHAR(20) | Trạng thái |
| `license_plate` | VARCHAR(50) | Biển số (UNIQUE) |
| `location` | VARCHAR(100) | Vị trí |
| `daily_km_limit` | INT | Giới hạn km/ngày |
| `exceed_fee_per_km` | INT | Phí vượt km |
| `fuel_consumption` | DECIMAL(5,2) | Tiêu thụ nhiên liệu |

### Các trường AUTO:
- `id` - Auto increment (Primary Key)
- `created_at` - Auto set khi insert
- `updated_at` - Auto update khi update

---

## 🔍 CÁC FILTER HOẠT ĐỘNG

### Frontend (searchcar.js):
```javascript
// Filter theo loại xe (4 chỗ, 5 chỗ, 7 chỗ)
filterCarsByType("sedan") → API: /by-type?seatCapacity=4

// Filter theo hãng (Toyota, Honda, Mazda...)
filterCarsByBrand("Toyota") → API: /by-brand?brand=Toyota

// Filter theo hộp số (Automatic, Manual)
filterCarsByTransmission("auto") → API: /by-transmission?type=Automatic

// Filter xe điện
loadElectricCars() → API: /electric

// Filter xe hybrid
loadHybridCars() → API: /hybrid
```

### Mapping loại xe → số chỗ:
```javascript
switch(carType) {
    case "mini":   seatCapacity = 4; break; // Mini 4 chỗ
    case "sedan":  seatCapacity = 4; break; // Sedan 4 chỗ
    case "pickup": seatCapacity = 4; break; // Bán tải 4 chỗ
    case "cuv-5":  seatCapacity = 5; break; // SUV 5 chỗ
    case "suv-7":  seatCapacity = 7; break; // SUV 7 chỗ
    case "mpv":    seatCapacity = 7; break; // MPV 7 chỗ
    case "minivan": seatCapacity = 7; break; // Minivan 7 chỗ
}
```

---

## 💾 DATABASE QUERIES

### Backend sử dụng JPA Repository:
```java
// CarRepository.java

// Tìm theo hãng
List<Car> findByBrandIgnoreCase(String brand);

// Tìm theo hộp số
List<Car> findByTransmissionTypeIgnoreCase(String type);

// Tìm theo số chỗ
List<Car> findBySeatCapacity(Integer capacity);

// Tìm xe điện
@Query("SELECT c FROM Car c WHERE LOWER(c.fuelType) = 'electric'")
List<Car> findElectricCars();

// Tìm xe hybrid
@Query("SELECT c FROM Car c WHERE LOWER(c.fuelType) LIKE '%hybrid%'")
List<Car> findHybridCars();

// Tìm kiếm đa điều kiện
@Query("SELECT c FROM Car c WHERE ...")
List<Car> searchCars(brand, transmission, fuel, seats);
```

---

## 🚀 CÁCH THÊM XE MỚI

### Phương pháp 1: SQL Script
```sql
INSERT INTO cars (
    brand, model, name, seat_capacity, fuel_type, 
    transmission_type, price_per_day, 
    status, license_plate, location,
    created_at, updated_at
) VALUES (
    'Toyota', 'Camry', 'Toyota Camry 2024', 5, 'Gasoline',
    'Automatic', 750000,
    'Available', '30A-77777', 'Hà Nội',
    GETDATE(), GETDATE()
);
```

### Phương pháp 2: API Request
```json
POST http://localhost:8080/api/cars
{
  "brand": "Toyota",
  "model": "Camry",
  "seatCapacity": 5,
  "fuelType": "Gasoline",
  "transmissionType": "Automatic",
  "pricePerDay": 750000,
  "status": "Available",
  "licensePlate": "30A-77777",
  "location": "Hà Nội"
}
```

### Kết quả:
1. Xe được thêm vào database
2. Backend tự động detect thay đổi
3. Frontend gọi API `/all` → nhận xe mới
4. Xe hiển thị trên grid

---

## 🔧 CONFIGURATION

### Backend (application.properties):
```properties
server.port=8080
spring.datasource.url=jdbc:sqlserver://localhost:1433;databaseName=drivenow_db
spring.jpa.hibernate.ddl-auto=update
```

### Frontend (searchcar.js):
```javascript
const API_BASE_URL = "http://localhost:8080/api";
```

---

## ✅ CHECKLIST HOẠT ĐỘNG

- [x] Database `drivenow_db` tồn tại
- [x] Table `cars` có dữ liệu
- [x] Backend chạy port 8080
- [x] API `/all` trả về JSON
- [x] Frontend load được xe
- [x] Filter hoạt động
- [x] Thêm xe mới → Hiển thị ngay

---

## 📚 TÀI LIỆU LIÊN QUAN

- `HUONG_DAN_THEM_XE_MOI.md` - Hướng dẫn chi tiết
- `QUICK_START_ADD_CAR.md` - Hướng dẫn nhanh
- `add_new_cars.sql` - Script thêm 25+ xe
- `QUICK_ADD_CAR_TEMPLATE.sql` - Template đơn giản

---

**Tóm lại**: Hệ thống hoạt động theo mô hình MVC với Spring Boot backend + HTML/JS frontend, giao tiếp qua REST API, dữ liệu lưu trong SQL Server. Frontend tự động load và render xe từ API khi trang được mở.
