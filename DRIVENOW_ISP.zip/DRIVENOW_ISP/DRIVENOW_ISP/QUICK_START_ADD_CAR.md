# 🚀 HƯỚNG DẪN NHANH - THÊM XE VÀO DATABASE VÀ LOAD LÊN TRANG SEARCH

## 📋 BƯỚC 1: CHUẨN BỊ

### Kiểm tra Backend đang chạy:
```powershell
# Mở terminal và kiểm tra
cd "c:\Users\ACER\Desktop\Project  ISP\2110\DRIVENOW_ISP\DRIVENOW_ISP\Project1"

# Xem backend có chạy không (tìm port 8080)
netstat -ano | findstr :8080

# Nếu chưa chạy, start backend
.\mvnw.cmd spring-boot:run
```

### Test API:
Mở browser: `http://localhost:8080/api/cars/all`

Nếu thấy JSON → ✅ Backend OK!

---

## 📝 BƯỚC 2: THÊM XE VÀO DATABASE

### Cách 1: Dùng SQL Script (Khuyến nghị)

#### A. Thêm nhiều xe mẫu (25+ xe):
```powershell
# Mở SQL Server và chạy file
sqlcmd -S localhost -d drivenow_db -i add_new_cars.sql

# Hoặc mở SQL Server Management Studio và Execute file:
# Project1/add_new_cars.sql
```

#### B. Thêm từng xe đơn lẻ:
```sql
-- Mở file: QUICK_ADD_CAR_TEMPLATE.sql
-- Uncomment template phù hợp
-- Điền thông tin xe
-- Execute

-- Ví dụ đơn giản nhất:
INSERT INTO cars (
    brand, model, name, seat_capacity, fuel_type, 
    transmission_type, price_per_day, 
    status, license_plate, location,
    created_at, updated_at
) VALUES (
    'Toyota', 'Camry', 'Toyota Camry 2024', 5, 'Gasoline',
    'Automatic', 750000,
    'Available', '30A-77777', 'Hà Nội',
    GETDATE(), GETDATE()
);
```

### Cách 2: Dùng API (POST Request)

**Endpoint**: `POST http://localhost:8080/api/cars`

**Postman/Thunder Client**:
```json
{
  "brand": "Toyota",
  "model": "Camry",
  "name": "Toyota Camry 2024",
  "seatCapacity": 5,
  "fuelType": "Gasoline",
  "transmissionType": "Automatic",
  "pricePerDay": 750000,
  "status": "Available",
  "licensePlate": "30A-77777",
  "location": "Hà Nội"
}
```

---

## ✅ BƯỚC 3: KIỂM TRA DATABASE

```sql
-- Kiểm tra xe vừa thêm
SELECT TOP 5 * FROM cars ORDER BY created_at DESC;

-- Đếm tổng số xe
SELECT COUNT(*) as total FROM cars;

-- Kiểm tra theo hãng
SELECT brand, COUNT(*) as count 
FROM cars 
GROUP BY brand;
```

---

## 🌐 BƯỚC 4: LOAD XE LÊN TRANG SEARCH

### Tự động (Không cần làm gì):
- Frontend sẽ tự động gọi API khi load trang
- API: `GET http://localhost:8080/api/cars/all`
- JavaScript sẽ render xe vào grid

### Mở trang Search Car:
```powershell
# Mở file trong browser
start "DriveNow/html/searchcar.html"

# Hoặc double-click file:
# c:\Users\ACER\Desktop\Project  ISP\2110\DRIVENOW_ISP\DRIVENOW_ISP\DriveNow\html\searchcar.html
```

---

## 🔍 BƯỚC 5: KIỂM TRA FRONTEND

### Mở Developer Tools (F12):
```javascript
// Console sẽ hiển thị:
// "DriveNow Search Car Page Loaded"
// "Loading all cars..."
// "All cars loaded: {success: true, cars: Array(30)}"
// "Rendered 30 cars"
```

### Kiểm tra xe hiển thị:
1. ✅ Xe hiển thị trong grid
2. ✅ Thông tin đầy đủ: tên, giá, số chỗ, hộp số, nhiên liệu
3. ✅ Nút "Thuê xe" hoạt động
4. ✅ Có thể filter theo loại xe, hãng xe, truyền động

### Test các Filter:
```
1. Click "Loại Xe" → Chọn "Sedan" → Áp dụng → Xem chỉ xe Sedan
2. Click "Hãng Xe" → Chọn "Toyota" → Áp dụng → Xem chỉ xe Toyota  
3. Click "Xe Điện" → Xem xe Electric
4. Click "Xe Xăng & Điện" → Xem xe Hybrid
5. Click "Truyền động" → Chọn "Số tự động" → Áp dụng
6. Click "Bộ Lọc" → Điều chỉnh giá, km, năm... → Áp dụng
```

---

## 🔧 BƯỚC 6: TROUBLESHOOTING

### Vấn đề: Xe không hiển thị

#### Kiểm tra 1: Backend có chạy không?
```powershell
# Test API
curl http://localhost:8080/api/cars/all

# Hoặc mở browser:
http://localhost:8080/api/cars/all
```

**Kết quả mong muốn**: JSON với `{"success": true, "cars": [...]}`

#### Kiểm tra 2: Database có dữ liệu không?
```sql
SELECT COUNT(*) FROM cars WHERE status = 'Available';
```

**Kết quả mong muốn**: Số lượng > 0

#### Kiểm tra 3: Console có lỗi không?
- Mở DevTools (F12) → Console
- Xem có lỗi CORS, 404, 500 không?

#### Kiểm tra 4: Cache browser
```
Ctrl + Shift + R (Hard Reload)
Hoặc Ctrl + F5
```

### Vấn đề: Lỗi "Cannot insert NULL"

**Nguyên nhân**: Thiếu trường bắt buộc

**Giải pháp**: Đảm bảo có:
- `brand` ✅
- `model` ✅
- `seat_capacity` ✅
- `price_per_day` ✅

### Vấn đề: Lỗi "Duplicate license_plate"

**Nguyên nhân**: Biển số bị trùng

**Giải pháp**: Đổi biển số xe
```sql
UPDATE cars SET license_plate = '30A-XXXXX' WHERE id = 123;
```

### Vấn đề: CORS Error

**Đã fix trong Controller**:
```java
@CrossOrigin(origins = "*")
```

Nếu vẫn lỗi → Restart backend

---

## 📊 QUY TRÌNH HOÀN CHỈNH (ALL-IN-ONE)

```powershell
# 1. Start Backend
cd "c:\Users\ACER\Desktop\Project  ISP\2110\DRIVENOW_ISP\DRIVENOW_ISP\Project1"
.\mvnw.cmd spring-boot:run

# 2. Thêm xe (Terminal mới)
sqlcmd -S localhost -d drivenow_db -i add_new_cars.sql

# 3. Test API
curl http://localhost:8080/api/cars/all

# 4. Mở Frontend
cd "..\DriveNow\html"
start searchcar.html

# 5. Mở DevTools (F12) và kiểm tra Console
```

---

## 📚 CÁC FILE QUAN TRỌNG

### Hướng dẫn chi tiết:
- `HUONG_DAN_THEM_XE_MOI.md` - Tài liệu đầy đủ

### SQL Scripts:
- `add_new_cars.sql` - Script thêm 25+ xe mẫu
- `QUICK_ADD_CAR_TEMPLATE.sql` - Template nhanh để thêm từng xe

### Backend Code:
- `src/main/java/com/carrentleproject/drivenow/model/Car.java` - Entity
- `src/main/java/com/carrentleproject/drivenow/controller/SearchCarController.java` - API
- `src/main/java/com/carrentleproject/drivenow/service/SearchCarService.java` - Logic
- `src/main/java/com/carrentleproject/drivenow/dao/CarRepository.java` - Database

### Frontend Code:
- `DriveNow/html/searchcar.html` - Giao diện
- `DriveNow/js/searchcar.js` - Logic frontend
- `DriveNow/css/searchcar.css` - Style

---

## 🎯 CHECKLIST

Trước khi thêm xe, đảm bảo:
- [ ] Database `drivenow_db` đã tồn tại
- [ ] Table `cars` đã được tạo (Spring Boot tự tạo)
- [ ] Backend đang chạy ở port 8080
- [ ] Có thể truy cập `http://localhost:8080/api/cars/all`

Sau khi thêm xe:
- [ ] Query database thấy xe mới
- [ ] API trả về xe mới
- [ ] Frontend hiển thị xe mới
- [ ] Filter hoạt động đúng
- [ ] Nút "Thuê xe" hoạt động

---

## 💡 MẸO HAY

### Thêm nhanh nhiều xe cùng màu khác nhau:
```sql
INSERT INTO cars (brand, model, name, color, car_type, seat_capacity, fuel_type, transmission_type, price_per_day, status, license_plate, location, created_at, updated_at)
VALUES 
('Toyota', 'Vios', 'Toyota Vios - Trắng', 'Trắng', 'Sedan', 4, 'Gasoline', 'Automatic', 450000, 'Available', '30A-10001', 'Hà Nội', GETDATE(), GETDATE()),
('Toyota', 'Vios', 'Toyota Vios - Đen', 'Đen', 'Sedan', 4, 'Gasoline', 'Automatic', 450000, 'Available', '30A-10002', 'Hà Nội', GETDATE(), GETDATE()),
('Toyota', 'Vios', 'Toyota Vios - Bạc', 'Bạc', 'Sedan', 4, 'Gasoline', 'Automatic', 450000, 'Available', '30A-10003', 'Hà Nội', GETDATE(), GETDATE());
```

### Backup trước khi thêm:
```sql
SELECT * INTO cars_backup FROM cars;
```

### Xóa xe test:
```sql
DELETE FROM cars WHERE license_plate LIKE '%-TEST';
```

### Update xe:
```sql
UPDATE cars SET price_per_day = 500000 WHERE brand = 'Toyota' AND model = 'Vios';
```

---

## 📞 HỖ TRỢ NHANH

### Lệnh hữu ích:

```sql
-- Xem tất cả xe
SELECT * FROM cars ORDER BY created_at DESC;

-- Xem xe Available
SELECT * FROM cars WHERE status = 'Available';

-- Đếm xe theo hãng
SELECT brand, COUNT(*) FROM cars GROUP BY brand;

-- Tìm xe theo giá
SELECT * FROM cars WHERE price_per_day BETWEEN 400000 AND 700000;

-- Xem xe mới nhất
SELECT TOP 10 * FROM cars ORDER BY id DESC;
```

---

## ✅ KẾT QUẢ MONG ĐỢI

Sau khi hoàn thành:
1. Database có ít nhất 30+ xe
2. Trang search car hiển thị tất cả xe
3. Filter hoạt động chính xác
4. Có thể xem chi tiết từng xe
5. Dữ liệu hiển thị đầy đủ: tên, giá, số chỗ, hộp số, nhiên liệu, vị trí

**Chúc bạn thành công! 🚗💨**
