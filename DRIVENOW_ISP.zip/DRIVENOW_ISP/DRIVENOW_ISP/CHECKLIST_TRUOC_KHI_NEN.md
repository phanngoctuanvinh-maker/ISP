# ✅ CHECKLIST TRƯỚC KHI NÉN VÀ GỬI

## 📋 Kiểm tra trước khi nén

### 1️⃣ Backend Files
- [ ] `Project1/src/main/resources/application.properties` - XÓA hoặc ẨN password thật
- [ ] `Project1/insert_vietnamese_cars_FIXED.sql` - File có đầy đủ 30 xe
- [ ] `Project1/update_car_images_online.sql` - File có đầy đủ link ảnh
- [ ] `Project1/start-backend.bat` - File batch để start backend
- [ ] `Project1/pom.xml` - File Maven configuration

### 2️⃣ Frontend Files
- [ ] `DriveNow/html/searchcar.html` - Đã sửa đường dẫn `../js/api.js` (KHÔNG phải `/ISP392-Font/api.js`)
- [ ] `DriveNow/js/searchcar.js` - File JavaScript chính
- [ ] `DriveNow/js/api.js` - File config API
- [ ] `DriveNow/css/` - Tất cả CSS files
- [ ] `DriveNow/assets/inmage/` - Ảnh default (nếu có)

### 3️⃣ Documentation
- [ ] `START_HERE.txt` - Hướng dẫn nhanh (FILE QUAN TRỌNG NHẤT!)
- [ ] `README_CHO_BAN_BE.md` - Hướng dẫn chi tiết
- [ ] `GIAI_PHAP_FIX_XE_DIEN.md` - Giải thích kỹ thuật (optional)
- [ ] `.gitignore` - Loại trừ file không cần thiết

### 4️⃣ Test trước khi nén
- [ ] Backend chạy được: `http://localhost:8080/api/cars/all` trả về 30 xe
- [ ] Frontend hiển thị đủ 30 xe với ảnh
- [ ] Click "Xe Điện" → Hiển thị 3 VinFast
- [ ] Click "Toyota" → Hiển thị 6 Toyota
- [ ] Không có lỗi trong Console (F12)

---

## 🗂️ Cấu trúc folder cần nén

```
DRIVENOW_ISP/
│
├── START_HERE.txt                    ← ĐỌC ĐẦU TIÊN!
├── README_CHO_BAN_BE.md              ← Hướng dẫn đầy đủ
├── GIAI_PHAP_FIX_XE_DIEN.md         ← (Optional) Giải thích kỹ thuật
│
├── DriveNow/                         ← FRONTEND
│   ├── html/
│   │   └── searchcar.html
│   ├── js/
│   │   ├── searchcar.js
│   │   └── api.js
│   ├── css/
│   │   └── *.css
│   └── assets/
│       └── inmage/
│           └── default-car.png (nếu có)
│
└── Project1/                         ← BACKEND
    ├── start-backend.bat             ← Script start nhanh
    ├── insert_vietnamese_cars_FIXED.sql  ← Data 30 xe
    ├── update_car_images_online.sql  ← Ảnh Unsplash
    ├── pom.xml
    ├── mvnw.cmd
    ├── src/
    │   ├── main/
    │   │   ├── java/
    │   │   └── resources/
    │   │       └── application.properties  ← CHECK PASSWORD!
    │   └── test/
    └── target/                       ← XÓA folder này trước khi nén (giảm dung lượng)
```

---

## 🚫 XÓA TRƯỚC KHI NÉN (Giảm dung lượng)

```powershell
# Chạy trong PowerShell tại folder DRIVENOW_ISP

# Xóa folder target (có thể build lại)
Remove-Item -Recurse -Force "Project1\target" -ErrorAction SilentlyContinue

# Xóa cache VSCode
Remove-Item -Recurse -Force ".vscode" -ErrorAction SilentlyContinue

# Xóa log files
Remove-Item -Recurse -Force "Project1\logs" -ErrorAction SilentlyContinue

Write-Host "✅ Đã xóa các file không cần thiết!"
```

---

## 🗜️ NÉN FILE

### Cách 1: Dùng Windows Explorer (Khuyến nghị cho người không rành)
1. Right-click folder `DRIVENOW_ISP`
2. Chọn **Send to > Compressed (zipped) folder**
3. Đặt tên: `DriveNow_Project_Complete.zip`

### Cách 2: Dùng 7-Zip (Nén nhỏ hơn)
1. Cài 7-Zip: https://www.7-zip.org/
2. Right-click folder `DRIVENOW_ISP`
3. Chọn **7-Zip > Add to archive**
4. Format: `.zip` hoặc `.7z`
5. Compression level: **Ultra** (nén mạnh nhất)

---

## 📤 GỬI CHO BẠN

### Gửi qua Google Drive (Khuyến nghị)
1. Upload file zip lên Google Drive
2. Right-click > **Get link** > Set **Anyone with the link can view**
3. Copy link và gửi cho bạn

### Gửi qua Email
⚠️ File zip có thể > 25MB → Không gửi được qua Gmail thông thường
→ Dùng Google Drive thay thế

---

## 📝 LỜI NHẮN GỬI BẠN

```
Chào bạn!

Mình gửi bạn project DriveNow đây. Đọc kỹ file START_HERE.txt nhé!

Tóm tắt nhanh:
1. Tạo database: drivenow_db
2. Chạy 2 file SQL trong folder Project1
3. Đổi password trong application.properties
4. Double-click start-backend.bat
5. Mở VS Code > Install Live Server > Open searchcar.html

Nếu gặp lỗi gì thì đọc file README_CHO_BAN_BE.md nhé!

Good luck! 🚀
```

---

## ✅ HOÀN THÀNH

Khi đã check hết checklist trên:
- [x] Đã test backend
- [x] Đã test frontend
- [x] Đã xóa folder target
- [x] Đã ẩn password trong application.properties
- [x] Đã tạo các file hướng dẫn
- [x] Đã nén file
- [x] Đã upload và gửi link

→ **XONG! Bạn của bạn giờ có thể chạy project rồi!** 🎉

---

**Ngày tạo:** 22/10/2025  
**Người tạo:** DriveNow Team
