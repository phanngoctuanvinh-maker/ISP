# 🔧 FIX BACKEND API - HƯỚNG DẪN NHANH

## ⚡ CÁCH 1: RESTART BACKEND (5 PHÚT)

### Bước 1: Tìm terminal backend
Trong VS Code:
- Mở panel Terminal (Ctrl + `)
- Tìm terminal có tên "Run: DrivenowApplication"
- HOẶC terminal đang hiển thị log Spring Boot

### Bước 2: Stop backend
```
Nhấn Ctrl+C trong terminal backend
```

### Bước 3: Start lại backend
```powershell
cd "c:\Users\ACER\Desktop\Project  ISP\2110\DRIVENOW_ISP\DRIVENOW_ISP\Project1"
.\mvnw.cmd spring-boot:run
```

### Bước 4: Đợi backend khởi động
Xem log xuất hiện dòng:
```
Started DrivenowApplication in X.XXX seconds
```

### Bước 5: Test API
Mở browser: `http://localhost:8080/api/cars/all`

**Kỳ vọng**: Thấy JSON với 26 xe

### Bước 6: Refresh frontend
Mở: `DriveNow/html/searchcar.html`  
Nhấn F5 → Xe sẽ hiển thị!

---

## ⚡ CÁCH 2: FIX LỖI ENTITY (NẾU RESTART KHÔNG HIỆU QUẢ)

Nếu backend vẫn lỗi sau khi restart, sửa file `Car.java`:

### Mở file:
```
Project1/src/main/java/com/carrentleproject/drivenow/model/Car.java
```

### Tìm dòng có `seats`:
```java
@Column(name = "seats")
private Integer seats;
```

### Thay bằng:
```java
@Column(name = "seat_capacity")
private Integer seatCapacity;
```

### HOẶC comment dòng `seats`:
```java
// @Column(name = "seats")
// private Integer seats;
```

### Lưu file và restart backend

---

## 🧪 TEST NHANH

### Test 1: Database có dữ liệu?
```powershell
sqlcmd -S localhost -Q "USE drivenow_db; SELECT COUNT(*) as total FROM cars;"
```
**Kỳ vọng**: 26

### Test 2: Backend đang chạy?
```powershell
netstat -ano | findstr :8080
```
**Kỳ vọng**: Thấy port 8080 LISTENING

### Test 3: API hoạt động?
```powershell
curl http://localhost:8080/api/cars/all
```
**Kỳ vọng**: JSON response, KHÔNG phải 500 Error

### Test 4: Frontend nhận dữ liệu?
1. Mở `searchcar.html`
2. Nhấn F12 (DevTools)
3. Tab Console
4. Xem log: "All cars loaded: ..."

---

## 🎯 CHECKLIST

- [ ] Backend đã restart
- [ ] API trả về JSON (không lỗi 500)
- [ ] Browser mở được http://localhost:8080/api/cars/all
- [ ] searchcar.html hiển thị xe
- [ ] Filter hoạt động

---

## 📊 KẾT QUẢ MONG ĐỢI

Khi thành công, bạn sẽ thấy:

### Trong API response:
```json
{
  "success": true,
  "message": "Tìm thấy 26 xe",
  "cars": [
    {
      "id": 1,
      "brand": "Toyota",
      "model": "Vios",
      "name": "Toyota Vios 2024 - Trắng",
      "seatCapacity": 4,
      "pricePerDay": 450000,
      ...
    }
  ]
}
```

### Trong searchcar.html:
- Grid hiển thị 26 xe
- Mỗi card xe có: ảnh, tên, giá, số chỗ, hộp số
- Filter hoạt động: Loại xe, Hãng xe, Truyền động

---

## ❌ NẾU VẪN LỖI

### Lỗi 500 - Internal Server Error

**Kiểm tra log backend**:
1. Xem terminal backend
2. Tìm dòng ERROR hoặc Exception
3. Copy lỗi và paste vào chat

**Lỗi thường gặp**:
```
Column 'xxx' not found
→ Entity không khớp với database

NullPointerException
→ Dữ liệu bị thiếu

Could not execute statement
→ SQL query sai
```

### Lỗi CORS

**Triệu chứng**: Console log "CORS policy blocked"

**Giải pháp**: Đã có `@CrossOrigin(origins = "*")` trong Controller

### Xe không hiển thị

**Kiểm tra**:
1. F12 → Console → Xem lỗi
2. F12 → Network → Xem API call status
3. Đảm bảo status = 200, không phải 500

---

## 💾 BACKUP (AN TOÀN)

Trước khi sửa code, backup:

```powershell
# Backup database
sqlcmd -S localhost -Q "USE drivenow_db; SELECT * INTO cars_backup_20251021 FROM cars;"

# Backup code
xcopy "Project1\src" "Project1\src_backup" /E /I /Y
```

---

## 🚀 QUICK COMMANDS

```powershell
# 1. Restart backend
cd "c:\Users\ACER\Desktop\Project  ISP\2110\DRIVENOW_ISP\DRIVENOW_ISP\Project1"
.\mvnw.cmd spring-boot:run

# 2. Test API
start http://localhost:8080/api/cars/all

# 3. Mở frontend
start "c:\Users\ACER\Desktop\Project  ISP\2110\DRIVENOW_ISP\DRIVENOW_ISP\DriveNow\html\searchcar.html"

# 4. Check database
sqlcmd -S localhost -Q "USE drivenow_db; SELECT COUNT(*) FROM cars;"
```

---

**TÓM TẮT**: Database đã có 26 xe ✅ → Chỉ cần RESTART BACKEND → API sẽ hoạt động → Xe hiển thị trên frontend! 🎉

**RESTART NGAY!** 🚀
