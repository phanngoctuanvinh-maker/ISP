# 🔧 SỬA LẠI DATABASE SANG TIẾNG VIỆT - HƯỚNG DẪN NHANH

## 📋 TÌNH HUỐNG

Database hiện tại của bạn có dữ liệu **TIẾNG ANH**:
- ❌ `fuel_type`: `Gasoline`, `Diesel`, `Electric`, `Hybrid`
- ❌ `transmission_type`: `Automatic`, `Manual`
- ❌ `status`: `Available`, `Rented`

Cần chuyển sang **TIẾNG VIỆT**:
- ✅ `fuel_type`: `Xăng`, `Dầu diesel`, `Điện`, `Hybrid (Xăng + Điện)`
- ✅ `transmission_type`: `Tự động`, `Số sàn`
- ✅ `status`: `Có sẵn`, `Đã thuê`, `Bảo trì`

---

## ⚡ CÁCH SỬA (2 BƯỚC - 3 PHÚT)

### **BƯỚC 1: Kiểm tra database hiện tại** (1 phút)

```
1. Mở SQL Server Management Studio (SSMS)
2. Kết nối: localhost (sa/12345)
3. Mở file: Project1/CHECK_DATABASE.sql
4. Nhấn F5 (Execute)
5. Xem kết quả trong Messages
```

**Kết quả sẽ cho biết:**
- ✅ Bao nhiêu xe đã là tiếng Việt
- ❌ Bao nhiêu xe còn tiếng Anh
- 📋 Danh sách fuel_type, transmission_type hiện có

---

### **BƯỚC 2: Update sang tiếng Việt** (2 phút)

```
1. Vẫn trong SSMS
2. Mở file: Project1/UPDATE_TO_VIETNAMESE.sql
3. Nhấn F5 (Execute)
4. Chờ thông báo "✅ HOÀN THÀNH"
```

**Script sẽ tự động:**
- ✅ Chuyển `Gasoline` → `Xăng`
- ✅ Chuyển `Diesel` → `Dầu diesel`
- ✅ Chuyển `Electric` → `Điện`
- ✅ Chuyển `Hybrid` → `Hybrid (Xăng + Điện)`
- ✅ Chuyển `Automatic` → `Tự động`
- ✅ Chuyển `Manual` → `Số sàn`
- ✅ Chuyển `Available` → `Có sẵn`

---

### **BƯỚC 3: Restart Backend & Test** (1 phút)

```powershell
# Dừng backend hiện tại (Ctrl+C)
cd Project1
.\start-backend.bat
```

**Test:**
1. Mở: http://localhost:8080/api/cars/all
2. Kiểm tra thấy:
   ```json
   {
     "fuelType": "Xăng",
     "transmissionType": "Tự động",
     "status": "Có sẵn"
   }
   ```

---

## 📊 BẢNG CHUYỂN ĐỔI

### **Nhiên liệu (fuel_type)**
| Tiếng Anh | → | Tiếng Việt |
|-----------|---|------------|
| `Gasoline` | → | `Xăng` |
| `Petrol` | → | `Xăng` |
| `Diesel` | → | `Dầu diesel` |
| `Electric` | → | `Điện` |
| `Hybrid` | → | `Hybrid (Xăng + Điện)` |

### **Hộp số (transmission_type)**
| Tiếng Anh | → | Tiếng Việt |
|-----------|---|------------|
| `Automatic` | → | `Tự động` |
| `Auto` | → | `Tự động` |
| `Manual` | → | `Số sàn` |

### **Trạng thái (status)**
| Tiếng Anh | → | Tiếng Việt |
|-----------|---|------------|
| `Available` | → | `Có sẵn` |
| `Rented` | → | `Đã thuê` |
| `Maintenance` | → | `Bảo trì` |

---

## 🔍 KIỂM TRA SAU KHI UPDATE

### **Trong SQL Server:**
```sql
-- Kiểm tra fuel_type
SELECT DISTINCT fuel_type FROM cars;

-- Kết quả mong đợi:
-- Xăng
-- Dầu diesel
-- Điện
-- Hybrid (Xăng + Điện)

-- Kiểm tra transmission_type
SELECT DISTINCT transmission_type FROM cars;

-- Kết quả mong đợi:
-- Tự động
-- Số sàn
```

### **Trong API:**
```
GET http://localhost:8080/api/cars/all
```

**Response:**
```json
{
  "success": true,
  "cars": [
    {
      "id": 1,
      "brand": "Toyota",
      "fuelType": "Xăng",           // ✅ Tiếng Việt
      "transmissionType": "Tự động", // ✅ Tiếng Việt
      "status": "Có sẵn"            // ✅ Tiếng Việt
    }
  ]
}
```

---

## 🛠️ TROUBLESHOOTING

### **Vấn đề 1: Script báo lỗi "Invalid object name 'cars'"**
**Nguyên nhân:** Database `drivenow_db` chưa được chọn

**Giải pháp:**
```sql
-- Thêm dòng này vào đầu script:
USE drivenow_db;
GO
```

### **Vấn đề 2: Sau update vẫn thấy tiếng Anh**
**Nguyên nhân:** Backend chưa restart hoặc cache

**Giải pháp:**
1. Stop backend (Ctrl+C)
2. Restart: `.\start-backend.bat`
3. Xóa cache trình duyệt (Ctrl+Shift+Del)

### **Vấn đề 3: Một số xe vẫn tiếng Anh**
**Nguyên nhân:** Dữ liệu có format khác

**Giải pháp:**
```sql
-- Kiểm tra giá trị thực tế
SELECT DISTINCT fuel_type FROM cars;

-- Update thủ công nếu cần
UPDATE cars SET fuel_type = N'Xăng' 
WHERE fuel_type = 'Gasoline';
```

---

## 📝 LƯU Ý QUAN TRỌNG

### **1. Luôn dùng prefix N**
Khi thêm xe mới vào database:
```sql
-- ❌ SAI
INSERT INTO cars (fuel_type) VALUES ('Xăng');

-- ✅ ĐÚNG
INSERT INTO cars (fuel_type) VALUES (N'Xăng');
                                      ↑
                                   Quan trọng!
```

### **2. Giá trị chuẩn**
Chỉ sử dụng các giá trị sau:

**fuel_type:**
- `Xăng`
- `Dầu diesel`
- `Điện`
- `Hybrid (Xăng + Điện)`

**transmission_type:**
- `Tự động`
- `Số sàn`

**status:**
- `Có sẵn`
- `Đã thuê`
- `Bảo trì`

---

## 📂 FILES ĐÃ TẠO

1. ✅ `CHECK_DATABASE.sql` - Kiểm tra database hiện tại
2. ✅ `UPDATE_TO_VIETNAMESE.sql` - Update sang tiếng Việt
3. ✅ `fix_vietnamese_encoding.sql` - Script sửa cấu trúc + thêm xe mẫu (nếu cần reset toàn bộ)

---

## 🎯 TÓM TẮT

```
KIỂM TRA → UPDATE → RESTART → TEST
   ↓          ↓         ↓        ↓
CHECK_   UPDATE_TO_  Backend   API/
DATABASE VIETNAMESE            Frontend
```

**Thời gian:** ~3-5 phút
**Kết quả:** Database 100% tiếng Việt

---

**🎉 HOÀN THÀNH!**

Nếu có vấn đề, chạy lại `CHECK_DATABASE.sql` để xem trạng thái hiện tại.
