-- ========================================
-- SCRIPT THÊM XE MỚI - DRIVENOW
-- Sử dụng: Copy và paste vào SQL Server
-- hoặc chạy: sqlcmd -S localhost -d drivenow_db -i add_new_cars.sql
-- ========================================

USE drivenow_db;
GO

-- ========================================
-- PHẦN 1: THÊM XE MẪU CƠ BẢN
-- ========================================

-- 1. Toyota Camry 2024 (Sedan 5 chỗ cao cấp)
INSERT INTO cars (
    brand, model, name, year, color, 
    car_type, seat_capacity, fuel_type, transmission_type,
    daily_rate, price_per_day, 
    description, mileage, image_url, status,
    license_plate, insurance_info, location,
    created_at, updated_at
) VALUES (
    'Toyota', 'Camry', 'Toyota Camry 2024', 2024, 'Trắng ngọc trai',
    'Sedan', 5, 'Gasoline', 'Automatic',
    750000, 750000,
    'Sedan hạng D cao cấp, êm ái, sang trọng, phù hợp đi công tác và du lịch', 
    8000, 'https://example.com/toyota-camry.jpg', 'Available',
    '30A-77777', 'Bảo hiểm vật chất + bảo hiểm trách nhiệm dân sự', 'Hà Nội',
    GETDATE(), GETDATE()
);

-- 2. Honda Civic 2024 (Sedan 5 chỗ thể thao)
INSERT INTO cars (
    brand, model, name, year, color, 
    car_type, seat_capacity, fuel_type, transmission_type,
    daily_rate, price_per_day, 
    description, mileage, image_url, status,
    license_plate, insurance_info, location,
    daily_km_limit, exceed_fee_per_km, fuel_consumption,
    created_at, updated_at
) VALUES (
    'Honda', 'Civic', 'Honda Civic 2024', 2024, 'Xanh dương',
    'Sedan', 5, 'Gasoline', 'Automatic',
    680000, 680000,
    'Sedan thể thao, thiết kế trẻ trung, động cơ mạnh mẽ', 
    5000, 'https://example.com/honda-civic.jpg', 'Available',
    '30B-88888', 'Bảo hiểm đầy đủ', 'Hà Nội',
    300, 5000, 6.5,
    GETDATE(), GETDATE()
);

-- 3. Mazda CX-30 2024 (SUV 5 chỗ)
INSERT INTO cars (
    brand, model, name, year, color, 
    car_type, seat_capacity, fuel_type, transmission_type,
    daily_rate, price_per_day, 
    description, mileage, image_url, status,
    license_plate, insurance_info, location,
    daily_km_limit, exceed_fee_per_km, fuel_consumption,
    created_at, updated_at
) VALUES (
    'Mazda', 'CX-30', 'Mazda CX-30 2024', 2024, 'Đỏ pha lê',
    'SUV', 5, 'Gasoline', 'Automatic',
    620000, 620000,
    'SUV crossover 5 chỗ, thiết kế sang trọng, công nghệ hiện đại', 
    6000, 'https://example.com/mazda-cx30.jpg', 'Available',
    '30C-66666', 'Bảo hiểm đầy đủ', 'Hà Nội',
    350, 4500, 6.8,
    GETDATE(), GETDATE()
);

-- 4. Hyundai Palisade 2024 (SUV 7 chỗ hạng sang)
INSERT INTO cars (
    brand, model, name, year, color, 
    car_type, seat_capacity, fuel_type, transmission_type,
    daily_rate, price_per_day, 
    description, mileage, image_url, status,
    license_plate, insurance_info, location,
    daily_km_limit, exceed_fee_per_km, fuel_consumption,
    created_at, updated_at
) VALUES (
    'Hyundai', 'Palisade', 'Hyundai Palisade 2024', 2024, 'Đen',
    'SUV', 7, 'Gasoline', 'Automatic',
    1100000, 1100000,
    'SUV 7 chỗ hạng sang, ghế da cao cấp, hệ thống giải trí hiện đại, an toàn tuyệt đối', 
    4000, 'https://example.com/hyundai-palisade.jpg', 'Available',
    '30F-55555', 'Bảo hiểm VIP + hỗ trợ 24/7', 'Hà Nội',
    250, 6000, 9.2,
    GETDATE(), GETDATE()
);

-- 5. Kia Carnival 2024 (Minivan cao cấp)
INSERT INTO cars (
    brand, model, name, year, color, 
    car_type, seat_capacity, fuel_type, transmission_type,
    daily_rate, price_per_day, 
    description, mileage, image_url, status,
    license_plate, insurance_info, location,
    daily_km_limit, exceed_fee_per_km, fuel_consumption,
    created_at, updated_at
) VALUES (
    'Kia', 'Carnival', 'Kia Carnival 2024', 2024, 'Bạc titan',
    'Minivan', 7, 'Diesel', 'Automatic',
    1200000, 1200000,
    'Minivan hạng sang 7-9 chỗ, ghế massage, cửa sổ trời, phù hợp gia đình và công ty', 
    3000, 'https://example.com/kia-carnival.jpg', 'Available',
    '30E-44444', 'Bảo hiểm toàn diện + đưa đón sân bay miễn phí', 'Hà Nội',
    200, 7000, 8.5,
    GETDATE(), GETDATE()
);

PRINT '✅ Đã thêm 5 xe mẫu cơ bản';
GO

-- ========================================
-- PHẦN 2: XE ĐIỆN (ELECTRIC CARS)
-- ========================================

-- 6. Vinfast VF e34 2024 (SUV điện 5 chỗ)
INSERT INTO cars (
    brand, model, name, year, color, 
    car_type, seat_capacity, fuel_type, transmission_type,
    daily_rate, price_per_day, 
    description, mileage, image_url, status,
    license_plate, insurance_info, location,
    daily_km_limit, exceed_fee_per_km, fuel_consumption,
    created_at, updated_at
) VALUES (
    'Vinfast', 'VF e34', 'Vinfast VF e34 2024', 2024, 'Xanh lá',
    'SUV', 5, 'Electric', 'Automatic',
    600000, 600000,
    'SUV điện 5 chỗ, tầm hoạt động 300km, sạc nhanh 30 phút đạt 80%', 
    2000, 'https://example.com/vinfast-vfe34.jpg', 'Available',
    '30G-33333', 'Bảo hiểm + hỗ trợ sạc điện miễn phí', 'Hà Nội',
    NULL, NULL, 0,
    GETDATE(), GETDATE()
);

-- 7. Mercedes EQS 450 2024 (Sedan điện cao cấp)
INSERT INTO cars (
    brand, model, name, year, color, 
    car_type, seat_capacity, fuel_type, transmission_type,
    daily_rate, price_per_day, 
    description, mileage, image_url, status,
    license_plate, insurance_info, location,
    daily_km_limit, exceed_fee_per_km, fuel_consumption,
    created_at, updated_at
) VALUES (
    'Mercedes', 'EQS', 'Mercedes EQS 450 2024', 2024, 'Đen kim loại',
    'Sedan', 5, 'Electric', 'Automatic',
    2500000, 2500000,
    'Sedan điện hạng sang, tầm hoạt động 600km, màn hình OLED 56 inch, công nghệ tự lái', 
    1000, 'https://example.com/mercedes-eqs.jpg', 'Available',
    '30A-11111', 'Bảo hiểm VIP + sạc điện 24/7 + tài xế riêng', 'Hà Nội',
    NULL, NULL, 0,
    GETDATE(), GETDATE()
);

-- 8. Tesla Model 3 2024 (Sedan điện thể thao)
INSERT INTO cars (
    brand, model, name, year, color, 
    car_type, seat_capacity, fuel_type, transmission_type,
    daily_rate, price_per_day, 
    description, mileage, image_url, status,
    license_plate, insurance_info, location,
    daily_km_limit, exceed_fee_per_km, fuel_consumption,
    created_at, updated_at
) VALUES (
    'Tesla', 'Model 3', 'Tesla Model 3 2024', 2024, 'Xanh dương metallic',
    'Sedan', 5, 'Electric', 'Automatic',
    1800000, 1800000,
    'Sedan điện thể thao, tăng tốc 0-100km/h trong 3.3s, tầm hoạt động 500km, Autopilot', 
    800, 'https://example.com/tesla-model3.jpg', 'Available',
    '30A-22222', 'Bảo hiểm toàn diện + sạc tại nhà miễn phí', 'Hà Nội',
    NULL, NULL, 0,
    GETDATE(), GETDATE()
);

PRINT '✅ Đã thêm 3 xe điện';
GO

-- ========================================
-- PHẦN 3: XE HYBRID (XĂNG & ĐIỆN)
-- ========================================

-- 9. Toyota RAV4 Hybrid 2024
INSERT INTO cars (
    brand, model, name, year, color, 
    car_type, seat_capacity, fuel_type, transmission_type,
    daily_rate, price_per_day, 
    description, mileage, image_url, status,
    license_plate, insurance_info, location,
    daily_km_limit, exceed_fee_per_km, fuel_consumption,
    created_at, updated_at
) VALUES (
    'Toyota', 'RAV4', 'Toyota RAV4 Hybrid 2024', 2024, 'Xám bạc',
    'SUV', 5, 'Hybrid', 'Automatic',
    950000, 950000,
    'SUV hybrid 5 chỗ, tiết kiệm nhiên liệu, hệ thống an toàn Toyota Safety Sense', 
    4000, 'https://example.com/toyota-rav4-hybrid.jpg', 'Available',
    '30A-99998', 'Bảo hiểm đầy đủ', 'Hà Nội',
    300, 5000, 4.8,
    GETDATE(), GETDATE()
);

-- 10. Honda CR-V Hybrid 2024
INSERT INTO cars (
    brand, model, name, year, color, 
    car_type, seat_capacity, fuel_type, transmission_type,
    daily_rate, price_per_day, 
    description, mileage, image_url, status,
    license_plate, insurance_info, location,
    daily_km_limit, exceed_fee_per_km, fuel_consumption,
    created_at, updated_at
) VALUES (
    'Honda', 'CR-V', 'Honda CR-V Hybrid 2024', 2024, 'Trắng',
    'SUV', 7, 'Hybrid', 'Automatic',
    1050000, 1050000,
    'SUV hybrid 7 chỗ, động cơ 2.0L kết hợp motor điện, vận hành êm ái', 
    3500, 'https://example.com/honda-crv-hybrid.jpg', 'Available',
    '30B-99998', 'Bảo hiểm đầy đủ', 'Hà Nội',
    280, 5500, 5.2,
    GETDATE(), GETDATE()
);

-- 11. BMW X5 xDrive45e 2024 (Hybrid cao cấp)
INSERT INTO cars (
    brand, model, name, year, color, 
    car_type, seat_capacity, fuel_type, transmission_type,
    daily_rate, price_per_day, 
    description, mileage, image_url, status,
    license_plate, insurance_info, location,
    daily_km_limit, exceed_fee_per_km, fuel_consumption,
    created_at, updated_at
) VALUES (
    'BMW', 'X5', 'BMW X5 xDrive45e 2024', 2024, 'Xanh dương kim cương',
    'SUV', 7, 'Hybrid', 'Automatic',
    1800000, 1800000,
    'SUV hybrid hạng sang 7 chỗ, camera 360, ghế massage, công nghệ cao cấp nhất', 
    2500, 'https://example.com/bmw-x5-hybrid.jpg', 'Available',
    '30A-00001', 'Bảo hiểm VIP + hỗ trợ 24/7 + đưa đón miễn phí', 'Hà Nội',
    250, 8000, 7.2,
    GETDATE(), GETDATE()
);

PRINT '✅ Đã thêm 3 xe hybrid';
GO

-- ========================================
-- PHẦN 4: XE PHỔ THÔNG (THÊM SỐ LƯỢNG)
-- ========================================

-- Thêm 5 xe Toyota Vios với màu khác nhau
INSERT INTO cars (
    brand, model, name, year, color, 
    car_type, seat_capacity, fuel_type, transmission_type,
    price_per_day, description, status, license_plate, location,
    daily_km_limit, exceed_fee_per_km, fuel_consumption,
    created_at, updated_at
) VALUES 
('Toyota', 'Vios', 'Toyota Vios 2024 - Trắng', 2024, 'Trắng', 'Sedan', 4, 'Gasoline', 'Automatic', 450000, 'Sedan tiết kiệm nhiên liệu', 'Available', '30A-10001', 'Hà Nội', 300, 4000, 5.5, GETDATE(), GETDATE()),
('Toyota', 'Vios', 'Toyota Vios 2024 - Đen', 2024, 'Đen', 'Sedan', 4, 'Gasoline', 'Automatic', 450000, 'Sedan tiết kiệm nhiên liệu', 'Available', '30A-10002', 'Hà Nội', 300, 4000, 5.5, GETDATE(), GETDATE()),
('Toyota', 'Vios', 'Toyota Vios 2024 - Bạc', 2024, 'Bạc', 'Sedan', 4, 'Gasoline', 'Automatic', 450000, 'Sedan tiết kiệm nhiên liệu', 'Available', '30A-10003', 'Hà Nội', 300, 4000, 5.5, GETDATE(), GETDATE()),
('Toyota', 'Vios', 'Toyota Vios 2024 - Đỏ', 2024, 'Đỏ', 'Sedan', 4, 'Gasoline', 'Automatic', 450000, 'Sedan tiết kiệm nhiên liệu', 'Available', '30A-10004', 'Hà Nội', 300, 4000, 5.5, GETDATE(), GETDATE()),
('Toyota', 'Vios', 'Toyota Vios 2024 - Xanh', 2024, 'Xanh', 'Sedan', 4, 'Gasoline', 'Automatic', 450000, 'Sedan tiết kiệm nhiên liệu', 'Available', '30A-10005', 'Hà Nội', 300, 4000, 5.5, GETDATE(), GETDATE());

-- Thêm 3 xe Honda City
INSERT INTO cars (
    brand, model, name, year, color, 
    car_type, seat_capacity, fuel_type, transmission_type,
    price_per_day, description, status, license_plate, location,
    daily_km_limit, exceed_fee_per_km, fuel_consumption,
    created_at, updated_at
) VALUES 
('Honda', 'City', 'Honda City 2024 - Trắng', 2024, 'Trắng', 'Sedan', 4, 'Gasoline', 'Automatic', 480000, 'Sedan trẻ trung', 'Available', '30B-10001', 'Hà Nội', 320, 4200, 5.8, GETDATE(), GETDATE()),
('Honda', 'City', 'Honda City 2024 - Đỏ', 2024, 'Đỏ', 'Sedan', 4, 'Gasoline', 'Automatic', 480000, 'Sedan trẻ trung', 'Available', '30B-10002', 'Hà Nội', 320, 4200, 5.8, GETDATE(), GETDATE()),
('Honda', 'City', 'Honda City 2024 - Xám', 2024, 'Xám', 'Sedan', 4, 'Gasoline', 'Automatic', 480000, 'Sedan trẻ trung', 'Available', '30B-10003', 'Hà Nội', 320, 4200, 5.8, GETDATE(), GETDATE());

-- Thêm 3 xe Mazda CX-5
INSERT INTO cars (
    brand, model, name, year, color, 
    car_type, seat_capacity, fuel_type, transmission_type,
    price_per_day, description, status, license_plate, location,
    daily_km_limit, exceed_fee_per_km, fuel_consumption,
    created_at, updated_at
) VALUES 
('Mazda', 'CX-5', 'Mazda CX-5 2024 - Đỏ', 2024, 'Đỏ pha lê', 'SUV', 5, 'Gasoline', 'Automatic', 700000, 'SUV premium', 'Available', '30C-10001', 'Hà Nội', 300, 5000, 7.0, GETDATE(), GETDATE()),
('Mazda', 'CX-5', 'Mazda CX-5 2024 - Xanh', 2024, 'Xanh dương', 'SUV', 5, 'Gasoline', 'Automatic', 700000, 'SUV premium', 'Available', '30C-10002', 'Hà Nội', 300, 5000, 7.0, GETDATE(), GETDATE()),
('Mazda', 'CX-5', 'Mazda CX-5 2024 - Trắng', 2024, 'Trắng', 'SUV', 5, 'Gasoline', 'Automatic', 700000, 'SUV premium', 'Available', '30C-10003', 'Hà Nội', 300, 5000, 7.0, GETDATE(), GETDATE());

PRINT '✅ Đã thêm 11 xe phổ thông (tăng số lượng)';
GO

-- ========================================
-- PHẦN 5: XE CAO CẤP (LUXURY CARS)
-- ========================================

-- 12. Audi A8 2024
INSERT INTO cars (
    brand, model, name, year, color, 
    car_type, seat_capacity, fuel_type, transmission_type,
    daily_rate, price_per_day, 
    description, mileage, image_url, status,
    license_plate, insurance_info, location,
    daily_km_limit, exceed_fee_per_km, fuel_consumption,
    created_at, updated_at
) VALUES (
    'Audi', 'A8', 'Audi A8 L 2024', 2024, 'Đen',
    'Sedan', 5, 'Hybrid', 'Automatic',
    2200000, 2200000,
    'Sedan hạng sang, ghế massage, hệ thống âm thanh Bang & Olufsen, công nghệ tự lái cấp 3', 
    1500, 'https://example.com/audi-a8.jpg', 'Available',
    '30A-00888', 'Bảo hiểm VIP + tài xế riêng + đưa đón miễn phí', 'Hà Nội',
    200, 10000, 8.0,
    GETDATE(), GETDATE()
);

-- 13. Lexus RX 350h 2024
INSERT INTO cars (
    brand, model, name, year, color, 
    car_type, seat_capacity, fuel_type, transmission_type,
    daily_rate, price_per_day, 
    description, mileage, image_url, status,
    license_plate, insurance_info, location,
    daily_km_limit, exceed_fee_per_km, fuel_consumption,
    created_at, updated_at
) VALUES (
    'Lexus', 'RX', 'Lexus RX 350h 2024', 2024, 'Trắng ngọc trai',
    'SUV', 7, 'Hybrid', 'Automatic',
    1650000, 1650000,
    'SUV hạng sang 7 chỗ, hybrid tiết kiệm, nội thất sang trọng, êm ái tuyệt đối', 
    2000, 'https://example.com/lexus-rx.jpg', 'Available',
    '30A-00999', 'Bảo hiểm toàn diện + bảo dưỡng miễn phí', 'Hà Nội',
    250, 8000, 6.5,
    GETDATE(), GETDATE()
);

PRINT '✅ Đã thêm 2 xe cao cấp';
GO

-- ========================================
-- KIỂM TRA KẾT QUẢ
-- ========================================

PRINT '';
PRINT '========================================';
PRINT 'TỔNG KẾT';
PRINT '========================================';

-- Đếm tổng số xe
SELECT COUNT(*) as 'Tổng số xe' FROM cars;

-- Thống kê theo hãng
PRINT '';
PRINT 'Thống kê theo hãng:';
SELECT brand as 'Hãng xe', COUNT(*) as 'Số lượng' 
FROM cars 
GROUP BY brand 
ORDER BY COUNT(*) DESC;

-- Thống kê theo loại nhiên liệu
PRINT '';
PRINT 'Thống kê theo nhiên liệu:';
SELECT fuel_type as 'Loại nhiên liệu', COUNT(*) as 'Số lượng' 
FROM cars 
GROUP BY fuel_type 
ORDER BY COUNT(*) DESC;

-- Thống kê theo số chỗ
PRINT '';
PRINT 'Thống kê theo số chỗ:';
SELECT seat_capacity as 'Số chỗ', COUNT(*) as 'Số lượng' 
FROM cars 
GROUP BY seat_capacity 
ORDER BY seat_capacity;

-- Xem 5 xe mới nhất
PRINT '';
PRINT 'Top 5 xe vừa thêm:';
SELECT TOP 5 id, brand, model, name, price_per_day, status, created_at
FROM cars
ORDER BY created_at DESC;

PRINT '';
PRINT '========================================';
PRINT '✅ HOÀN THÀNH! Đã thêm xe mới thành công';
PRINT '========================================';
PRINT '';
PRINT 'Bước tiếp theo:';
PRINT '1. Restart Spring Boot backend';
PRINT '2. Mở http://localhost:8080/api/cars/all';
PRINT '3. Mở DriveNow/html/searchcar.html';
PRINT '4. Kiểm tra xe hiển thị đúng';
PRINT '';

GO

-- ========================================
-- MẪU TEST QUERY (Uncomment để test)
-- ========================================

/*
-- Test lấy tất cả xe
SELECT * FROM cars ORDER BY created_at DESC;

-- Test lấy xe theo hãng
SELECT * FROM cars WHERE brand = 'Toyota';

-- Test lấy xe điện
SELECT * FROM cars WHERE fuel_type = 'Electric';

-- Test lấy xe hybrid
SELECT * FROM cars WHERE fuel_type = 'Hybrid';

-- Test lấy xe theo số chỗ
SELECT * FROM cars WHERE seat_capacity = 7;

-- Test xóa xe test (CẨN THẬN!)
-- DELETE FROM cars WHERE license_plate LIKE '%-TEST';

-- Backup table trước khi thêm
-- SELECT * INTO cars_backup_20250121 FROM cars;
*/
