# 🐛 DEBUG & FIX - REGISTER API

## ❌ LỖI HIỆN TẠI

**Response:**
```json
{
    "success": false,
    "message": "Validation failed",
    "data": {
        "role": "Role không được để trống",
        "username": "Username không được để trống"
    }
}
```

**Status:** `400 Bad Request`

---

## 🔍 NGUYÊN NHÂN

Backend yêu cầu:
1. ✅ `username` (là email) - NOT `email`
2. ✅ `role` - "customer" hoặc "driver"
3. ✅ `phone` - NOT `phoneNumber`
4. ✅ `dob` - NOT `dateOfBirth`

---

## ✅ BODY ĐÚNG CHO POSTMAN

### **Request URL:**
```
POST http://localhost:8080/api/auth/register
```

### **Headers:**
```
Content-Type: application/json
```

### **Body (RAW JSON):**
```json
{
    "username": "test@example.com",
    "password": "Password123",
    "role": "customer",
    "fullName": "Nguyen Van Test",
    "phone": "0987654321",
    "address": "123 Test Street, Hanoi",
    "dob": "1990-01-01",
    "gender": "male",
    "licenseNumber": null
}
```

---

## 📋 FIELD MAPPING

| ❌ Tên cũ (sai) | ✅ Tên đúng | Required | Valid Values |
|----------------|------------|----------|--------------|
| `email` | `username` | ✅ Yes | Email format |
| `password` | `password` | ✅ Yes | Min 6 chars |
| - | `role` | ✅ Yes | "customer" / "driver" |
| `fullName` | `fullName` | ✅ Yes | Any string |
| `phoneNumber` | `phone` | ⚠️ No | 10-11 digits |
| `address` | `address` | ⚠️ No | Any string |
| `dateOfBirth` | `dob` | ⚠️ No | YYYY-MM-DD |
| - | `gender` | ⚠️ No | "male"/"female"/"other" |
| `licenseNumber` | `licenseNumber` | ⚠️ No | For driver only |

---

## 🎯 HƯỚNG DẪN TEST TRONG POSTMAN

### Bước 1: Mở Request "Register"
- Trong Postman, chọn request **"Register"** 
- Hoặc tạo request mới: POST `http://localhost:8080/api/auth/register`

### Bước 2: Sửa Body
1. Chọn tab **"Body"**
2. Chọn **"raw"**
3. Chọn **"JSON"** (dropdown bên phải)
4. **Copy và paste** body này:

```json
{
    "username": "testuser001@gmail.com",
    "password": "Test@123456",
    "role": "customer",
    "fullName": "Nguyen Van Test",
    "phone": "0987654321",
    "address": "123 Nguyen Trai, Ha Noi",
    "dob": "1995-05-15",
    "gender": "male"
}
```

### Bước 3: Click "Send"

---

## ✅ EXPECTED RESPONSE

**Status:** `201 Created`

**Response:**
```json
{
    "success": true,
    "message": "Đăng ký thành công",
    "data": {
        "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
        "accountId": 1,
        "username": "testuser001@gmail.com",
        "role": "customer",
        "fullName": "Nguyen Van Test",
        "message": "Đăng ký thành công"
    }
}
```

Token sẽ **tự động lưu** vào variable `{{token}}`!

---

## 🔄 TEST CASE: REGISTER DRIVER

Nếu muốn đăng ký tài xế:

```json
{
    "username": "driver001@gmail.com",
    "password": "Driver@123",
    "role": "driver",
    "fullName": "Tran Van Driver",
    "phone": "0912345678",
    "address": "456 Le Loi, Ha Noi",
    "dob": "1988-03-20",
    "gender": "male",
    "licenseNumber": "ABC123456",
    "yearsOfExperience": 5,
    "idCard": "001234567890"
}
```

---

## 🐛 TROUBLESHOOTING

### ❌ Lỗi: "Username phải là email hợp lệ"
**Fix:** Đảm bảo `username` có format email
```json
"username": "test@example.com"  ✅
"username": "testuser"          ❌
```

### ❌ Lỗi: "Role phải là 'customer' hoặc 'driver'"
**Fix:** Role chỉ chấp nhận 2 giá trị
```json
"role": "customer"  ✅
"role": "driver"    ✅
"role": "admin"     ❌
```

### ❌ Lỗi: "Phone phải là số và có 10-11 chữ số"
**Fix:** Phone phải đúng format
```json
"phone": "0987654321"   ✅ (10 số)
"phone": "09876543210"  ✅ (11 số)
"phone": "098-765-4321" ❌ (có dấu -)
"phone": "123"          ❌ (quá ngắn)
```

### ❌ Lỗi: "Gender phải là 'male', 'female' hoặc 'other'"
**Fix:** Gender chỉ chấp nhận 3 giá trị
```json
"gender": "male"    ✅
"gender": "female"  ✅
"gender": "other"   ✅
"gender": "nam"     ❌
```

---

## 📝 VALIDATION RULES SUMMARY

```javascript
username: {
  required: true,
  format: "email"
}

password: {
  required: true,
  minLength: 6
}

role: {
  required: true,
  enum: ["customer", "driver"]
}

fullName: {
  required: true
}

phone: {
  optional: true,
  pattern: "^[0-9]{10,11}$"
}

dob: {
  optional: true,
  format: "YYYY-MM-DD"
}

gender: {
  optional: true,
  enum: ["male", "female", "other"]
}
```

---

## 🎯 QUICK TEST COMMANDS

### Test với curl (PowerShell):
```powershell
$body = @{
    username = "test@example.com"
    password = "Password123"
    role = "customer"
    fullName = "Test User"
    phone = "0987654321"
} | ConvertTo-Json

Invoke-RestMethod -Uri "http://localhost:8080/api/auth/register" `
    -Method POST `
    -Body $body `
    -ContentType "application/json"
```

---

## ✅ CHECKLIST

Trước khi click Send:
- [ ] URL: `http://localhost:8080/api/auth/register`
- [ ] Method: POST
- [ ] Header: Content-Type = application/json
- [ ] Body: raw JSON
- [ ] `username` có @ và domain
- [ ] `password` >= 6 ký tự
- [ ] `role` = "customer" hoặc "driver"
- [ ] `fullName` không empty
- [ ] `phone` 10-11 số (nếu có)
- [ ] Server đang chạy trên port 8080

---

## 🎉 SAU KHI REGISTER THÀNH CÔNG

### 1. Verify trong Database
```sql
SELECT * FROM accounts WHERE username = 'test@example.com';
SELECT * FROM customers WHERE email = 'test@example.com';
```

### 2. Test Login
```json
POST http://localhost:8080/api/auth/login
{
    "username": "test@example.com",
    "password": "Password123"
}
```

### 3. Check Token
- Token tự động lưu trong Postman Variables
- Click vào collection name → Tab "Variables"
- Xem `token` value

---

**🚀 BÂY GIỜ HÃY THỬ LẠI VỚI BODY ĐÚNG!**
