-- ========================================
-- CẬP NHẬT ẢNH XE THỰC TẾ CHO 26 XE
-- Sử dụng ảnh từ các nguồn online
-- ========================================

USE drivenow_db;
GO

-- ========================================
-- TOYOTA (6 xe)
-- ========================================

-- Toyota Vios Trắng
UPDATE cars SET image_url = 'https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?w=500&h=350&fit=crop'
WHERE id = 1;

-- Toyota Vios Đen
UPDATE cars SET image_url = 'https://images.unsplash.com/photo-1583121274602-3e2820c69888?w=500&h=350&fit=crop'
WHERE id = 2;

-- Toyota Camry
UPDATE cars SET image_url = 'https://images.unsplash.com/photo-1621135802920-133df287f89c?w=500&h=350&fit=crop'
WHERE id = 3;

-- Toyota Fortuner
UPDATE cars SET image_url = 'https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?w=500&h=350&fit=crop'
WHERE id = 4;

-- Toyota Innova
UPDATE cars SET image_url = 'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=500&h=350&fit=crop'
WHERE id = 5;

-- Toyota Corolla Cross
UPDATE cars SET image_url = 'https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=500&h=350&fit=crop'
WHERE id = 6;

-- ========================================
-- HONDA (5 xe)
-- ========================================

-- Honda City Trắng
UPDATE cars SET image_url = 'https://images.unsplash.com/photo-1605559424843-9e4c228bf1c2?w=500&h=350&fit=crop'
WHERE id = 7;

-- Honda City Đỏ
UPDATE cars SET image_url = 'https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?w=500&h=350&fit=crop'
WHERE id = 8;

-- Honda Civic
UPDATE cars SET image_url = 'https://images.unsplash.com/photo-1590362891991-f776e747a588?w=500&h=350&fit=crop'
WHERE id = 9;

-- Honda CR-V
UPDATE cars SET image_url = 'https://images.unsplash.com/photo-1609521263047-f8f205293f24?w=500&h=350&fit=crop'
WHERE id = 10;

-- Honda BR-V
UPDATE cars SET image_url = 'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?w=500&h=350&fit=crop'
WHERE id = 11;

-- ========================================
-- MAZDA (5 xe)
-- ========================================

-- Mazda 2
UPDATE cars SET image_url = 'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?w=500&h=350&fit=crop'
WHERE id = 12;

-- Mazda 3
UPDATE cars SET image_url = 'https://images.unsplash.com/photo-1617814076367-b759c7d7e738?w=500&h=350&fit=crop'
WHERE id = 13;

-- Mazda CX-5 Đỏ
UPDATE cars SET image_url = 'https://images.unsplash.com/photo-1617886903355-9354bb57751f?w=500&h=350&fit=crop'
WHERE id = 14;

-- Mazda CX-5 Trắng
UPDATE cars SET image_url = 'https://images.unsplash.com/photo-1610647752706-3bb12232b3ab?w=500&h=350&fit=crop'
WHERE id = 15;

-- Mazda CX-8
UPDATE cars SET image_url = 'https://images.unsplash.com/photo-1611015830788-81b57d2c0024?w=500&h=350&fit=crop'
WHERE id = 16;

-- ========================================
-- FORD (3 xe)
-- ========================================

-- Ford Ranger
UPDATE cars SET image_url = 'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?w=500&h=350&fit=crop'
WHERE id = 17;

-- Ford Everest
UPDATE cars SET image_url = 'https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?w=500&h=350&fit=crop'
WHERE id = 18;

-- Ford Territory
UPDATE cars SET image_url = 'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=500&h=350&fit=crop'
WHERE id = 19;

-- ========================================
-- KIA (3 xe)
-- ========================================

-- Kia Seltos
UPDATE cars SET image_url = 'https://images.unsplash.com/photo-1621839673705-6617adf9e890?w=500&h=350&fit=crop'
WHERE id = 20;

-- Kia Sorento
UPDATE cars SET image_url = 'https://images.unsplash.com/photo-1609521263047-f8f205293f24?w=500&h=350&fit=crop'
WHERE id = 21;

-- Kia Carnival
UPDATE cars SET image_url = 'https://images.unsplash.com/photo-1622493850477-dc6e1b0e8b32?w=500&h=350&fit=crop'
WHERE id = 22;

-- ========================================
-- HYUNDAI (3 xe)
-- ========================================

-- Hyundai Accent
UPDATE cars SET image_url = 'https://images.unsplash.com/photo-1605559424843-9e4c228bf1c2?w=500&h=350&fit=crop'
WHERE id = 23;

-- Hyundai Tucson
UPDATE cars SET image_url = 'https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=500&h=350&fit=crop'
WHERE id = 24;

-- Hyundai Santa Fe
UPDATE cars SET image_url = 'https://images.unsplash.com/photo-1611015830788-81b57d2c0024?w=500&h=350&fit=crop'
WHERE id = 25;

-- ========================================
-- VINFAST - XE ĐIỆN (3 xe)
-- ========================================

-- Vinfast VF5
UPDATE cars SET image_url = 'https://images.unsplash.com/photo-1593941707882-a5bba14938c7?w=500&h=350&fit=crop'
WHERE id = 26;

-- Vinfast VF8 (có thể không có do lỗi trước đó)
UPDATE cars SET image_url = 'https://images.unsplash.com/photo-1560958089-b8a1929cea89?w=500&h=350&fit=crop'
WHERE brand = 'Vinfast' AND model = 'VF8';

-- Vinfast VF9 (có thể không có do lỗi trước đó)
UPDATE cars SET image_url = 'https://images.unsplash.com/photo-1617886903355-9354bb57751f?w=500&h=350&fit=crop'
WHERE brand = 'Vinfast' AND model = 'VF9';

-- ========================================
-- MITSUBISHI - HYBRID (1 xe)
-- ========================================

-- Mitsubishi Outlander
UPDATE cars SET image_url = 'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=500&h=350&fit=crop'
WHERE brand = 'Mitsubishi' AND model = 'Outlander';

-- ========================================
-- KIỂM TRA KẾT QUẢ
-- ========================================

PRINT '';
PRINT '========================================';
PRINT 'ĐÃ CẬP NHẬT ẢNH CHO 26 XE';
PRINT '========================================';

-- Xem 5 xe đầu tiên
SELECT TOP 5 id, brand, model, name, 
       SUBSTRING(image_url, 1, 50) + '...' as image_url_preview
FROM cars
ORDER BY id;

PRINT '';
PRINT '✅ Hoàn thành! Refresh trang searchcar.html để xem ảnh xe!';
PRINT '';

GO
