# 🚀 HƯỚNG DẪN NHANH - TEST API VỚI POSTMAN

## ✅ Server đã chạy thành công!
- **URL:** http://localhost:8080
- **Status:** ✅ Running

---

## 📦 FILES ĐÃ TẠO

### 1. `DriveNow_Postman_Collection.json`
- Postman Collection đầy đủ với 60+ API endpoints
- Tự động lưu token sau khi login
- Variables được config sẵn

### 2. `POSTMAN_TESTING_GUIDE.md`
- Hướng dẫn chi tiết từng API
- Test scenarios đầy đủ
- Troubleshooting guide

---

## 🎯 BƯỚC 1: IMPORT VÀO POSTMAN

### Cách 1: Import từ File
1. Mở Postman
2. Click **Import** (góc trên bên trái)
3. Kéo thả file `DriveNow_Postman_Collection.json` vào
4. Click **Import**

### Cách 2: Copy JSON
1. Mở file `DriveNow_Postman_Collection.json`
2. Copy toàn bộ nội dung
3. Postman > Import > Raw text > Paste > Continue

✅ Collection "DriveNow API - Complete Collection" sẽ xuất hiện!

---

## 🧪 BƯỚC 2: TEST NGAY - QUICK START

### Test 1: Register (Đăng ký)
```
POST http://localhost:8080/api/auth/register
Content-Type: application/json

{
    "email": "test001@gmail.com",
    "password": "Test@123456",
    "fullName": "Nguyen Van Test",
    "phoneNumber": "0987654321",
    "address": "123 Nguyen Trai, Ha Noi",
    "dateOfBirth": "1995-05-15",
    "licenseNumber": "012345678"
}
```

**Expected Response:** 
- Status: 201 Created
- Token tự động lưu vào variable

---

### Test 2: Login
```
POST http://localhost:8080/api/auth/login
Content-Type: application/json

{
    "email": "test001@gmail.com",
    "password": "Test@123456"
}
```

**Expected Response:**
```json
{
    "success": true,
    "message": "Đăng nhập thành công",
    "data": {
        "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
        "email": "test001@gmail.com",
        "fullName": "Nguyen Van Test"
    }
}
```

---

### Test 3: Get All Cars (Public API)
```
GET http://localhost:8080/api/cars
```

✅ Không cần token, ai cũng xem được!

---

### Test 4: Search Cars
```
GET http://localhost:8080/api/search/cars?location=Hà Nội&startDate=2025-10-20T10:00:00&endDate=2025-10-25T10:00:00
```

---

### Test 5: Create Booking (Cần token)
```
POST http://localhost:8080/api/bookings
Authorization: Bearer YOUR_TOKEN_HERE
Content-Type: application/json

{
    "carId": 1,
    "customerId": 1,
    "rentalStartDate": "2025-10-20T10:00:00",
    "rentalEndDate": "2025-10-25T10:00:00",
    "pickupLocation": "Hà Nội",
    "returnLocation": "Hà Nội",
    "driverOption": false,
    "notes": "Cần xe sạch sẽ"
}
```

---

## 📊 DANH SÁCH API CHÍNH

### 🔐 Authentication (7 APIs)
- POST `/api/auth/register` - Đăng ký
- POST `/api/auth/login` - Đăng nhập
- POST `/api/auth/google-login` - Login Google
- POST `/api/auth/forgot-password` - Quên mật khẩu
- POST `/api/auth/verify-otp` - Xác thực OTP
- POST `/api/auth/reset-password` - Đặt lại mật khẩu
- POST `/auth/logout` - Đăng xuất

### 🚗 Cars (7 APIs)
- GET `/api/cars` - Danh sách xe
- GET `/api/cars/{id}` - Chi tiết xe
- POST `/api/cars` - Thêm xe mới
- PUT `/api/cars/{id}` - Cập nhật xe
- DELETE `/api/cars/{id}` - Xóa xe
- PATCH `/api/cars/{id}/status` - Đổi trạng thái

### 📅 Bookings (9 APIs)
- POST `/api/bookings` - Tạo booking
- GET `/api/bookings/{id}` - Chi tiết booking
- PUT `/api/bookings/{id}` - Cập nhật booking
- PATCH `/api/bookings/{id}/cancel` - Hủy booking
- PATCH `/api/bookings/{id}/confirm` - Xác nhận booking
- PATCH `/api/bookings/{id}/complete` - Hoàn thành booking
- GET `/api/bookings/customer/{id}` - Booking theo customer
- GET `/api/bookings/car/{id}` - Booking theo xe

### 🔍 Search & Filter (2 APIs)
- GET `/api/search/cars` - Tìm xe có sẵn
- GET `/api/search/filter` - Lọc xe theo tiêu chí

### ⭐ Favorites (3 APIs)
- GET `/api/favorites` - Danh sách yêu thích
- POST `/api/favorites/{carId}` - Thêm yêu thích
- DELETE `/api/favorites/{carId}` - Xóa yêu thích

### 📝 History & Reviews (3 APIs)
- GET `/api/history/customer/{id}` - Lịch sử khách hàng
- POST `/api/history/review` - Thêm đánh giá
- GET `/api/history/car/{id}/reviews` - Đánh giá của xe

### 👤 Profile (3 APIs)
- GET `/profile` - Xem profile
- PUT `/profile` - Cập nhật profile
- PUT `/profile/change-password` - Đổi mật khẩu

### 📄 Rental Contracts (2 APIs)
- POST `/api/rental-contracts` - Tạo hợp đồng
- GET `/api/rental-contracts/booking/{id}` - Xem hợp đồng

### 🚚 Delivery Schedules (3 APIs)
- POST `/api/delivery-schedules` - Tạo lịch giao xe
- GET `/api/delivery-schedules/booking/{id}` - Xem lịch
- PATCH `/api/delivery-schedules/{id}/status` - Cập nhật trạng thái

### 👥 Group Bookings (2 APIs)
- POST `/api/group-bookings` - Tạo booking nhóm
- GET `/api/group-bookings/{id}` - Xem booking nhóm

### ✔️ Validation (1 API)
- GET `/api/validation/email-exists` - Kiểm tra email tồn tại

---

## 🎯 TEST FLOW HOÀN CHỈNH

### Scenario 1: User Journey
1. ✅ Register → Đăng ký tài khoản
2. ✅ Login → Đăng nhập (lấy token)
3. ✅ Search cars → Tìm xe phù hợp
4. ✅ Add to favorites → Lưu xe yêu thích
5. ✅ Create booking → Đặt xe
6. ✅ Get my bookings → Xem booking
7. ✅ Add review → Đánh giá sau khi hoàn thành

### Scenario 2: Admin Car Management
1. ✅ Login as admin
2. ✅ Create car → Thêm xe mới
3. ✅ Update car → Cập nhật thông tin
4. ✅ Update status → Đổi trạng thái (available/rented/maintenance)
5. ✅ Delete car (nếu cần)

### Scenario 3: Booking Flow
1. ✅ Customer search cars
2. ✅ Customer create booking
3. ✅ Admin confirm booking
4. ✅ Create delivery schedule
5. ✅ Complete booking
6. ✅ Customer add review

---

## 🛠️ DEBUGGING

### Check Server Status
```powershell
curl http://localhost:8080/api/cars
```

### Check Port
```powershell
netstat -ano | findstr :8080
```

### View Logs
- Xem terminal đang chạy `start-backend.bat`
- Log được in ra real-time

---

## 💡 TIPS QUAN TRỌNG

### 1. Token Auto-Save
- Collection có script tự động lưu token sau login
- Không cần copy-paste thủ công
- Token được dùng cho tất cả request cần auth

### 2. Variables
- `{{baseUrl}}` = http://localhost:8080
- `{{token}}` = JWT token (auto-saved)
- Có thể đổi baseUrl dễ dàng cho production

### 3. Response Examples
- Mỗi request có thể save response example
- Dùng làm documentation

### 4. Test Scripts
- Collection có sẵn test scripts
- Tự động validate responses
- Check status codes

---

## 📞 TRỢ GIÚP

### Lỗi thường gặp:

**❌ 401 Unauthorized**
- Login lại để lấy token mới
- Kiểm tra token trong Variables

**❌ 400 Bad Request**
- Kiểm tra format dữ liệu
- Email, password, date format

**❌ 500 Internal Server Error**
- Xem logs trong terminal
- Kiểm tra database connection

---

## 📁 FILES REFERENCE

1. **DriveNow_Postman_Collection.json** - Import vào Postman
2. **POSTMAN_TESTING_GUIDE.md** - Hướng dẫn chi tiết
3. **README.md** (file này) - Quick start guide

---

## 🎉 BẮT ĐẦU TEST NGAY!

1. Import collection vào Postman
2. Test Register/Login
3. Explore các API khác
4. Đọc `POSTMAN_TESTING_GUIDE.md` để biết chi tiết

**Server is ready at:** http://localhost:8080

**Happy Testing! 🚀**
