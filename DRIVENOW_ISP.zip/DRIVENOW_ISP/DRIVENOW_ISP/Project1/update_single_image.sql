-- CẬP NHẬT ẢNH XE VỚI LINK BẠN VỪA TÌM

-- Ví dụ: Update ảnh cho Toyota Vios (ID = 1)
UPDATE cars 
SET image_url = N'https://images.unsplash.com/photo-1605816988069-b11383b50717?w=800' 
WHERE id = 1;

-- Kiểm tra kết quả
SELECT id, name, image_url FROM cars WHERE id = 1;

-- ========================================
-- TEMPLATE ĐỂ BẠN TỰ THÊM:
-- ========================================

-- Bước 1: Tìm ID của xe muốn thay ảnh
SELECT id, name FROM cars;

-- Bước 2: Update ảnh (Thay [ID] và [LINK])
UPDATE cars 
SET image_url = N'https://images.unsplash.com/photo-XXXXXXXXX?w=800' 
WHERE id = [ID];

-- Bước 3: Kiểm tra
SELECT id, name, image_url FROM cars WHERE id = [ID];
