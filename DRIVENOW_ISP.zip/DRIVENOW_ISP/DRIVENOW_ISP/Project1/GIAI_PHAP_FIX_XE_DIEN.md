# 🔧 Giải Pháp Fix Lỗi Lọc Xe Điện (Giữ Nguyên Dấu)

## ❌ VẤN ĐỀ
- Khi click tab "Xe Điện", API `/api/cars/electric` trả về **0 xe**
- Nhưng database có 3 xe VinFast với `fuel_type = "Điện"`
- Nguyên nhân: **JPQL không match được Unicode 272 (Đ) giữa Java code và SQL Server**

## ✅ GIẢI PHÁP: NATIVE QUERY

### 1️⃣ Cách Fix (Giữ Nguyên Dấu Tiếng Việt)

**File:** `CarRepository.java`

```java
// ❌ CÁCH CŨ (JPQL - không work với Vietnamese Unicode):
@Query("SELECT c FROM Car c WHERE LOWER(c.fuelType) LIKE '%điện%'")
List<Car> findElectricCars();

// ✅ CÁCH MỚI (Native Query - work với N'Điện'):
@Query(value = "SELECT * FROM cars WHERE fuel_type = N'Điện' OR LOWER(fuel_type) = 'electric'", 
       nativeQuery = true)
List<Car> findElectricCars();
```

### 2️⃣ Tại Sao Native Query Work?

| Phương pháp | Xử lý Unicode | Kết quả |
|------------|---------------|---------|
| **JPQL** | Java compile string 'Điện' → có thể khác Unicode 272 | ❌ Không match |
| **Native Query** | SQL Server nhận raw string với `N'Điện'` prefix | ✅ Match chính xác |

### 3️⃣ Code Hoàn Chỉnh

```java
@Repository
public interface CarRepository extends JpaRepository<Car, Long> {
    
    // Xe điện
    @Query(value = "SELECT * FROM cars WHERE fuel_type = N'Điện' OR LOWER(fuel_type) = 'electric'", 
           nativeQuery = true)
    List<Car> findElectricCars();
    
    // Xe hybrid
    @Query(value = "SELECT * FROM cars WHERE LOWER(fuel_type) LIKE '%hybrid%' OR fuel_type LIKE N'%Xăng%Điện%'", 
           nativeQuery = true)
    List<Car> findHybridCars();
}
```

### 4️⃣ Kiểm Tra Database

```sql
-- Xem fuel_type hiện tại
SELECT id, brand, name, fuel_type, 
       UNICODE(SUBSTRING(fuel_type,1,1)) as unicode_code
FROM cars 
WHERE brand = N'VinFast';

-- Kết quả mong muốn:
-- unicode_code = 272 (Đ viết hoa tiếng Việt)
-- fuel_type hiển thị: "Điện" (4 ký tự)
```

### 5️⃣ Test API

```powershell
# Test endpoint xe điện
Invoke-RestMethod -Uri "http://localhost:8080/api/cars/electric"

# Kết quả mong đợi:
{
  "success": true,
  "message": "Đã tìm thấy xe điện",
  "totalCount": 3,
  "cars": [
    { "brand": "VinFast", "name": "VinFast VF5 Plus 2024", "fuelType": "Điện" },
    { "brand": "VinFast", "name": "VinFast VF8 2024", "fuelType": "Điện" },
    { "brand": "VinFast", "name": "VinFast VF9 2024", "fuelType": "Điện" }
  ]
}
```

## 📋 CHECKLIST

- [x] Đổi query từ JPQL sang Native Query
- [x] Thêm `N'Điện'` prefix trong SQL
- [x] Set `nativeQuery = true` trong @Query
- [x] Restart backend
- [ ] Test `/api/cars/electric` → phải trả về 3 xe VinFast
- [ ] Test trên frontend searchcar.html → click tab "Xe Điện"

## 🎯 ƯU ĐIỂM

✅ **Giữ nguyên dấu tiếng Việt** trong database  
✅ **Không cần thay đổi data** (vẫn dùng "Điện", "Xăng", etc.)  
✅ **SQL Server tự xử lý Unicode** qua N prefix  
✅ **Code sạch hơn** - không cần workaround  

## ⚠️ LƯU Ý

- `nativeQuery = true` → SQL thuần, không dùng entity mapping syntax
- Phải dùng **tên cột database** (`fuel_type`) chứ không phải field name (`fuelType`)
- Phải dùng **tên bảng database** (`cars`) chứ không phải entity name (`Car`)
- Luôn dùng `N'...'` prefix cho string tiếng Việt trong SQL Server

---

**Ngày tạo:** 22/10/2025  
**Trạng thái:** ✅ Đã fix xong (đang test backend)
