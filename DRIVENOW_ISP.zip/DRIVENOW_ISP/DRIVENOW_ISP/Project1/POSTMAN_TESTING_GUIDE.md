# HƯỚNG DẪN TEST API VỚI POSTMAN

## 📋 MỤC LỤC
1. [Import Collection vào Postman](#import-collection)
2. [Cấu hình Environment](#configure-environment)
3. [Test API theo thứ tự](#test-flow)
4. [Các API chính](#main-apis)
5. [Xử lý lỗi thường gặp](#troubleshooting)

---

## 🚀 IMPORT COLLECTION

### Bước 1: Mở Postman
- Mở ứng dụng Postman trên máy tính
- Nếu chưa có, tải tại: https://www.postman.com/downloads/

### Bước 2: Import Collection
1. Click nút **Import** ở góc trên bên trái
2. Chọn tab **File**
3. Kéo thả file `DriveNow_Postman_Collection.json` vào
4. Click **Import**

✅ Collection "DriveNow API - Complete Collection" sẽ xuất hiện trong sidebar

---

## ⚙️ CONFIGURE ENVIRONMENT

### Variables được cấu hình tự động:
- `baseUrl`: http://localhost:8080
- `token`: Sẽ tự động lưu sau khi login

### Kiểm tra Variables:
1. Click vào collection "DriveNow API - Complete Collection"
2. Chọn tab **Variables**
3. Đảm bảo `baseUrl` = `http://localhost:8080`

---

## 🧪 TEST API THEO THỨ TỰ

### 1️⃣ AUTHENTICATION FLOW

#### A. Register (Đăng ký tài khoản mới)
```
POST {{baseUrl}}/api/auth/register
```

**Body mẫu:**
```json
{
    "email": "testuser@gmail.com",
    "password": "Test@123456",
    "fullName": "Nguyen Van Test",
    "phoneNumber": "0987654321",
    "address": "123 Nguyen Trai, Ha Noi",
    "dateOfBirth": "1995-05-15",
    "licenseNumber": "012345678"
}
```

**Kết quả mong đợi:**
- Status: `201 Created`
- Response chứa `token` → Token tự động lưu vào variable

---

#### B. Login (Đăng nhập)
```
POST {{baseUrl}}/api/auth/login
```

**Body mẫu:**
```json
{
    "email": "testuser@gmail.com",
    "password": "Test@123456"
}
```

**Kết quả mong đợi:**
- Status: `200 OK`
- Response:
```json
{
    "success": true,
    "message": "Đăng nhập thành công",
    "data": {
        "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
        "email": "testuser@gmail.com",
        "fullName": "Nguyen Van Test"
    }
}
```

✅ **Token tự động được lưu** và dùng cho các request tiếp theo!

---

#### C. Forgot Password Flow

**1. Request OTP:**
```
POST {{baseUrl}}/api/auth/forgot-password
Body: { "email": "testuser@gmail.com" }
```

**2. Verify OTP:**
```
POST {{baseUrl}}/api/auth/verify-otp
Body: { "email": "testuser@gmail.com", "otp": "123456" }
```

**3. Reset Password:**
```
POST {{baseUrl}}/api/auth/reset-password
Body: { 
    "email": "testuser@gmail.com", 
    "otp": "123456",
    "newPassword": "NewPassword@123"
}
```

---

### 2️⃣ CAR MANAGEMENT

#### A. Get All Cars (Public)
```
GET {{baseUrl}}/api/cars
```
✅ Không cần token, ai cũng xem được

---

#### B. Get Car By ID
```
GET {{baseUrl}}/api/cars/1
```

---

#### C. Create Car (Admin only)
```
POST {{baseUrl}}/api/cars
Authorization: Bearer {{token}}
```

**Body mẫu:**
```json
{
    "brandName": "Toyota",
    "modelName": "Vios 2024",
    "year": 2024,
    "color": "Trắng",
    "licensePlate": "30A-12345",
    "seatingCapacity": 5,
    "fuelType": "Xăng",
    "transmission": "Tự động",
    "dailyRate": 600000.00,
    "location": "Hà Nội",
    "features": "Camera lùi, Cảm biến va chạm, Bluetooth",
    "description": "Xe mới 100%, bảo dưỡng định kỳ",
    "status": "available"
}
```

**Các giá trị hợp lệ:**
- `fuelType`: "Xăng", "Dầu", "Điện", "Hybrid"
- `transmission`: "Tự động", "Số sàn"
- `status`: "available", "rented", "maintenance"

---

#### D. Update Car
```
PUT {{baseUrl}}/api/cars/1
Authorization: Bearer {{token}}
```

---

#### E. Update Car Status
```
PATCH {{baseUrl}}/api/cars/1/status?status=rented
Authorization: Bearer {{token}}
```

---

#### F. Delete Car
```
DELETE {{baseUrl}}/api/cars/1
Authorization: Bearer {{token}}
```

---

### 3️⃣ BOOKING FLOW

#### A. Search Available Cars
```
GET {{baseUrl}}/api/search/cars?location=Hà Nội&startDate=2025-10-20T10:00:00&endDate=2025-10-25T10:00:00
```

**Query Parameters:**
- `location`: Địa điểm thuê xe
- `startDate`: Ngày bắt đầu (format: yyyy-MM-ddTHH:mm:ss)
- `endDate`: Ngày kết thúc
- `minPrice`: Giá tối thiểu (optional)
- `maxPrice`: Giá tối đa (optional)

---

#### B. Create Booking
```
POST {{baseUrl}}/api/bookings
Authorization: Bearer {{token}}
```

**Body mẫu:**
```json
{
    "carId": 1,
    "customerId": 1,
    "rentalStartDate": "2025-10-20T10:00:00",
    "rentalEndDate": "2025-10-25T10:00:00",
    "pickupLocation": "Hà Nội - Cầu Giấy",
    "returnLocation": "Hà Nội - Cầu Giấy",
    "driverOption": false,
    "notes": "Cần xe sạch sẽ"
}
```

**Kết quả:**
- Status: `201 Created`
- Booking được tạo với status = `pending`
- Tính toán tự động: `totalAmount` = số ngày × `dailyRate`

---

#### C. Get Booking Details
```
GET {{baseUrl}}/api/bookings/1
Authorization: Bearer {{token}}
```

---

#### D. Update Booking (Chỉ khi status=pending)
```
PUT {{baseUrl}}/api/bookings/1
Authorization: Bearer {{token}}
```

---

#### E. Confirm Booking (Admin)
```
PATCH {{baseUrl}}/api/bookings/1/confirm
Authorization: Bearer {{token}}
```
Status: `pending` → `confirmed`

---

#### F. Complete Booking
```
PATCH {{baseUrl}}/api/bookings/1/complete
Authorization: Bearer {{token}}
```
Status: `confirmed` → `completed`

---

#### G. Cancel Booking
```
PATCH {{baseUrl}}/api/bookings/1/cancel
Authorization: Bearer {{token}}
```

---

#### H. Get Customer Bookings
```
GET {{baseUrl}}/api/bookings/customer/1
Authorization: Bearer {{token}}
```

---

#### I. Get Car Bookings
```
GET {{baseUrl}}/api/bookings/car/1
Authorization: Bearer {{token}}
```

---

### 4️⃣ REVIEW & HISTORY

#### A. Get Customer History
```
GET {{baseUrl}}/api/history/customer/1
Authorization: Bearer {{token}}
```

---

#### B. Add Review (Sau khi hoàn thành booking)
```
POST {{baseUrl}}/api/history/review
Authorization: Bearer {{token}}
```

**Body mẫu:**
```json
{
    "bookingId": 1,
    "rating": 5,
    "comment": "Xe đẹp, sạch sẽ, chủ xe nhiệt tình!"
}
```

**Rating:** 1-5 sao

---

#### C. Get Car Reviews
```
GET {{baseUrl}}/api/history/car/1/reviews
```
✅ Public API, không cần token

---

### 5️⃣ FAVORITES

#### A. Get User Favorites
```
GET {{baseUrl}}/api/favorites
Authorization: Bearer {{token}}
```

---

#### B. Add Car to Favorites
```
POST {{baseUrl}}/api/favorites/1
Authorization: Bearer {{token}}
```
`1` = carId

---

#### C. Remove from Favorites
```
DELETE {{baseUrl}}/api/favorites/1
Authorization: Bearer {{token}}
```

---

### 6️⃣ PROFILE MANAGEMENT

#### A. Get Profile
```
GET {{baseUrl}}/profile
Authorization: Bearer {{token}}
```

---

#### B. Update Profile
```
PUT {{baseUrl}}/profile
Authorization: Bearer {{token}}
```

**Body mẫu:**
```json
{
    "fullName": "Nguyen Van Updated",
    "phoneNumber": "0987654322",
    "address": "456 New Address, Hanoi",
    "dateOfBirth": "1995-05-15",
    "licenseNumber": "012345679"
}
```

---

#### C. Change Password
```
PUT {{baseUrl}}/profile/change-password
Authorization: Bearer {{token}}
```

**Body:**
```json
{
    "oldPassword": "Test@123456",
    "newPassword": "NewPassword@789"
}
```

---

### 7️⃣ ADVANCED FEATURES

#### A. Rental Contract
```
POST {{baseUrl}}/api/rental-contracts
Authorization: Bearer {{token}}
```

**Body:**
```json
{
    "bookingId": 1,
    "contractNumber": "HD2025001",
    "securityDeposit": 5000000.00,
    "terms": "Điều khoản thuê xe theo quy định công ty"
}
```

---

#### B. Delivery Schedule
```
POST {{baseUrl}}/api/delivery-schedules
Authorization: Bearer {{token}}
```

**Body:**
```json
{
    "bookingId": 1,
    "deliveryType": "pickup",
    "scheduledTime": "2025-10-20T09:00:00",
    "deliveryAddress": "123 Nguyen Trai, Hanoi",
    "driverName": "Nguyen Van Driver",
    "driverPhone": "0912345678"
}
```

**deliveryType:** `pickup` hoặc `return`

---

#### C. Group Booking
```
POST {{baseUrl}}/api/group-bookings
Authorization: Bearer {{token}}
```

**Body:**
```json
{
    "groupName": "Tour Đà Lạt 2025",
    "organizerId": 1,
    "totalCars": 3,
    "startDate": "2025-11-01T08:00:00",
    "endDate": "2025-11-05T18:00:00",
    "notes": "Cần 3 xe 7 chỗ cho tour"
}
```

---

## 🔍 FILTER & SEARCH

### Filter Cars
```
GET {{baseUrl}}/api/search/filter?brandName=Toyota&fuelType=Xăng&transmission=Tự động&minSeating=5&maxSeating=7
```

**Query Parameters (tất cả optional):**
- `brandName`: Hãng xe
- `modelName`: Tên model
- `fuelType`: Loại nhiên liệu
- `transmission`: Loại hộp số
- `minSeating`: Số chỗ tối thiểu
- `maxSeating`: Số chỗ tối đa
- `location`: Địa điểm

---

## 🛠️ TROUBLESHOOTING

### ❌ Lỗi 401 Unauthorized
**Nguyên nhân:** Token hết hạn hoặc không hợp lệ

**Giải pháp:**
1. Login lại để lấy token mới
2. Kiểm tra token trong Variables

---

### ❌ Lỗi 400 Bad Request
**Nguyên nhân:** Dữ liệu không hợp lệ

**Kiểm tra:**
- Email đúng format
- Password >= 8 ký tự
- Số điện thoại đúng format
- Date format: `yyyy-MM-ddTHH:mm:ss`

---

### ❌ Lỗi 404 Not Found
**Nguyên nhân:** ID không tồn tại

**Giải pháp:** Get list trước để lấy ID hợp lệ

---

### ❌ Lỗi 500 Internal Server Error
**Nguyên nhân:** Lỗi server hoặc database

**Kiểm tra:**
1. Server có đang chạy không? (port 8080)
2. Database có connect được không?
3. Xem log trong console Spring Boot

---

## 📊 TEST SCENARIOS

### Scenario 1: Complete Booking Flow
1. Register/Login → Lấy token
2. Search cars → Tìm xe phù hợp
3. Create booking → Đặt xe
4. Confirm booking → Admin xác nhận
5. Create delivery schedule → Lên lịch giao xe
6. Complete booking → Hoàn thành
7. Add review → Đánh giá

---

### Scenario 2: Car Management
1. Login as Admin
2. Create car → Thêm xe mới
3. Get all cars → Xem danh sách
4. Update car → Cập nhật thông tin
5. Update status → Đổi trạng thái
6. Delete car (nếu cần)

---

### Scenario 3: User Journey
1. Register → Đăng ký
2. Login → Đăng nhập
3. Search cars → Tìm xe
4. Add to favorites → Lưu xe yêu thích
5. Create booking → Đặt xe
6. Get my bookings → Xem booking của mình
7. Complete & review → Hoàn thành và đánh giá

---

## 🎯 TIPS

### 1. Sử dụng Tests trong Postman
- Token tự động lưu sau login
- Không cần copy-paste token thủ công

### 2. Environment Variables
- Dùng `{{baseUrl}}` thay vì hardcode URL
- Dễ dàng đổi giữa localhost/production

### 3. Organize Collections
- Tạo folders cho từng module
- Đặt tên request rõ ràng

### 4. Save Responses
- Save example responses
- Dùng làm documentation

---

## 📞 SUPPORT

Nếu gặp vấn đề:
1. Check server logs trong terminal
2. Xem response error message
3. Kiểm tra database connection
4. Review request body format

---

**🎉 CHÚC BẠN TEST THÀNH CÔNG!**
