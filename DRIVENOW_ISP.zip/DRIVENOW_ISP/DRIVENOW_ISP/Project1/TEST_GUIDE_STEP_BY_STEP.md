# 🧪 HƯỚNG DẪN TEST API TỪNG BƯỚC - DRIVENOW

## ✅ CHUẨN BỊ
- [x] Server đã chạy trên port 8080
- [x] Postman đã import collection "DriveNow API - Complete Collection"
- [x] Database đã sẵn sàng

---

## 🔐 PHẦN 1: AUTHENTICATION (7 APIs)

### ✅ TEST 1: REGISTER - Đăng ký tài khoản mới

**Request đang hiển thị trong Postman của bạn:**
```
POST http://localhost:8080/api/auth/register
```

**Body (đã có sẵn):**
```json
{
    "email": "test@example.com",
    "password": "Password123",
    "fullName": "Nguyen Van Test",
    "phoneNumber": "0987654321",
    "address": "123 Test Street, Hanoi",
    "dateOfBirth": "1990-01-01",
    "licenseNumber": "012345678"
}
```

**Các bước thực hiện:**
1. ✅ Request đã được chọn sẵn trong Postman
2. 🔵 Click nút **"Send"** màu xanh bên phải
3. ⏳ Đợi response (2-3 giây)

**Expected Response:**
```json
{
    "success": true,
    "message": "Đăng ký thành công",
    "data": {
        "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
        "email": "test@example.com",
        "fullName": "Nguyen Van Test",
        "role": "CUSTOMER"
    }
}
```

**Status Code:** `201 Created` ✅

**Lưu ý quan trọng:**
- 🎯 Token sẽ **TỰ ĐỘNG** được lưu vào variable `{{token}}`
- ✅ Không cần copy-paste token thủ công
- 📝 Email phải unique, nếu test lại thì đổi email khác

**Kiểm tra token đã lưu:**
1. Click vào tên collection "DriveNow API - Complete Collection"
2. Chọn tab **"Variables"**
3. Xem giá trị của `token` → Phải có giá trị JWT dài

---

### ✅ TEST 2: LOGIN - Đăng nhập

**Chuyển sang request Login:**
1. Trong sidebar trái, click vào **"Login"** (ngay dưới Register)

**Request:**
```
POST http://localhost:8080/api/auth/login
```

**Body:**
```json
{
    "email": "test@example.com",
    "password": "Password123"
}
```

**Các bước:**
1. Đảm bảo email/password khớp với tài khoản vừa register
2. Click **"Send"**

**Expected Response:**
```json
{
    "success": true,
    "message": "Đăng nhập thành công",
    "data": {
        "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
        "email": "test@example.com",
        "fullName": "Nguyen Van Test",
        "role": "CUSTOMER"
    }
}
```

**Status Code:** `200 OK` ✅

**Test Case: Sai mật khẩu**
- Đổi password thành `"WrongPassword123"`
- Click Send
- Expected: `401 Unauthorized` với message "Sai email hoặc mật khẩu"

---

### ✅ TEST 3: FORGOT PASSWORD - Quên mật khẩu

**Chuyển sang request:**
1. Click **"Forgot Password"** trong sidebar

**Request:**
```
POST http://localhost:8080/api/auth/forgot-password
```

**Body:**
```json
{
    "email": "test@example.com"
}
```

**Các bước:**
1. Nhập email đã đăng ký
2. Click **"Send"**

**Expected Response:**
```json
{
    "success": true,
    "message": "Mã OTP đã được gửi đến email của bạn",
    "data": null
}
```

**Status Code:** `200 OK` ✅

**Lưu ý:**
- 📧 OTP sẽ được gửi đến email `quyenthedinh@gmail.com` (cấu hình trong application.properties)
- ⏰ OTP có hiệu lực 5 phút
- 🔍 Nếu test môi trường local, check console Spring Boot để xem OTP

**Xem OTP trong console:**
- Mở terminal đang chạy server
- Tìm dòng: `OTP for email test@example.com: 123456`

---

### ✅ TEST 4: VERIFY OTP - Xác thực mã OTP

**Request:**
```
POST http://localhost:8080/api/auth/verify-otp
```

**Body:**
```json
{
    "email": "test@example.com",
    "otp": "123456"
}
```

**Các bước:**
1. Lấy OTP từ email hoặc console
2. Thay `"123456"` bằng OTP thực tế
3. Click **"Send"**

**Expected Response:**
```json
{
    "success": true,
    "message": "Xác thực OTP thành công",
    "data": null
}
```

**Status Code:** `200 OK` ✅

**Test Cases:**
- ❌ OTP sai → `400 Bad Request: "OTP không hợp lệ"`
- ❌ OTP hết hạn → `400 Bad Request: "OTP đã hết hạn"`

---

### ✅ TEST 5: RESET PASSWORD - Đặt lại mật khẩu

**Request:**
```
POST http://localhost:8080/api/auth/reset-password
```

**Body:**
```json
{
    "email": "test@example.com",
    "otp": "123456",
    "newPassword": "NewPassword456"
}
```

**Các bước:**
1. Sử dụng email và OTP đã verify
2. Nhập mật khẩu mới
3. Click **"Send"**

**Expected Response:**
```json
{
    "success": true,
    "message": "Đặt lại mật khẩu thành công",
    "data": null
}
```

**Status Code:** `200 OK` ✅

**Verify reset password:**
- Quay lại **Login** request
- Đổi password thành `"NewPassword456"`
- Click Send → Phải login thành công ✅

---

### ✅ TEST 6: GOOGLE LOGIN

**Request:**
```
POST http://localhost:8080/api/auth/google-login
```

**Body:**
```json
{
    "token": "YOUR_GOOGLE_TOKEN_HERE"
}
```

**Lưu ý:**
- 🔑 Cần Google OAuth token thực
- 🌐 Dùng cho production, môi trường dev có thể skip
- ⚙️ Cấu hình Google Client ID/Secret trong application.properties

---

### ✅ TEST 7: LOGOUT - Đăng xuất

**Request:**
```
POST http://localhost:8080/auth/logout
Authorization: Bearer {{token}}
```

**Các bước:**
1. Click **"Logout"** trong sidebar
2. Đảm bảo đã login (có token)
3. Click **"Send"**

**Expected Response:**
```json
{
    "success": true,
    "message": "Đăng xuất thành công",
    "data": null
}
```

**Status Code:** `200 OK` ✅

---

## 🚗 PHẦN 2: CARS MANAGEMENT (7 APIs)

### ✅ TEST 8: GET ALL CARS - Xem tất cả xe (Public API)

**Chuyển sang folder Cars:**
1. Expand folder **"Cars"** trong sidebar
2. Click **"Get All Cars"**

**Request:**
```
GET http://localhost:8080/api/cars
```

**Các bước:**
1. Click **"Send"**
2. Không cần token (Public API)

**Expected Response:**
```json
{
    "success": true,
    "message": "Lấy danh sách xe thành công",
    "data": [
        {
            "carId": 1,
            "brandName": "Toyota",
            "modelName": "Camry 2024",
            "year": 2024,
            "color": "Trắng",
            "licensePlate": "30A-12345",
            "seatingCapacity": 5,
            "fuelType": "Xăng",
            "transmission": "Tự động",
            "dailyRate": 800000.00,
            "location": "Hà Nội",
            "status": "available",
            "features": "Camera, Cảm biến lùi",
            "description": "Xe mới 2024",
            "images": []
        }
    ]
}
```

**Status Code:** `200 OK` ✅

**Lưu ý:**
- Nếu database trống, data sẽ là array rỗng `[]`
- Cần thêm xe trước khi test các API khác

---

### ✅ TEST 9: GET CAR BY ID - Xem chi tiết xe

**Request:**
```
GET http://localhost:8080/api/cars/1
```

**Các bước:**
1. Click **"Get Car By ID"**
2. Đổi `1` thành ID xe có trong database
3. Click **"Send"**

**Expected Response:**
```json
{
    "success": true,
    "message": "Lấy thông tin xe thành công",
    "data": {
        "carId": 1,
        "brandName": "Toyota",
        "modelName": "Camry 2024",
        // ... chi tiết xe
    }
}
```

**Status Code:** `200 OK` ✅

**Test Case: ID không tồn tại**
- URL: `http://localhost:8080/api/cars/9999`
- Expected: `404 Not Found: "Không tìm thấy xe"`

---

### ✅ TEST 10: CREATE CAR - Thêm xe mới (Admin)

**Request:**
```
POST http://localhost:8080/api/cars
Authorization: Bearer {{token}}
```

**Body:**
```json
{
    "brandName": "Toyota",
    "modelName": "Vios 2024",
    "year": 2024,
    "color": "Trắng",
    "licensePlate": "30A-99999",
    "seatingCapacity": 5,
    "fuelType": "Xăng",
    "transmission": "Tự động",
    "dailyRate": 600000.00,
    "location": "Hà Nội",
    "features": "Camera lùi, Cảm biến va chạm, Bluetooth",
    "description": "Xe mới 100%, bảo dưỡng định kỳ",
    "status": "available"
}
```

**Các bước:**
1. Click **"Create Car"**
2. Đảm bảo đã login (có token)
3. Có thể sửa thông tin xe
4. Click **"Send"**

**Expected Response:**
```json
{
    "success": true,
    "message": "Tạo xe thành công",
    "data": {
        "carId": 2,
        "brandName": "Toyota",
        "modelName": "Vios 2024",
        // ... thông tin xe vừa tạo
    }
}
```

**Status Code:** `201 Created` ✅

**Validation Rules:**
- `year`: Phải từ 1900 đến hiện tại
- `seatingCapacity`: 2-50 chỗ
- `dailyRate`: > 0
- `licensePlate`: Phải unique

**Test Cases:**
```json
// ❌ Thiếu required field
{ "brandName": "Toyota" }
→ 400 Bad Request

// ❌ License plate trùng
{ "licensePlate": "30A-99999" }
→ 400 Bad Request: "Biển số xe đã tồn tại"

// ❌ Không có token
→ 401 Unauthorized
```

---

### ✅ TEST 11: UPDATE CAR - Cập nhật thông tin xe

**Request:**
```
PUT http://localhost:8080/api/cars/2
Authorization: Bearer {{token}}
```

**Body:**
```json
{
    "brandName": "Toyota",
    "modelName": "Vios 2024 Updated",
    "year": 2024,
    "color": "Đen",
    "licensePlate": "30A-99999",
    "seatingCapacity": 5,
    "fuelType": "Xăng",
    "transmission": "Tự động",
    "dailyRate": 650000.00,
    "location": "Hà Nội - Cầu Giấy",
    "features": "Camera 360, Cảm biến lùi, Màn hình cảm ứng",
    "description": "Xe đã cập nhật giá và thông tin",
    "status": "available"
}
```

**Các bước:**
1. Click **"Update Car"**
2. Đổi `2` thành ID xe vừa tạo
3. Sửa thông tin cần update
4. Click **"Send"**

**Expected Response:**
```json
{
    "success": true,
    "message": "Cập nhật xe thành công",
    "data": {
        "carId": 2,
        // ... thông tin đã update
    }
}
```

**Status Code:** `200 OK` ✅

---

### ✅ TEST 12: UPDATE CAR STATUS - Đổi trạng thái xe

**Request:**
```
PATCH http://localhost:8080/api/cars/2/status?status=rented
Authorization: Bearer {{token}}
```

**Các bước:**
1. Click **"Update Car Status"**
2. Đổi carId = `2`
3. Đổi query param `status` thành:
   - `available` - Xe có sẵn
   - `rented` - Đang cho thuê
   - `maintenance` - Bảo trì

**Expected Response:**
```json
{
    "success": true,
    "message": "Cập nhật trạng thái xe thành công",
    "data": {
        "carId": 2,
        "status": "rented",
        // ...
    }
}
```

**Status Code:** `200 OK` ✅

---

### ✅ TEST 13: DELETE CAR - Xóa xe

**Request:**
```
DELETE http://localhost:8080/api/cars/2
Authorization: Bearer {{token}}
```

**Các bước:**
1. Click **"Delete Car"**
2. Đổi ID xe cần xóa
3. Click **"Send"**

**Expected Response:**
```json
{
    "success": true,
    "message": "Xóa xe thành công",
    "data": null
}
```

**Status Code:** `200 OK` ✅

**Lưu ý:**
- ⚠️ Không thể xóa xe đang có booking active
- ⚠️ Soft delete - Xe vẫn còn trong DB nhưng không hiển thị

---

## 🔍 PHẦN 3: SEARCH & FILTER (2 APIs)

### ✅ TEST 14: SEARCH CARS - Tìm xe theo điều kiện

**Expand folder "Search":**
1. Click **"Search Cars"**

**Request:**
```
GET http://localhost:8080/api/search/cars?location=Hà Nội&startDate=2025-10-20T10:00:00&endDate=2025-10-25T10:00:00&minPrice=500000&maxPrice=1000000
```

**Query Parameters:**
- `location`: "Hà Nội" (required)
- `startDate`: "2025-10-20T10:00:00" (required)
- `endDate`: "2025-10-25T10:00:00" (required)
- `minPrice`: 500000 (optional)
- `maxPrice`: 1000000 (optional)

**Các bước:**
1. Trong Postman, chọn tab **"Params"**
2. Sửa giá trị các params:
   - location: Hà Nội
   - startDate: 2025-10-20T10:00:00
   - endDate: 2025-10-25T10:00:00
3. Click **"Send"**

**Expected Response:**
```json
{
    "success": true,
    "message": "Tìm kiếm xe thành công",
    "data": [
        {
            "carId": 1,
            "brandName": "Toyota",
            "isAvailable": true,
            // ... xe available trong khoảng thời gian
        }
    ]
}
```

**Status Code:** `200 OK` ✅

**Logic:**
- Chỉ trả về xe `status = available`
- Xe không bị booking trùng thời gian
- Trong khoảng giá (nếu có)

---

### ✅ TEST 15: FILTER CARS - Lọc xe theo tiêu chí

**Request:**
```
GET http://localhost:8080/api/search/filter?brandName=Toyota&fuelType=Xăng&transmission=Tự động&minSeating=5&maxSeating=7
```

**Query Parameters (tất cả optional):**
- `brandName`: "Toyota"
- `modelName`: "Vios"
- `fuelType`: "Xăng" / "Dầu" / "Điện" / "Hybrid"
- `transmission`: "Tự động" / "Số sàn"
- `minSeating`: 5
- `maxSeating`: 7
- `location`: "Hà Nội"

**Các bước:**
1. Click **"Filter Cars"**
2. Tab **"Params"**, sửa filter criteria
3. Click **"Send"**

**Expected Response:**
```json
{
    "success": true,
    "message": "Lọc xe thành công",
    "data": [
        // Xe khớp với tiêu chí
    ]
}
```

**Status Code:** `200 OK` ✅

---

## 📅 PHẦN 4: BOOKINGS (8 APIs)

### ✅ TEST 16: CREATE BOOKING - Tạo đơn đặt xe

**Expand folder "Bookings":**
1. Click **"Create Booking"**

**Request:**
```
POST http://localhost:8080/api/bookings
Authorization: Bearer {{token}}
```

**Body:**
```json
{
    "carId": 1,
    "customerId": 1,
    "rentalStartDate": "2025-10-20T10:00:00",
    "rentalEndDate": "2025-10-25T10:00:00",
    "pickupLocation": "Hà Nội - Cầu Giấy",
    "returnLocation": "Hà Nội - Cầu Giấy",
    "driverOption": false,
    "notes": "Cần xe sạch sẽ, đúng giờ"
}
```

**Các bước:**
1. Đảm bảo `carId` tồn tại (từ Get All Cars)
2. `customerId` = ID của user đã login
3. Chọn thời gian thuê xe
4. Click **"Send"**

**Expected Response:**
```json
{
    "success": true,
    "message": "Đặt xe thành công",
    "data": {
        "bookingId": 1,
        "carId": 1,
        "customerId": 1,
        "bookingDate": "2025-10-15T19:45:00",
        "rentalStartDate": "2025-10-20T10:00:00",
        "rentalEndDate": "2025-10-25T10:00:00",
        "totalAmount": 4000000.00,
        "status": "pending",
        "pickupLocation": "Hà Nội - Cầu Giấy",
        "returnLocation": "Hà Nội - Cầu Giấy",
        "driverOption": false
    }
}
```

**Status Code:** `201 Created` ✅

**Tính toán:**
- `totalAmount` = số ngày × `dailyRate`
- Số ngày = (endDate - startDate)
- VD: 5 ngày × 800,000 = 4,000,000 VNĐ

**Validation:**
- ✅ Xe phải available
- ✅ Không trùng booking khác
- ✅ startDate < endDate
- ✅ startDate >= hôm nay

---

### ✅ TEST 17: GET BOOKING BY ID

**Request:**
```
GET http://localhost:8080/api/bookings/1
Authorization: Bearer {{token}}
```

**Các bước:**
1. Click **"Get Booking By ID"**
2. Đổi `1` thành bookingId vừa tạo
3. Click **"Send"**

**Expected Response:**
```json
{
    "success": true,
    "message": "Lấy thông tin booking thành công",
    "data": {
        "bookingId": 1,
        // ... chi tiết booking
        "car": {
            // thông tin xe
        },
        "customer": {
            // thông tin khách hàng
        }
    }
}
```

**Status Code:** `200 OK` ✅

---

### ✅ TEST 18: UPDATE BOOKING - Cập nhật booking

**Request:**
```
PUT http://localhost:8080/api/bookings/1
Authorization: Bearer {{token}}
```

**Body:**
```json
{
    "rentalStartDate": "2025-10-21T10:00:00",
    "rentalEndDate": "2025-10-26T10:00:00",
    "pickupLocation": "Hà Nội - Hoàn Kiếm",
    "returnLocation": "Hà Nội - Hoàn Kiếm",
    "driverOption": true,
    "notes": "Cần thêm tài xế"
}
```

**Các bước:**
1. Click **"Update Booking"**
2. Chỉ update được khi `status = pending`
3. Sửa thông tin cần thay đổi
4. Click **"Send"**

**Expected Response:**
```json
{
    "success": true,
    "message": "Cập nhật booking thành công",
    "data": {
        "bookingId": 1,
        // ... thông tin đã update
        "totalAmount": 5200000.00
    }
}
```

**Status Code:** `200 OK` ✅

**Lưu ý:**
- ⚠️ Chỉ update được khi status = `pending`
- ⚠️ `totalAmount` tự động tính lại

---

### ✅ TEST 19: CONFIRM BOOKING - Xác nhận booking (Admin)

**Request:**
```
PATCH http://localhost:8080/api/bookings/1/confirm
Authorization: Bearer {{token}}
```

**Các bước:**
1. Click **"Confirm Booking"**
2. Click **"Send"**

**Expected Response:**
```json
{
    "success": true,
    "message": "Xác nhận booking thành công",
    "data": {
        "bookingId": 1,
        "status": "confirmed",
        // ...
    }
}
```

**Status Code:** `200 OK` ✅

**Status Flow:**
```
pending → confirmed → completed
         ↓
      cancelled
```

---

### ✅ TEST 20: COMPLETE BOOKING - Hoàn thành booking

**Request:**
```
PATCH http://localhost:8080/api/bookings/1/complete
Authorization: Bearer {{token}}
```

**Các bước:**
1. Click **"Complete Booking"**
2. Click **"Send"**

**Expected Response:**
```json
{
    "success": true,
    "message": "Hoàn thành booking thành công",
    "data": {
        "bookingId": 1,
        "status": "completed",
        // ...
    }
}
```

**Status Code:** `200 OK` ✅

---

### ✅ TEST 21: CANCEL BOOKING - Hủy booking

**Request:**
```
PATCH http://localhost:8080/api/bookings/1/cancel
Authorization: Bearer {{token}}
```

**Các bước:**
1. Click **"Cancel Booking"**
2. Click **"Send"**

**Expected Response:**
```json
{
    "success": true,
    "message": "Hủy booking thành công",
    "data": {
        "bookingId": 1,
        "status": "cancelled",
        // ...
    }
}
```

**Status Code:** `200 OK` ✅

---

### ✅ TEST 22: GET BOOKINGS BY CUSTOMER

**Request:**
```
GET http://localhost:8080/api/bookings/customer/1
Authorization: Bearer {{token}}
```

**Expected Response:**
```json
{
    "success": true,
    "message": "Lấy danh sách booking thành công",
    "data": [
        {
            "bookingId": 1,
            // ...
        },
        {
            "bookingId": 2,
            // ...
        }
    ]
}
```

**Status Code:** `200 OK` ✅

---

### ✅ TEST 23: GET BOOKINGS BY CAR

**Request:**
```
GET http://localhost:8080/api/bookings/car/1
Authorization: Bearer {{token}}
```

**Expected Response:**
```json
{
    "success": true,
    "message": "Lấy danh sách booking của xe thành công",
    "data": [
        // Tất cả booking của xe ID=1
    ]
}
```

**Status Code:** `200 OK` ✅

---

## 👤 PHẦN 5: PROFILE MANAGEMENT (3 APIs)

### ✅ TEST 24: GET PROFILE

**Expand folder "Profile":**

**Request:**
```
GET http://localhost:8080/profile
Authorization: Bearer {{token}}
```

**Expected Response:**
```json
{
    "success": true,
    "message": "Lấy thông tin profile thành công",
    "data": {
        "customerId": 1,
        "email": "test@example.com",
        "fullName": "Nguyen Van Test",
        "phoneNumber": "0987654321",
        "address": "123 Test Street, Hanoi",
        "dateOfBirth": "1990-01-01",
        "licenseNumber": "012345678",
        "role": "CUSTOMER"
    }
}
```

**Status Code:** `200 OK` ✅

---

### ✅ TEST 25: UPDATE PROFILE

**Request:**
```
PUT http://localhost:8080/profile
Authorization: Bearer {{token}}
```

**Body:**
```json
{
    "fullName": "Nguyen Van Updated",
    "phoneNumber": "0987654322",
    "address": "456 New Address, Hanoi",
    "dateOfBirth": "1990-01-01",
    "licenseNumber": "012345679"
}
```

**Expected Response:**
```json
{
    "success": true,
    "message": "Cập nhật profile thành công",
    "data": {
        // ... thông tin đã update
    }
}
```

**Status Code:** `200 OK` ✅

---

### ✅ TEST 26: CHANGE PASSWORD

**Request:**
```
PUT http://localhost:8080/profile/change-password
Authorization: Bearer {{token}}
```

**Body:**
```json
{
    "oldPassword": "NewPassword456",
    "newPassword": "SuperNewPassword789"
}
```

**Expected Response:**
```json
{
    "success": true,
    "message": "Đổi mật khẩu thành công",
    "data": null
}
```

**Status Code:** `200 OK` ✅

**Verify:**
- Logout
- Login với password mới
- Phải thành công ✅

---

## 📝 PHẦN 6: HISTORY & REVIEWS (3 APIs)

### ✅ TEST 27: GET CUSTOMER HISTORY

**Expand folder "History":**

**Request:**
```
GET http://localhost:8080/api/history/customer/1
Authorization: Bearer {{token}}
```

**Expected Response:**
```json
{
    "success": true,
    "message": "Lấy lịch sử thành công",
    "data": [
        {
            "historyId": 1,
            "bookingId": 1,
            "carId": 1,
            "customerId": 1,
            "rentalDate": "2025-10-20T10:00:00",
            "returnDate": "2025-10-25T10:00:00",
            "totalAmount": 4000000.00,
            "status": "completed"
        }
    ]
}
```

**Status Code:** `200 OK` ✅

---

### ✅ TEST 28: ADD REVIEW - Thêm đánh giá

**Request:**
```
POST http://localhost:8080/api/history/review
Authorization: Bearer {{token}}
```

**Body:**
```json
{
    "bookingId": 1,
    "rating": 5,
    "comment": "Xe rất tốt, sạch sẽ, chủ xe thân thiện! Sẽ thuê lại lần sau."
}
```

**Validation:**
- `rating`: 1-5 sao
- `comment`: Không bắt buộc
- Chỉ review được booking đã `completed`

**Expected Response:**
```json
{
    "success": true,
    "message": "Thêm đánh giá thành công",
    "data": {
        "reviewId": 1,
        "bookingId": 1,
        "rating": 5,
        "comment": "Xe rất tốt...",
        "reviewDate": "2025-10-15T19:50:00"
    }
}
```

**Status Code:** `201 Created` ✅

---

### ✅ TEST 29: GET CAR REVIEWS - Xem đánh giá của xe

**Request:**
```
GET http://localhost:8080/api/history/car/1/reviews
```

**Các bước:**
1. Click **"Get Car Reviews"**
2. Không cần token (Public API)
3. Click **"Send"**

**Expected Response:**
```json
{
    "success": true,
    "message": "Lấy danh sách đánh giá thành công",
    "data": [
        {
            "reviewId": 1,
            "customerName": "Nguyen Van Test",
            "rating": 5,
            "comment": "Xe rất tốt...",
            "reviewDate": "2025-10-15T19:50:00"
        }
    ]
}
```

**Status Code:** `200 OK` ✅

---

## ⭐ PHẦN 7: FAVORITES (3 APIs)

### ✅ TEST 30: GET USER FAVORITES

**Expand folder "Favorites":**

**Request:**
```
GET http://localhost:8080/api/favorites
Authorization: Bearer {{token}}
```

**Expected Response:**
```json
{
    "success": true,
    "message": "Lấy danh sách yêu thích thành công",
    "data": [
        {
            "favoriteId": 1,
            "carId": 1,
            "car": {
                // thông tin xe
            }
        }
    ]
}
```

**Status Code:** `200 OK` ✅

---

### ✅ TEST 31: ADD FAVORITE

**Request:**
```
POST http://localhost:8080/api/favorites/1
Authorization: Bearer {{token}}
```

**Các bước:**
1. Click **"Add Favorite"**
2. Đổi `1` thành carId muốn thêm
3. Click **"Send"**

**Expected Response:**
```json
{
    "success": true,
    "message": "Thêm vào danh sách yêu thích thành công",
    "data": {
        "favoriteId": 1,
        "carId": 1,
        "customerId": 1
    }
}
```

**Status Code:** `201 Created` ✅

---

### ✅ TEST 32: REMOVE FAVORITE

**Request:**
```
DELETE http://localhost:8080/api/favorites/1
Authorization: Bearer {{token}}
```

**Expected Response:**
```json
{
    "success": true,
    "message": "Xóa khỏi danh sách yêu thích thành công",
    "data": null
}
```

**Status Code:** `200 OK` ✅

---

## 📄 PHẦN 8: RENTAL CONTRACTS (2 APIs)

### ✅ TEST 33: CREATE CONTRACT

**Expand folder "Rental Contracts":**

**Request:**
```
POST http://localhost:8080/api/rental-contracts
Authorization: Bearer {{token}}
```

**Body:**
```json
{
    "bookingId": 1,
    "contractNumber": "HD2025001",
    "securityDeposit": 5000000.00,
    "terms": "1. Khách hàng phải trả xe đúng hạn\n2. Bồi thường nếu có hư hỏng\n3. Không sử dụng vào mục đích bất hợp pháp"
}
```

**Expected Response:**
```json
{
    "success": true,
    "message": "Tạo hợp đồng thành công",
    "data": {
        "contractId": 1,
        "bookingId": 1,
        "contractNumber": "HD2025001",
        "securityDeposit": 5000000.00,
        "terms": "1. Khách hàng...",
        "createdDate": "2025-10-15T19:55:00"
    }
}
```

**Status Code:** `201 Created` ✅

---

### ✅ TEST 34: GET CONTRACT BY BOOKING

**Request:**
```
GET http://localhost:8080/api/rental-contracts/booking/1
Authorization: Bearer {{token}}
```

**Expected Response:**
```json
{
    "success": true,
    "message": "Lấy thông tin hợp đồng thành công",
    "data": {
        "contractId": 1,
        // ... chi tiết hợp đồng
    }
}
```

**Status Code:** `200 OK` ✅

---

## 🚚 PHẦN 9: DELIVERY SCHEDULES (3 APIs)

### ✅ TEST 35: CREATE DELIVERY SCHEDULE

**Expand folder "Delivery Schedules":**

**Request:**
```
POST http://localhost:8080/api/delivery-schedules
Authorization: Bearer {{token}}
```

**Body:**
```json
{
    "bookingId": 1,
    "deliveryType": "pickup",
    "scheduledTime": "2025-10-20T09:00:00",
    "deliveryAddress": "123 Nguyen Trai, Thanh Xuan, Hanoi",
    "driverName": "Nguyen Van Driver",
    "driverPhone": "0912345678"
}
```

**deliveryType:**
- `pickup` - Giao xe cho khách
- `return` - Nhận xe trả lại

**Expected Response:**
```json
{
    "success": true,
    "message": "Tạo lịch giao xe thành công",
    "data": {
        "scheduleId": 1,
        "bookingId": 1,
        "deliveryType": "pickup",
        "scheduledTime": "2025-10-20T09:00:00",
        "deliveryAddress": "123 Nguyen Trai...",
        "driverName": "Nguyen Van Driver",
        "driverPhone": "0912345678",
        "status": "scheduled"
    }
}
```

**Status Code:** `201 Created` ✅

---

### ✅ TEST 36: GET DELIVERY BY BOOKING

**Request:**
```
GET http://localhost:8080/api/delivery-schedules/booking/1
Authorization: Bearer {{token}}
```

**Expected Response:**
```json
{
    "success": true,
    "message": "Lấy lịch giao xe thành công",
    "data": [
        {
            "scheduleId": 1,
            "deliveryType": "pickup",
            // ...
        },
        {
            "scheduleId": 2,
            "deliveryType": "return",
            // ...
        }
    ]
}
```

**Status Code:** `200 OK` ✅

---

### ✅ TEST 37: UPDATE DELIVERY STATUS

**Request:**
```
PATCH http://localhost:8080/api/delivery-schedules/1/status?status=completed
Authorization: Bearer {{token}}
```

**Query param `status`:**
- `scheduled` - Đã lên lịch
- `in_progress` - Đang giao
- `completed` - Hoàn thành
- `cancelled` - Đã hủy

**Expected Response:**
```json
{
    "success": true,
    "message": "Cập nhật trạng thái giao xe thành công",
    "data": {
        "scheduleId": 1,
        "status": "completed",
        // ...
    }
}
```

**Status Code:** `200 OK` ✅

---

## 👥 PHẦN 10: GROUP BOOKINGS (2 APIs)

### ✅ TEST 38: CREATE GROUP BOOKING

**Expand folder "Group Bookings":**

**Request:**
```
POST http://localhost:8080/api/group-bookings
Authorization: Bearer {{token}}
```

**Body:**
```json
{
    "groupName": "Tour Đà Lạt 2025 - Team ABC",
    "organizerId": 1,
    "totalCars": 3,
    "startDate": "2025-11-01T08:00:00",
    "endDate": "2025-11-05T18:00:00",
    "notes": "Cần 3 xe 7 chỗ cho tour công ty, tài xế giỏi"
}
```

**Expected Response:**
```json
{
    "success": true,
    "message": "Tạo booking nhóm thành công",
    "data": {
        "groupId": 1,
        "groupName": "Tour Đà Lạt 2025 - Team ABC",
        "organizerId": 1,
        "totalCars": 3,
        "startDate": "2025-11-01T08:00:00",
        "endDate": "2025-11-05T18:00:00",
        "status": "pending",
        "notes": "Cần 3 xe..."
    }
}
```

**Status Code:** `201 Created` ✅

---

### ✅ TEST 39: GET GROUP BOOKING

**Request:**
```
GET http://localhost:8080/api/group-bookings/1
Authorization: Bearer {{token}}
```

**Expected Response:**
```json
{
    "success": true,
    "message": "Lấy thông tin booking nhóm thành công",
    "data": {
        "groupId": 1,
        "groupName": "Tour Đà Lạt 2025 - Team ABC",
        // ... chi tiết
        "bookings": [
            // Danh sách các booking trong group
        ]
    }
}
```

**Status Code:** `200 OK` ✅

---

## ✔️ PHẦN 11: VALIDATION (1 API)

### ✅ TEST 40: CHECK EMAIL EXISTS

**Expand folder "Validation":**

**Request:**
```
GET http://localhost:8080/api/validation/email-exists?email=test@example.com
```

**Các bước:**
1. Click **"Check Email Exists"**
2. Sửa query param `email`
3. Click **"Send"**

**Expected Response:**
```json
{
    "success": true,
    "message": "Email đã tồn tại",
    "data": true
}
```

hoặc

```json
{
    "success": true,
    "message": "Email chưa tồn tại",
    "data": false
}
```

**Status Code:** `200 OK` ✅

---

## 🎯 SUMMARY - TỔNG KẾT

### ✅ APIS ĐÃ TEST: 40/40

#### Authentication: 7 APIs
- [x] Register
- [x] Login
- [x] Forgot Password
- [x] Verify OTP
- [x] Reset Password
- [x] Google Login
- [x] Logout

#### Cars: 7 APIs
- [x] Get All Cars
- [x] Get Car By ID
- [x] Create Car
- [x] Update Car
- [x] Delete Car
- [x] Update Car Status

#### Search: 2 APIs
- [x] Search Cars
- [x] Filter Cars

#### Bookings: 8 APIs
- [x] Create Booking
- [x] Get Booking By ID
- [x] Update Booking
- [x] Cancel Booking
- [x] Confirm Booking
- [x] Complete Booking
- [x] Get Bookings By Customer
- [x] Get Bookings By Car

#### Profile: 3 APIs
- [x] Get Profile
- [x] Update Profile
- [x] Change Password

#### History: 3 APIs
- [x] Get Customer History
- [x] Add Review
- [x] Get Car Reviews

#### Favorites: 3 APIs
- [x] Get User Favorites
- [x] Add Favorite
- [x] Remove Favorite

#### Rental Contracts: 2 APIs
- [x] Create Contract
- [x] Get Contract By Booking

#### Delivery Schedules: 3 APIs
- [x] Create Delivery Schedule
- [x] Get Delivery By Booking
- [x] Update Delivery Status

#### Group Bookings: 2 APIs
- [x] Create Group Booking
- [x] Get Group Booking

#### Validation: 1 API
- [x] Check Email Exists

---

## 🎉 HOÀN THÀNH!

Bạn đã test xong tất cả 40 APIs của hệ thống DriveNow! 🚀

### Next Steps:
1. ✅ Export Collection để backup
2. ✅ Tạo Environment cho Production
3. ✅ Setup Automated Tests
4. ✅ Write API Documentation

**Chúc mừng bạn!** 🎊
