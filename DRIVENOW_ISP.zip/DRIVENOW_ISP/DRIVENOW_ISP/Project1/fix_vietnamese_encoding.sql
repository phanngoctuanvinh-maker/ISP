-- ========================================
-- SCRIPT SỬA KIỂU DỮ LIỆU TIẾNG VIỆT
-- Chuyển từ VARCHAR sang NVARCHAR
-- ========================================

USE drivenow_db;
GO

-- Backup dữ liệu hiện tại vào bảng tạm (nếu cần)
-- SELECT * INTO cars_backup FROM cars;

-- ========================================
-- 1. SỬA CẤU TRÚC BẢNG CARS
-- ========================================

PRINT 'Bắt đầu sửa kiểu dữ liệu bảng cars...';

-- Sửa các cột text sang NVARCHAR để hỗ trợ tiếng Việt
ALTER TABLE cars ALTER COLUMN brand NVARCHAR(50);
ALTER TABLE cars ALTER COLUMN model NVARCHAR(50);
ALTER TABLE cars ALTER COLUMN name NVARCHAR(100);
ALTER TABLE cars ALTER COLUMN color NVARCHAR(50);
ALTER TABLE cars ALTER COLUMN car_type NVARCHAR(50);
ALTER TABLE cars ALTER COLUMN fuel_type NVARCHAR(50);
ALTER TABLE cars ALTER COLUMN transmission_type NVARCHAR(50);
ALTER TABLE cars ALTER COLUMN description NVARCHAR(MAX);
ALTER TABLE cars ALTER COLUMN image_url NVARCHAR(500);
ALTER TABLE cars ALTER COLUMN status NVARCHAR(50);
ALTER TABLE cars ALTER COLUMN license_plate NVARCHAR(50);
ALTER TABLE cars ALTER COLUMN insurance_info NVARCHAR(500);
ALTER TABLE cars ALTER COLUMN location NVARCHAR(200);

PRINT '✅ Đã sửa xong kiểu dữ liệu bảng cars!';
GO

-- ========================================
-- 2. XÓA DỮ LIỆU CŨ VÀ THÊM DỮ LIỆU MỚI TIẾNG VIỆT
-- ========================================

DELETE FROM cars;
PRINT 'Đã xóa dữ liệu cũ';
GO

-- ========================================
-- THÊM 30 XE VỚI TIẾNG VIỆT CHUẨN
-- ========================================

-- Toyota (6 xe)
INSERT INTO cars (brand, model, name, year, color, seat_capacity, fuel_type, transmission_type, daily_rate, price_per_day, description, mileage, image_url, status, license_plate, insurance_info, location, car_type, created_at, updated_at)
VALUES 
(N'Toyota', N'Vios', N'Toyota Vios 2024 - Trắng', 2024, N'Trắng', 4, N'Xăng', N'Tự động', 450000, 450000, N'Sedan tiết kiệm nhiên liệu, phù hợp đi phố và công việc hàng ngày', 15000, N'https://example.com/vios-white.jpg', N'Có sẵn', N'30A-10001', N'Bảo hiểm vật chất và trách nhiệm dân sự', N'Hà Nội', N'Sedan', GETDATE(), GETDATE()),

(N'Toyota', N'Vios', N'Toyota Vios 2024 - Đen', 2024, N'Đen', 4, N'Xăng', N'Tự động', 450000, 450000, N'Sedan tiết kiệm nhiên liệu, thiết kế sang trọng', 12000, N'https://example.com/vios-black.jpg', N'Có sẵn', N'30A-10002', N'Bảo hiểm vật chất và trách nhiệm dân sự', N'Hà Nội', N'Sedan', GETDATE(), GETDATE()),

(N'Toyota', N'Camry', N'Toyota Camry 2024', 2024, N'Trắng ngọc trai', 5, N'Xăng', N'Tự động', 750000, 750000, N'Sedan hạng D cao cấp, êm ái, sang trọng, động cơ mạnh mẽ', 8000, N'https://example.com/camry.jpg', N'Có sẵn', N'30A-20001', N'Bảo hiểm toàn diện cao cấp', N'Hà Nội', N'Sedan', GETDATE(), GETDATE()),

(N'Toyota', N'Fortuner', N'Toyota Fortuner 2024', 2024, N'Bạc', 7, N'Dầu diesel', N'Tự động', 900000, 900000, N'SUV 7 chỗ mạnh mẽ, phù hợp đi xa và địa hình khó', 12000, N'https://example.com/fortuner.jpg', N'Có sẵn', N'30A-20002', N'Bảo hiểm vật chất và trách nhiệm dân sự', N'Hà Nội', N'SUV', GETDATE(), GETDATE()),

(N'Toyota', N'Innova', N'Toyota Innova 2024', 2024, N'Xám', 7, N'Xăng', N'Số sàn', 550000, 550000, N'MPV 7 chỗ phổ biến, rộng rãi, phù hợp gia đình', 20000, N'https://example.com/innova.jpg', N'Có sẵn', N'30A-20003', N'Bảo hiểm vật chất và trách nhiệm dân sự', N'Hà Nội', N'MPV', GETDATE(), GETDATE()),

(N'Toyota', N'Corolla Cross', N'Toyota Corolla Cross 2024', 2024, N'Đen', 5, N'Xăng', N'Tự động', 650000, 650000, N'SUV 5 chỗ năng động, gầm cao, tiện nghi hiện đại', 8000, N'https://example.com/cross.jpg', N'Có sẵn', N'30A-20004', N'Bảo hiểm vật chất và trách nhiệm dân sự', N'Hà Nội', N'SUV', GETDATE(), GETDATE());

-- Honda (5 xe)
INSERT INTO cars (brand, model, name, year, color, seat_capacity, fuel_type, transmission_type, daily_rate, price_per_day, description, mileage, image_url, status, license_plate, insurance_info, location, car_type, created_at, updated_at)
VALUES 
(N'Honda', N'City', N'Honda City 2024 - Trắng', 2024, N'Trắng', 4, N'Xăng', N'Tự động', 480000, 480000, N'Sedan trẻ trung, năng động, tiết kiệm nhiên liệu', 10000, N'https://example.com/city-white.jpg', N'Có sẵn', N'30B-10001', N'Bảo hiểm vật chất và trách nhiệm dân sự', N'Hà Nội', N'Sedan', GETDATE(), GETDATE()),

(N'Honda', N'City', N'Honda City 2024 - Đỏ', 2024, N'Đỏ', 4, N'Xăng', N'Tự động', 480000, 480000, N'Sedan trẻ trung, năng động, thiết kế thể thao', 9000, N'https://example.com/city-red.jpg', N'Có sẵn', N'30B-10002', N'Bảo hiểm vật chất và trách nhiệm dân sự', N'Hà Nội', N'Sedan', GETDATE(), GETDATE()),

(N'Honda', N'Civic', N'Honda Civic 2024', 2024, N'Xanh dương', 5, N'Xăng', N'Tự động', 680000, 680000, N'Sedan thể thao, thiết kế trẻ trung, công nghệ hiện đại', 5000, N'https://example.com/civic.jpg', N'Có sẵn', N'30B-20001', N'Bảo hiểm vật chất và trách nhiệm dân sự', N'Hà Nội', N'Sedan', GETDATE(), GETDATE()),

(N'Honda', N'CR-V', N'Honda CR-V 2024', 2024, N'Trắng', 5, N'Xăng', N'Tự động', 750000, 750000, N'SUV 5 chỗ sang trọng, tiện nghi đầy đủ', 7000, N'https://example.com/crv.jpg', N'Có sẵn', N'30B-20002', N'Bảo hiểm vật chất và trách nhiệm dân sự', N'Hà Nội', N'SUV', GETDATE(), GETDATE()),

(N'Honda', N'BR-V', N'Honda BR-V 2024', 2024, N'Xám', 7, N'Xăng', N'Tự động', 600000, 600000, N'SUV 7 chỗ linh hoạt, gầm cao, phù hợp gia đình', 15000, N'https://example.com/brv.jpg', N'Có sẵn', N'30B-20003', N'Bảo hiểm vật chất và trách nhiệm dân sự', N'Hà Nội', N'SUV', GETDATE(), GETDATE());

-- Mazda (5 xe)
INSERT INTO cars (brand, model, name, year, color, seat_capacity, fuel_type, transmission_type, daily_rate, price_per_day, description, mileage, image_url, status, license_plate, insurance_info, location, car_type, created_at, updated_at)
VALUES 
(N'Mazda', N'2', N'Mazda 2 2024', 2024, N'Bạc', 4, N'Xăng', N'Tự động', 420000, 420000, N'Hatchback nhỏ gọn, tiện lợi đi phố', 12000, N'https://example.com/mazda2.jpg', N'Có sẵn', N'30C-10001', N'Bảo hiểm vật chất và trách nhiệm dân sự', N'Hà Nội', N'Hatchback', GETDATE(), GETDATE()),

(N'Mazda', N'3', N'Mazda 3 2024', 2024, N'Đỏ pha lê', 4, N'Xăng', N'Tự động', 520000, 520000, N'Sedan thể thao, thiết kế đẹp mắt, công nghệ Skyactiv', 8000, N'https://example.com/mazda3.jpg', N'Có sẵn', N'30C-20001', N'Bảo hiểm vật chất và trách nhiệm dân sự', N'Hà Nội', N'Sedan', GETDATE(), GETDATE()),

(N'Mazda', N'CX-5', N'Mazda CX-5 2024 - Đỏ', 2024, N'Đỏ pha lê', 5, N'Xăng', N'Tự động', 700000, 700000, N'SUV 5 chỗ cao cấp, thiết kế sang trọng', 10000, N'https://example.com/cx5-red.jpg', N'Có sẵn', N'30C-30001', N'Bảo hiểm vật chất và trách nhiệm dân sự', N'Hà Nội', N'SUV', GETDATE(), GETDATE()),

(N'Mazda', N'CX-5', N'Mazda CX-5 2024 - Trắng', 2024, N'Trắng', 5, N'Xăng', N'Tự động', 700000, 700000, N'SUV 5 chỗ cao cấp, tiện nghi hiện đại', 9000, N'https://example.com/cx5-white.jpg', N'Có sẵn', N'30C-30002', N'Bảo hiểm vật chất và trách nhiệm dân sự', N'Hà Nội', N'SUV', GETDATE(), GETDATE()),

(N'Mazda', N'CX-8', N'Mazda CX-8 2024', 2024, N'Xanh dương', 7, N'Dầu diesel', N'Tự động', 950000, 950000, N'SUV 7 chỗ cao cấp nhất, nội thất sang trọng', 6000, N'https://example.com/cx8.jpg', N'Có sẵn', N'30C-40001', N'Bảo hiểm toàn diện cao cấp', N'Hà Nội', N'SUV', GETDATE(), GETDATE());

-- Ford (3 xe)
INSERT INTO cars (brand, model, name, year, color, seat_capacity, fuel_type, transmission_type, daily_rate, price_per_day, description, mileage, image_url, status, license_plate, insurance_info, location, car_type, created_at, updated_at)
VALUES 
(N'Ford', N'Ranger', N'Ford Ranger 2024', 2024, N'Cam', 4, N'Dầu diesel', N'Số sàn', 800000, 800000, N'Bán tải mạnh mẽ, phù hợp địa hình khó, chở hàng', 18000, N'https://example.com/ranger.jpg', N'Có sẵn', N'30D-10001', N'Bảo hiểm vật chất và trách nhiệm dân sự', N'Hà Nội', N'Bán tải', GETDATE(), GETDATE()),

(N'Ford', N'Everest', N'Ford Everest 2024', 2024, N'Đen', 7, N'Dầu diesel', N'Tự động', 1000000, 1000000, N'SUV 7 chỗ địa hình cao cấp, khả năng vượt trội', 9000, N'https://example.com/everest.jpg', N'Có sẵn', N'30D-20001', N'Bảo hiểm toàn diện cao cấp', N'Hà Nội', N'SUV', GETDATE(), GETDATE()),

(N'Ford', N'Territory', N'Ford Territory 2024', 2024, N'Xanh lá', 5, N'Xăng', N'Tự động', 650000, 650000, N'SUV 5 chỗ hiện đại, công nghệ thông minh', 7000, N'https://example.com/territory.jpg', N'Có sẵn', N'30D-30001', N'Bảo hiểm vật chất và trách nhiệm dân sự', N'Hà Nội', N'SUV', GETDATE(), GETDATE());

-- Kia (3 xe)
INSERT INTO cars (brand, model, name, year, color, seat_capacity, fuel_type, transmission_type, daily_rate, price_per_day, description, mileage, image_url, status, license_plate, insurance_info, location, car_type, created_at, updated_at)
VALUES 
(N'Kia', N'Seltos', N'Kia Seltos 2024', 2024, N'Cam đồng', 5, N'Xăng', N'Tự động', 580000, 580000, N'SUV 5 chỗ trẻ trung, năng động, giá hợp lý', 11000, N'https://example.com/seltos.jpg', N'Có sẵn', N'30E-10001', N'Bảo hiểm vật chất và trách nhiệm dân sự', N'Hà Nội', N'SUV', GETDATE(), GETDATE()),

(N'Kia', N'Sorento', N'Kia Sorento 2024', 2024, N'Nâu', 7, N'Dầu diesel', N'Tự động', 880000, 880000, N'SUV 7 chỗ sang trọng, tiện nghi cao cấp', 8000, N'https://example.com/sorento.jpg', N'Có sẵn', N'30E-20001', N'Bảo hiểm vật chất và trách nhiệm dân sự', N'Hà Nội', N'SUV', GETDATE(), GETDATE()),

(N'Kia', N'Carnival', N'Kia Carnival 2024', 2024, N'Trắng', 7, N'Dầu diesel', N'Tự động', 1200000, 1200000, N'Minivan hạng sang 7-9 chỗ, không gian rộng rãi', 5000, N'https://example.com/carnival.jpg', N'Có sẵn', N'30E-30001', N'Bảo hiểm toàn diện VIP', N'Hà Nội', N'Minivan', GETDATE(), GETDATE());

-- Hyundai (4 xe)
INSERT INTO cars (brand, model, name, year, color, seat_capacity, fuel_type, transmission_type, daily_rate, price_per_day, description, mileage, image_url, status, license_plate, insurance_info, location, car_type, created_at, updated_at)
VALUES 
(N'Hyundai', N'Accent', N'Hyundai Accent 2024', 2024, N'Trắng', 4, N'Xăng', N'Tự động', 440000, 440000, N'Sedan phổ thông, tiết kiệm, phù hợp mọi nhu cầu', 14000, N'https://example.com/accent.jpg', N'Có sẵn', N'30F-10001', N'Bảo hiểm vật chất và trách nhiệm dân sự', N'Hà Nội', N'Sedan', GETDATE(), GETDATE()),

(N'Hyundai', N'Tucson', N'Hyundai Tucson 2024', 2024, N'Xám', 5, N'Xăng', N'Tự động', 720000, 720000, N'SUV 5 chỗ thông minh, công nghệ hiện đại', 9000, N'https://example.com/tucson.jpg', N'Có sẵn', N'30F-20001', N'Bảo hiểm vật chất và trách nhiệm dân sự', N'Hà Nội', N'SUV', GETDATE(), GETDATE()),

(N'Hyundai', N'Santa Fe', N'Hyundai Santa Fe 2024', 2024, N'Đen', 7, N'Dầu diesel', N'Tự động', 920000, 920000, N'SUV 7 chỗ cao cấp, an toàn tối đa', 7000, N'https://example.com/santafe.jpg', N'Có sẵn', N'30F-30001', N'Bảo hiểm toàn diện cao cấp', N'Hà Nội', N'SUV', GETDATE(), GETDATE()),

(N'Hyundai', N'Stargazer', N'Hyundai Stargazer 2024', 2024, N'Bạc', 7, N'Xăng', N'Tự động', 500000, 500000, N'MPV 7 chỗ giá tốt, không gian linh hoạt', 10000, N'https://example.com/stargazer.jpg', N'Có sẵn', N'30F-40001', N'Bảo hiểm vật chất và trách nhiệm dân sự', N'Hà Nội', N'MPV', GETDATE(), GETDATE());

-- Vinfast (3 xe điện)
INSERT INTO cars (brand, model, name, year, color, seat_capacity, fuel_type, transmission_type, daily_rate, price_per_day, description, mileage, image_url, status, license_plate, insurance_info, location, car_type, created_at, updated_at)
VALUES 
(N'VinFast', N'VF5', N'VinFast VF5 Plus 2024', 2024, N'Xanh lá', 5, N'Điện', N'Tự động', 550000, 550000, N'SUV điện 5 chỗ nhỏ gọn, tầm hoạt động 300km, thân thiện môi trường', 3000, N'https://example.com/vf5.jpg', N'Có sẵn', N'30G-10001', N'Bảo hiểm + Sạc điện miễn phí', N'Hà Nội', N'SUV điện', GETDATE(), GETDATE()),

(N'VinFast', N'VF8', N'VinFast VF8 2024', 2024, N'Xanh dương', 5, N'Điện', N'Tự động', 900000, 900000, N'SUV điện 5 chỗ cao cấp, tầm hoạt động 400km, công nghệ thông minh', 2000, N'https://example.com/vf8.jpg', N'Có sẵn', N'30G-20001', N'Bảo hiểm + Sạc điện 24/7', N'Hà Nội', N'SUV điện', GETDATE(), GETDATE()),

(N'VinFast', N'VF9', N'VinFast VF9 2024', 2024, N'Đen', 7, N'Điện', N'Tự động', 1500000, 1500000, N'SUV điện 7 chỗ hạng sang, tầm hoạt động 600km, nội thất cao cấp', 1000, N'https://example.com/vf9.jpg', N'Có sẵn', N'30G-30001', N'Bảo hiểm VIP + Sạc tại nhà', N'Hà Nội', N'SUV điện', GETDATE(), GETDATE());

-- Mitsubishi (1 xe hybrid)
INSERT INTO cars (brand, model, name, year, color, seat_capacity, fuel_type, transmission_type, daily_rate, price_per_day, description, mileage, image_url, status, license_plate, insurance_info, location, car_type, created_at, updated_at)
VALUES 
(N'Mitsubishi', N'Outlander', N'Mitsubishi Outlander PHEV 2024', 2024, N'Đỏ', 7, N'Hybrid (Xăng + Điện)', N'Tự động', 1100000, 1100000, N'SUV 7 chỗ hybrid tiết kiệm nhiên liệu, thân thiện môi trường', 6000, N'https://example.com/outlander.jpg', N'Có sẵn', N'30H-10001', N'Bảo hiểm toàn diện cao cấp', N'Hà Nội', N'SUV', GETDATE(), GETDATE());

GO

-- ========================================
-- THỐNG KÊ KẾT QUẢ
-- ========================================

PRINT '';
PRINT '========================================';
PRINT 'KẾT QUẢ THÊM XE VỚI TIẾNG VIỆT';
PRINT '========================================';
PRINT '';

SELECT COUNT(*) as N'Tổng số xe' FROM cars;
PRINT '';

SELECT brand as N'Hãng xe', COUNT(*) as N'Số lượng' 
FROM cars 
GROUP BY brand 
ORDER BY COUNT(*) DESC;
PRINT '';

SELECT fuel_type as N'Nhiên liệu', COUNT(*) as N'Số lượng' 
FROM cars 
GROUP BY fuel_type;
PRINT '';

SELECT seat_capacity as N'Số chỗ ngồi', COUNT(*) as N'Số lượng' 
FROM cars 
GROUP BY seat_capacity 
ORDER BY seat_capacity;
PRINT '';

PRINT '✅ HOÀN THÀNH! Đã sửa kiểu dữ liệu và thêm 30 xe tiếng Việt';
PRINT '';
PRINT 'Bước tiếp theo:';
PRINT '1. Restart Spring Boot backend';
PRINT '2. Test API: http://localhost:8080/api/cars/all';
PRINT '3. Mở DriveNow/html/searchcar.html để kiểm tra';
PRINT '';

GO
