-- SỬA LỖI ENCODING CHO FUEL_TYPE VÀ CÁC CỘT TIẾNG VIỆT

-- Bước 1: Đổi collation của các cột text sang Vietnamese_CI_AS
ALTER TABLE cars 
ALTER COLUMN fuel_type NVARCHAR(50) COLLATE Vietnamese_CI_AS;

ALTER TABLE cars 
ALTER COLUMN transmission_type NVARCHAR(50) COLLATE Vietnamese_CI_AS;

ALTER TABLE cars 
ALTER COLUMN status NVARCHAR(50) COLLATE Vietnamese_CI_AS;

PRINT N'✅ Đã đổi collation sang Vietnamese_CI_AS';

-- Bước 2: Xóa dữ liệu VinFast cũ bị lỗi encoding
DELETE FROM cars WHERE brand = N'VinFast';

PRINT N'✅ Đã xóa VinFast cũ';

-- Bước 3: Insert lại VinFast với encoding đúng
INSERT INTO cars (brand, model, name, year, color, car_type, seat_capacity, fuel_type, transmission_type, daily_rate, price_per_day, description, mileage, image_url, status, license_plate, insurance_info, location, created_at, updated_at)
VALUES 
(N'VinFast', N'VF5', N'VinFast VF5 Plus 2024', 2024, N'Xanh lá', N'SUV', 5, N'Điện', N'Tự động', 550000, 550000.00, N'SUV điện 5 chỗ nhỏ gọn, tầm hoạt động 300km', 3000, N'https://images.unsplash.com/photo-1593941707882-a5bba14938c7?w=800', N'Có sẵn', N'30G-10001', N'Bảo hiểm + Sạc điện miễn phí', N'Hà Nội', GETDATE(), GETDATE()),

(N'VinFast', N'VF8', N'VinFast VF8 2024', 2024, N'Xanh dương', N'SUV', 5, N'Điện', N'Tự động', 900000, 900000.00, N'SUV điện 5 chỗ cao cấp, tầm hoạt động 400km', 2000, N'https://images.unsplash.com/photo-1617469767053-d3b523a0b982?w=800', N'Có sẵn', N'30G-20001', N'Bảo hiểm + Sạc điện 24/7', N'Hà Nội', GETDATE(), GETDATE()),

(N'VinFast', N'VF9', N'VinFast VF9 2024', 2024, N'Đen', N'SUV', 7, N'Điện', N'Tự động', 1500000, 1500000.00, N'SUV điện 7 chỗ hạng sang, tầm hoạt động 600km', 1000, N'https://images.unsplash.com/photo-1609521263047-f8f205293f24?w=800', N'Có sẵn', N'30G-30001', N'Bảo hiểm VIP + Sạc tại nhà', N'Hà Nội', GETDATE(), GETDATE());

PRINT N'✅ Đã insert lại 3 xe VinFast';

-- Bước 4: Kiểm tra kết quả
SELECT id, brand, name, fuel_type, 
       UNICODE(SUBSTRING(fuel_type, 1, 1)) as first_char_code,
       LEN(fuel_type) as length
FROM cars 
WHERE brand = N'VinFast';

PRINT N'';
PRINT N'📋 Unicode code phải là:';
PRINT N'   - Đ = 272 (SAI - Latin D with stroke)';  
PRINT N'   - Đ = 208 (SAI - Cyrillic D)';
PRINT N'   - Đ = 272 (SAI)';
PRINT N'   - Đ = 272 (ĐÚNG nếu dùng CP1258 Vietnamese)';
PRINT N'';
PRINT N'Nếu vẫn thấy 272, có thể cần thay bằng chu''oi "Dien" tạm thời';
