-- ===================================================================
-- THÊM COLUMNS CHO ADVANCED FILTER
-- Chạy script này để thêm các trường cần thiết cho bộ lọc nâng cao
-- ===================================================================

USE drivenow_db;
GO

-- Kiểm tra và thêm column daily_km_limit (nếu chưa có)
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS 
               WHERE TABLE_NAME = 'cars' AND COLUMN_NAME = 'daily_km_limit')
BEGIN
    ALTER TABLE cars ADD daily_km_limit INT NULL;
    PRINT '✅ Đã thêm column: daily_km_limit';
END
ELSE
BEGIN
    PRINT 'ℹ️  Column daily_km_limit đã tồn tại';
END
GO

-- Kiểm tra và thêm column exceed_fee_per_km (nếu chưa có)
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS 
               WHERE TABLE_NAME = 'cars' AND COLUMN_NAME = 'exceed_fee_per_km')
BEGIN
    ALTER TABLE cars ADD exceed_fee_per_km INT NULL;
    PRINT '✅ Đã thêm column: exceed_fee_per_km';
END
ELSE
BEGIN
    PRINT 'ℹ️  Column exceed_fee_per_km đã tồn tại';
END
GO

-- Kiểm tra và thêm column fuel_consumption (nếu chưa có)
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS 
               WHERE TABLE_NAME = 'cars' AND COLUMN_NAME = 'fuel_consumption')
BEGIN
    ALTER TABLE cars ADD fuel_consumption DECIMAL(5,2) NULL;
    PRINT '✅ Đã thêm column: fuel_consumption';
END
ELSE
BEGIN
    PRINT 'ℹ️  Column fuel_consumption đã tồn tại';
END
GO

-- ===================================================================
-- CẬP NHẬT DỮ LIỆU MẪU CHO ADVANCED FILTER
-- ===================================================================

-- Update Toyota (ID 1-6): Xe phổ thông, giới hạn 300km/ngày, phí vượt 3000đ/km
UPDATE cars 
SET daily_km_limit = 300,
    exceed_fee_per_km = 3000,
    fuel_consumption = CASE 
        WHEN id = 1 THEN 6.5  -- Vios
        WHEN id = 2 THEN 7.2  -- Camry
        WHEN id = 3 THEN 7.8  -- Fortuner
        WHEN id = 4 THEN 6.8  -- Corolla Cross
        WHEN id = 5 THEN 9.5  -- Land Cruiser
        WHEN id = 6 THEN 6.9  -- Veloz Cross
        ELSE 7.5
    END
WHERE brand = N'Toyota' AND id BETWEEN 1 AND 6;

PRINT '✅ Đã update dữ liệu Toyota (6 xe)';
GO

-- Update Honda (ID 7-12): Xe tiết kiệm, giới hạn 350km/ngày, phí vượt 2500đ/km
UPDATE cars 
SET daily_km_limit = 350,
    exceed_fee_per_km = 2500,
    fuel_consumption = CASE 
        WHEN id = 7 THEN 5.8   -- City
        WHEN id = 8 THEN 6.5   -- Civic
        WHEN id = 9 THEN 8.2   -- CR-V
        WHEN id = 10 THEN 7.0  -- Accord
        WHEN id = 11 THEN 6.3  -- HR-V
        WHEN id = 12 THEN 7.5  -- Brio
        ELSE 6.8
    END
WHERE brand = N'Honda' AND id BETWEEN 7 AND 12;

PRINT '✅ Đã update dữ liệu Honda (6 xe)';
GO

-- Update Mazda (ID 13-17): Xe cao cấp, giới hạn 400km/ngày, phí vượt 4000đ/km
UPDATE cars 
SET daily_km_limit = 400,
    exceed_fee_per_km = 4000,
    fuel_consumption = CASE 
        WHEN id = 13 THEN 6.2  -- Mazda3
        WHEN id = 14 THEN 6.8  -- Mazda6
        WHEN id = 15 THEN 8.0  -- CX-5
        WHEN id = 16 THEN 9.2  -- CX-8
        WHEN id = 17 THEN 7.5  -- CX-30
        ELSE 7.5
    END
WHERE brand = N'Mazda' AND id BETWEEN 13 AND 17;

PRINT '✅ Đã update dữ liệu Mazda (5 xe)';
GO

-- Update Ford (ID 18-20): Xe Mỹ, giới hạn 250km/ngày, phí vượt 3500đ/km
UPDATE cars 
SET daily_km_limit = 250,
    exceed_fee_per_km = 3500,
    fuel_consumption = CASE 
        WHEN id = 18 THEN 9.5   -- Explorer
        WHEN id = 19 THEN 10.2  -- Everest
        WHEN id = 20 THEN 11.5  -- Ranger
        ELSE 10.0
    END
WHERE brand = N'Ford' AND id BETWEEN 18 AND 20;

PRINT '✅ Đã update dữ liệu Ford (3 xe)';
GO

-- Update Kia (ID 21-23): Xe giá rẻ, giới hạn 300km/ngày, phí vượt 2000đ/km
UPDATE cars 
SET daily_km_limit = 300,
    exceed_fee_per_km = 2000,
    fuel_consumption = CASE 
        WHEN id = 21 THEN 6.0  -- Seltos
        WHEN id = 22 THEN 6.5  -- Sorento
        WHEN id = 23 THEN 5.5  -- Morning
        ELSE 6.0
    END
WHERE brand = N'Kia' AND id BETWEEN 21 AND 23;

PRINT '✅ Đã update dữ liệu Kia (3 xe)';
GO

-- Update Hyundai (ID 24-27): Xe Hàn, giới hạn 350km/ngày, phí vượt 2800đ/km
UPDATE cars 
SET daily_km_limit = 350,
    exceed_fee_per_km = 2800,
    fuel_consumption = CASE 
        WHEN id = 24 THEN 7.0  -- Tucson
        WHEN id = 25 THEN 8.5  -- Santa Fe
        WHEN id = 26 THEN 6.2  -- Accent
        WHEN id = 27 THEN 6.8  -- Elantra
        ELSE 7.0
    END
WHERE brand = N'Hyundai' AND id BETWEEN 24 AND 27;

PRINT '✅ Đã update dữ liệu Hyundai (4 xe)';
GO

-- Update VinFast (ID 28-30): Xe điện, KHÔNG giới hạn km, phí vượt = 0 (miễn phí)
UPDATE cars 
SET daily_km_limit = NULL,      -- NULL = không giới hạn
    exceed_fee_per_km = 0,       -- 0 = miễn phí
    fuel_consumption = 0         -- Xe điện = 0L/100km
WHERE brand = N'VinFast' AND id BETWEEN 28 AND 30;

PRINT '✅ Đã update dữ liệu VinFast - Xe điện (3 xe)';
GO

-- ===================================================================
-- VERIFY DỮ LIỆU
-- ===================================================================

SELECT 
    id,
    brand,
    name,
    daily_km_limit,
    exceed_fee_per_km,
    fuel_consumption,
    fuel_type
FROM cars
ORDER BY id;

PRINT '';
PRINT '═══════════════════════════════════════════════════';
PRINT '  ✅ HOÀN TẤT! Đã thêm và cập nhật dữ liệu';
PRINT '═══════════════════════════════════════════════════';
PRINT '';
PRINT '📊 Tóm tắt:';
PRINT '  - Toyota (6 xe): 300km/ngày, 3000đ/km vượt, 6-10L/100km';
PRINT '  - Honda (6 xe): 350km/ngày, 2500đ/km vượt, 5-8L/100km';
PRINT '  - Mazda (5 xe): 400km/ngày, 4000đ/km vượt, 6-9L/100km';
PRINT '  - Ford (3 xe): 250km/ngày, 3500đ/km vượt, 9-12L/100km';
PRINT '  - Kia (3 xe): 300km/ngày, 2000đ/km vượt, 5-7L/100km';
PRINT '  - Hyundai (4 xe): 350km/ngày, 2800đ/km vượt, 6-9L/100km';
PRINT '  - VinFast (3 xe): Không giới hạn, Miễn phí, 0L/100km (Điện)';
PRINT '';
