-- CẬP NHẬT ẢNH XE VỚI LINK THỰC TẾ TỪ INTERNET
-- Sử dụng ảnh từ các nguồn miễn phí: Unsplash, Pexels

-- TOYOTA (6 xe)
-- Toyota Vios Trắng
UPDATE cars SET image_url = N'https://images.unsplash.com/photo-1619767886558-efdc259cde1a?w=800' WHERE id = 1;

-- Toyota Vios Đen  
UPDATE cars SET image_url = N'https://images.unsplash.com/photo-1617531653332-bd46c24f2068?w=800' WHERE id = 2;

-- Toyota Camry
UPDATE cars SET image_url = N'https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?w=800' WHERE id = 3;

-- Toyota Fortuner
UPDATE cars SET image_url = N'https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?w=800' WHERE id = 4;

-- Toyota Innova
UPDATE cars SET image_url = N'https://images.unsplash.com/photo-1552519507-d9a0e1e4b800?w=800' WHERE id = 5;

-- Toyota Corolla Cross
UPDATE cars SET image_url = N'https://images.unsplash.com/photo-1609521263047-f8f205293f24?w=800' WHERE id = 6;

-- HONDA (6 xe)
-- Honda City Trắng
UPDATE cars SET image_url = N'https://images.unsplash.com/photo-1583121274602-3e2820c69888?w=800' WHERE id = 7;

-- Honda City Đỏ
UPDATE cars SET image_url = N'https://images.unsplash.com/photo-1580273916550-e323be2ae537?w=800' WHERE id = 8;

-- Honda Civic
UPDATE cars SET image_url = N'https://images.unsplash.com/photo-1590362891991-f776e747a588?w=800' WHERE id = 9;

-- Honda CR-V
UPDATE cars SET image_url = N'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?w=800' WHERE id = 10;

-- Honda BR-V
UPDATE cars SET image_url = N'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=800' WHERE id = 11;

-- Honda Accord
UPDATE cars SET image_url = N'https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=800' WHERE id = 12;

-- MAZDA (5 xe)
-- Mazda 2
UPDATE cars SET image_url = N'https://images.unsplash.com/photo-1617814076367-b759c7d7e738?w=800' WHERE id = 13;

-- Mazda 3
UPDATE cars SET image_url = N'https://images.unsplash.com/photo-1614162692292-7ac56d7f1313?w=800' WHERE id = 14;

-- Mazda CX-5 Đỏ
UPDATE cars SET image_url = N'https://images.unsplash.com/photo-1609521263047-f8f205293f24?w=800' WHERE id = 15;

-- Mazda CX-5 Trắng
UPDATE cars SET image_url = N'https://images.unsplash.com/photo-1616422285623-13ff0162193c?w=800' WHERE id = 16;

-- Mazda CX-8
UPDATE cars SET image_url = N'https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?w=800' WHERE id = 17;

-- FORD (3 xe)
-- Ford Ranger
UPDATE cars SET image_url = N'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?w=800' WHERE id = 18;

-- Ford Everest
UPDATE cars SET image_url = N'https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?w=800' WHERE id = 19;

-- Ford Territory
UPDATE cars SET image_url = N'https://images.unsplash.com/photo-1581540222194-0def2dda95b8?w=800' WHERE id = 20;

-- KIA (3 xe)
-- Kia Seltos
UPDATE cars SET image_url = N'https://images.unsplash.com/photo-1609521263047-f8f205293f24?w=800' WHERE id = 21;

-- Kia Sorento
UPDATE cars SET image_url = N'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?w=800' WHERE id = 22;

-- Kia Carnival
UPDATE cars SET image_url = N'https://images.unsplash.com/photo-1464219789935-c2d9d9aba644?w=800' WHERE id = 23;

-- HYUNDAI (4 xe)
-- Hyundai Accent
UPDATE cars SET image_url = N'https://images.unsplash.com/photo-1583121274602-3e2820c69888?w=800' WHERE id = 24;

-- Hyundai Tucson
UPDATE cars SET image_url = N'https://images.unsplash.com/photo-1606016159991-82b4b5e8c7fc?w=800' WHERE id = 25;

-- Hyundai Santa Fe
UPDATE cars SET image_url = N'https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?w=800' WHERE id = 26;

-- Hyundai Stargazer
UPDATE cars SET image_url = N'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=800' WHERE id = 27;

-- VINFAST (3 xe điện)
-- VinFast VF5
UPDATE cars SET image_url = N'https://images.unsplash.com/photo-1593941707882-a5bba14938c7?w=800' WHERE id = 28;

-- VinFast VF8
UPDATE cars SET image_url = N'https://images.unsplash.com/photo-1617469767053-d3b523a0b982?w=800' WHERE id = 29;

-- VinFast VF9
UPDATE cars SET image_url = N'https://images.unsplash.com/photo-1609521263047-f8f205293f24?w=800' WHERE id = 30;

PRINT N'✅ Đã cập nhật ảnh online cho 30 xe!';

-- Kiểm tra kết quả
SELECT id, name, image_url FROM cars ORDER BY id;
