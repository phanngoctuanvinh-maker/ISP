-- ========================================
-- SCRIPT THÊM XE ĐƠN GIẢN - CHỈ DÙNG CÁC CỘT CÓ SẴN
-- ========================================

USE drivenow_db;
GO

-- Xóa dữ liệu cũ nếu có
DELETE FROM cars;
GO

-- ========================================
-- THÊM 30 XE PHONG PHÚ
-- ========================================

-- Toyota (6 xe)
INSERT INTO cars (brand, model, name, year, color, seat_capacity, fuel_type, transmission_type, daily_rate, price_per_day, description, mileage, image_url, status, license_plate, insurance_info, location, created_at, updated_at)
VALUES 
('Toyota', 'Vios', 'Toyota Vios 2024 - Trắng', 2024, 'Trắng', 4, 'Gasoline', 'Automatic', 450000, 450000, 'Sedan tiết kiệm nhiên liệu, phù hợp đi phố', 15000, 'https://example.com/vios-white.jpg', 'Available', '30A-10001', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),
('Toyota', 'Vios', 'Toyota Vios 2024 - Đen', 2024, 'Đen', 4, 'Gasoline', 'Automatic', 450000, 450000, 'Sedan tiết kiệm nhiên liệu, phù hợp đi phố', 12000, 'https://example.com/vios-black.jpg', 'Available', '30A-10002', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),
('Toyota', 'Camry', 'Toyota Camry 2024', 2024, 'Trắng ngọc trai', 5, 'Gasoline', 'Automatic', 750000, 750000, 'Sedan hạng D cao cấp, êm ái, sang trọng', 8000, 'https://example.com/camry.jpg', 'Available', '30A-20001', 'Bảo hiểm toàn diện', 'Hà Nội', GETDATE(), GETDATE()),
('Toyota', 'Fortuner', 'Toyota Fortuner 2024', 2024, 'Bạc', 7, 'Diesel', 'Automatic', 900000, 900000, 'SUV 7 chỗ mạnh mẽ, phù hợp đi xa', 12000, 'https://example.com/fortuner.jpg', 'Available', '30A-20002', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),
('Toyota', 'Innova', 'Toyota Innova 2024', 2024, 'Xám', 7, 'Gasoline', 'Manual', 550000, 550000, 'MPV 7 chỗ phổ biến, rộng rãi', 20000, 'https://example.com/innova.jpg', 'Available', '30A-20003', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),
('Toyota', 'Corolla Cross', 'Toyota Corolla Cross 2024', 2024, 'Đen', 5, 'Gasoline', 'Automatic', 650000, 650000, 'SUV 5 chỗ năng động, gầm cao', 8000, 'https://example.com/cross.jpg', 'Available', '30A-20004', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE());

-- Honda (5 xe)
INSERT INTO cars (brand, model, name, year, color, seat_capacity, fuel_type, transmission_type, daily_rate, price_per_day, description, mileage, image_url, status, license_plate, insurance_info, location, created_at, updated_at)
VALUES 
('Honda', 'City', 'Honda City 2024 - Trắng', 2024, 'Trắng', 4, 'Gasoline', 'Automatic', 480000, 480000, 'Sedan trẻ trung, năng động', 10000, 'https://example.com/city-white.jpg', 'Available', '30B-10001', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),
('Honda', 'City', 'Honda City 2024 - Đỏ', 2024, 'Đỏ', 4, 'Gasoline', 'Automatic', 480000, 480000, 'Sedan trẻ trung, năng động', 9000, 'https://example.com/city-red.jpg', 'Available', '30B-10002', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),
('Honda', 'Civic', 'Honda Civic 2024', 2024, 'Xanh dương', 5, 'Gasoline', 'Automatic', 680000, 680000, 'Sedan thể thao, thiết kế trẻ trung', 5000, 'https://example.com/civic.jpg', 'Available', '30B-20001', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),
('Honda', 'CR-V', 'Honda CR-V 2024', 2024, 'Trắng', 5, 'Gasoline', 'Automatic', 750000, 750000, 'SUV 5 chỗ sang trọng', 7000, 'https://example.com/crv.jpg', 'Available', '30B-20002', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),
('Honda', 'BR-V', 'Honda BR-V 2024', 2024, 'Xám', 7, 'Gasoline', 'Automatic', 600000, 600000, 'SUV 7 chỗ linh hoạt', 15000, 'https://example.com/brv.jpg', 'Available', '30B-20003', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE());

-- Mazda (5 xe)
INSERT INTO cars (brand, model, name, year, color, seat_capacity, fuel_type, transmission_type, daily_rate, price_per_day, description, mileage, image_url, status, license_plate, insurance_info, location, created_at, updated_at)
VALUES 
('Mazda', '2', 'Mazda 2 2024', 2024, 'Bạc', 4, 'Gasoline', 'Automatic', 420000, 420000, 'Hatchback nhỏ gọn, tiện lợi', 12000, 'https://example.com/mazda2.jpg', 'Available', '30C-10001', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),
('Mazda', '3', 'Mazda 3 2024', 2024, 'Đỏ pha lê', 4, 'Gasoline', 'Automatic', 520000, 520000, 'Sedan thể thao, thiết kế đẹp', 8000, 'https://example.com/mazda3.jpg', 'Available', '30C-20001', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),
('Mazda', 'CX-5', 'Mazda CX-5 2024 - Đỏ', 2024, 'Đỏ pha lê', 5, 'Gasoline', 'Automatic', 700000, 700000, 'SUV 5 chỗ premium', 10000, 'https://example.com/cx5-red.jpg', 'Available', '30C-30001', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),
('Mazda', 'CX-5', 'Mazda CX-5 2024 - Trắng', 2024, 'Trắng', 5, 'Gasoline', 'Automatic', 700000, 700000, 'SUV 5 chỗ premium', 9000, 'https://example.com/cx5-white.jpg', 'Available', '30C-30002', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),
('Mazda', 'CX-8', 'Mazda CX-8 2024', 2024, 'Xanh dương', 7, 'Diesel', 'Automatic', 950000, 950000, 'SUV 7 chỗ cao cấp nhất', 6000, 'https://example.com/cx8.jpg', 'Available', '30C-40001', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE());

-- Ford (3 xe)
INSERT INTO cars (brand, model, name, year, color, seat_capacity, fuel_type, transmission_type, daily_rate, price_per_day, description, mileage, image_url, status, license_plate, insurance_info, location, created_at, updated_at)
VALUES 
('Ford', 'Ranger', 'Ford Ranger 2024', 2024, 'Cam', 4, 'Diesel', 'Manual', 800000, 800000, 'Bán tải mạnh mẽ, phù hợp địa hình', 18000, 'https://example.com/ranger.jpg', 'Available', '30D-10001', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),
('Ford', 'Everest', 'Ford Everest 2024', 2024, 'Đen', 7, 'Diesel', 'Automatic', 1000000, 1000000, 'SUV 7 chỗ địa hình', 9000, 'https://example.com/everest.jpg', 'Available', '30D-20001', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),
('Ford', 'Territory', 'Ford Territory 2024', 2024, 'Xanh', 5, 'Gasoline', 'Automatic', 650000, 650000, 'SUV 5 chỗ hiện đại', 7000, 'https://example.com/territory.jpg', 'Available', '30D-30001', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE());

-- Kia (3 xe)
INSERT INTO cars (brand, model, name, year, color, seat_capacity, fuel_type, transmission_type, daily_rate, price_per_day, description, mileage, image_url, status, license_plate, insurance_info, location, created_at, updated_at)
VALUES 
('Kia', 'Seltos', 'Kia Seltos 2024', 2024, 'Cam đồng', 5, 'Gasoline', 'Automatic', 580000, 580000, 'SUV 5 chỗ trẻ trung', 11000, 'https://example.com/seltos.jpg', 'Available', '30E-10001', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),
('Kia', 'Sorento', 'Kia Sorento 2024', 2024, 'Nâu', 7, 'Diesel', 'Automatic', 880000, 880000, 'SUV 7 chỗ sang trọng', 8000, 'https://example.com/sorento.jpg', 'Available', '30E-20001', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),
('Kia', 'Carnival', 'Kia Carnival 2024', 2024, 'Trắng', 7, 'Diesel', 'Automatic', 1200000, 1200000, 'Minivan hạng sang 7-9 chỗ', 5000, 'https://example.com/carnival.jpg', 'Available', '30E-30001', 'Bảo hiểm toàn diện', 'Hà Nội', GETDATE(), GETDATE());

-- Hyundai (4 xe)
INSERT INTO cars (brand, model, name, year, color, seat_capacity, fuel_type, transmission_type, daily_rate, price_per_day, description, mileage, image_url, status, license_plate, insurance_info, location, created_at, updated_at)
VALUES 
('Hyundai', 'Accent', 'Hyundai Accent 2024', 2024, 'Trắng', 4, 'Gasoline', 'Automatic', 440000, 440000, 'Sedan phổ thông, tiết kiệm', 14000, 'https://example.com/accent.jpg', 'Available', '30F-10001', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),
('Hyundai', 'Tucson', 'Hyundai Tucson 2024', 2024, 'Xám', 5, 'Gasoline', 'Automatic', 720000, 720000, 'SUV 5 chỗ thông minh', 9000, 'https://example.com/tucson.jpg', 'Available', '30F-20001', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),
('Hyundai', 'Santa Fe', 'Hyundai Santa Fe 2024', 2024, 'Đen', 7, 'Diesel', 'Automatic', 920000, 920000, 'SUV 7 chỗ cao cấp', 7000, 'https://example.com/santafe.jpg', 'Bảo hiểm đầy đủ', '30F-30001', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE()),
('Hyundai', 'Stargazer', 'Hyundai Stargazer 2024', 2024, 'Bạc', 7, 'Gasoline', 'Automatic', 500000, 500000, 'MPV 7 chỗ giá tốt', 10000, 'https://example.com/stargazer.jpg', 'Available', '30F-40001', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE());

-- Vinfast (3 xe điện)
INSERT INTO cars (brand, model, name, year, color, seat_capacity, fuel_type, transmission_type, daily_rate, price_per_day, description, mileage, image_url, status, license_plate, insurance_info, location, created_at, updated_at)
VALUES 
('Vinfast', 'VF5', 'Vinfast VF5 Plus 2024', 2024, 'Xanh lá', 5, 'Electric', 'Automatic', 550000, 550000, 'SUV điện 5 chỗ nhỏ gọn, tầm hoạt động 300km', 3000, 'https://example.com/vf5.jpg', 'Available', '30G-10001', 'Bảo hiểm + sạc điện miễn phí', 'Hà Nội', GETDATE(), GETDATE()),
('Vinfast', 'VF8', 'Vinfast VF8 2024', 2024, 'Xanh dương', 5, 'Electric', 'Automatic', 900000, 900000, 'SUV điện 5 chỗ cao cấp, tầm hoạt động 400km', 2000, 'https://example.com/vf8.jpg', 'Available', '30G-20001', 'Bảo hiểm + sạc điện 24/7', 'Hà Nội', GETDATE(), GETDATE()),
('Vinfast', 'VF9', 'Vinfast VF9 2024', 2024, 'Đen', 7, 'Electric', 'Automatic', 1500000, 1500000, 'SUV điện 7 chỗ hạng sang, tầm hoạt động 600km', 1000, 'https://example.com/vf9.jpg', 'Available', '30G-30001', 'Bảo hiểm VIP + sạc tại nhà', 'Hà Nội', GETDATE(), GETDATE());

-- Mitsubishi (1 xe hybrid)
INSERT INTO cars (brand, model, name, year, color, seat_capacity, fuel_type, transmission_type, daily_rate, price_per_day, description, mileage, image_url, status, license_plate, insurance_info, location, created_at, updated_at)
VALUES 
('Mitsubishi', 'Outlander', 'Mitsubishi Outlander PHEV 2024', 2024, 'Đỏ', 7, 'Hybrid', 'Automatic', 1100000, 1100000, 'SUV 7 chỗ hybrid (xăng & điện)', 6000, 'https://example.com/outlander.jpg', 'Available', '30H-10001', 'Bảo hiểm đầy đủ', 'Hà Nội', GETDATE(), GETDATE());

GO

PRINT '';
PRINT '========================================';
PRINT 'KẾT QUẢ THÊM XE';
PRINT '========================================';

-- Thống kê
SELECT COUNT(*) as 'Tổng số xe' FROM cars;
PRINT '';

SELECT brand as 'Hãng xe', COUNT(*) as 'Số lượng' 
FROM cars 
GROUP BY brand 
ORDER BY COUNT(*) DESC;
PRINT '';

SELECT fuel_type as 'Nhiên liệu', COUNT(*) as 'Số lượng' 
FROM cars 
GROUP BY fuel_type;
PRINT '';

SELECT seat_capacity as 'Số chỗ', COUNT(*) as 'Số lượng' 
FROM cars 
GROUP BY seat_capacity 
ORDER BY seat_capacity;
PRINT '';

PRINT '✅ HOÀN THÀNH! Đã thêm 30 xe vào database';
PRINT '';
PRINT 'Bước tiếp theo:';
PRINT '1. Test API: http://localhost:8080/api/cars/all';
PRINT '2. Mở DriveNow/html/searchcar.html';
PRINT '';

GO
