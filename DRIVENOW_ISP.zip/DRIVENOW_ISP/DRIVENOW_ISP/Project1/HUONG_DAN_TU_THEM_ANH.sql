-- ========================================
-- HƯỚNG DẪN TỰ THÊM ẢNH CHO XE
-- ========================================

-- Cách 1: Dùng link online (Unsplash, Pexels...)
-- Thay [ID_XE] và [LINK_ẢNH] bằng giá trị thực tế

UPDATE cars 
SET image_url = N'https://images.unsplash.com/photo-xxxxxxxxx?w=800' 
WHERE id = 1;  -- Thay số 1 bằng ID xe bạn muốn update


-- Cách 2: Dùng ảnh local (đã tải về)
-- Copy ảnh vào thư mục: DriveNow/assets/inmage/
-- Sau đó chạy:

UPDATE cars 
SET image_url = N'assets/inmage/ten-file-anh.jpg' 
WHERE id = 1;  -- Thay số 1 bằng ID xe bạn muốn update


-- ========================================
-- VÍ DỤ CỤ THỂ:
-- ========================================

-- Ví dụ 1: Update ảnh Toyota Vios (ID = 1) bằng link Unsplash
UPDATE cars 
SET image_url = N'https://images.unsplash.com/photo-1619767886558-efdc259cde1a?w=800' 
WHERE id = 1;

-- Ví dụ 2: Update ảnh Honda City (ID = 7) bằng ảnh local
UPDATE cars 
SET image_url = N'assets/inmage/honda-city-red.jpg' 
WHERE id = 7;

-- Ví dụ 3: Update nhiều xe cùng lúc
UPDATE cars SET image_url = N'https://images.unsplash.com/photo-1619767886558-efdc259cde1a?w=800' WHERE id = 1;
UPDATE cars SET image_url = N'https://images.unsplash.com/photo-1617531653332-bd46c24f2068?w=800' WHERE id = 2;
UPDATE cars SET image_url = N'https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?w=800' WHERE id = 3;


-- ========================================
-- KIỂM TRA KẾT QUẢ:
-- ========================================

-- Xem tất cả ảnh hiện tại
SELECT id, name, image_url FROM cars ORDER BY id;

-- Xem ảnh của 1 xe cụ thể
SELECT id, name, image_url FROM cars WHERE id = 1;


-- ========================================
-- GỢI Ý TÌM ẢNH:
-- ========================================

-- 🌐 Unsplash: https://unsplash.com
--    Tìm kiếm: "toyota vios", "honda civic", "suv car", "sedan white"...
--    Click ảnh → Chuột phải → Copy image address

-- 🌐 Pexels: https://pexels.com
--    Tương tự Unsplash

-- 🌐 Google Images: https://images.google.com
--    Tìm ảnh → Tools → Size → Large
--    Click ảnh → View image → Copy link


-- ========================================
-- LƯU Ý:
-- ========================================

-- 1. Link ảnh phải là URL trực tiếp tới file ảnh (.jpg, .png, .webp)
-- 2. Nếu dùng ảnh local, đảm bảo file tồn tại trong thư mục assets/inmage/
-- 3. Nên dùng ảnh có kích thước vừa phải (800-1200px width) để load nhanh
-- 4. Sau khi update, reload trang web để thấy thay đổi
