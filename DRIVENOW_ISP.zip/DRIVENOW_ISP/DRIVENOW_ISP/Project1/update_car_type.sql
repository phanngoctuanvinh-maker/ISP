-- ========================================
-- UPDATE CAR_TYPE CHO TẤT CẢ XE
-- ========================================

USE drivenow_db;
GO

-- Mini (xe nhỏ gọn 4 chỗ)
UPDATE cars SET car_type = 'Mini' 
WHERE model IN ('i10', 'Morning', 'Wigo', 'Spark') OR seat_capacity = 4 AND brand IN ('Hyundai', 'Kia', 'Toyota', 'Chevrolet');

-- Sedan (xe sedan 4-5 chỗ)
UPDATE cars SET car_type = 'Sedan' 
WHERE model IN ('Vios', 'City', 'Accent', 'Cerato', 'Civic', 'Mazda3', 'Camry', 'Altis');

-- Pickup (bán tải 5 chỗ)
UPDATE cars SET car_type = 'Pickup' 
WHERE model IN ('Ranger', 'Hilux', 'Colorado', 'Navara', 'D-Max', 'BT-50', 'Triton');

-- CUV/Crossover (5 chỗ)
UPDATE cars SET car_type = 'CUV' 
WHERE model IN ('Corolla Cross', 'HR-V', 'CR-V', 'Seltos', 'Tucson', 'Sportage', 'CX-5', 'Escape');

-- SUV (7 chỗ)
UPDATE cars SET car_type = 'SUV' 
WHERE model IN ('Fortuner', 'Everest', 'Santa Fe', 'Sorento', 'CX-8', 'CX-9', 'Palisade', 'Explorer', 'Pajero Sport');

-- MPV (7 chỗ)
UPDATE cars SET car_type = 'MPV' 
WHERE model IN ('Innova', 'Avanza', 'Xpander', 'Rush', 'Ertiga', 'XL7', 'Veloz');

-- Minivan (7-9 chỗ)
UPDATE cars SET car_type = 'Minivan' 
WHERE model IN ('Carnival', 'Sedona', 'Odyssey', 'Sienna', 'Alphard', 'Granvia');

-- Kiểm tra kết quả
SELECT 
    car_type,
    COUNT(*) as total_cars
FROM cars
GROUP BY car_type
ORDER BY car_type;

GO
