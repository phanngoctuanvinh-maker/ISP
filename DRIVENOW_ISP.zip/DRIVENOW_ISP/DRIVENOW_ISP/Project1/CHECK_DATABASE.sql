-- ========================================
-- SCRIPT KIỂM TRA DATABASE HIỆN TẠI
-- Chạy script này để xem dữ liệu hiện có
-- ========================================

USE drivenow_db;
GO

PRINT '========================================';
PRINT 'KIỂM TRA DATABASE - DRIVENOW';
PRINT '========================================';
PRINT '';

-- ========================================
-- 1. KIỂM TRA CẤU TRÚC BẢNG
-- ========================================

PRINT '[1] Kiểm tra cấu trúc bảng cars...';
PRINT '';

-- Kiểm tra kiểu dữ liệu các cột
SELECT 
    COLUMN_NAME as N'Tên cột', 
    DATA_TYPE as N'Kiểu dữ liệu', 
    CHARACTER_MAXIMUM_LENGTH as N'Độ dài'
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'cars'
AND COLUMN_NAME IN ('brand', 'fuel_type', 'transmission_type', 'status', 'description')
ORDER BY ORDINAL_POSITION;

PRINT '';

-- ========================================
-- 2. KIỂM TRA DỮ LIỆU HIỆN CÓ
-- ========================================

PRINT '[2] Kiểm tra dữ liệu hiện có...';
PRINT '';

-- Đếm tổng số xe
DECLARE @TotalCars INT;
SELECT @TotalCars = COUNT(*) FROM cars;
PRINT 'Tổng số xe trong database: ' + CAST(@TotalCars AS VARCHAR);
PRINT '';

-- ========================================
-- 3. KIỂM TRA NHIÊN LIỆU (FUEL_TYPE)
-- ========================================

PRINT '[3] Phân tích fuel_type (Nhiên liệu):';
SELECT 
    fuel_type as N'Loại nhiên liệu',
    COUNT(*) as N'Số lượng',
    CASE 
        WHEN fuel_type LIKE N'%Xăng%' OR fuel_type LIKE N'%Điện%' OR fuel_type LIKE N'%Dầu%' THEN N'✅ Tiếng Việt'
        ELSE N'❌ Tiếng Anh'
    END as N'Trạng thái'
FROM cars
GROUP BY fuel_type
ORDER BY COUNT(*) DESC;
PRINT '';

-- ========================================
-- 4. KIỂM TRA HỘP SỐ (TRANSMISSION_TYPE)
-- ========================================

PRINT '[4] Phân tích transmission_type (Hộp số):';
SELECT 
    transmission_type as N'Loại hộp số',
    COUNT(*) as N'Số lượng',
    CASE 
        WHEN transmission_type LIKE N'%Tự động%' OR transmission_type LIKE N'%Số sàn%' THEN N'✅ Tiếng Việt'
        ELSE N'❌ Tiếng Anh'
    END as N'Trạng thái'
FROM cars
GROUP BY transmission_type
ORDER BY COUNT(*) DESC;
PRINT '';

-- ========================================
-- 5. KIỂM TRA TRẠNG THÁI (STATUS)
-- ========================================

PRINT '[5] Phân tích status (Trạng thái):';
SELECT 
    status as N'Trạng thái',
    COUNT(*) as N'Số lượng',
    CASE 
        WHEN status LIKE N'%Có sẵn%' OR status LIKE N'%Đã thuê%' OR status LIKE N'%Bảo trì%' THEN N'✅ Tiếng Việt'
        ELSE N'❌ Tiếng Anh'
    END as N'Ngôn ngữ'
FROM cars
GROUP BY status
ORDER BY COUNT(*) DESC;
PRINT '';

-- ========================================
-- 6. XEM MẪU DỮ LIỆU
-- ========================================

PRINT '[6] Xem 5 xe mẫu:';
SELECT TOP 5
    id,
    brand as N'Hãng',
    name as N'Tên xe',
    fuel_type as N'Nhiên liệu',
    transmission_type as N'Hộp số',
    status as N'Trạng thái',
    LEFT(description, 50) as N'Mô tả (50 ký tự đầu)'
FROM cars
ORDER BY id;
PRINT '';

-- ========================================
-- 7. KẾT LUẬN
-- ========================================

PRINT '========================================';
PRINT 'KẾT LUẬN';
PRINT '========================================';
PRINT '';

DECLARE @VietnameseCars INT;
DECLARE @EnglishCars INT;

SELECT @VietnameseCars = COUNT(*) 
FROM cars 
WHERE fuel_type LIKE N'%Xăng%' 
   OR fuel_type LIKE N'%Điện%' 
   OR fuel_type LIKE N'%Dầu%'
   OR transmission_type LIKE N'%Tự động%' 
   OR transmission_type LIKE N'%Số sàn%';

SELECT @EnglishCars = COUNT(*) 
FROM cars 
WHERE LOWER(fuel_type) IN ('gasoline', 'diesel', 'electric', 'hybrid')
   OR LOWER(transmission_type) IN ('automatic', 'manual');

IF @EnglishCars > 0
BEGIN
    PRINT '⚠️  CẢNH BÁO: Tìm thấy ' + CAST(@EnglishCars AS VARCHAR) + ' xe có dữ liệu TIẾNG ANH';
    PRINT '';
    PRINT 'KHUYẾN NGHỊ:';
    PRINT '→ Chạy script: UPDATE_TO_VIETNAMESE.sql';
    PRINT '→ Để chuyển tất cả dữ liệu sang tiếng Việt';
END
ELSE
BEGIN
    PRINT '✅ TẤT CẢ DỮ LIỆU ĐÃ LÀ TIẾNG VIỆT!';
    PRINT '→ Không cần update';
END

PRINT '';
PRINT '========================================';

GO
