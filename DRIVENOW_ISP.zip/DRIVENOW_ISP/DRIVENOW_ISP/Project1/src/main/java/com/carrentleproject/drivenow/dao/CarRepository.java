package com.carrentleproject.drivenow.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.carrentleproject.drivenow.model.Car;

@Repository
public interface CarRepository extends JpaRepository<Car, Long> {

    // Tìm xe theo hãng
    List<Car> findByBrandIgnoreCase(String brand);

    // Tìm xe theo loại truyền động
    List<Car> findByTransmissionTypeIgnoreCase(String transmissionType);

    // Tìm xe theo loại nhiên liệu
    List<Car> findByFuelTypeIgnoreCase(String fuelType);

    // Tìm xe theo số chỗ ngồi (seat_capacity)
    List<Car> findBySeatCapacity(Integer seatCapacity);

    // Tìm xe theo loại xe (car_type)
    List<Car> findByCarTypeIgnoreCase(String carType);

    // Tìm xe theo trạng thái
    List<Car> findByStatus(String status);

    // Tìm xe điện - dùng Native Query để SQL Server xử lý Unicode đúng
    @Query(value = "SELECT * FROM cars WHERE fuel_type = N'Điện' OR LOWER(fuel_type) = 'electric'", nativeQuery = true)
    List<Car> findElectricCars();

    // Tìm xe xăng và điện (hybrid)
    @Query(value = "SELECT * FROM cars WHERE LOWER(fuel_type) LIKE '%hybrid%' OR fuel_type LIKE N'%Xăng%Điện%'", nativeQuery = true)
    List<Car> findHybridCars();

    // Tìm xe theo nhiều điều kiện
    @Query("SELECT c FROM Car c WHERE " +
            "(:brand IS NULL OR LOWER(c.brand) = LOWER(:brand)) AND " +
            "(:transmissionType IS NULL OR LOWER(c.transmissionType) = LOWER(:transmissionType)) AND " +
            "(:fuelType IS NULL OR LOWER(c.fuelType) = LOWER(:fuelType)) AND " +
            "(:seatCapacity IS NULL OR c.seatCapacity = :seatCapacity)")
    List<Car> searchCars(@Param("brand") String brand,
                         @Param("transmissionType") String transmissionType,
                         @Param("fuelType") String fuelType,
                         @Param("seatCapacity") Integer seatCapacity);
}
