package com.carrentleproject.drivenow.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class ValidSeatsValidator implements ConstraintValidator<ValidSeats, Integer> {

    @Override
    public void initialize(ValidSeats constraintAnnotation) {
        // No initialization needed
    }

    @Override
    public boolean isValid(Integer seats, ConstraintValidatorContext context) {
        // Null values are handled by @NotNull
        if (seats == null) {
            return true;
        }
        // Only allow 4 or 7 seats
        return seats == 4 || seats == 7;
    }
}
