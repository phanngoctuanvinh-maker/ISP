package com.carrentleproject.drivenow.dto;

import java.math.BigDecimal;

import com.carrentleproject.drivenow.validation.ValidSeats;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class CarUpdateRequest {

    @Size(max = 50, message = "Thương hiệu không được vượt quá 50 ký tự")
    private String brand;

    @Size(max = 50, message = "Mẫu hiệu không được vượt quá 50 ký tự")
    private String model;

    @ValidSeats(message = "Số chỗ ngồi chỉ được phép là 4 hoặc 7")
    private Integer seats;

    @Size(max = 50, message = "Loại nhiên liệu không được vượt quá 50 ký tự")
    private String fuelType;

    @Size(max = 50, message = "Biển số không được vượt quá 50 ký tự")
    private String licensePlate;

    @Size(max = 255, message = "Thông tin bảo hiểm không được vượt quá 255 ký tự")
    private String insuranceInfo;

    @Size(max = 255, message = "URL hình ảnh không được vượt quá 255 ký tự")
    private String imageUrl;

    @Size(max = 100, message = "Địa điểm không được vượt quá 100 ký tự")
    private String location;

    @DecimalMin(value = "0.0", inclusive = false, message = "Giá phải lớn hơn 0")
    private BigDecimal pricePerDay;

    @Pattern(regexp = "available|rented|maintenance", message = "Trạng thái phải là: available, rented, hoặc maintenance")
    private String status;

    // Constructors
    public CarUpdateRequest() {
    }

    // Getters and Setters
    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public Integer getSeats() {
        return seats;
    }

    public void setSeats(Integer seats) {
        this.seats = seats;
    }

    public String getFuelType() {
        return fuelType;
    }

    public void setFuelType(String fuelType) {
        this.fuelType = fuelType;
    }

    public String getLicensePlate() {
        return licensePlate;
    }

    public void setLicensePlate(String licensePlate) {
        this.licensePlate = licensePlate;
    }

    public String getInsuranceInfo() {
        return insuranceInfo;
    }

    public void setInsuranceInfo(String insuranceInfo) {
        this.insuranceInfo = insuranceInfo;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public BigDecimal getPricePerDay() {
        return pricePerDay;
    }

    public void setPricePerDay(BigDecimal pricePerDay) {
        this.pricePerDay = pricePerDay;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
