package com.carrentleproject.drivenow.dto;

import jakarta.validation.constraints.Size;

/**
 * DTO cho yêu cầu hủy booking
 */
public class BookingCancelRequest {
    
    @Size(max = 500, message = "Lý do hủy không được vượt quá 500 ký tự")
    private String cancellationReason;

    // Constructors
    public BookingCancelRequest() {
    }

    public BookingCancelRequest(String cancellationReason) {
        this.cancellationReason = cancellationReason;
    }

    // Getters and Setters
    public String getCancellationReason() {
        return cancellationReason;
    }

    public void setCancellationReason(String cancellationReason) {
        this.cancellationReason = cancellationReason;
    }
}
