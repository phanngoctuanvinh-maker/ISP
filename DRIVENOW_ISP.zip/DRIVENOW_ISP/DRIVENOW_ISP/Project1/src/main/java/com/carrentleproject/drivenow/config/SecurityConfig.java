package com.carrentleproject.drivenow.config;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {

    @Autowired
    private UserDetailsService userDetailsService;

    @Autowired
    private JwtAuthenticationFilter jwtAuthenticationFilter;

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @SuppressWarnings("deprecation")
    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
        authProvider.setUserDetailsService(userDetailsService);
        authProvider.setPasswordEncoder(passwordEncoder());
        return authProvider;
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authConfig) throws Exception {
        return authConfig.getAuthenticationManager();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .cors(cors -> cors.configurationSource(corsConfigurationSource()))
                .csrf(csrf -> csrf.disable())
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(auth -> auth
                        // Public endpoints - Không cần authentication
                        .requestMatchers("/api/auth/**", "/auth/**", "/api/validation/**").permitAll()
                        
                        // Car endpoints - GET public, POST/PUT/DELETE cần auth
                        .requestMatchers(HttpMethod.GET, "/api/cars/**").permitAll()
                        .requestMatchers(HttpMethod.POST, "/api/cars/**").authenticated()
                        .requestMatchers(HttpMethod.PUT, "/api/cars/**").authenticated()
                        .requestMatchers(HttpMethod.DELETE, "/api/cars/**").authenticated()
                        .requestMatchers(HttpMethod.PATCH, "/api/cars/**").authenticated()
                        
                        // Search endpoints - Public (customer cần search trước khi login)
                        .requestMatchers("/api/search/**").permitAll()
                        
                        // Customer History - GET reviews public, POST/other cần auth
                        .requestMatchers(HttpMethod.GET, "/api/customer/history/cars/*/reviews").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/customer/history/cars/*/rating").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/customer/history/reviews/check/*").permitAll()
                        .requestMatchers("/api/customer/history/**").authenticated()
                        
                        // History endpoints - Cần authentication
                        .requestMatchers("/api/history/**").authenticated()
                        
                        // Favorites - GET check/count/top public, POST/DELETE cần auth
                        .requestMatchers(HttpMethod.GET, "/api/favorites/check").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/favorites/top").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/favorites/cars/*/count").permitAll()
                        .requestMatchers("/api/favorites/**").authenticated()
                        
                        // Rental Contracts - Cần authentication
                        .requestMatchers("/api/rental-contracts/**").authenticated()
                        
                        // Delivery Schedules - Cần authentication
                        .requestMatchers("/api/delivery-schedules/**").authenticated()
                        
                        // Group Bookings - Cần authentication
                        .requestMatchers("/api/group-bookings/**").authenticated()
                        
                        // Profile endpoints - Cần authentication
                        .requestMatchers("/api/profile/**", "/profile/**").authenticated()
                        
                        // Tất cả các API khác - Cần authentication
                        .anyRequest().authenticated())
                .authenticationProvider(authenticationProvider())
                .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        // Cho phép mọi origin trong môi trường development
        configuration.setAllowedOriginPatterns(Arrays.asList("*"));
        configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        configuration.setAllowedHeaders(Arrays.asList("*"));
        configuration.setAllowCredentials(true);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }
}
