package com.carrentleproject.drivenow.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

// Disable WebConfig CORS - use SecurityConfig CORS instead to avoid conflicts
@Configuration
public class WebConfig implements WebMvcConfigurer {

    // CORS configuration moved to SecurityConfig.java
    // Commented out to avoid conflict with SecurityConfig
    /*
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/api/**")
                .allowedOriginPatterns("*")
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH")
                .allowedHeaders("*")
                .allowCredentials(true);
    }
    */
}
