package com.carrentleproject.drivenow.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.carrentleproject.drivenow.dto.AdvancedFilterRequest;
import com.carrentleproject.drivenow.dto.SearchCarRequest;
import com.carrentleproject.drivenow.dto.SearchCarResponse;
import com.carrentleproject.drivenow.model.Car;
import com.carrentleproject.drivenow.service.AdvancedFilterService;
import com.carrentleproject.drivenow.service.SearchCarService;
import com.carrentleproject.drivenow.dao.CarRepository;

@RestController
@RequestMapping("/api/cars")
@CrossOrigin(origins = "*")
public class SearchCarController {

    @Autowired
    private SearchCarService searchCarService;

    @Autowired
    private AdvancedFilterService advancedFilterService;

    @Autowired
    private CarRepository carRepository;

    /**
     * API tìm kiếm xe
     * POST /api/cars/search
     */
    @PostMapping("/search")
    public ResponseEntity<SearchCarResponse> searchCars(@RequestBody SearchCarRequest request) {
        try {
            List<Car> cars = searchCarService.searchCars(
                    request.getFilterType(),
                    request.getBrand(),
                    request.getTransmissionType(),
                    request.getSeatCapacity(),
                    request.getFuelType()
            );

            if (cars == null || cars.isEmpty()) {
                return ResponseEntity.ok(new SearchCarResponse(
                        false,
                        "Không tìm thấy xe phù hợp với tiêu chí tìm kiếm",
                        cars
                ));
            }

            return ResponseEntity.ok(new SearchCarResponse(
                    true,
                    "Tìm thấy " + cars.size() + " xe",
                    cars
            ));

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new SearchCarResponse(
                            false,
                            "Lỗi hệ thống: " + e.getMessage(),
                            null
                    ));
        }
    }

    /**
     * API lấy tất cả xe
     * GET /api/cars/all
     */
    @GetMapping("/all")
    public ResponseEntity<SearchCarResponse> getAllCars() {
        try {
            List<Car> cars = searchCarService.getAllCars();

            if (cars == null || cars.isEmpty()) {
                return ResponseEntity.ok(new SearchCarResponse(
                        false,
                        "Không có xe nào trong hệ thống",
                        cars
                ));
            }

            return ResponseEntity.ok(new SearchCarResponse(
                    true,
                    "Tìm thấy " + cars.size() + " xe",
                    cars
            ));

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new SearchCarResponse(
                            false,
                            "Lỗi hệ thống: " + e.getMessage(),
                            null
                    ));
        }
    }

    /**
     * API lấy xe theo loại xe (car_type)
     * GET /api/cars/by-type?carType=Sedan
     * GET /api/cars/by-type?carType=Pickup
     */
    @GetMapping("/by-type")
    public ResponseEntity<SearchCarResponse> getCarsByType(@RequestParam String carType) {
        try {
            List<Car> cars = carRepository.findByCarTypeIgnoreCase(carType);

            if (cars == null || cars.isEmpty()) {
                return ResponseEntity.ok(new SearchCarResponse(
                        false,
                        "Không tìm thấy xe loại " + carType,
                        cars
                ));
            }

            return ResponseEntity.ok(new SearchCarResponse(
                    true,
                    "Tìm thấy " + cars.size() + " xe loại " + carType,
                    cars
            ));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new SearchCarResponse(false, "Lỗi server: " + e.getMessage(), null));
        }
    }

    /**
     * API lấy xe theo số chỗ ngồi (seat_capacity) - Giữ lại để tương thích
     * GET /api/cars/by-seat-capacity?seatCapacity=4
     */
    @GetMapping("/by-seat-capacity")
    public ResponseEntity<SearchCarResponse> getCarsBySeatCapacity(@RequestParam Integer seatCapacity) {
        try {
            SearchCarRequest request = new SearchCarRequest();
            request.setFilterType("type");
            request.setSeatCapacity(seatCapacity);

            List<Car> cars = searchCarService.searchCars(
                    request.getFilterType(),
                    null,
                    null,
                    seatCapacity,
                    null
            );

            if (cars == null || cars.isEmpty()) {
                return ResponseEntity.ok(new SearchCarResponse(
                        false,
                        "Không tìm thấy xe " + seatCapacity + " chỗ",
                        cars
                ));
            }

            return ResponseEntity.ok(new SearchCarResponse(
                    true,
                    "Tìm thấy " + cars.size() + " xe " + seatCapacity + " chỗ",
                    cars
            ));

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new SearchCarResponse(
                            false,
                            "Lỗi hệ thống: " + e.getMessage(),
                            null
                    ));
        }
    }

    /**
     * API lấy xe theo hãng
     * GET /api/cars/by-brand?brand=Toyota
     */
    @GetMapping("/by-brand")
    public ResponseEntity<SearchCarResponse> getCarsByBrand(@RequestParam String brand) {
        try {
            SearchCarRequest request = new SearchCarRequest();
            request.setFilterType("brand");
            request.setBrand(brand);

            List<Car> cars = searchCarService.searchCars(
                    request.getFilterType(),
                    brand,
                    null,
                    null,
                    null
            );

            if (cars == null || cars.isEmpty()) {
                return ResponseEntity.ok(new SearchCarResponse(
                        false,
                        "Không tìm thấy xe hãng " + brand,
                        cars
                ));
            }

            return ResponseEntity.ok(new SearchCarResponse(
                    true,
                    "Tìm thấy " + cars.size() + " xe hãng " + brand,
                    cars
            ));

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new SearchCarResponse(
                            false,
                            "Lỗi hệ thống: " + e.getMessage(),
                            null
                    ));
        }
    }

    /**
     * API lấy xe theo loại truyền động
     * GET /api/cars/by-transmission?type=Số sàn
     */
    @GetMapping("/by-transmission")
    public ResponseEntity<SearchCarResponse> getCarsByTransmission(@RequestParam String type) {
        try {
            SearchCarRequest request = new SearchCarRequest();
            request.setFilterType("transmission");
            request.setTransmissionType(type);

            List<Car> cars = searchCarService.searchCars(
                    request.getFilterType(),
                    null,
                    type,
                    null,
                    null
            );

            if (cars == null || cars.isEmpty()) {
                return ResponseEntity.ok(new SearchCarResponse(
                        false,
                        "Không tìm thấy xe " + type,
                        cars
                ));
            }

            return ResponseEntity.ok(new SearchCarResponse(
                    true,
                    "Tìm thấy " + cars.size() + " xe " + type,
                    cars
            ));

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new SearchCarResponse(
                            false,
                            "Lỗi hệ thống: " + e.getMessage(),
                            null
                    ));
        }
    }

    /**
     * API lấy xe điện
     * GET /api/cars/electric
     */
    @GetMapping("/electric")
    public ResponseEntity<SearchCarResponse> getElectricCars() {
        try {
            SearchCarRequest request = new SearchCarRequest();
            request.setFilterType("electric");

            List<Car> cars = searchCarService.searchCars(
                    request.getFilterType(),
                    null,
                    null,
                    null,
                    null
            );

            if (cars == null || cars.isEmpty()) {
                return ResponseEntity.ok(new SearchCarResponse(
                        false,
                        "Không tìm thấy xe điện",
                        cars
                ));
            }

            return ResponseEntity.ok(new SearchCarResponse(
                    true,
                    "Tìm thấy " + cars.size() + " xe điện",
                    cars
            ));

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new SearchCarResponse(
                            false,
                            "Lỗi hệ thống: " + e.getMessage(),
                            null
                    ));
        }
    }

    /**
     * API lấy xe xăng & điện (hybrid)
     * GET /api/cars/hybrid
     */
    @GetMapping("/hybrid")
    public ResponseEntity<SearchCarResponse> getHybridCars() {
        try {
            SearchCarRequest request = new SearchCarRequest();
            request.setFilterType("hybrid");

            List<Car> cars = searchCarService.searchCars(
                    request.getFilterType(),
                    null,
                    null,
                    null,
                    null
            );

            if (cars == null || cars.isEmpty()) {
                return ResponseEntity.ok(new SearchCarResponse(
                        false,
                        "Không tìm thấy xe xăng & điện",
                        cars
                ));
            }

            return ResponseEntity.ok(new SearchCarResponse(
                    true,
                    "Tìm thấy " + cars.size() + " xe xăng & điện",
                    cars
            ));

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new SearchCarResponse(
                            false,
                            "Lỗi hệ thống: " + e.getMessage(),
                            null
                    ));
        }
    }

    /**
     * API lấy danh sách hãng xe
     * GET /api/cars/brands
     */
    @GetMapping("/brands")
    public ResponseEntity<List<String>> getAvailableBrands() {
        try {
            List<String> brands = searchCarService.getAvailableBrands();
            return ResponseEntity.ok(brands);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    /**
     * API lấy danh sách loại truyền động
     * GET /api/cars/transmissions
     */
    @GetMapping("/transmissions")
    public ResponseEntity<List<String>> getTransmissionTypes() {
        try {
            List<String> types = searchCarService.getTransmissionTypes();
            return ResponseEntity.ok(types);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    /**
     * API lấy chi tiết xe theo ID
     * GET /api/cars/{id}
     */
    @GetMapping("/{id}")
    public ResponseEntity<Car> getCarById(@PathVariable Long id) {
        try {
            Car car = searchCarService.getCarById(id);
            if (car == null) {
                return ResponseEntity.notFound().build();
            }
            return ResponseEntity.ok(car);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    /**
     * API BỘ LỌC NÂNG CAO (ADVANCED FILTER)
     * POST /api/cars/advanced-filter
     * 
     * Body example:
     * {
     *   "sortBy": "price_low",
     *   "minPrice": 350000,
     *   "maxPrice": 3000000,
     *   "transmissionType": "Automatic",
     *   "minDailyKmLimit": 50,
     *   "maxDailyKmLimit": 500,
     *   "minExceedFee": 0,
     *   "maxExceedFee": 5000,
     *   "maxDistance": 50,
     *   "minSeatCapacity": 3,
     *   "maxSeatCapacity": 9,
     *   "minYear": 2008,
     *   "maxYear": 2024,
     *   "fuelType": "Gasoline",
     *   "minFuelConsumption": 1.0,
     *   "maxFuelConsumption": 30.0,
     *   "features": ["Bluetooth", "Camera 360"],
     *   "page": 0,
     *   "size": 10
     * }
     */
    @PostMapping("/advanced-filter")
    public ResponseEntity<Map<String, Object>> advancedFilter(@RequestBody AdvancedFilterRequest request) {
        try {
            List<Car> cars = advancedFilterService.applyAdvancedFilter(request);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Lọc thành công");
            response.put("cars", cars);
            response.put("totalCars", cars.size());
            response.put("filterCriteria", request);

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Lỗi khi lọc xe: " + e.getMessage());
            errorResponse.put("cars", null);
            
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }
}

