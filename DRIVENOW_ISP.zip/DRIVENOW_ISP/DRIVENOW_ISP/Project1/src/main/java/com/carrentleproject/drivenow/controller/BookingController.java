package com.carrentleproject.drivenow.controller;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.carrentleproject.drivenow.dto.BookingCancelRequest;
import com.carrentleproject.drivenow.dto.BookingCreateRequest;
import com.carrentleproject.drivenow.dto.BookingDTO;
import com.carrentleproject.drivenow.dto.BookingUpdateRequest;
import com.carrentleproject.drivenow.service.BookingService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/bookings")
@CrossOrigin(origins = "*")
public class BookingController {

    @Autowired
    private BookingService bookingService;

    // ==================== BOOKING CRUD ENDPOINTS ====================

    /**
     * POST /api/bookings - Tạo booking mới (Đặt xe)
     */
    @PostMapping
    public ResponseEntity<Map<String, Object>> createBooking(@Valid @RequestBody BookingCreateRequest request) {
        Map<String, Object> response = new HashMap<>();
        try {
            BookingDTO bookingDTO = bookingService.createBooking(request);
            response.put("success", true);
            response.put("message", "Đặt xe thành công");
            response.put("data", bookingDTO);
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (IllegalArgumentException e) {
            response.put("success", false);
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Đã xảy ra lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * PUT /api/bookings/{id} - Cập nhật booking (chỉ khi status = pending)
     */
    @PutMapping("/{id}")
    public ResponseEntity<Map<String, Object>> updateBooking(
            @PathVariable("id") Integer bookingId,
            @Valid @RequestBody BookingUpdateRequest request) {
        Map<String, Object> response = new HashMap<>();
        try {
            BookingDTO bookingDTO = bookingService.updateBooking(bookingId, request);
            response.put("success", true);
            response.put("message", "Cập nhật booking thành công");
            response.put("data", bookingDTO);
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            response.put("success", false);
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Đã xảy ra lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * GET /api/bookings/{id} - Lấy chi tiết booking
     */
    @GetMapping("/{id}")
    public ResponseEntity<Map<String, Object>> getBookingById(@PathVariable("id") Integer bookingId) {
        Map<String, Object> response = new HashMap<>();
        try {
            BookingDTO bookingDTO = bookingService.getBookingById(bookingId);
            response.put("success", true);
            response.put("message", "Lấy thông tin booking thành công");
            response.put("data", bookingDTO);
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            response.put("success", false);
            response.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Đã xảy ra lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * GET /api/bookings/customer/{customerId} - Lấy tất cả bookings của khách hàng
     */
    @GetMapping("/customer/{customerId}")
    public ResponseEntity<Map<String, Object>> getBookingsByCustomer(@PathVariable Integer customerId) {
        Map<String, Object> response = new HashMap<>();
        try {
            List<BookingDTO> bookings = bookingService.getBookingsByCustomer(customerId);
            response.put("success", true);
            response.put("message", "Lấy danh sách booking thành công");
            response.put("data", bookings);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Đã xảy ra lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * GET /api/bookings/car/{carId} - Lấy tất cả bookings của xe
     */
    @GetMapping("/car/{carId}")
    public ResponseEntity<Map<String, Object>> getBookingsByCar(@PathVariable Integer carId) {
        Map<String, Object> response = new HashMap<>();
        try {
            List<BookingDTO> bookings = bookingService.getBookingsByCar(carId);
            response.put("success", true);
            response.put("message", "Lấy danh sách booking của xe thành công");
            response.put("data", bookings);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Đã xảy ra lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * GET /api/bookings/customer/{customerId}/upcoming - Lấy bookings sắp tới
     */
    @GetMapping("/customer/{customerId}/upcoming")
    public ResponseEntity<Map<String, Object>> getUpcomingBookings(@PathVariable Integer customerId) {
        Map<String, Object> response = new HashMap<>();
        try {
            List<BookingDTO> bookings = bookingService.getUpcomingBookingsByCustomer(customerId);
            response.put("success", true);
            response.put("message", "Lấy danh sách booking sắp tới thành công");
            response.put("data", bookings);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Đã xảy ra lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * GET /api/bookings/customer/{customerId}/history - Lấy lịch sử booking
     */
    @GetMapping("/customer/{customerId}/history")
    public ResponseEntity<Map<String, Object>> getBookingHistory(@PathVariable Integer customerId) {
        Map<String, Object> response = new HashMap<>();
        try {
            List<BookingDTO> bookings = bookingService.getBookingHistoryByCustomer(customerId);
            response.put("success", true);
            response.put("message", "Lấy lịch sử booking thành công");
            response.put("data", bookings);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Đã xảy ra lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * GET /api/bookings - Lấy tất cả bookings (Admin)
     */
    @GetMapping
    public ResponseEntity<Map<String, Object>> getAllBookings(
            @RequestParam(required = false) String status) {
        Map<String, Object> response = new HashMap<>();
        try {
            List<BookingDTO> bookings;
            if (status != null && !status.isEmpty()) {
                bookings = bookingService.getBookingsByStatus(status);
            } else {
                bookings = bookingService.getAllBookings();
            }
            response.put("success", true);
            response.put("message", "Lấy danh sách booking thành công");
            response.put("data", bookings);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Đã xảy ra lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // ==================== BOOKING STATUS MANAGEMENT ====================

    /**
     * PATCH /api/bookings/{id}/confirm - Xác nhận booking (Admin)
     */
    @PatchMapping("/{id}/confirm")
    public ResponseEntity<Map<String, Object>> confirmBooking(@PathVariable("id") Integer bookingId) {
        Map<String, Object> response = new HashMap<>();
        try {
            BookingDTO bookingDTO = bookingService.confirmBooking(bookingId);
            response.put("success", true);
            response.put("message", "Xác nhận booking thành công");
            response.put("data", bookingDTO);
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            response.put("success", false);
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Đã xảy ra lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * PATCH /api/bookings/{id}/start - Bắt đầu chuyến đi
     */
    @PatchMapping("/{id}/start")
    public ResponseEntity<Map<String, Object>> startBooking(@PathVariable("id") Integer bookingId) {
        Map<String, Object> response = new HashMap<>();
        try {
            BookingDTO bookingDTO = bookingService.startBooking(bookingId);
            response.put("success", true);
            response.put("message", "Bắt đầu chuyến đi thành công");
            response.put("data", bookingDTO);
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            response.put("success", false);
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Đã xảy ra lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * PATCH /api/bookings/{id}/complete - Hoàn thành booking
     */
    @PatchMapping("/{id}/complete")
    public ResponseEntity<Map<String, Object>> completeBooking(@PathVariable("id") Integer bookingId) {
        Map<String, Object> response = new HashMap<>();
        try {
            BookingDTO bookingDTO = bookingService.completeBooking(bookingId);
            response.put("success", true);
            response.put("message", "Hoàn thành booking thành công");
            response.put("data", bookingDTO);
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            response.put("success", false);
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Đã xảy ra lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * PATCH /api/bookings/{id}/cancel - Hủy booking
     */
    @PatchMapping("/{id}/cancel")
    public ResponseEntity<Map<String, Object>> cancelBooking(
            @PathVariable("id") Integer bookingId,
            @Valid @RequestBody(required = false) BookingCancelRequest request) {
        Map<String, Object> response = new HashMap<>();
        try {
            String cancellationReason = request != null ? request.getCancellationReason() : null;
            BookingDTO bookingDTO = bookingService.cancelBooking(bookingId, cancellationReason);
            response.put("success", true);
            response.put("message", "Hủy booking thành công");
            response.put("data", bookingDTO);
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            response.put("success", false);
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Đã xảy ra lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // ============================================================
    // [EXTENSION FEATURE] - API gia hạn booking
    // Cho phép khách hàng gia hạn thêm thời gian thuê xe
    // ============================================================

    /**
     * PATCH /api/bookings/{id}/extend - Gia hạn booking
     */
    @PatchMapping("/{id}/extend")
    public ResponseEntity<Map<String, Object>> extendBooking(
            @PathVariable("id") Integer bookingId,
            @RequestBody Map<String, String> body) {
        Map<String, Object> response = new HashMap<>();
        try {
            String newReturnDateStr = body.get("newReturnDate");
            if (newReturnDateStr == null || newReturnDateStr.isEmpty()) {
                response.put("success", false);
                response.put("message", "New return date is required");
                return ResponseEntity.badRequest().body(response);
            }
            
            LocalDateTime newReturnDate = LocalDateTime.parse(newReturnDateStr);
            BookingDTO bookingDTO = bookingService.extendBooking(bookingId, newReturnDate);
            response.put("success", true);
            response.put("message", "Gia hạn booking thành công");
            response.put("data", bookingDTO);
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            response.put("success", false);
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Đã xảy ra lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }
    
    // ============================================================
    // [END EXTENSION FEATURE]
    // ============================================================

    /**
     * PATCH /api/bookings/{id}/payment - Cập nhật payment status
     */
    @PatchMapping("/{id}/payment")
    public ResponseEntity<Map<String, Object>> updatePaymentStatus(
            @PathVariable("id") Integer bookingId,
            @RequestBody Map<String, String> body) {
        Map<String, Object> response = new HashMap<>();
        try {
            String paymentStatus = body.get("paymentStatus");
            if (paymentStatus == null || paymentStatus.isEmpty()) {
                response.put("success", false);
                response.put("message", "Payment status is required");
                return ResponseEntity.badRequest().body(response);
            }
            
            BookingDTO bookingDTO = bookingService.updatePaymentStatus(bookingId, paymentStatus);
            response.put("success", true);
            response.put("message", "Cập nhật payment status thành công");
            response.put("data", bookingDTO);
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            response.put("success", false);
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Đã xảy ra lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // ==================== HELPER ENDPOINTS ====================

    /**
     * GET /api/bookings/check-availability - Kiểm tra xe có khả dụng không
     */
    @GetMapping("/check-availability")
    public ResponseEntity<Map<String, Object>> checkCarAvailability(
            @RequestParam Integer carId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime pickupDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime returnDate) {
        Map<String, Object> response = new HashMap<>();
        try {
            boolean isAvailable = bookingService.checkCarAvailability(carId, pickupDate, returnDate);
            response.put("success", true);
            response.put("message", isAvailable ? "Xe có sẵn" : "Xe không có sẵn trong thời gian này");
            response.put("data", Map.of("available", isAvailable));
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Đã xảy ra lỗi: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }
}
