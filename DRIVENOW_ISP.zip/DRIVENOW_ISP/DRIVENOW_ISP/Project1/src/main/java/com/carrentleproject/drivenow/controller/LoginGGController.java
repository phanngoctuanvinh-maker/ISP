package com.carrentleproject.drivenow.controller;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.carrentleproject.drivenow.config.JwtTokenProvider;
import com.carrentleproject.drivenow.dao.AccountDAO;
import com.carrentleproject.drivenow.dao.CustomerDAO;
import com.carrentleproject.drivenow.dto.ApiResponse;
import com.carrentleproject.drivenow.dto.AuthResponse;
import com.carrentleproject.drivenow.dto.GoogleLoginRequest;
import com.carrentleproject.drivenow.model.Account;
import com.carrentleproject.drivenow.model.Customer;
import com.carrentleproject.drivenow.service.GoogleService;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/auth")
public class LoginGGController {

    @Autowired
    private GoogleService googleService;

    @Autowired
    private AccountDAO accountDAO;

    @Autowired
    private CustomerDAO customerDAO;

    @Autowired
    private JwtTokenProvider jwtTokenProvider;

    @Autowired
    private PasswordEncoder passwordEncoder;

    /**
     * Google Login endpoint
     * Flow: Verify Google Token → Tìm/Tạo Account → Generate JWT
     */
    @PostMapping("/google-login")
    @Transactional
    public ResponseEntity<ApiResponse<AuthResponse>> googleLogin(@Valid @RequestBody GoogleLoginRequest request) {
        // 1. Verify Google ID Token
        GoogleIdToken.Payload payload = googleService.verifyGoogleToken(request.getIdToken());

        // 2. Lấy thông tin user từ Google
        String email = googleService.getEmailFromPayload(payload);
        String fullName = googleService.getNameFromPayload(payload);

        // 3. Kiểm tra user đã tồn tại chưa
        Account account = accountDAO.findByUsername(email).orElse(null);

        if (account == null) {
            // 4. Tạo account mới (auto-register)
            account = new Account();
            account.setUsername(email);
            // Generate random password (user sẽ không cần password vì login qua Google)
            account.setPassword(passwordEncoder.encode(UUID.randomUUID().toString()));
            account.setRole("customer");
            account.setStatus("active");
            account = accountDAO.save(account);

            // Tạo Customer profile
            Customer customer = new Customer();
            customer.setAccount(account);
            customer.setFullName(fullName != null ? fullName : "Google User");
            customer.setEmail(email);
            // Phone, address, dob, gender có thể null (sẽ cập nhật sau)
            customerDAO.save(customer);
        } else {
            // Kiểm tra account status
            if (!"active".equals(account.getStatus())) {
                return ResponseEntity.ok(
                        ApiResponse.error("Tài khoản đã bị khóa"));
            }
        }

        // 5. Generate JWT token
        String jwt = jwtTokenProvider.generateTokenFromUsername(account.getUsername());

        // 6. Lấy Customer info để trả về
        Customer customer = customerDAO.findByAccountAccountId(account.getAccountId())
                .orElse(null);
        String customerFullName = customer != null ? customer.getFullName() : fullName;

        AuthResponse response = new AuthResponse(
                jwt,
                account.getAccountId(),
                account.getUsername(),
                account.getRole(),
                customerFullName);
        response.setMessage("Đăng nhập Google thành công");

        return ResponseEntity.ok(ApiResponse.success("Đăng nhập Google thành công", response));
    }
}
