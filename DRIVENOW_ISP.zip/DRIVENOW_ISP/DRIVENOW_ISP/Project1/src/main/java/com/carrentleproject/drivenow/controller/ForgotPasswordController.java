package com.carrentleproject.drivenow.controller;

import com.carrentleproject.drivenow.dto.ApiResponse;
import com.carrentleproject.drivenow.dto.ForgotPasswordRequest;
import com.carrentleproject.drivenow.dto.ResetPasswordRequest;
import com.carrentleproject.drivenow.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class ForgotPasswordController {

    @Autowired
    private AuthService authService;

    /**
     * Bước 1: Gửi OTP về email
     */
    @PostMapping("/forgot-password")
    public ResponseEntity<ApiResponse<String>> forgotPassword(@Valid @RequestBody ForgotPasswordRequest request) {
        ApiResponse<String> response = authService.forgotPassword(request);
        return ResponseEntity.ok(response);
    }

    /**
     * Bước 2: Xác thực OTP và đặt lại mật khẩu mới
     */
    @PostMapping("/reset-password")
    public ResponseEntity<ApiResponse<String>> resetPassword(@Valid @RequestBody ResetPasswordRequest request) {
        ApiResponse<String> response = authService.resetPassword(request);
        return ResponseEntity.ok(response);
    }

    /**
     * Gửi lại OTP về email (resend)
     */
    @PostMapping("/resend-otp")
    public ResponseEntity<ApiResponse<String>> resendOtp(@RequestBody ForgotPasswordRequest request) {
        // Kiểm tra email có tồn tại không
        authService.forgotPassword(request);
        return ResponseEntity.ok(ApiResponse.success("Mã OTP mới đã được gửi lại email của bạn", null));
    }
}
