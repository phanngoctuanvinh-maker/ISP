package com.carrentleproject.drivenow.validation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

@Target({ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = ValidSeatsValidator.class)
public @interface ValidSeats {
    String message() default "Số chỗ ngồi chỉ được phép là 4 hoặc 7";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}
