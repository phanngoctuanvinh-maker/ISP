-- CẬP NHẬT ẢNH CHO CÁC XE
-- Sử dụng ảnh có sẵn trong thư mục assets/inmage

-- Toyota Vios - Trắng (ID 1)
UPDATE cars SET image_url = N'assets/inmage/image copy.png' WHERE id = 1;

-- Toyota Vios - Đen (ID 2)
UPDATE cars SET image_url = N'assets/inmage/image copy 2.png' WHERE id = 2;

-- Toyota Camry (ID 3)
UPDATE cars SET image_url = N'assets/inmage/image copy 3.png' WHERE id = 3;

-- Toyota Fortuner (ID 4)
UPDATE cars SET image_url = N'assets/inmage/image copy 4.png' WHERE id = 4;

-- Toyota Innova (ID 5)
UPDATE cars SET image_url = N'assets/inmage/image copy 5.png' WHERE id = 5;

-- Toyota Corolla Cross (ID 6)
UPDATE cars SET image_url = N'assets/inmage/image copy 6.png' WHERE id = 6;

-- Honda City - Trắng (ID 7)
UPDATE cars SET image_url = N'assets/inmage/image copy 7.png' WHERE id = 7;

-- Honda City - Đỏ (ID 8)
UPDATE cars SET image_url = N'assets/inmage/image copy 8.png' WHERE id = 8;

-- Honda Civic (ID 9)
UPDATE cars SET image_url = N'assets/inmage/image copy 9.png' WHERE id = 9;

-- Honda CR-V (ID 10)
UPDATE cars SET image_url = N'assets/inmage/image copy 10.png' WHERE id = 10;

-- Honda BR-V (ID 11)
UPDATE cars SET image_url = N'assets/inmage/image copy 11.png' WHERE id = 11;

-- Honda Accord (ID 12)
UPDATE cars SET image_url = N'assets/inmage/image copy 12.png' WHERE id = 12;

-- Mazda 2 (ID 13)
UPDATE cars SET image_url = N'assets/inmage/image copy 13.png' WHERE id = 13;

-- Mazda 3 (ID 14)
UPDATE cars SET image_url = N'assets/inmage/image copy 14.png' WHERE id = 14;

-- Mazda CX-5 Đỏ (ID 15)
UPDATE cars SET image_url = N'assets/inmage/image copy 15.png' WHERE id = 15;

-- Mazda CX-5 Trắng (ID 16)
UPDATE cars SET image_url = N'assets/inmage/image copy 16.png' WHERE id = 16;

-- Mazda CX-8 (ID 17)
UPDATE cars SET image_url = N'assets/inmage/image copy 17.png' WHERE id = 17;

-- Ford Ranger (ID 18)
UPDATE cars SET image_url = N'assets/inmage/image copy 18.png' WHERE id = 18;

-- Ford Everest (ID 19)
UPDATE cars SET image_url = N'assets/inmage/pexels-leventsimsek-3616649.jpg' WHERE id = 19;

-- Ford Territory (ID 20)
UPDATE cars SET image_url = N'assets/inmage/pexels-sarmad-mughal-94606-305070.jpg' WHERE id = 20;

-- Kia Seltos (ID 21)
UPDATE cars SET image_url = N'assets/inmage/OIP.jpeg' WHERE id = 21;

-- Kia Sorento (ID 22)
UPDATE cars SET image_url = N'assets/inmage/OIP (1).jpeg' WHERE id = 22;

-- Kia Carnival (ID 23)
UPDATE cars SET image_url = N'assets/inmage/OIP (2).jpeg' WHERE id = 23;

-- Hyundai Accent (ID 24)
UPDATE cars SET image_url = N'assets/inmage/free-photo-of-bi-n-phong-c-nh-thien-nhien-xe.jpeg' WHERE id = 24;

-- Hyundai Tucson (ID 25)
UPDATE cars SET image_url = N'assets/inmage/car-8745689_1280.jpg' WHERE id = 25;

-- Hyundai Santa Fe (ID 26)
UPDATE cars SET image_url = N'assets/inmage/b00d0cdbf06fab3b2d8cc6847a014495.jpg' WHERE id = 26;

-- Hyundai Stargazer (ID 27)
UPDATE cars SET image_url = N'assets/inmage/R.jpeg' WHERE id = 27;

-- VinFast VF5 (ID 28)
UPDATE cars SET image_url = N'assets/inmage/OIP.webp' WHERE id = 28;

-- VinFast VF8 (ID 29)
UPDATE cars SET image_url = N'assets/inmage/OIP (1).webp' WHERE id = 29;

-- VinFast VF9 (ID 30)
UPDATE cars SET image_url = N'assets/inmage/image.png' WHERE id = 30;

PRINT N'✅ Đã cập nhật ảnh cho 30 xe thành công!';

-- Kiểm tra kết quả
SELECT id, name, image_url FROM cars ORDER BY id;
