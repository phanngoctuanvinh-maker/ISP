-- ===================================================================
-- FIX: Thay đổi fuel_type từ "Điện" (Unicode 272) sang "Điện" hoặc "Dien"
-- Vì JPA không thể match đúng ký tự Unicode 272 từ database
-- ===================================================================

-- Cách 1: Đổi thành chữ không dấu (đơn giản nhất, không lo encoding)
UPDATE cars 
SET fuel_type = N'Dien'  
WHERE brand = N'VinFast';

-- Kiểm tra kết quả
SELECT id, brand, name, fuel_type, LEN(fuel_type) as length 
FROM cars 
WHERE brand = N'VinFast';

PRINT '✅ Đã đổi fuel_type VinFast thành "Dien" (không dấu)';
PRINT 'Giờ query: WHERE c.fuelType = ''Dien'' sẽ work!';
