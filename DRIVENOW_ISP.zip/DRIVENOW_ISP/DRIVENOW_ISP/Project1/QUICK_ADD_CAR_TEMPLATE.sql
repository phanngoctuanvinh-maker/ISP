-- ========================================
-- TEMPLATE NHANH - THÊM 1 XE MỚI
-- Copy template này và điền thông tin xe
-- ========================================

USE drivenow_db;
GO

-- ========================================
-- BƯỚC 1: CHỌN LOẠI XE BẠN MUỐN THÊM
-- ========================================

-- ⭐ TEMPLATE 1: XE XĂNG CƠ BẢN (Gasoline - Phổ biến nhất)
INSERT INTO cars (
    brand,                -- Hãng xe: Toyota, Honda, Mazda, Ford, Kia, Hyundai, Vinfast, Mitsubishi
    model,                -- Dòng xe: Vios, City, CX-5, Ranger, v.v.
    name,                 -- Tên đầy đủ: "Toyota Vios 2024"
    year,                 -- Năm: 2024, 2023, 2022...
    color,                -- Màu: Trắng, Đen, Đỏ, Xanh, Bạc, Xám...
    car_type,             -- Loại: Mini, Sedan, SUV, MPV, Pickup, Minivan
    seat_capacity,        -- Số chỗ: 4, 5, 7
    fuel_type,            -- Nhiên liệu: Gasoline, Diesel, Electric, Hybrid
    transmission_type,    -- Hộp số: Automatic, Manual
    price_per_day,        -- Giá/ngày (VNĐ): 450000, 650000, 900000...
    description,          -- Mô tả ngắn
    status,               -- Trạng thái: Available, Rented, Maintenance
    license_plate,        -- Biển số: 30A-12345 (PHẢI DUY NHẤT!)
    location,             -- Địa điểm: Hà Nội, TP.HCM, Đà Nẵng...
    created_at,
    updated_at
) VALUES (
    'Toyota',                                    -- ✏️ Đổi hãng xe
    'Vios',                                      -- ✏️ Đổi dòng xe
    'Toyota Vios 2024',                          -- ✏️ Đổi tên
    2024,                                        -- ✏️ Đổi năm
    'Trắng',                                     -- ✏️ Đổi màu
    'Sedan',                                     -- ✏️ Chọn: Mini/Sedan/SUV/MPV/Pickup/Minivan
    4,                                           -- ✏️ Số chỗ: 4/5/7
    'Gasoline',                                  -- ✏️ Nhiên liệu: Gasoline/Diesel/Electric/Hybrid
    'Automatic',                                 -- ✏️ Hộp số: Automatic/Manual
    450000,                                      -- ✏️ Giá thuê/ngày (VNĐ)
    'Sedan tiết kiệm nhiên liệu, phù hợp đi phố', -- ✏️ Mô tả
    'Available',                                 -- ✏️ Available/Rented/Maintenance
    '30A-XXXXX',                                 -- ✏️ ĐỔI BIỂN SỐ (PHẢI UNIQUE!)
    'Hà Nội',                                    -- ✏️ Địa điểm
    GETDATE(),
    GETDATE()
);

-- ⭐ TEMPLATE 2: XE CÓ ĐẦY ĐỦ THÔNG TIN (Có giới hạn km, phí vượt km, tiêu thụ nhiên liệu)
/*
INSERT INTO cars (
    brand, model, name, year, color, 
    car_type, seat_capacity, fuel_type, transmission_type,
    price_per_day, description, image_url, status,
    license_plate, insurance_info, location,
    daily_km_limit,        -- Giới hạn km/ngày (NULL = không giới hạn)
    exceed_fee_per_km,     -- Phí vượt km (VNĐ/km)
    fuel_consumption,      -- Tiêu thụ nhiên liệu (L/100km)
    created_at, updated_at
) VALUES (
    'Honda',                                      -- ✏️ Hãng
    'Civic',                                      -- ✏️ Dòng
    'Honda Civic 2024',                           -- ✏️ Tên
    2024,                                         -- ✏️ Năm
    'Xanh dương',                                 -- ✏️ Màu
    'Sedan',                                      -- ✏️ Loại
    5,                                            -- ✏️ Số chỗ
    'Gasoline',                                   -- ✏️ Nhiên liệu
    'Automatic',                                  -- ✏️ Hộp số
    680000,                                       -- ✏️ Giá/ngày
    'Sedan thể thao, thiết kế trẻ trung',        -- ✏️ Mô tả
    'https://example.com/civic.jpg',             -- ✏️ Link ảnh (hoặc để trống)
    'Available',                                  -- ✏️ Trạng thái
    '30B-XXXXX',                                  -- ✏️ Biển số (UNIQUE!)
    'Bảo hiểm đầy đủ',                           -- ✏️ Bảo hiểm
    'Hà Nội',                                     -- ✏️ Địa điểm
    300,                                          -- ✏️ Giới hạn 300km/ngày
    5000,                                         -- ✏️ Phí vượt 5000đ/km
    6.5,                                          -- ✏️ Tiêu thụ 6.5L/100km
    GETDATE(),
    GETDATE()
);
*/

-- ⭐ TEMPLATE 3: XE ĐIỆN (Electric Car)
/*
INSERT INTO cars (
    brand, model, name, year, color, 
    car_type, seat_capacity, fuel_type, transmission_type,
    price_per_day, description, status,
    license_plate, location,
    fuel_consumption,      -- Xe điện = 0
    created_at, updated_at
) VALUES (
    'Vinfast',                                    -- ✏️ Hãng
    'VF8',                                        -- ✏️ Dòng
    'Vinfast VF8 2024',                           -- ✏️ Tên
    2024,                                         -- ✏️ Năm
    'Xanh lá',                                    -- ✏️ Màu
    'SUV',                                        -- ✏️ Loại
    5,                                            -- ✏️ Số chỗ
    'Electric',                                   -- ✏️ Nhiên liệu = Electric
    'Automatic',                                  -- ✏️ Hộp số
    900000,                                       -- ✏️ Giá/ngày
    'SUV điện 5 chỗ, tầm hoạt động 400km',       -- ✏️ Mô tả
    'Available',                                  -- ✏️ Trạng thái
    '30G-XXXXX',                                  -- ✏️ Biển số (UNIQUE!)
    'Hà Nội',                                     -- ✏️ Địa điểm
    0,                                            -- ✏️ Xe điện = 0
    GETDATE(),
    GETDATE()
);
*/

-- ⭐ TEMPLATE 4: XE HYBRID (Xăng & Điện)
/*
INSERT INTO cars (
    brand, model, name, year, color, 
    car_type, seat_capacity, fuel_type, transmission_type,
    price_per_day, description, status,
    license_plate, location,
    fuel_consumption,      -- Hybrid thường 4-6 L/100km
    created_at, updated_at
) VALUES (
    'Toyota',                                     -- ✏️ Hãng
    'RAV4',                                       -- ✏️ Dòng
    'Toyota RAV4 Hybrid 2024',                    -- ✏️ Tên
    2024,                                         -- ✏️ Năm
    'Xám',                                        -- ✏️ Màu
    'SUV',                                        -- ✏️ Loại
    5,                                            -- ✏️ Số chỗ
    'Hybrid',                                     -- ✏️ Nhiên liệu = Hybrid
    'Automatic',                                  -- ✏️ Hộp số
    950000,                                       -- ✏️ Giá/ngày
    'SUV hybrid tiết kiệm, an toàn',             -- ✏️ Mô tả
    'Available',                                  -- ✏️ Trạng thái
    '30A-XXXXX',                                  -- ✏️ Biển số (UNIQUE!)
    'Hà Nội',                                     -- ✏️ Địa điểm
    4.8,                                          -- ✏️ Tiêu thụ thấp
    GETDATE(),
    GETDATE()
);
*/

-- ========================================
-- BƯỚC 2: KIỂM TRA XE VỪA THÊM
-- ========================================

-- Xem xe mới nhất
SELECT TOP 5 * FROM cars ORDER BY created_at DESC;

-- Kiểm tra biển số có bị trùng không
SELECT license_plate, COUNT(*) as count
FROM cars
GROUP BY license_plate
HAVING COUNT(*) > 1;

-- ========================================
-- GHI CHÚ QUAN TRỌNG
-- ========================================

/*
✅ CÁC TRƯỜNG BẮT BUỘC (KHÔNG ĐƯỢC BỎ TRỐNG):
   - brand (hãng xe)
   - model (dòng xe)
   - seat_capacity (số chỗ ngồi)
   - price_per_day (giá thuê/ngày)

⚠️ BIỂN SỐ XE (license_plate) PHẢI DUY NHẤT!
   Nếu trùng sẽ báo lỗi

📊 LOẠI XE (car_type):
   - Mini       : Xe nhỏ 4 chỗ (Mazda 2, Kia Morning)
   - Sedan      : Xe sedan 4-5 chỗ (Vios, City, Camry)
   - SUV        : Xe gầm cao 5-7 chỗ (CR-V, Fortuner)
   - MPV        : Xe gia đình 7 chỗ gầm thấp (Innova, Xpander)
   - Pickup     : Xe bán tải (Ranger, Colorado)
   - Minivan    : Xe 7-9 chỗ cao cấp (Carnival)

⛽ LOẠI NHIÊN LIỆU (fuel_type):
   - Gasoline   : Xăng (phổ biến nhất)
   - Diesel     : Dầu diesel
   - Electric   : Điện
   - Hybrid     : Xăng & Điện

🎛️ HỘP SỐ (transmission_type):
   - Automatic  : Số tự động
   - Manual     : Số sàn

💰 GIÁ THAM KHẢO (price_per_day):
   - Xe phổ thông 4 chỗ:  350,000 - 550,000 VNĐ
   - Xe sedan 5 chỗ:      500,000 - 800,000 VNĐ
   - SUV 5 chỗ:           600,000 - 1,000,000 VNĐ
   - SUV 7 chỗ:           800,000 - 1,500,000 VNĐ
   - Xe điện:             900,000 - 2,500,000 VNĐ
   - Xe sang:             1,500,000 - 3,000,000 VNĐ
*/

-- ========================================
-- VÍ DỤ THỰC TÊ - COPY VÀ CHẠY LUÔN
-- ========================================

-- Thêm Toyota Fortuner 2024
/*
INSERT INTO cars (
    brand, model, name, year, color, 
    car_type, seat_capacity, fuel_type, transmission_type,
    price_per_day, description, status, license_plate, location,
    created_at, updated_at
) VALUES (
    'Toyota', 'Fortuner', 'Toyota Fortuner 2024', 2024, 'Trắng',
    'SUV', 7, 'Diesel', 'Automatic',
    900000, 'SUV 7 chỗ mạnh mẽ, phù hợp đi xa', 'Available', '30A-99999', 'Hà Nội',
    GETDATE(), GETDATE()
);
*/

-- Thêm Mazda CX-5 2024
/*
INSERT INTO cars (
    brand, model, name, year, color, 
    car_type, seat_capacity, fuel_type, transmission_type,
    price_per_day, description, status, license_plate, location,
    created_at, updated_at
) VALUES (
    'Mazda', 'CX-5', 'Mazda CX-5 2024', 2024, 'Đỏ pha lê',
    'SUV', 5, 'Gasoline', 'Automatic',
    700000, 'SUV 5 chỗ thiết kế đẹp', 'Available', '30C-88888', 'Hà Nội',
    GETDATE(), GETDATE()
);
*/

PRINT '✅ Sẵn sàng thêm xe! Uncomment template bên trên và chạy!';
GO
