-- ========================================
-- SCRIPT CẬP NHẬT DỮ LIỆU SANG TIẾNG VIỆT
-- Chạy script này để update tất cả dữ liệu sang tiếng Việt
-- ========================================

USE drivenow_db;
GO

PRINT '========================================';
PRINT 'BẮT ĐẦU CẬP NHẬT DỮ LIỆU SANG TIẾNG VIỆT';
PRINT '========================================';
PRINT '';

-- ========================================
-- BƯỚC 1: CẬP NHẬT FUEL_TYPE (NHIÊN LIỆU)
-- ========================================

PRINT '[1/3] Cập nhật fuel_type sang tiếng Việt...';

UPDATE cars SET fuel_type = N'Xăng' 
WHERE LOWER(fuel_type) IN ('gasoline', 'petrol', 'xang');

UPDATE cars SET fuel_type = N'Dầu diesel' 
WHERE LOWER(fuel_type) IN ('diesel', 'dau diesel', 'dầu');

UPDATE cars SET fuel_type = N'Điện' 
WHERE LOWER(fuel_type) IN ('electric', 'dien', 'điện');

UPDATE cars SET fuel_type = N'Hybrid (Xăng + Điện)' 
WHERE LOWER(fuel_type) IN ('hybrid', 'hybrid (xăng + điện)', 'xăng + điện');

PRINT '✅ Đã cập nhật fuel_type';
GO

-- ========================================
-- BƯỚC 2: CẬP NHẬT TRANSMISSION_TYPE (HỘP SỐ)
-- ========================================

PRINT '[2/3] Cập nhật transmission_type sang tiếng Việt...';

UPDATE cars SET transmission_type = N'Tự động' 
WHERE LOWER(transmission_type) IN ('automatic', 'auto', 'tự động', 'tu dong');

UPDATE cars SET transmission_type = N'Số sàn' 
WHERE LOWER(transmission_type) IN ('manual', 'số sàn', 'so san');

PRINT '✅ Đã cập nhật transmission_type';
GO

-- ========================================
-- BƯỚC 3: CẬP NHẬT STATUS (TRẠNG THÁI)
-- ========================================

PRINT '[3/3] Cập nhật status sang tiếng Việt...';

UPDATE cars SET status = N'Có sẵn' 
WHERE LOWER(status) IN ('available', 'có sẵn', 'co san');

UPDATE cars SET status = N'Đã thuê' 
WHERE LOWER(status) IN ('rented', 'đã thuê', 'da thue');

UPDATE cars SET status = N'Bảo trì' 
WHERE LOWER(status) IN ('maintenance', 'bảo trì', 'bao tri');

PRINT '✅ Đã cập nhật status';
GO

-- ========================================
-- KIỂM TRA KẾT QUẢ
-- ========================================

PRINT '';
PRINT '========================================';
PRINT 'KẾT QUẢ CẬP NHẬT';
PRINT '========================================';
PRINT '';

-- Thống kê nhiên liệu
PRINT 'NHIÊN LIỆU (FUEL_TYPE):';
SELECT fuel_type as N'Loại nhiên liệu', COUNT(*) as N'Số lượng'
FROM cars
GROUP BY fuel_type
ORDER BY COUNT(*) DESC;
PRINT '';

-- Thống kê hộp số
PRINT 'HỘP SỐ (TRANSMISSION_TYPE):';
SELECT transmission_type as N'Loại hộp số', COUNT(*) as N'Số lượng'
FROM cars
GROUP BY transmission_type
ORDER BY COUNT(*) DESC;
PRINT '';

-- Thống kê trạng thái
PRINT 'TRẠNG THÁI (STATUS):';
SELECT status as N'Trạng thái', COUNT(*) as N'Số lượng'
FROM cars
GROUP BY status
ORDER BY COUNT(*) DESC;
PRINT '';

PRINT '========================================';
PRINT '✅ HOÀN THÀNH CẬP NHẬT TIẾNG VIỆT!';
PRINT '========================================';
PRINT '';
PRINT 'Bước tiếp theo:';
PRINT '1. Restart backend: cd Project1; .\start-backend.bat';
PRINT '2. Test API: http://localhost:8080/api/cars/all';
PRINT '3. Kiểm tra frontend: DriveNow/html/searchcar.html';
PRINT '';

GO
