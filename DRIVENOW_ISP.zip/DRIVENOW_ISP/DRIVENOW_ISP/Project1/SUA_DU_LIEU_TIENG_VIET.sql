-- ========================================
-- SCRIPT SỬA DỮ LIỆU TIẾNG VIỆT
-- Chỉ update DATA, không sửa cấu trúc bảng
-- ========================================

USE drivenow_db;
GO

PRINT '========================================';
PRINT 'BẮT ĐẦU SỬA DỮ LIỆU TIẾNG VIỆT';
PRINT '========================================';
PRINT '';

-- ========================================
-- 1. SỬA NHIÊN LIỆU (fuel_type)
-- ========================================

PRINT '[1/4] Sửa fuel_type (Nhiên liệu)...';

UPDATE cars SET fuel_type = N'Xăng' 
WHERE LOWER(fuel_type) IN ('gasoline', 'petrol', 'xang');

UPDATE cars SET fuel_type = N'Dầu diesel' 
WHERE LOWER(fuel_type) IN ('diesel', 'dau', 'dầu');

UPDATE cars SET fuel_type = N'Điện' 
WHERE LOWER(fuel_type) IN ('electric', 'dien');

UPDATE cars SET fuel_type = N'Hybrid (Xăng + Điện)' 
WHERE LOWER(fuel_type) LIKE '%hybrid%';

PRINT '✅ Đã sửa fuel_type';
GO

-- ========================================
-- 2. SỬA HỘP SỐ (transmission_type)
-- ========================================

PRINT '[2/4] Sửa transmission_type (Hộp số)...';

UPDATE cars SET transmission_type = N'Tự động' 
WHERE LOWER(transmission_type) IN ('automatic', 'auto');

UPDATE cars SET transmission_type = N'Số sàn' 
WHERE LOWER(transmission_type) IN ('manual');

PRINT '✅ Đã sửa transmission_type';
GO

-- ========================================
-- 3. SỬA TRẠNG THÁI (status)
-- ========================================

PRINT '[3/4] Sửa status (Trạng thái)...';

UPDATE cars SET status = N'Có sẵn' 
WHERE LOWER(status) IN ('available', 'co san');

UPDATE cars SET status = N'Đã thuê' 
WHERE LOWER(status) IN ('rented', 'da thue');

UPDATE cars SET status = N'Bảo trì' 
WHERE LOWER(status) IN ('maintenance', 'bao tri');

PRINT '✅ Đã sửa status';
GO

-- ========================================
-- 4. SỬA MÔ TẢ TIẾNG VIỆT (description)
-- ========================================

PRINT '[4/4] Sửa description (Mô tả)...';

-- Sửa các từ tiếng Anh thông dụng trong mô tả
UPDATE cars SET description = REPLACE(description, 'SUV', N'SUV')
WHERE description LIKE '%SUV%';

UPDATE cars SET description = REPLACE(description, 'Sedan', N'Sedan')
WHERE description LIKE '%Sedan%';

PRINT '✅ Đã sửa description';
GO

-- ========================================
-- KIỂM TRA KẾT QUẢ
-- ========================================

PRINT '';
PRINT '========================================';
PRINT 'KẾT QUẢ SAU KHI SỬA';
PRINT '========================================';
PRINT '';

PRINT 'NHIÊN LIỆU:';
SELECT fuel_type AS N'Loại nhiên liệu', COUNT(*) AS N'Số lượng'
FROM cars
GROUP BY fuel_type
ORDER BY COUNT(*) DESC;
PRINT '';

PRINT 'HỘP SỐ:';
SELECT transmission_type AS N'Loại hộp số', COUNT(*) AS N'Số lượng'
FROM cars
GROUP BY transmission_type
ORDER BY COUNT(*) DESC;
PRINT '';

PRINT 'TRẠNG THÁI:';
SELECT status AS N'Trạng thái', COUNT(*) AS N'Số lượng'
FROM cars
GROUP BY status
ORDER BY COUNT(*) DESC;
PRINT '';

PRINT 'MẪU DỮ LIỆU (5 xe đầu):';
SELECT TOP 5 
    id,
    brand AS N'Hãng',
    name AS N'Tên xe',
    fuel_type AS N'Nhiên liệu',
    transmission_type AS N'Hộp số',
    status AS N'Trạng thái'
FROM cars
ORDER BY id;
PRINT '';

PRINT '========================================';
PRINT '✅ HOÀN THÀNH SỬA DỮ LIỆU!';
PRINT '========================================';
PRINT '';
PRINT 'Bước tiếp theo:';
PRINT '1. Restart backend: cd Project1; .\start-backend.bat';
PRINT '2. Test API: http://localhost:8080/api/cars/all';
PRINT '';

GO
