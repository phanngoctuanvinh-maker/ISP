# 🇻🇳 SỬA TIẾNG VIỆT CHO DRIVENOW - HƯỚNG DẪN NHANH

## ⚡ 3 BƯỚC ĐƠN GIẢN

### **BƯỚC 1: Chạy SQL Script** (5 phút)
```
1. Mở SQL Server Management Studio (SSMS)
2. Kết nối: localhost (sa/12345)
3. Mở file: Project1/fix_vietnamese_encoding.sql
4. Nhấn F5 (Execute)
5. Chờ "✅ HOÀN THÀNH!" xuất hiện
```

### **BƯỚC 2: Restart Backend** (1 phút)
```powershell
# Dừng server hiện tại (Ctrl+C)
cd Project1
.\start-backend.bat
```

### **BƯỚC 3: Kiểm tra** (2 phút)
```powershell
# Chạy script test tự động
.\test-tieng-viet.bat
```

**HOẶC** test thủ công:
- Mở trình duyệt: http://localhost:8080/api/cars/all
- Kiểm tra thấy: `"fuelType": "Xăng"`, `"transmissionType": "Tự động"`

---

## 🎯 KẾT QUẢ

### ✅ TRƯỚC KHI SỬA:
```json
{
  "fuelType": "Gasoline",
  "transmissionType": "Automatic",
  "description": "Sedan ti?t ki?m nhi�n li?u"
}
```

### ✅ SAU KHI SỬA:
```json
{
  "fuelType": "Xăng",
  "transmissionType": "Tự động",
  "description": "Sedan tiết kiệm nhiên liệu, phù hợp đi phố"
}
```

---

## 📝 LƯU Ý QUAN TRỌNG

### **Khi thêm xe mới:**
```sql
-- ❌ SAI - thiếu N
INSERT INTO cars (brand, fuel_type) 
VALUES ('Toyota', 'Xăng');

-- ✅ ĐÚNG - có N trước string tiếng Việt
INSERT INTO cars (brand, fuel_type) 
VALUES (N'Toyota', N'Xăng');
```

### **Giá trị chuẩn:**
- **Nhiên liệu:** `Xăng`, `Dầu diesel`, `Điện`, `Hybrid (Xăng + Điện)`
- **Hộp số:** `Tự động`, `Số sàn`
- **Trạng thái:** `Có sẵn`, `Đã thuê`, `Bảo trì`

---

## 🔧 TROUBLESHOOTING

### **Vấn đề: Vẫn thấy "????" hoặc ký tự lỗi**
**Giải pháp:**
1. Kiểm tra đã chạy script SQL chưa?
2. Restart backend sau khi chạy SQL
3. Xóa cache trình duyệt (Ctrl+Shift+Del)

### **Vấn đề: API trả về rỗng**
**Giải pháp:**
```sql
-- Kiểm tra dữ liệu trong database
USE drivenow_db;
SELECT COUNT(*) FROM cars;
-- Phải thấy: 30 xe
```

### **Vấn đề: Lỗi khi chạy SQL script**
**Giải pháp:**
- Đảm bảo database `drivenow_db` đã tồn tại
- Kiểm tra quyền user `sa`

---

## 📚 TÀI LIỆU CHI TIẾT

- **Chi tiết:** `HUONG_DAN_SUA_TIENG_VIET.md`
- **Tổng kết:** `TONG_KET_SUA_TIENG_VIET.md`
- **Script SQL:** `Project1/fix_vietnamese_encoding.sql`

---

## ✨ 30 XE MẪU ĐÃ ĐƯỢC THÊM

| Hãng | Số lượng | Đặc biệt |
|------|----------|----------|
| Toyota | 6 | Vios, Camry, Fortuner, Innova, Corolla Cross |
| Honda | 5 | City, Civic, CR-V, BR-V |
| Mazda | 5 | 2, 3, CX-5, CX-8 |
| Ford | 3 | Ranger, Everest, Territory |
| Kia | 3 | Seltos, Sorento, Carnival |
| Hyundai | 4 | Accent, Tucson, Santa Fe, Stargazer |
| **VinFast** | **3** | **VF5, VF8, VF9 (Xe điện)** ⚡ |
| Mitsubishi | 1 | Outlander PHEV (Hybrid) 🔋 |

**TỔNG:** 30 xe - Đa dạng loại, nhiên liệu, giá cả

---

**🎉 HOÀN THÀNH! Hệ thống giờ 100% tiếng Việt!**

📧 Có vấn đề? Xem file `HUONG_DAN_SUA_TIENG_VIET.md`
