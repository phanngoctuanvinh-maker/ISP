# 🧪 TEST NHANH TRANG CHI TIẾT XE

## 🚀 QUICK START

### Bước 1: Start Backend (nếu chưa chạy)
```cmd
cd Project1
mvnw.cmd spring-boot:run
```

### Bước 2: Mở trang tìm kiếm
```
http://127.0.0.1:5500/DriveNow/html/searchcar.html
```

### Bước 3: Click vào bất kỳ xe nào
```
Click "Thuê xe" → Tự động chuyển sang cardetail.html?id={id}
```

---

## 📋 TEST SCENARIOS

### ✅ Test 1: Xe thường (Toyota Vios)
**URL**: `http://127.0.0.1:5500/DriveNow/html/cardetail.html?id=1`

**Expected Results:**
- ✅ Title: "Toyota Toyota Vios 2024 - Trắng 2024"
- ✅ Price: "450,000đ/ngày"
- ✅ Đặc điểm:
  - Truyền động: Tự động
  - Số ghế: 4 chỗ
  - Nhiên liệu: Xăng
  - Loại xe: Sedan
  - Màu sắc: Trắng
  - Km đã đi: 15,000 km
- ✅ Thông tin lộ trình:
  - Giới hạn km/ngày: 300 km
  - Phí vượt giới hạn: 3,000đ/km
  - Mức tiêu thụ: 6.5 L/100km

---

### ✅ Test 2: Xe điện (VinFast VF5)
**URL**: `http://127.0.0.1:5500/DriveNow/html/cardetail.html?id=34`

**Expected Results:**
- ✅ Title: "VinFast VinFast VF5 Plus 2024 2024"
- ✅ Price: "550,000đ/ngày"
- ✅ Đặc điểm:
  - Nhiên liệu: Điện ⚡
- ✅ Thông tin lộ trình (ĐẶC BIỆT):
  - Giới hạn km/ngày: **KHÔNG GIỚI HẠN** (màu xanh) ✅
  - Phí vượt giới hạn: **MIỄN PHÍ** (màu xanh) ✅
  - Mức tiêu thụ: 0 L/100km (xe điện)

---

### ✅ Test 3: Xe điện khác
**VinFast VF8**: `cardetail.html?id=35`  
**VinFast VF9**: `cardetail.html?id=36`

**Expected**: Giống Test 2, unlimited km + miễn phí ✅

---

### ❌ Test 4: ID không tồn tại
**URL**: `http://127.0.0.1:5500/DriveNow/html/cardetail.html?id=999`

**Expected**:
- Alert: "Không thể tải thông tin xe. Vui lòng thử lại!"
- Không redirect (chỉ alert)

---

### ❌ Test 5: Không có ID
**URL**: `http://127.0.0.1:5500/DriveNow/html/cardetail.html`

**Expected**:
- Alert: "Không tìm thấy ID xe!"
- Redirect về: `searchcar.html`

---

## 🎮 TEST INTERACTIVE FEATURES

### Test 6: Nút Share
1. Click icon Share (mũi tên)
2. **Expected**: Alert "Chức năng chia sẻ đang được phát triển!"

### Test 7: Nút Favorite (❤️)
1. Click icon Heart
2. **Expected**: Icon đổi từ ❤️ (outline) → ❤️ (solid red)
3. Click lại → Đổi về ❤️ (outline)

### Test 8: Nút "Xem tất cả ảnh"
1. Click "Xem tất cả ảnh"
2. **Expected**: Alert "Chức năng xem ảnh đang được phát triển!"

### Test 9: Link "Báo cáo xe này"
1. Scroll xuống cuối trang
2. Click "🚩 Báo cáo xe này"
3. **Expected**: Alert "Chức năng báo cáo đang được phát triển!"

### Test 10: Radio Lộ trình
1. Click "Nội thành"
   - **Expected**: Hiển thị "Điểm đón: Tân Sơn Nhất", ẩn input điểm đến
2. Click "Liên tỉnh"
   - **Expected**: Hiển thị input "Nhập địa điểm cụ thể"
3. Click "Liên tỉnh (1 chiều)"
   - **Expected**: Giống "Liên tỉnh"

---

## 🧪 TEST API TRỰC TIẾP (PowerShell)

### Test API xe thường:
```powershell
curl http://localhost:8080/api/cars/1 | ConvertFrom-Json | Format-List
```

### Test API xe điện:
```powershell
curl http://localhost:8080/api/cars/34 | ConvertFrom-Json | Format-List id, brand, name, pricePerDay, fuelType, dailyKmLimit, exceedFeePerKm, fuelConsumption
```

**Expected VinFast Data:**
```
id              : 34
brand           : VinFast
name            : VinFast VF5 Plus 2024
pricePerDay     : 550000.00
fuelType        : Điện
dailyKmLimit    :           ← NULL (unlimited)
exceedFeePerKm  : 0         ← Free
fuelConsumption : 0.00      ← Electric
```

---

## 📸 SCREENSHOT CHECKLIST

### Desktop View:
- [ ] Header với tabs "Đặc điểm" / "Chủ xe"
- [ ] Image gallery (1 main + 3 thumbnails)
- [ ] Car title + subtitle (location, rating)
- [ ] Features grid (6 items with icons)
- [ ] Description section
- [ ] Amenities grid (7 items)
- [ ] Terms & Conditions
- [ ] Cancellation Policy table
- [ ] Reviews section
- [ ] Owner profile card
- [ ] Booking card (sticky sidebar)
- [ ] Report link at bottom

### Mobile View (< 768px):
- [ ] Single column layout
- [ ] Image gallery stacked
- [ ] Booking card below content
- [ ] All sections responsive

---

## ✅ SUCCESS CRITERIA

### Functional:
- ✅ Fetch data from `/api/cars/{id}`
- ✅ Render car name, price, location
- ✅ Display all features (6 items)
- ✅ Display amenities (7 items)
- ✅ Show booking info correctly
- ✅ VinFast shows "Unlimited" & "Free" ✅
- ✅ Interactive buttons work
- ✅ Error handling for invalid ID

### Visual:
- ✅ Images load correctly
- ✅ Price formatted (850,000đ)
- ✅ Icons display properly
- ✅ Colors correct (green=success, red=warning)
- ✅ Responsive on all devices
- ✅ Sticky booking card on scroll

### UX:
- ✅ Click from searchcar → cardetail works
- ✅ URL parameter ?id=X works
- ✅ Alert messages clear
- ✅ Smooth transitions
- ✅ No console errors

---

## 🐛 COMMON ISSUES & FIXES

### Issue 1: Backend not running
**Error**: `Failed to fetch` hoặc `net::ERR_CONNECTION_REFUSED`  
**Fix**: 
```cmd
cd Project1
mvnw.cmd spring-boot:run
```

### Issue 2: Vietnamese text garbled
**Error**: Hiển thị `Tr???ng` thay vì `Trắng`  
**Fix**: Database đã dùng NVARCHAR, OK trong API, terminal encoding issue only

### Issue 3: Image not found
**Error**: Broken image icon  
**Fix**: 
```javascript
// Already handled in code:
onerror="this.src='../assets/inmage/default-car.png'"
```

### Issue 4: Booking button always disabled
**Status**: Expected behavior (chưa tích hợp date picker)  
**Future**: Enable khi user nhập điểm đến

---

## 📊 TEST REPORT TEMPLATE

```
Date: ___________
Tester: ___________

[ ] Test 1: Xe thường (ID=1) - PASS / FAIL
[ ] Test 2: Xe điện (ID=34) - PASS / FAIL
[ ] Test 3: Xe điện khác - PASS / FAIL
[ ] Test 4: ID không tồn tại - PASS / FAIL
[ ] Test 5: Không có ID - PASS / FAIL
[ ] Test 6: Nút Share - PASS / FAIL
[ ] Test 7: Nút Favorite - PASS / FAIL
[ ] Test 8: Xem ảnh - PASS / FAIL
[ ] Test 9: Báo cáo - PASS / FAIL
[ ] Test 10: Radio lộ trình - PASS / FAIL

Overall: PASS / FAIL
Notes: _______________________________
```

---

**Created**: 22/10/2025  
**Version**: 1.0  
**Status**: Ready for Testing ✅
