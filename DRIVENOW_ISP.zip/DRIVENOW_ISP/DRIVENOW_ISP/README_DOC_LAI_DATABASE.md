# 🇻🇳 ĐỌC LẠI VÀ SỬA DATABASE TIẾNG VIỆT - DRIVENOW

## 🎯 MỤC ĐÍCH

Kiểm tra và chuyển đổi **TẤT CẢ** dữ liệu trong database từ tiếng Anh sang tiếng Việt chuẩn.

---

## ⚡ CÁCH CHẠY NHANH (3 LỆNH)

### **Bước 1: Kiểm tra database hiện tại**
```powershell
# Chạy script kiểm tra tự động
.\check-database-language.bat
```

**Hoặc** kiểm tra trong SSMS:
```sql
-- Mở file: Project1/CHECK_DATABASE.sql trong SSMS
-- Nhấn F5
```

### **Bước 2: Update sang tiếng Việt**
```sql
-- Trong SSMS:
-- Mở file: Project1/UPDATE_TO_VIETNAMESE.sql
-- Nhấn F5 (Execute)
```

### **Bước 3: Restart Backend**
```powershell
cd Project1
.\start-backend.bat
```

---

## 📁 CÁC FILE ĐÃ TẠO

| File | Mục đích | Cách dùng |
|------|----------|-----------|
| **CHECK_DATABASE.sql** | Kiểm tra database hiện tại | Chạy trong SSMS để xem trạng thái |
| **UPDATE_TO_VIETNAMESE.sql** | Update dữ liệu sang tiếng Việt | Chạy trong SSMS để update |
| **fix_vietnamese_encoding.sql** | Reset toàn bộ + thêm 30 xe mẫu | Chỉ dùng khi muốn reset lại database |
| **check-database-language.bat** | Kiểm tra tự động qua API | Chạy trực tiếp trong terminal |

---

## 📊 TRƯỚC VÀ SAU

### ❌ **TRƯỚC (Tiếng Anh)**
```json
{
  "id": 1,
  "brand": "Toyota",
  "fuelType": "Gasoline",
  "transmissionType": "Automatic",
  "status": "Available"
}
```

### ✅ **SAU (Tiếng Việt)**
```json
{
  "id": 1,
  "brand": "Toyota",
  "fuelType": "Xăng",
  "transmissionType": "Tự động",
  "status": "Có sẵn"
}
```

---

## 🔄 QUI TRÌNH CHI TIẾT

### **PHƯƠNG ÁN 1: Update dữ liệu hiện có (KHUYẾN NGHỊ)**

Giữ nguyên tất cả xe hiện có, chỉ chuyển đổi ngôn ngữ:

```
1. Mở SSMS → Kết nối localhost (sa/12345)
2. File → Open → Project1/UPDATE_TO_VIETNAMESE.sql
3. Nhấn F5
4. Đợi thông báo "✅ HOÀN THÀNH"
5. Restart backend
6. Test: http://localhost:8080/api/cars/all
```

**Script này sẽ:**
- ✅ Chuyển `Gasoline` → `Xăng`
- ✅ Chuyển `Diesel` → `Dầu diesel`
- ✅ Chuyển `Electric` → `Điện`
- ✅ Chuyển `Automatic` → `Tự động`
- ✅ Chuyển `Manual` → `Số sàn`
- ✅ Chuyển `Available` → `Có sẵn`

**Ưu điểm:**
- ✅ Giữ nguyên tất cả xe hiện có
- ✅ Không mất dữ liệu
- ✅ Nhanh (< 1 phút)

---

### **PHƯƠNG ÁN 2: Reset toàn bộ database**

Xóa tất cả xe cũ, thêm 30 xe mẫu mới hoàn toàn tiếng Việt:

```
1. Mở SSMS → Kết nối localhost
2. File → Open → Project1/fix_vietnamese_encoding.sql
3. Nhấn F5
4. Đợi script hoàn tất
5. Restart backend
```

**Script này sẽ:**
- ⚠️ XÓA tất cả xe hiện có
- ✅ Chuyển cấu trúc bảng VARCHAR → NVARCHAR
- ✅ Thêm 30 xe mẫu mới (tiếng Việt 100%)

**Ưu điểm:**
- ✅ Database hoàn toàn mới, chuẩn 100%
- ✅ Có sẵn 30 xe đa dạng

**Nhược điểm:**
- ❌ Mất hết dữ liệu xe cũ
- ⚠️ Chỉ dùng khi muốn reset

---

## 🔍 KIỂM TRA KẾT QUẢ

### **Cách 1: Dùng script tự động**
```powershell
.\check-database-language.bat
```

### **Cách 2: Kiểm tra trong SQL**
```sql
-- Xem danh sách fuel_type
SELECT DISTINCT fuel_type FROM cars;

-- Kết quả mong đợi (tiếng Việt):
-- Xăng
-- Dầu diesel
-- Điện
-- Hybrid (Xăng + Điện)

-- Xem danh sách transmission_type
SELECT DISTINCT transmission_type FROM cars;

-- Kết quả mong đợi:
-- Tự động
-- Số sàn
```

### **Cách 3: Test API**
```
GET http://localhost:8080/api/cars/all
```

---

## 📝 BẢNG CHUYỂN ĐỔI CHUẨN

### **fuel_type (Nhiên liệu)**
```
Gasoline → Xăng
Petrol   → Xăng
Diesel   → Dầu diesel
Electric → Điện
Hybrid   → Hybrid (Xăng + Điện)
```

### **transmission_type (Hộp số)**
```
Automatic → Tự động
Auto      → Tự động
Manual    → Số sàn
```

### **status (Trạng thái)**
```
Available   → Có sẵn
Rented      → Đã thuê
Maintenance → Bảo trì
```

---

## 🛠️ TROUBLESHOOTING

### **❌ Vấn đề: Script báo lỗi "database không tồn tại"**
```sql
-- Tạo database nếu chưa có:
CREATE DATABASE drivenow_db;
GO
```

### **❌ Vấn đề: Sau update vẫn thấy tiếng Anh**
**Nguyên nhân:** Backend cache

**Giải pháp:**
```powershell
# Stop backend (Ctrl+C)
cd Project1
.\start-backend.bat
# Xóa cache browser (Ctrl+Shift+Del)
```

### **❌ Vấn đề: Ký tự tiếng Việt hiển thị "????"**
**Nguyên nhân:** Cấu trúc bảng chưa dùng NVARCHAR

**Giải pháp:**
```sql
-- Chạy script sửa cấu trúc:
-- File: fix_vietnamese_encoding.sql
```

### **❌ Vấn đề: API trả về rỗng**
```sql
-- Kiểm tra số lượng xe:
SELECT COUNT(*) FROM cars;

-- Nếu = 0, chạy script thêm xe:
-- fix_vietnamese_encoding.sql
```

---

## ⚙️ BACKEND ĐÃ ĐƯỢC CẤU HÌNH

✅ **Car.java** - Tất cả cột đã dùng `NVARCHAR`
✅ **application.properties** - Đã có UTF-8 encoding
✅ **SearchCarService.java** - Tìm kiếm trực tiếp tiếng Việt
✅ **CarRepository.java** - Query hỗ trợ tiếng Việt
✅ **searchcar.js** - Hiển thị trực tiếp từ database

**Không cần sửa code!** Chỉ cần update database.

---

## 📚 TÀI LIỆU LIÊN QUAN

- **Chi tiết:** `HUONG_DAN_SUA_DATABASE_TIENG_VIET.md`
- **Tổng quan:** `TONG_KET_SUA_TIENG_VIET.md`
- **Hướng dẫn ban đầu:** `HUONG_DAN_SUA_TIENG_VIET.md`

---

## ✅ CHECKLIST SAU KHI HOÀN THÀNH

- [ ] Chạy `CHECK_DATABASE.sql` - Không còn tiếng Anh
- [ ] Chạy `UPDATE_TO_VIETNAMESE.sql` - Thành công
- [ ] Restart backend - Không lỗi
- [ ] API `/api/cars/all` trả về tiếng Việt
- [ ] Frontend hiển thị đúng tiếng Việt
- [ ] Filter theo nhiên liệu, hộp số hoạt động
- [ ] Tìm kiếm xe hoạt động tốt

---

## 🎯 TÓM TẮT NHANH

```
┌─────────────────────────────────────────┐
│  KIỂM TRA → UPDATE → RESTART → TEST    │
└─────────────────────────────────────────┘
      ↓          ↓         ↓        ↓
   CHECK_   UPDATE_TO_  Backend   API +
  DATABASE VIETNAMESE            Frontend
```

**Thời gian:** 3-5 phút
**Kết quả:** Database 100% tiếng Việt

---

**🚀 BẮT ĐẦU NGAY:**

```powershell
# Bước 1: Kiểm tra
.\check-database-language.bat

# Bước 2: Nếu cần update, mở SSMS và chạy:
# UPDATE_TO_VIETNAMESE.sql

# Bước 3: Restart
cd Project1
.\start-backend.bat
```

**🎉 XONG!**
