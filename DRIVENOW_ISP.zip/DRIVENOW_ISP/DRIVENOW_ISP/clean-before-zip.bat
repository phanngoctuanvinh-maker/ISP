@echo off
echo ========================================
echo   CLEAN PROJECT - XOA FILE KHONG CAN
echo ========================================
echo.

echo Dang xoa folder target (Maven build files)...
if exist "Project1\target" (
    rmdir /s /q "Project1\target"
    echo   - Da xoa: Project1\target
) else (
    echo   - Khong co folder target
)

echo.
echo Dang xoa cache VSCode...
if exist ".vscode" (
    rmdir /s /q ".vscode"
    echo   - Da xoa: .vscode
) else (
    echo   - Khong co folder .vscode
)

echo.
echo Dang xoa log files...
if exist "Project1\logs" (
    rmdir /s /q "Project1\logs"
    echo   - Da xoa: Project1\logs
) else (
    echo   - Khong co folder logs
)

echo.
echo Dang xoa file .class...
for /r "Project1\src" %%f in (*.class) do (
    del /q "%%f"
)
echo   - Da xoa tat ca file .class

echo.
echo ========================================
echo   HOAN THANH!
echo ========================================
echo.
echo Folder da sach, san sang nen va gui!
echo.
echo Kich thuoc folder truoc: ~500MB
echo Kich thuoc folder sau:  ~50MB
echo.
pause
