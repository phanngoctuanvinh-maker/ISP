// profileuser.js - Hiển thị thông tin khách hàng và xử lý click tên

document.addEventListener('DOMContentLoaded', function() {
    // Lấy user từ localStorage (sau khi đăng nhập lưu vào currentUser)
    // Nếu chưa có thì chuyển về trang đăng nhập
    const user = api.getCurrentUser();
    if (!user) {
        window.location.href = 'homepage.html';
        return;
    }

    // Hiển thị thông tin user đúng trường
    document.getElementById('profileName').textContent = user.fullName || user.name || user.username || '';
    document.getElementById('joinDate').textContent = user.joinDate || user.createdAt || '--/--/----';
    document.getElementById('dob').textContent = user.dob || '';
    document.getElementById('gender').textContent = user.gender || '';
    document.getElementById('phone').textContent = user.phone || user.sdt || user.mobile || '';
    document.getElementById('email').textContent = user.email || user.username || '';
    document.getElementById('avatarImg').src = user.avatar || '../assets/icons/user-avatar.svg';

    // Khi nhấn vào tên khách hàng
    document.getElementById('profileName').addEventListener('click', function() {
        alert('Bạn đã nhấn vào tên khách hàng!');
        // Có thể mở modal chỉnh sửa thông tin ở đây
    });

    // Đăng xuất khi nhấn vào menu Đăng xuất
    const logoutMenu = document.querySelector('.menu li:last-child');
    if (logoutMenu) {
        logoutMenu.style.cursor = 'pointer';
        logoutMenu.addEventListener('click', function() {
            if (window.api && typeof window.api.logout === 'function') {
                window.api.logout();
            } else {
                // Xóa token và chuyển về trang chủ nếu không có api.logout
                localStorage.removeItem('token');
                localStorage.removeItem('userProfile');
                window.location.href = 'homepage.html';
            }
        });
    }

    // Click logo DriveNow để về homepage (giữ trạng thái đăng nhập)
    const logo = document.getElementById('logoDriveNow');
    if (logo) {
        logo.addEventListener('click', function() {
            window.location.href = 'homepage.html';
        });
    }

    // Chuyển sang trang đổi mật khẩu khi nhấn menu Đổi mật khẩu
    const menuItems = document.querySelectorAll('.menu li');
    // Đổi mật khẩu là mục thứ 5 (bắt đầu từ 0)
    if (menuItems[4]) {
        menuItems[4].style.cursor = 'pointer';
        menuItems[4].addEventListener('click', function() {
            window.location.href = 'changepassword.html';
        });
    }

        // Thêm sự kiện cập nhật cho từng nút chỉnh sửa thông tin
        // Sử dụng modal chung cho cập nhật avatar, số điện thoại, email
        const editFields = [
            { id: 'editDob', label: 'ngày sinh' },
            { id: 'editGender', label: 'giới tính' },
            { id: 'editPhone', label: 'số điện thoại' },
            { id: 'editEmail', label: 'email' },
            { id: 'profileAvatar', label: 'avatar', isAvatar: true }
        ];
        let currentUpdateType = null;
        editFields.forEach(function(field) {
            const btn = document.getElementById(field.id);
            if (btn) {
                btn.addEventListener('click', function() {
                    const modal = document.getElementById('updateInfoModal');
                    const title = document.getElementById('updateInfoTitle');
                    const input = document.getElementById('updateInfoInput');
                    const avatarBox = document.getElementById('updateInfoAvatarBox');
                    currentUpdateType = field.id;
                    modal.style.display = 'flex';
                    input.style.display = 'block';
                    avatarBox.style.display = field.isAvatar ? 'flex' : 'none';
                    if (field.id === 'editPhone') {
                        title.textContent = 'Cập nhật số điện thoại';
                        input.type = 'text';
                        input.placeholder = 'Số điện thoại';
                        input.value = document.getElementById('phone').textContent.trim();
                    } else if (field.id === 'editEmail') {
                        title.textContent = 'Cập nhật email';
                        input.type = 'email';
                        input.placeholder = 'Email';
                        input.value = document.getElementById('email').textContent.trim();
                    } else if (field.isAvatar) {
                        title.textContent = 'Cập nhật ảnh đại diện';
                        input.style.display = 'none';
                        document.getElementById('updateInfoAvatar').src = document.getElementById('avatarImg').src;
                        // Không tự động mở file chọn ảnh nữa
                    } else {
                        alert('Cập nhật ' + field.label + '!');
                        modal.style.display = 'none';
                    }
                });
            }
        });

        // Đóng modal cập nhật thông tin
        document.getElementById('closeUpdateInfo').addEventListener('click', function() {
            document.getElementById('updateInfoModal').style.display = 'none';
        });

        // Xử lý cập nhật thông tin
        document.getElementById('submitUpdateInfo').addEventListener('click', function() {
            const input = document.getElementById('updateInfoInput');
            if (currentUpdateType === 'editPhone') {
                var newPhone = input.value.trim();
                if (newPhone) {
                    document.getElementById('phone').textContent = newPhone;
                    document.getElementById('updateInfoModal').style.display = 'none';
                    // TODO: Gọi API cập nhật số điện thoại ở đây nếu cần
                }
            } else if (currentUpdateType === 'editEmail') {
                var newEmail = input.value.trim();
                if (newEmail) {
                    document.getElementById('email').textContent = newEmail;
                    document.getElementById('updateInfoModal').style.display = 'none';
                    // TODO: Gọi API cập nhật email ở đây nếu cần
                }
            }
        });

        // Xử lý cập nhật avatar
        document.getElementById('updateInfoAvatarInput').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(ev) {
                    // Hiển thị avatar là hình tròn
                    var avatarImg = document.getElementById('avatarImg');
                    avatarImg.src = ev.target.result;
                    avatarImg.style.width = '100%';
                    avatarImg.style.height = '100%';
                    avatarImg.style.borderRadius = '50%';
                    avatarImg.style.objectFit = 'cover';
                    avatarImg.style.display = 'block';
                    // Ensure parent is circular and overflow hidden
                    var avatarParent = avatarImg.parentElement;
                    avatarParent.style.borderRadius = '50%';
                    avatarParent.style.overflow = 'hidden';
                    avatarParent.style.width = '110px';
                    avatarParent.style.height = '110px';

                    var modalAvatar = document.getElementById('updateInfoAvatar');
                    modalAvatar.src = ev.target.result;
                    modalAvatar.style.width = '100%';
                    modalAvatar.style.height = '100%';
                    modalAvatar.style.borderRadius = '50%';
                    modalAvatar.style.objectFit = 'cover';
                    modalAvatar.style.display = 'block';
                    var modalAvatarParent = modalAvatar.parentElement;
                    modalAvatarParent.style.borderRadius = '50%';
                    modalAvatarParent.style.overflow = 'hidden';
                    modalAvatarParent.style.width = '80px';
                    modalAvatarParent.style.height = '80px';
                    document.getElementById('updateInfoModal').style.display = 'none';
                    // Nếu có avatar ở thanh trạng thái đăng nhập thì cập nhật luôn
                    var navAvatar = document.querySelector('.auth-avatar');
                    if (navAvatar) {
                        navAvatar.src = ev.target.result;
                        navAvatar.style.borderRadius = '50%';
                        navAvatar.style.objectFit = 'cover';
                    }
                    // Lưu avatar vào localStorage để không bị mất khi reload
                    var userProfile = localStorage.getItem('userProfile');
                    if (userProfile) {
                        try {
                            var userObj = JSON.parse(userProfile);
                            userObj.avatar = ev.target.result;
                            localStorage.setItem('userProfile', JSON.stringify(userObj));
                        } catch (e) {}
                    }
                };
                reader.readAsDataURL(file);
            }
        });
});
