// Mapping from short codes to full city names
const cityMapping = {
    'hn': 'Hà Nội',
    'hcm': 'Hồ Chí Minh',
    'dn': 'Đà Nẵng',
    'hp': 'Hải Phòng',
    'ct': 'Cần Thơ',
    'bd': 'Bình Dương',
    'dn2': 'Đồng Nai',
    'kh': 'Khánh Hòa',
    'lc': 'Lâm Đồng',
    'vt': 'Vũng Tàu'
};

// Get city name from URL parameters or localStorage
function getCityName() {
    // Try to get from URL parameters first
    const urlParams = new URLSearchParams(window.location.search);
    let cityName = urlParams.get('city');
    
    // If not in URL, try localStorage
    if (!cityName) {
        cityName = localStorage.getItem('selectedCity');
    }
    
    // Decode URI component to get full city name
    if (cityName) {
        cityName = decodeURIComponent(cityName);
        
        // Check if it's a short code and convert to full name
        const lowerCityName = cityName.toLowerCase();
        if (cityMapping[lowerCityName]) {
            cityName = cityMapping[lowerCityName];
        }
    }
    
    // Default city if nothing is found
    return cityName || 'Chọn thành phố';
}

// Update city name in the page
function updateCityDisplay() {
    const cityName = getCityName();
    const cityDisplayElement = document.querySelector('.city-name');
    
    if (cityDisplayElement) {
        cityDisplayElement.textContent = cityName;
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    updateCityDisplay();

    // Kiểm tra trạng thái đăng nhập và cập nhật giao diện
    const authButtons = document.querySelector('.auth-buttons');
    let user = null;
    // Ưu tiên lấy từ localStorage/sessionStorage
    try {
        const userData = localStorage.getItem('user') || sessionStorage.getItem('user');
        if (userData) {
            user = JSON.parse(userData);
        }
    } catch (e) {}

    if (authButtons && user) {
        authButtons.innerHTML = `
            <div class="user-info" style="display:flex;align-items:center;gap:8px;">
                <img class="user-avatar" src="${user.avatarUrl || 'assets/icons/default-avatar.png'}" alt="avatar" style="width:32px;height:32px;border-radius:50%;object-fit:cover;">
                <span class="user-name" id="userNameClickable" style="cursor:pointer;">${user.fullName || user.username}</span>
            </div>
        `;
        setTimeout(() => {
            const userNameEl = document.getElementById('userNameClickable');
            if (userNameEl) {
                userNameEl.addEventListener('click', function() {
                    window.location.href = 'profileuser.html';
                });
            }
        }, 0);
    }

    // Handle car type selection
    document.querySelectorAll('.car-type-item').forEach(item => {
        item.addEventListener('click', () => {
            document.querySelectorAll('.car-type-item').forEach(i => i.classList.remove('active'));
            item.classList.add('active');
        });
    });

    // Handle brand selection
    document.querySelectorAll('.brand-card-item').forEach(item => {
        item.addEventListener('click', () => {
            document.querySelectorAll('.brand-card-item').forEach(i => i.classList.remove('active'));
            item.classList.add('active');
        });
    });
});

// Lấy tên thành phố từ URL hoặc localStorage
const urlParams = new URLSearchParams(window.location.search);
const cityFromUrl = urlParams.get('city');
const cityFromStorage = localStorage.getItem('selectedCity');
    
// Mapping tên thành phố đầy đủ (hỗ trợ cả chữ hoa và chữ thường)
const cityFullNames = {
    'Hà Nội': 'Hà Nội',
    'hà nội': 'Hà Nội',
    'HN': 'Hà Nội',
    'hn': 'Hà Nội',
    'Hồ Chí Minh': 'Hồ Chí Minh',
    'hồ chí minh': 'Hồ Chí Minh',
    'HCM': 'Hồ Chí Minh',
    'hcm': 'Hồ Chí Minh',
    'Đà Nẵng': 'Đà Nẵng',
    'đà nẵng': 'Đà Nẵng',
    'DN': 'Đà Nẵng',
    'dn': 'Đà Nẵng',
};

// Lấy tên thành phố (ưu tiên từ URL, sau đó localStorage)
let cityCode = cityFromUrl || cityFromStorage;
let cityName = 'Chọn thành phố';
    
// Nếu có cityCode, tìm trong mapping
if (cityCode) {
    // Thử tìm trực tiếp
    if (cityFullNames[cityCode]) {
        cityName = cityFullNames[cityCode];
    } 
    // Thử tìm với chữ thường
    else if (cityFullNames[cityCode.toLowerCase()]) {
        cityName = cityFullNames[cityCode.toLowerCase()];
    }
    // Nếu không tìm thấy, giữ nguyên cityCode
    else {
        cityName = cityCode;
    }
}

// Hiển thị tên thành phố
const cityNameElement = document.getElementById('cityName');
if (cityNameElement) {
    cityNameElement.textContent = cityName;
}

// Lưu tên đầy đủ vào localStorage để sử dụng sau
if (cityCode) {
    localStorage.setItem('selectedCity', cityCode);
    localStorage.setItem('selectedCityFullName', cityName);
}

// Xử lý nút back
const backBtn = document.querySelector('.back-btn');
if (backBtn) {
    backBtn.addEventListener('click', function() {
        window.history.back();
    });
}

// Xử lý filter buttons
const filterBtns = document.querySelectorAll('.filter-btn');
    
filterBtns.forEach(btn => {
    btn.addEventListener('click', function() {
        // Remove active class from all buttons
        filterBtns.forEach(b => b.classList.remove('active'));
        
        // Add active class to clicked button
        this.classList.add('active');
        
        // Lấy filter type
        const filterType = this.textContent.trim();
        console.log('Filter selected:', filterType);
        
        // TODO: Thêm logic lọc xe theo filter type
        filterCars(filterType);
    });
});


// --- KẾT NỐI API TÌM KIẾM XE ---
// Hàm gọi API tìm kiếm xe với các filter cơ bản
async function searchCars({ city, carType, brand, transmission } = {}) {
    const carGrid = document.querySelector('.cars-grid');
    if (!carGrid) return;
    carGrid.innerHTML = '<p>Đang tải danh sách xe...</p>';
    try {
        // Gọi API /api/cars/search (GET)
        // Chỉ truyền các filter có giá trị
        const params = new URLSearchParams();
        if (city) params.append('location', city);
        if (carType) params.append('carType', carType);
        if (brand) params.append('brand', brand);
        if (transmission) params.append('transmission', transmission);
        params.append('size', 20); // lấy nhiều xe hơn mặc định
        const response = await api.request(`/cars/search?${params.toString()}`);
        if (response.success && response.data && Array.isArray(response.data.cars)) {
            displayCars(response.data.cars);
        } else {
            carGrid.innerHTML = '<p>Không tìm thấy xe phù hợp.</p>';
        }
    } catch (error) {
        carGrid.innerHTML = `<p class="error">Lỗi khi tải danh sách xe: ${error.message}</p>`;
    }
}

// Hàm hiển thị danh sách xe (dạng card)
function displayCars(cars) {
    const carGrid = document.querySelector('.cars-grid');
    if (!carGrid) return;
    carGrid.innerHTML = '';
    if (!cars || cars.length === 0) {
        carGrid.innerHTML = '<p>Không có xe nào phù hợp.</p>';
        return;
    }
    cars.forEach(car => {
        const card = document.createElement('div');
        card.className = 'car-card-result';
        card.innerHTML = `
            <div class="car-image-wrapper">
                <img src="${car.imageUrl || '../assets/inmage/default-car.png'}" alt="Car" class="car-result-img">
            </div>
            <div class="car-info">
                <div class="car-title">${car.brand || ''} ${car.model || ''}</div>
                <div class="car-meta">${car.year || ''} • ${car.transmission || ''} • ${car.fuelType || ''}</div>
                <div class="car-price">${car.pricePerDay ? (car.pricePerDay.toLocaleString('vi-VN') + ' đ/ngày') : ''}</div>
            </div>
        `;
        card.addEventListener('click', () => {
            // Chuyển sang trang chi tiết xe nếu muốn
            // window.location.href = `cardetail.html?id=${car.id}`;
        });
        carGrid.appendChild(card);
    });
}

// --- GỌI API KHI LOAD TRANG VÀ KHI FILTER ---
document.addEventListener('DOMContentLoaded', function() {
    // Lấy city từ URL hoặc localStorage
    let city = getCityName();
    // Gọi API lần đầu
    searchCars({ city });

    // Xử lý filter loại xe
    document.querySelectorAll('.car-type-item').forEach(item => {
        item.addEventListener('click', function() {
            const carType = this.dataset.type;
            searchCars({ city, carType });
        });
    });

    // Xử lý filter hãng xe
    document.querySelectorAll('.brand-card-item').forEach(item => {
        item.addEventListener('click', function() {
            const brand = this.dataset.brand;
            searchCars({ city, brand });
        });
    });

    // Xử lý filter truyền động (nếu có)
    document.querySelectorAll('.transmission-list input[type="radio"]').forEach(item => {
        item.addEventListener('change', function() {
            const transmission = this.value;
            searchCars({ city, transmission });
        });
    });
});

// Load cars for the selected city
async function loadCarsForCity(cityName) {
    console.log('Loading cars for city:', cityName);
    const carGrid = document.querySelector('.cars-grid');
    if (!carGrid) return;

    carGrid.innerHTML = '<p>Đang tải danh sách xe...</p>'; // Loading message

    try {
        const response = await api.getSubscriptionCars(cityName);
        if (response.success && response.data.length > 0) {
            displayCars(response.data);
        } else {
            carGrid.innerHTML = '<p>Không tìm thấy xe nào cho khu vực này.</p>';
        }
    } catch (error) {
        carGrid.innerHTML = `<p class="error">Lỗi khi tải danh sách xe: ${error.message}</p>`;
    }
}

// Function to display cars
function displayCars(cars) {
    const carGrid = document.querySelector('.cars-grid');
    if (!carGrid) return;

    carGrid.innerHTML = ''; // Clear loading message

    cars.forEach(car => {
        const carItem = document.createElement('div');
        carItem.className = 'car-item';
        carItem.innerHTML = `
            <div class="car-img-placeholder" style="background-image: url('${car.imageUrl || '../assets/inmage/default-car.png'}')"></div>
            <div class="car-details">
                <h3 class="car-name">${car.brand} ${car.model}</h3>
                <p class="car-specs">${car.year} - ${car.transmission}</p>
                <div class="car-price">
                    <span class="price-amount">${new Intl.NumberFormat('vi-VN').format(car.pricePerMonth)}</span>
                    <span class="price-unit">đ/tháng</span>
                </div>
                <button class="btn-view-details">Xem chi tiết</button>
            </div>
        `;
        carGrid.appendChild(carItem);
    });
}
