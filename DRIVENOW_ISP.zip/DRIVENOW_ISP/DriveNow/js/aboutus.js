// Banner button click handler for About Us page
document.addEventListener('DOMContentLoaded', function() {
    const bannerBtns = document.querySelectorAll('.banner-btn');
    bannerBtns.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const btnText = btn.textContent.trim().toLowerCase();
            if (btnText.includes('dài hạn') || btnText.includes('dai han')) {
                window.location.href = 'carsubscription.html';
            } else if (btnText.includes('tài xế') || btnText.includes('tai xe')) {
                window.location.href = 'searchcar.html'; // Sửa đúng tên file
            }
        });
    });
});
