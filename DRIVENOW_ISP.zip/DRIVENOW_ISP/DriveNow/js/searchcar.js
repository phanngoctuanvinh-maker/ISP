document.addEventListener('DOMContentLoaded', () => {
    console.log('Search car page loaded');

    // Kiểm tra trạng thái đăng nhập và cập nhật giao diện
    const authButtons = document.querySelector('.auth-buttons');
    let user = null;
    try {
        const userData = localStorage.getItem('user') || sessionStorage.getItem('user');
        if (userData) {
            user = JSON.parse(userData);
        }
    } catch (e) {}

    if (authButtons && user) {
        authButtons.innerHTML = `
            <div class="user-info" style="display:flex;align-items:center;gap:8px;">
                <img class="user-avatar" src="${user.avatarUrl || '../assets/inmage/OIP.webp'}" alt="avatar" style="width:32px;height:32px;border-radius:50%;object-fit:cover;">
                <span class="user-name" id="userNameClickable" style="cursor:pointer;">${user.fullName || user.username}</span>
            </div>
        `;
        setTimeout(() => {
            const userNameEl = document.getElementById('userNameClickable');
            if (userNameEl) {
                userNameEl.addEventListener('click', function() {
                    window.location.href = 'profileuser.html';
                });
            }
        }, 0);
    }
    
    // Get URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const location = urlParams.get('location');
    const time = urlParams.get('time');
    const route = urlParams.get('route');
    
    // Display search info
    if (location) {
        const locationElement = document.querySelector('.search-info-item:first-child span');
        if (locationElement) {
            locationElement.textContent = location;
        }
    }
    
    if (time) {
        const timeElement = document.querySelector('.search-info-item:last-child span');
        if (timeElement) {
            timeElement.textContent = time;
        }
    }
    
    // Log search params
    console.log('Search params:', { location, time, route });
    
    // Filter tabs handling
    const filterTabs = document.querySelectorAll('.filter-tab');
    filterTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            // Remove active class from all tabs
            filterTabs.forEach(t => t.classList.remove('active'));
            // Add active class to clicked tab
            this.classList.add('active');
            
            // TODO: Filter cars based on selected tab
            console.log('Filter selected:', this.textContent.trim());
        });
    });
    
    // Car card click handler
    const carCards = document.querySelectorAll('.car-card-result');
    carCards.forEach(card => {
        card.addEventListener('click', function() {
            // TODO: Navigate to car detail page
            console.log('Car card clicked');
        });
    });
    
    // Xử lý filter tabs
    const carTypeModal = new bootstrap.Modal(document.getElementById('carTypeModal'));
    let selectedCarType = null;
    
    filterTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            // Remove active class from all tabs
            filterTabs.forEach(t => t.classList.remove('active'));
            
            // Add active class to clicked tab
            this.classList.add('active');
            
            // Get filter type from icon or text
            const tabText = this.textContent.trim();
            
            // Hiển thị modal nếu click vào "Loại Xe"
            if (tabText.includes('Loại Xe')) {
                carTypeModal.show();
            }
        });
    });
    
    // Xử lý chọn loại xe trong modal
    const carTypeItems = document.querySelectorAll('.car-type-item');
    
    carTypeItems.forEach(item => {
        item.addEventListener('click', function() {
            // Remove selected class from all items
            carTypeItems.forEach(i => i.classList.remove('selected'));
            
            // Add selected class to clicked item
            this.classList.add('selected');
            
            // Store selected car type
            selectedCarType = this.dataset.type;
        });
    });
    
    // Xử lý nút "Áp dụng"
    const applyBtn = document.getElementById('applyCarType');
    if (applyBtn) {
        applyBtn.addEventListener('click', function() {
            if (selectedCarType) {
                console.log('Selected car type:', selectedCarType);
                // TODO: Filter cars by selected type
                filterCarsByType(selectedCarType);
                carTypeModal.hide();
            }
        });
    }

    // Advanced filter modal
    const advancedFilterBtn = document.getElementById('advancedFilterBtn');
    const applyAdvancedFilter = document.getElementById('applyAdvancedFilter');
    const clearAdvancedFilter = document.getElementById('clearAdvancedFilter');
    const advancedFilterModalEl = document.getElementById('advancedFilterModal');

    if (advancedFilterModalEl) {
        const advancedFilterModal = new bootstrap.Modal(advancedFilterModalEl);

        // --- Event Listeners ---
        if (applyAdvancedFilter) {
            applyAdvancedFilter.addEventListener('click', function () {
                if (advancedFilterBtn) {
                    advancedFilterBtn.classList.add('active');
                }
                advancedFilterModal.hide();
            });
        }

        if (clearAdvancedFilter) {
            clearAdvancedFilter.addEventListener('click', function () {
                resetFilters();
                if (advancedFilterBtn) {
                    advancedFilterBtn.classList.remove('active');
                }
            });
        }

        // --- Slider Logic ---
        const rangeSliders = advancedFilterModalEl.querySelectorAll('.form-range');

        function updateSliderTrack(slider) {
            const min = parseFloat(slider.min);
            const max = parseFloat(slider.max);
            const value = parseFloat(slider.value);
            const percentage = ((value - min) / (max - min)) * 100;
            const gradient = `linear-gradient(to right, var(--bs-success) 0%, var(--bs-success) ${percentage}%, #e9ecef ${percentage}%, #e9ecef 100%)`;
            slider.style.background = gradient;
        }

        function updateSliderValueDisplay(slider) {
            const display = slider.nextElementSibling;
            if (!display || !display.classList.contains('range-value-display')) return;

            const value = parseFloat(slider.value);
            const min = parseFloat(slider.min);
            const max = parseFloat(slider.max);
            const unit = slider.dataset.unit || '';

            if (slider.id === 'delivery-fee-range' && value === min) {
                display.textContent = 'Miễn phí';
            } else if (slider.id === 'fuel-consumption-range' && value === max) {
                display.textContent = `Từ dưới ${value}L/100km`;
            } else if (value === min && (slider.id === 'price-range' || slider.id === 'distance-range' || slider.id === 'year-range' || slider.id === 'seats-range')) {
                display.textContent = 'Bất kì';
            } else if (unit === 'đ') {
                display.textContent = `Dưới ${value.toLocaleString('vi-VN')}${unit}`;
            } else if (unit === 'km') {
                 display.textContent = `Dưới ${value}${unit}`;
            } else if (slider.id === 'seats-range') {
                display.textContent = `${value} chỗ`;
            } else if (slider.id === 'year-range') {
                display.textContent = `Từ ${value}`;
            } else {
                 display.textContent = value;
            }
        }

        rangeSliders.forEach(slider => {
            slider.addEventListener('input', () => {
                updateSliderTrack(slider);
                updateSliderValueDisplay(slider);
            });
            updateSliderTrack(slider);
            updateSliderValueDisplay(slider);
        });

        // --- Reset Function ---
        function resetFilters() {
            // Reset select
            const select = advancedFilterModalEl.querySelector('select');
            if (select) select.selectedIndex = 0;

            // Reset range sliders
            rangeSliders.forEach(slider => {
                if(slider.id === 'fuel-consumption-range'){
                    slider.value = slider.max;
                } else if (slider.id === 'seats-range' || slider.id === 'year-range') {
                    slider.value = slider.min;
                }
                else {
                    slider.value = slider.min;
                }
                updateSliderTrack(slider);
                updateSliderValueDisplay(slider);
            });

            // Reset radio buttons
            const radios = advancedFilterModalEl.querySelectorAll('input[type="radio"]');
            radios.forEach(radio => {
                if (radio.id.endsWith('-all')) radio.checked = true;
            });

            // Reset checkboxes
            const checkboxes = advancedFilterModalEl.querySelectorAll('input[type="checkbox"]');
            checkboxes.forEach(checkbox => checkbox.checked = false);
        }
    }

    // Car Brand Modal Logic
    const carBrandFilterBtn = document.getElementById('carBrandFilterBtn');
    const applyCarBrand = document.getElementById('applyCarBrand');
    const carBrandModalEl = document.getElementById('carBrandModal');

    if (carBrandModalEl) {
        const carBrandModal = new bootstrap.Modal(carBrandModalEl);
        const brandCards = carBrandModalEl.querySelectorAll('.brand-card-item');

        brandCards.forEach(card => {
            card.addEventListener('click', () => {
                card.classList.toggle('selected');
            });
        });

        if (applyCarBrand) {
            applyCarBrand.addEventListener('click', function () {
                const selectedBrands = carBrandModalEl.querySelectorAll('.brand-card-item.selected');
                if (carBrandFilterBtn) {
                    if (selectedBrands.length > 0) {
                        carBrandFilterBtn.classList.add('active');
                    } else {
                        carBrandFilterBtn.classList.remove('active');
                    }
                }
                carBrandModal.hide();
            });
        }
    }

    // Transmission Modal Logic
    const transmissionFilterBtn = document.getElementById('transmissionFilterBtn');
    const applyTransmission = document.getElementById('applyTransmission');
    const transmissionModalEl = document.getElementById('transmissionModal');

    if (transmissionModalEl) {
        const transmissionModal = new bootstrap.Modal(transmissionModalEl);

        if (applyTransmission) {
            applyTransmission.addEventListener('click', function () {
                const selectedOption = transmissionModalEl.querySelector('input[name="transmissionOption"]:checked');
                if (transmissionFilterBtn) {
                    if (selectedOption && selectedOption.value !== 'all') {
                        transmissionFilterBtn.classList.add('active');
                    } else {
                        transmissionFilterBtn.classList.remove('active');
                    }
                }
                transmissionModal.hide();
            });
        }
    }
});


// --- KẾT NỐI API TÌM KIẾM XE ---
// Hàm gọi API tìm kiếm xe với các filter cơ bản
async function searchCars({ location, carType, brand, transmission } = {}) {
    const carGrid = document.querySelector('.cars-grid');
    if (!carGrid) return;
    carGrid.innerHTML = '<p>Đang tải danh sách xe...</p>';
    try {
        // Gọi API /api/cars/search (GET)
        // Chỉ truyền các filter có giá trị
        const params = new URLSearchParams();
        if (location) params.append('location', location);
        if (carType) params.append('carType', carType);
        if (brand) params.append('brand', brand);
        if (transmission) params.append('transmission', transmission);
        params.append('size', 20); // lấy nhiều xe hơn mặc định
        const response = await api.request(`/cars/search?${params.toString()}`);
        if (response.success && response.data && Array.isArray(response.data.cars)) {
            displayCars(response.data.cars);
        } else {
            carGrid.innerHTML = '<p>Không tìm thấy xe phù hợp.</p>';
        }
    } catch (error) {
        carGrid.innerHTML = `<p class=\"error\">Lỗi khi tải danh sách xe: ${error.message}</p>`;
    }
}

// Hàm hiển thị danh sách xe (dạng card)
function displayCars(cars) {
    const carGrid = document.querySelector('.cars-grid');
    if (!carGrid) return;
    carGrid.innerHTML = '';
    if (!cars || cars.length === 0) {
        carGrid.innerHTML = '<p>Không có xe nào phù hợp.</p>';
        return;
    }
    cars.forEach(car => {
        const card = document.createElement('div');
        card.className = 'car-card-result';
        card.innerHTML = `
            <div class=\"car-image-wrapper\">
                <img src=\"${car.imageUrl || '../assets/inmage/default-car.png'}\" alt=\"Car\" class=\"car-result-img\">
            </div>
            <div class=\"car-info\">
                <div class=\"car-title\">${car.brand || ''} ${car.model || ''}</div>
                <div class=\"car-meta\">${car.year || ''} • ${car.transmission || ''} • ${car.fuelType || ''}</div>
                <div class=\"car-price\">${car.pricePerDay ? (car.pricePerDay.toLocaleString('vi-VN') + ' đ/ngày') : ''}</div>
            </div>
        `;
        card.addEventListener('click', () => {
            // Chuyển sang trang chi tiết xe nếu muốn
            // window.location.href = `cardetail.html?id=${car.id}`;
        });
        carGrid.appendChild(card);
    });
}

// --- GỌI API KHI LOAD TRANG VÀ KHI FILTER ---
document.addEventListener('DOMContentLoaded', function() {
    // Lấy location từ URL (nếu có)
    const urlParams = new URLSearchParams(window.location.search);
    let location = urlParams.get('location');
    // Gọi API lần đầu
    searchCars({ location });

    // Xử lý filter loại xe
    document.querySelectorAll('.car-type-item').forEach(item => {
        item.addEventListener('click', function() {
            const carType = this.dataset.type;
            searchCars({ location, carType });
        });
    });

    // Xử lý filter hãng xe
    document.querySelectorAll('.brand-card-item').forEach(item => {
        item.addEventListener('click', function() {
            const brand = this.dataset.brand;
            searchCars({ location, brand });
        });
    });

    // Xử lý filter truyền động (nếu có)
    document.querySelectorAll('.transmission-list input[type="radio"]').forEach(item => {
        item.addEventListener('change', function() {
            const transmission = this.value;
            searchCars({ location, transmission });
        });
    });
});
