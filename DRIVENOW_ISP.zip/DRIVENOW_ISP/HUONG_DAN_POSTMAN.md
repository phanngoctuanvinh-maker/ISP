# 📮 HƯỚNG DẪN TEST API SEARCH TRONG POSTMAN

## Bước 1: Tạo Collection mới

1. **Mở Postman** (bạn đã mở rồi)
2. Click vào **"Collections"** ở sidebar bên trái
3. Click nút **"+"** hoặc **"New"** > **"Collection"**
4. Đặt tên: **"DriveNow - Car Search API"**

---

## Bước 2: Thêm các Request vào Collection

### 📌 **Request 1: Lấy tất cả xe**

1. Click vào Collection vừa tạo
2. Click **"Add request"**
3. Đặt tên: **"Get All Cars"**
4. Cấu hình:
   - **Method:** `GET`
   - **URL:** `http://localhost:8080/api/cars`
5. Click **"Send"** để test

**Kết quả mong đợi:**
```json
{
  "success": true,
  "data": [...],
  "total": 12
}
```

---

### 📌 **Request 2: Tìm kiếm xe cơ bản**

1. Add request mới: **"Search Cars - Basic"**
2. Cấu hình:
   - **Method:** `GET`
   - **URL:** `http://localhost:8080/api/cars/search`
3. Thêm **Query Params** (tab Params):

| Key | Value | Description |
|-----|-------|-------------|
| location | Nội Bài | Địa điểm |
| page | 0 | Trang |
| size | 12 | Số xe/trang |

4. Click **"Send"**

---

### 📌 **Request 3: Lọc theo hãng xe**

1. Add request: **"Search Cars - By Brand"**
2. Cấu hình:
   - **Method:** `GET`
   - **URL:** `http://localhost:8080/api/cars/search`
3. **Query Params:**

| Key | Value |
|-----|-------|
| brand | toyota |
| page | 0 |
| size | 12 |

4. Click **"Send"**

---

### 📌 **Request 4: Lọc theo giá**

1. Add request: **"Search Cars - By Price Range"**
2. Cấu hình:
   - **Method:** `GET`
   - **URL:** `http://localhost:8080/api/cars/search`
3. **Query Params:**

| Key | Value |
|-----|-------|
| minPrice | 400000 |
| maxPrice | 600000 |
| page | 0 |
| size | 12 |

4. Click **"Send"**

---

### 📌 **Request 5: Lọc theo số chỗ**

1. Add request: **"Search Cars - By Seat Capacity"**
2. Cấu hình:
   - **Method:** `GET`
   - **URL:** `http://localhost:8080/api/cars/search`
3. **Query Params:**

| Key | Value |
|-----|-------|
| minSeatCapacity | 7 |
| maxSeatCapacity | 7 |

4. Click **"Send"**

---

### 📌 **Request 6: Lọc nâng cao (Full Parameters)**

1. Add request: **"Search Cars - Advanced Filter"**
2. Cấu hình:
   - **Method:** `GET`
   - **URL:** `http://localhost:8080/api/cars/search`
3. **Query Params đầy đủ:**

| Key | Value | Mô tả |
|-----|-------|-------|
| location | Nội Bài | Địa điểm |
| brand | toyota | Hãng xe |
| transmission | Số tự động | Truyền động |
| fuelType | Xăng | Nhiên liệu |
| minPrice | 400000 | Giá tối thiểu |
| maxPrice | 600000 | Giá tối đa |
| minSeatCapacity | 5 | Số ghế tối thiểu |
| maxSeatCapacity | 7 | Số ghế tối đa |
| minYear | 2022 | Năm SX tối thiểu |
| maxYear | 2024 | Năm SX tối đa |
| sortBy | dailyRate | Sắp xếp theo |
| sortOrder | asc | Thứ tự |
| page | 0 | Trang |
| size | 12 | Kích thước |

4. Click **"Send"**

---

### 📌 **Request 7: Lọc với POST (JSON Body)**

1. Add request: **"Filter Cars - POST"**
2. Cấu hình:
   - **Method:** `POST`
   - **URL:** `http://localhost:8080/api/cars/filter`
3. Chọn tab **"Body"** > **"raw"** > chọn **"JSON"**
4. Nhập JSON:

```json
{
  "location": "Nội Bài",
  "brand": "toyota",
  "transmission": "Số tự động",
  "fuelType": "Xăng",
  "minPrice": 400000,
  "maxPrice": 600000,
  "minSeatCapacity": 5,
  "maxSeatCapacity": 7,
  "minYear": 2022,
  "maxYear": 2024,
  "sortBy": "dailyRate",
  "sortOrder": "asc",
  "page": 0,
  "size": 12
}
```

5. Click **"Send"**

---

### 📌 **Request 8: Lấy chi tiết xe**

1. Add request: **"Get Car By ID"**
2. Cấu hình:
   - **Method:** `GET`
   - **URL:** `http://localhost:8080/api/cars/1`
   - (Thay `1` bằng ID xe bạn muốn xem)
3. Click **"Send"**

---

### 📌 **Request 9: Lấy danh sách hãng xe**

1. Add request: **"Get All Brands"**
2. Cấu hình:
   - **Method:** `GET`
   - **URL:** `http://localhost:8080/api/cars/brands`
3. Click **"Send"**

---

### 📌 **Request 10: Đếm xe theo hãng**

1. Add request: **"Count Cars By Brand"**
2. Cấu hình:
   - **Method:** `GET`
   - **URL:** `http://localhost:8080/api/cars/count/toyota`
   - (Thay `toyota` bằng hãng khác: honda, mazda, ford, vinfast, etc.)
3. Click **"Send"**

---

## Bước 3: Các test case phổ biến

### ✅ **Test 1: Tìm xe điện**
```
GET http://localhost:8080/api/cars/search?fuelType=Điện
```

### ✅ **Test 2: Tìm xe xăng & điện (hybrid)**
```
GET http://localhost:8080/api/cars/search?fuelType=Xăng & điện
```

### ✅ **Test 3: Tìm xe số sàn**
```
GET http://localhost:8080/api/cars/search?transmission=Số sàn
```

### ✅ **Test 4: Tìm xe 4 chỗ mini**
```
GET http://localhost:8080/api/cars/search?minSeatCapacity=4&maxSeatCapacity=4
```

### ✅ **Test 5: Tìm xe Ford**
```
GET http://localhost:8080/api/cars/search?brand=ford
```

### ✅ **Test 6: Tìm xe giá rẻ (dưới 500k)**
```
GET http://localhost:8080/api/cars/search?maxPrice=500000&sortBy=dailyRate&sortOrder=asc
```

### ✅ **Test 7: Tìm xe mới (2023-2024)**
```
GET http://localhost:8080/api/cars/search?minYear=2023&maxYear=2024
```

---

## Bước 4: Lưu và Xuất Collection

### Lưu Collection:
1. Click chuột phải vào Collection
2. Chọn **"Save"**

### Xuất Collection (để backup):
1. Click vào Collection
2. Click nút **"..."** (3 chấm)
3. Chọn **"Export"**
4. Chọn **"Collection v2.1"**
5. Click **"Export"**
6. Lưu file JSON

---

## 🎯 Tips để test hiệu quả:

### 1. **Sử dụng Variables**
- Click vào Collection > tab **"Variables"**
- Thêm biến:
  - `baseUrl` = `http://localhost:8080`
  - `apiPath` = `/api/cars`
- Sau đó URL sẽ là: `{{baseUrl}}{{apiPath}}/search`

### 2. **Tạo Environment**
- Click vào icon **"Environment"** (hình bánh răng)
- Chọn **"Add"**
- Tên: **"DriveNow Local"**
- Thêm:
  - `baseUrl` = `http://localhost:8080`
  - `port` = `8080`

### 3. **Sử dụng Tests (Automation)**
Trong tab **"Tests"** của mỗi request, thêm:

```javascript
// Test status code
pm.test("Status code is 200", function () {
    pm.response.to.have.status(200);
});

// Test response time
pm.test("Response time is less than 1000ms", function () {
    pm.expect(pm.response.responseTime).to.be.below(1000);
});

// Test response structure
pm.test("Response has cars array", function () {
    var jsonData = pm.response.json();
    pm.expect(jsonData).to.have.property('cars');
});
```

---

## 🚨 Xử lý lỗi thường gặp:

### Lỗi 1: "Could not get any response"
**Nguyên nhân:** Server chưa chạy hoặc sai URL
**Giải pháp:**
- Kiểm tra server đang chạy: http://localhost:8080
- Kiểm tra URL trong Postman
- Tắt SSL verification: Settings > General > SSL certificate verification = OFF

### Lỗi 2: "404 Not Found"
**Nguyên nhân:** Sai endpoint
**Giải pháp:**
- Kiểm tra URL: `/api/cars/search` (không phải `/cars/search`)
- Kiểm tra method: GET không phải POST

### Lỗi 3: "500 Internal Server Error"
**Nguyên nhân:** Lỗi trong code hoặc database chưa có data
**Giải pháp:**
- Chạy SQL script: `insert_car_data.sql`
- Kiểm tra logs trong terminal VS Code

---

## 📊 Kết quả mẫu:

### Response thành công:
```json
{
  "cars": [
    {
      "id": 1,
      "brand": "Toyota",
      "model": "Vios",
      "name": "Toyota Vios 2023",
      "color": "Trắng",
      "dailyRate": 500000,
      "fuelType": "Xăng",
      "transmission": "Số tự động",
      "seatCapacity": 5,
      "year": 2023,
      "mileage": 15000,
      "status": "AVAILABLE",
      "location": "Nội Bài - Tân Sơn Nhất",
      "imageUrl": "../car/car/OIP.webp"
    }
  ],
  "currentPage": 0,
  "totalItems": 1,
  "totalPages": 1
}
```

---

## 🎉 Hoàn tất!

Bây giờ bạn đã có đầy đủ Collection để test tất cả API Search!

**Server đang chạy:** http://localhost:8080
**API Base:** http://localhost:8080/api/cars

Chúc bạn test thành công! 🚀
