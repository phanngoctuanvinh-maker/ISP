@echo off
echo ========================================
echo   RESTART SERVER - DRIVENOW
echo ========================================
echo.

echo [1/3] Dung server cu (port 8080)...
FOR /F "tokens=5" %%P IN ('netstat -ano ^| findstr :8080') DO (
    echo Tim thay process: %%P
    taskkill /F /PID %%P
)
timeout /t 2 /nobreak >nul

echo.
echo [2/3] Xoa cache Maven...
cd /d "%~dp0"
if exist target\classes (
    echo Xoa target\classes...
    rmdir /s /q target\classes 2>nul
)

echo.
echo [3/3] Khoi dong server moi...
echo Server se chay tai: http://localhost:8080
echo.
call mvn clean spring-boot:run

pause
