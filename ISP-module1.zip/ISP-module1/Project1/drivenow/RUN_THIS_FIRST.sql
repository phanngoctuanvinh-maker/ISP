-- =====================================================
-- CHẠY FILE NÀY TRƯỚC KHI TEST API
-- =====================================================

USE drivenow_db;
GO

-- Xóa bảng cũ nếu có (để tạo lại từ đầu)
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'revenue_reports')
    DROP TABLE revenue_reports;
GO

IF EXISTS (SELECT * FROM sys.tables WHERE name = 'rental_payments')
    DROP TABLE rental_payments;
GO

IF EXISTS (SELECT * FROM sys.tables WHERE name = 'deposits')
    DROP TABLE deposits;
GO

IF EXISTS (SELECT * FROM sys.tables WHERE name = 'transactions')
    DROP TABLE transactions;
GO

-- =====================================================
-- 1. Bảng TRANSACTIONS - Quản lý tất cả giao dịch
-- =====================================================
CREATE TABLE transactions (
    id BIGINT PRIMARY KEY IDENTITY(1,1),
    transaction_code VARCHAR(50) UNIQUE NOT NULL,
    booking_id BIGINT NULL,
    user_id BIGINT NOT NULL,
    transaction_type VARCHAR(20) NOT NULL CHECK (transaction_type IN ('DEPOSIT', 'PAYMENT', 'REFUND', 'PENALTY')),
    amount DECIMAL(15,2) NOT NULL CHECK (amount > 0),
    payment_method VARCHAR(50) NOT NULL CHECK (payment_method IN ('VNPAY', 'CASH', 'BANK_TRANSFER', 'CREDIT_CARD')),
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'COMPLETED', 'FAILED', 'REFUNDED', 'CANCELLED')),
    description NVARCHAR(500),
    reference_code VARCHAR(100),
    created_at DATETIME2 DEFAULT GETDATE(),
    updated_at DATETIME2 DEFAULT GETDATE(),
    completed_at DATETIME2 NULL,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE INDEX idx_transactions_user ON transactions(user_id);
CREATE INDEX idx_transactions_booking ON transactions(booking_id);
CREATE INDEX idx_transactions_type ON transactions(transaction_type);
CREATE INDEX idx_transactions_status ON transactions(status);
CREATE INDEX idx_transactions_created ON transactions(created_at);
GO

-- =====================================================
-- 2. Bảng DEPOSITS - Quản lý tiền cọc
-- =====================================================
CREATE TABLE deposits (
    id BIGINT PRIMARY KEY IDENTITY(1,1),
    deposit_code VARCHAR(50) UNIQUE NOT NULL,
    booking_id BIGINT NOT NULL,
    user_id BIGINT NOT NULL,
    transaction_id BIGINT NULL,
    deposit_amount DECIMAL(15,2) NOT NULL CHECK (deposit_amount > 0),
    refund_amount DECIMAL(15,2) DEFAULT 0 CHECK (refund_amount >= 0),
    penalty_amount DECIMAL(15,2) DEFAULT 0 CHECK (penalty_amount >= 0),
    deposit_status VARCHAR(20) NOT NULL DEFAULT 'PENDING' CHECK (deposit_status IN ('PENDING', 'PAID', 'REFUNDED', 'PARTIALLY_REFUNDED', 'FORFEITED')),
    payment_method VARCHAR(50),
    deposit_date DATETIME2 DEFAULT GETDATE(),
    refund_date DATETIME2 NULL,
    notes NVARCHAR(500),
    created_at DATETIME2 DEFAULT GETDATE(),
    updated_at DATETIME2 DEFAULT GETDATE(),
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (transaction_id) REFERENCES transactions(id)
);

CREATE INDEX idx_deposits_user ON deposits(user_id);
CREATE INDEX idx_deposits_booking ON deposits(booking_id);
CREATE INDEX idx_deposits_status ON deposits(deposit_status);
CREATE INDEX idx_deposits_code ON deposits(deposit_code);
GO

-- =====================================================
-- 3. Bảng RENTAL_PAYMENTS - Thanh toán thuê xe
-- =====================================================
CREATE TABLE rental_payments (
    id BIGINT PRIMARY KEY IDENTITY(1,1),
    payment_code VARCHAR(50) UNIQUE NOT NULL,
    booking_id BIGINT NOT NULL,
    user_id BIGINT NOT NULL,
    transaction_id BIGINT NULL,
    rental_amount DECIMAL(15,2) NOT NULL CHECK (rental_amount > 0),
    discount_amount DECIMAL(15,2) DEFAULT 0 CHECK (discount_amount >= 0),
    additional_fee DECIMAL(15,2) DEFAULT 0 CHECK (additional_fee >= 0),
    total_amount DECIMAL(15,2) NOT NULL CHECK (total_amount > 0),
    payment_status VARCHAR(20) NOT NULL DEFAULT 'PENDING' CHECK (payment_status IN ('PENDING', 'PAID', 'FAILED', 'REFUNDED', 'CANCELLED')),
    payment_method VARCHAR(50),
    payment_date DATETIME2 DEFAULT GETDATE(),
    due_date DATETIME2 NULL,
    notes NVARCHAR(500),
    created_at DATETIME2 DEFAULT GETDATE(),
    updated_at DATETIME2 DEFAULT GETDATE(),
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (transaction_id) REFERENCES transactions(id)
);

CREATE INDEX idx_rental_payments_user ON rental_payments(user_id);
CREATE INDEX idx_rental_payments_booking ON rental_payments(booking_id);
CREATE INDEX idx_rental_payments_status ON rental_payments(payment_status);
GO

-- =====================================================
-- 4. Bảng REVENUE_REPORTS - Báo cáo doanh thu
-- =====================================================
CREATE TABLE revenue_reports (
    id BIGINT PRIMARY KEY IDENTITY(1,1),
    report_code VARCHAR(50) UNIQUE NOT NULL,
    report_date DATE NOT NULL,
    total_deposits DECIMAL(15,2) DEFAULT 0,
    total_payments DECIMAL(15,2) DEFAULT 0,
    total_refunds DECIMAL(15,2) DEFAULT 0,
    total_penalties DECIMAL(15,2) DEFAULT 0,
    net_revenue DECIMAL(15,2) DEFAULT 0,
    transaction_count INT DEFAULT 0,
    notes NVARCHAR(500),
    created_at DATETIME2 DEFAULT GETDATE(),
    updated_at DATETIME2 DEFAULT GETDATE()
);

CREATE INDEX idx_revenue_date ON revenue_reports(report_date);
GO

-- =====================================================
-- TRIGGER tự động cập nhật updated_at
-- =====================================================
CREATE TRIGGER trg_transactions_update
ON transactions
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE transactions
    SET updated_at = GETDATE()
    FROM transactions t
    INNER JOIN inserted i ON t.id = i.id;
END;
GO

CREATE TRIGGER trg_deposits_update
ON deposits
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE deposits
    SET updated_at = GETDATE()
    FROM deposits d
    INNER JOIN inserted i ON d.id = i.id;
END;
GO

-- =====================================================
-- KIỂM TRA KẾT QUẢ
-- =====================================================
PRINT '✅ Đã tạo 4 bảng thành công!';
PRINT '1. transactions - Quản lý giao dịch';
PRINT '2. deposits - Quản lý tiền cọc';
PRINT '3. rental_payments - Thanh toán thuê xe';
PRINT '4. revenue_reports - Báo cáo doanh thu';
GO

-- Kiểm tra bảng
SELECT 
    t.name AS 'Table Name',
    (SELECT COUNT(*) FROM sys.columns c WHERE c.object_id = t.object_id) AS 'Column Count'
FROM sys.tables t
WHERE t.name IN ('transactions', 'deposits', 'rental_payments', 'revenue_reports')
ORDER BY t.name;
GO
