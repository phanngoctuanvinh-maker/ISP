-- =====================================================
-- HỆ THỐNG QUẢN LÝ THANH TOÁN - DRIVENOW
-- Bao gồm: Tiền cọc, Thanh toán, Hoàn cọc, Doanh thu
-- =====================================================

USE drivenow_db;
GO

-- 1. Bảng TRANSACTIONS - Quản lý tất cả giao dịch tài chính
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'transactions')
BEGIN
    CREATE TABLE transactions (
        id BIGINT PRIMARY KEY IDENTITY(1,1),
        transaction_code VARCHAR(50) UNIQUE NOT NULL,
        booking_id BIGINT NULL, -- Liên kết với booking (nếu có)
        user_id BIGINT NOT NULL, -- Khách hàng
        transaction_type VARCHAR(20) NOT NULL CHECK (transaction_type IN ('DEPOSIT', 'PAYMENT', 'REFUND', 'PENALTY')),
        amount DECIMAL(15,2) NOT NULL CHECK (amount > 0),
        payment_method VARCHAR(50) NOT NULL CHECK (payment_method IN ('VNPAY', 'CASH', 'BANK_TRANSFER', 'CREDIT_CARD')),
        status VARCHAR(20) NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'COMPLETED', 'FAILED', 'REFUNDED', 'CANCELLED')),
        description NVARCHAR(500),
        reference_code VARCHAR(100), -- Mã tham chiếu từ VNPay hoặc hệ thống khác
        created_at DATETIME2 DEFAULT GETDATE(),
        updated_at DATETIME2 DEFAULT GETDATE(),
        completed_at DATETIME2 NULL,
        FOREIGN KEY (user_id) REFERENCES users(id)
    );
    
    CREATE INDEX idx_transactions_user ON transactions(user_id);
    CREATE INDEX idx_transactions_booking ON transactions(booking_id);
    CREATE INDEX idx_transactions_type ON transactions(transaction_type);
    CREATE INDEX idx_transactions_status ON transactions(status);
    CREATE INDEX idx_transactions_created ON transactions(created_at);
END;
GO

-- 2. Bảng DEPOSITS - Quản lý tiền cọc chi tiết
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'deposits')
BEGIN
    CREATE TABLE deposits (
        id BIGINT PRIMARY KEY IDENTITY(1,1),
        deposit_code VARCHAR(50) UNIQUE NOT NULL,
        booking_id BIGINT NOT NULL,
        user_id BIGINT NOT NULL,
        transaction_id BIGINT NULL, -- Liên kết với transaction
        deposit_amount DECIMAL(15,2) NOT NULL CHECK (deposit_amount > 0),
        refund_amount DECIMAL(15,2) DEFAULT 0 CHECK (refund_amount >= 0),
        penalty_amount DECIMAL(15,2) DEFAULT 0 CHECK (penalty_amount >= 0),
        deposit_status VARCHAR(20) NOT NULL DEFAULT 'PENDING' CHECK (deposit_status IN ('PENDING', 'PAID', 'REFUNDED', 'PARTIALLY_REFUNDED', 'FORFEITED')),
        payment_method VARCHAR(50),
        deposit_date DATETIME2 DEFAULT GETDATE(),
        refund_date DATETIME2 NULL,
        notes NVARCHAR(1000),
        created_at DATETIME2 DEFAULT GETDATE(),
        updated_at DATETIME2 DEFAULT GETDATE(),
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (transaction_id) REFERENCES transactions(id)
    );
    
    CREATE INDEX idx_deposits_booking ON deposits(booking_id);
    CREATE INDEX idx_deposits_user ON deposits(user_id);
    CREATE INDEX idx_deposits_status ON deposits(deposit_status);
END;
GO

-- 3. Bảng RENTAL_PAYMENTS - Thanh toán phí thuê xe
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'rental_payments')
BEGIN
    CREATE TABLE rental_payments (
        id BIGINT PRIMARY KEY IDENTITY(1,1),
        payment_code VARCHAR(50) UNIQUE NOT NULL,
        booking_id BIGINT NOT NULL,
        user_id BIGINT NOT NULL,
        transaction_id BIGINT NULL,
        base_price DECIMAL(15,2) NOT NULL CHECK (base_price >= 0), -- Giá thuê cơ bản
        additional_fees DECIMAL(15,2) DEFAULT 0 CHECK (additional_fees >= 0), -- Phí phụ thu
        discount_amount DECIMAL(15,2) DEFAULT 0 CHECK (discount_amount >= 0), -- Giảm giá
        loyalty_discount DECIMAL(15,2) DEFAULT 0 CHECK (loyalty_discount >= 0), -- Giảm giá khách hàng thân thiết
        total_amount DECIMAL(15,2) NOT NULL CHECK (total_amount >= 0),
        paid_amount DECIMAL(15,2) DEFAULT 0 CHECK (paid_amount >= 0),
        payment_status VARCHAR(20) NOT NULL DEFAULT 'UNPAID' CHECK (payment_status IN ('UNPAID', 'PARTIAL', 'PAID', 'OVERDUE')),
        payment_method VARCHAR(50),
        payment_date DATETIME2 NULL,
        due_date DATETIME2 NULL,
        created_at DATETIME2 DEFAULT GETDATE(),
        updated_at DATETIME2 DEFAULT GETDATE(),
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (transaction_id) REFERENCES transactions(id)
    );
    
    CREATE INDEX idx_rental_payments_booking ON rental_payments(booking_id);
    CREATE INDEX idx_rental_payments_user ON rental_payments(user_id);
    CREATE INDEX idx_rental_payments_status ON rental_payments(payment_status);
END;
GO

-- 4. Bảng REVENUE_REPORTS - Báo cáo doanh thu
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'revenue_reports')
BEGIN
    CREATE TABLE revenue_reports (
        id BIGINT PRIMARY KEY IDENTITY(1,1),
        report_date DATE NOT NULL,
        report_type VARCHAR(20) NOT NULL CHECK (report_type IN ('DAILY', 'WEEKLY', 'MONTHLY', 'YEARLY')),
        total_revenue DECIMAL(15,2) DEFAULT 0,
        deposit_revenue DECIMAL(15,2) DEFAULT 0,
        rental_revenue DECIMAL(15,2) DEFAULT 0,
        penalty_revenue DECIMAL(15,2) DEFAULT 0,
        refund_amount DECIMAL(15,2) DEFAULT 0,
        total_transactions INT DEFAULT 0,
        created_at DATETIME2 DEFAULT GETDATE(),
        updated_at DATETIME2 DEFAULT GETDATE(),
        UNIQUE (report_date, report_type)
    );
    
    CREATE INDEX idx_revenue_date ON revenue_reports(report_date);
    CREATE INDEX idx_revenue_type ON revenue_reports(report_type);
END;
GO

-- 5. Thêm trigger tự động cập nhật updated_at
CREATE OR ALTER TRIGGER trg_transactions_update
ON transactions
AFTER UPDATE
AS
BEGIN
    UPDATE transactions
    SET updated_at = GETDATE()
    FROM transactions t
    INNER JOIN inserted i ON t.id = i.id;
END;
GO

CREATE OR ALTER TRIGGER trg_deposits_update
ON deposits
AFTER UPDATE
AS
BEGIN
    UPDATE deposits
    SET updated_at = GETDATE()
    FROM deposits d
    INNER JOIN inserted i ON d.id = i.id;
END;
GO

CREATE OR ALTER TRIGGER trg_rental_payments_update
ON rental_payments
AFTER UPDATE
AS
BEGIN
    UPDATE rental_payments
    SET updated_at = GETDATE()
    FROM rental_payments rp
    INNER JOIN inserted i ON rp.id = i.id;
END;
GO

PRINT 'Database schema for Payment Management created successfully!';
