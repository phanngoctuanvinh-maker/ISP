-- =====================================================
-- INSERT TEST DATA FOR DEPOSIT MANAGEMENT
-- =====================================================

USE drivenow_db;
GO

-- Test data for transactions
INSERT INTO transactions (transaction_code, booking_id, user_id, transaction_type, amount, payment_method, status, description, created_at, updated_at)
VALUES 
('TXN-TEST001', 1, 1, 'DEPOSIT', 5000000, 'VNPAY', 'COMPLETED', 'Test deposit for booking 1', GETDATE(), GETDATE()),
('TXN-TEST002', 2, 2, 'DEPOSIT', 3000000, 'CASH', 'PENDING', 'Test deposit for booking 2', GETDATE(), GETDATE());
GO

-- Test data for deposits
INSERT INTO deposits (deposit_code, booking_id, user_id, transaction_id, deposit_amount, refund_amount, penalty_amount, deposit_status, payment_method, deposit_date, notes, created_at, updated_at)
VALUES 
('DEP-TEST001', 1, 1, 1, 5000000, 0, 0, 'PAID', 'VNPAY', GETDATE(), 'Test deposit - paid', GETDATE(), GETDATE()),
('DEP-TEST002', 2, 2, 2, 3000000, 0, 0, 'PENDING', 'CASH', GETDATE(), 'Test deposit - pending', GETDATE(), GETDATE());
GO

PRINT 'Test data inserted successfully!';
