-- ===================================
-- FIX DISCOUNT_TYPE ENUM VALUES
-- ===================================
-- Lỗi: "No enum constant PERCENT" vì DB có giá trị cũ "PERCENT" 
-- nhưng Java enum là "PERCENTAGE"

USE drivenow_db;
GO

-- 1. XÓA TẤT CẢ DATA CŨ (nếu muốn)
PRINT 'Deleting old test data...';
DELETE FROM loyalty_history;
DELETE FROM loyalty_points;
DELETE FROM promo_codes;
DELETE FROM promotions;
GO

PRINT 'Old data deleted successfully!';
GO

-- 2. RESET IDENTITY (bắt đầu từ 1)
DBCC CHECKIDENT ('promotions', RESEED, 0);
DBCC CHECKIDENT ('promo_codes', RESEED, 0);
DBCC CHECKIDENT ('loyalty_points', RESEED, 0);
DBCC CHECKIDENT ('loyalty_history', RESEED, 0);
GO

-- 3. INSERT TEST DATA MỚI (với PERCENTAGE và FIXED_AMOUNT đúng)
PRINT 'Inserting new test data...';

-- Promotions
INSERT INTO promotions (name, description, discount_type, discount_value, min_order_value, max_discount_amount, start_date, end_date, usage_limit, used_count, status, created_by, created_at, updated_at)
VALUES ('Giảm 20% cho đơn hàng từ 1 triệu', 'Khuyến mãi giảm 20% cho tất cả đơn hàng từ 1,000,000 VND trở lên. Tối đa giảm 200,000 VND', 'PERCENTAGE', 20.0, 1000000.0, 200000.0, '2025-01-01 00:00:00', '2025-12-31 23:59:59', 100, 0, 'ACTIVE', 1, GETDATE(), GETDATE());

INSERT INTO promotions (name, description, discount_type, discount_value, min_order_value, max_discount_amount, start_date, end_date, usage_limit, used_count, status, created_by, created_at, updated_at)
VALUES ('Giảm 15% cho khách hàng mới', 'Chương trình dành riêng cho khách hàng mới. Giảm 15% tối đa 150,000 VND', 'PERCENTAGE', 15.0, 500000.0, 150000.0, '2025-01-01 00:00:00', '2025-12-31 23:59:59', 200, 5, 'ACTIVE', 1, GETDATE(), GETDATE());

INSERT INTO promotions (name, description, discount_type, discount_value, min_order_value, max_discount_amount, start_date, end_date, usage_limit, used_count, status, created_by, created_at, updated_at)
VALUES ('Giảm 100,000 VND', 'Giảm cố định 100,000 VND cho đơn hàng từ 800,000 VND', 'FIXED_AMOUNT', 100000.0, 800000.0, NULL, '2025-01-01 00:00:00', '2025-06-30 23:59:59', 50, 10, 'ACTIVE', 1, GETDATE(), GETDATE());

INSERT INTO promotions (name, description, discount_type, discount_value, min_order_value, max_discount_amount, start_date, end_date, usage_limit, used_count, status, created_by, created_at, updated_at)
VALUES ('Flash Sale 30%', 'Flash sale cuối tuần - Giảm 30% tối đa 300,000 VND', 'PERCENTAGE', 30.0, 1500000.0, 300000.0, '2025-06-01 00:00:00', '2025-06-30 23:59:59', 20, 15, 'ACTIVE', 1, GETDATE(), GETDATE());

INSERT INTO promotions (name, description, discount_type, discount_value, min_order_value, max_discount_amount, start_date, end_date, usage_limit, used_count, status, created_by, created_at, updated_at)
VALUES ('Khuyến mãi tháng 3', 'Đã hết hạn - Giảm 25%', 'PERCENTAGE', 25.0, 1000000.0, 250000.0, '2024-03-01 00:00:00', '2024-03-31 23:59:59', 100, 80, 'INACTIVE', 1, GETDATE(), GETDATE());

-- Promo codes
INSERT INTO promo_codes (promotion_id, code, single_use, max_uses, used_count, user_restriction, min_order_value, created_at, expires_at)
VALUES (1, 'SAVE20', 0, 100, 10, NULL, 1000000.0, GETDATE(), '2025-12-31 23:59:59');

INSERT INTO promo_codes (promotion_id, code, single_use, max_uses, used_count, user_restriction, min_order_value, created_at, expires_at)
VALUES (2, 'NEWCUSTOMER15', 1, 1, 0, 2, 500000.0, GETDATE(), '2025-12-31 23:59:59');

INSERT INTO promo_codes (promotion_id, code, single_use, max_uses, used_count, user_restriction, min_order_value, created_at, expires_at)
VALUES (3, 'FLAT100K', 0, 50, 5, NULL, 800000.0, GETDATE(), '2025-06-30 23:59:59');

INSERT INTO promo_codes (promotion_id, code, single_use, max_uses, used_count, user_restriction, min_order_value, created_at, expires_at)
VALUES (4, 'FLASHSALE30', 0, 20, 8, NULL, 1500000.0, GETDATE(), '2025-06-30 23:59:59');

INSERT INTO promo_codes (promotion_id, code, single_use, max_uses, used_count, user_restriction, min_order_value, created_at, expires_at)
VALUES (1, 'WELCOME2024', 0, 200, 25, NULL, 500000.0, GETDATE(), '2025-12-31 23:59:59');

INSERT INTO promo_codes (promotion_id, code, single_use, max_uses, used_count, user_restriction, min_order_value, created_at, expires_at)
VALUES (5, 'MARCH2024', 0, 100, 75, NULL, 1000000.0, '2024-03-01 00:00:00', '2024-03-31 23:59:59');

INSERT INTO promo_codes (promotion_id, code, single_use, max_uses, used_count, user_restriction, min_order_value, created_at, expires_at)
VALUES (2, 'ONETIME15', 1, 1, 0, 3, 500000.0, GETDATE(), '2025-12-31 23:59:59');

INSERT INTO promo_codes (promotion_id, code, single_use, max_uses, used_count, user_restriction, min_order_value, created_at, expires_at)
VALUES (4, 'VIP30', 0, 10, 3, NULL, 2000000.0, GETDATE(), '2025-12-31 23:59:59');

-- Loyalty points
INSERT INTO loyalty_points (user_id, points, lifetime_points, last_updated)
VALUES (1, 150, 450, GETDATE());

INSERT INTO loyalty_points (user_id, points, lifetime_points, last_updated)
VALUES (2, 650, 850, GETDATE());

INSERT INTO loyalty_points (user_id, points, lifetime_points, last_updated)
VALUES (3, 1200, 1500, GETDATE());

INSERT INTO loyalty_points (user_id, points, lifetime_points, last_updated)
VALUES (4, 2500, 3200, GETDATE());

INSERT INTO loyalty_points (user_id, points, lifetime_points, last_updated)
VALUES (5, 80, 80, GETDATE());

-- Loyalty history
INSERT INTO loyalty_history (user_id, transaction_type, points, order_value, description, created_at)
VALUES (1, 'EARN', 30, 3000000, 'Thuê xe Mercedes E-Class 3 ngày', DATEADD(day, -10, GETDATE()));

INSERT INTO loyalty_history (user_id, transaction_type, points, order_value, description, created_at)
VALUES (1, 'EARN', 20, 2000000, 'Thuê xe Toyota Camry 2 ngày', DATEADD(day, -5, GETDATE()));

INSERT INTO loyalty_history (user_id, transaction_type, points, order_value, description, created_at)
VALUES (1, 'REDEEM', -50, NULL, 'Đổi điểm lấy voucher 500k', DATEADD(day, -2, GETDATE()));

GO

PRINT '✅ Test data inserted successfully!';
GO

-- VERIFY
SELECT 'PROMOTIONS' as TableName, COUNT(*) as RecordCount FROM promotions;
SELECT discount_type, COUNT(*) as Count FROM promotions GROUP BY discount_type;
SELECT * FROM promotions;
GO
