# 🚀 HƯỚNG DẪN TEST PROMOTION & LOYALTY APIs QUA POSTMAN

## 📋 CHUẨN BỊ

### 1. Import Postman Collection
1. Mở Postman
2. Click **Import** → **Upload Files**
3. Chọn file: `drivenow-promotion-loyalty.postman_collection.json`
4. Click **Import**

### 2. Cài Đặt Environment Variables (Optional)
- `baseUrl`: `http://localhost:8080`
- `promotionId`: `1` (sẽ cập nhật sau khi tạo promotion)
- `userId`: `1`

---

## 🎯 TEST SCENARIOS - PROMOTION APIs (12 Tests)

### ✅ Test 1: Health Check
**Request:** `GET /api/promotions/test`

**Expected Response:**
```json
{
    "status": "success",
    "message": "Promotion API is working!",
    "timestamp": [2025, 10, 14, 20, 30, 15, 123456]
}
```

---

### ✅ Test 2: Tạo Promotion (Giảm 20%)
**Request:** `POST /api/promotions`

**Body:**
```json
{
  "name": "Summer Sale 2024",
  "description": "Giảm 20% cho tất cả đơn hàng mùa hè",
  "discountType": "PERCENTAGE",
  "discountValue": 20.0,
  "minOrderValue": 1000000.0,
  "maxDiscountAmount": 200000.0,
  "startDate": "2025-06-01T00:00:00",
  "endDate": "2025-12-31T23:59:59",
  "usageLimit": 100,
  "status": "ACTIVE",
  "createdBy": 1
}
```

**Expected Response:**
```json
{
    "status": "success",
    "message": "Tạo chương trình khuyến mãi thành công",
    "data": {
        "id": 6,
        "name": "Summer Sale 2024",
        "discountType": "PERCENTAGE",
        "discountValue": 20.0,
        ...
    }
}
```

📝 **Lưu lại `id` của promotion vừa tạo để dùng cho các test sau!**

---

### ✅ Test 3: Tạo Promotion (Giảm Cố Định 150k)
**Request:** `POST /api/promotions`

**Body:**
```json
{
  "name": "Giảm 150k cho khách mới",
  "description": "Giảm cố định 150,000 VND cho khách hàng mới",
  "discountType": "FIXED_AMOUNT",
  "discountValue": 150000.0,
  "minOrderValue": 500000.0,
  "startDate": "2025-01-01T00:00:00",
  "endDate": "2025-12-31T23:59:59",
  "usageLimit": 200,
  "status": "ACTIVE",
  "createdBy": 1
}
```

---

### ✅ Test 4: Lấy Tất Cả Promotions
**Request:** `GET /api/promotions`

**Expected Response:**
```json
{
    "status": "success",
    "data": [
        {
            "id": 1,
            "name": "Giảm 20% cho đơn hàng từ 1 triệu",
            ...
        },
        ...
    ],
    "count": 5
}
```

---

### ✅ Test 5: Lấy Promotion Theo ID
**Request:** `GET /api/promotions/1`

**Expected Response:**
```json
{
    "status": "success",
    "data": {
        "id": 1,
        "name": "Giảm 20% cho đơn hàng từ 1 triệu",
        "discountType": "PERCENTAGE",
        "discountValue": 20.0,
        ...
    }
}
```

---

### ✅ Test 6: Cập Nhật Promotion
**Request:** `PUT /api/promotions/1`

**Body:**
```json
{
  "name": "Summer Sale 2024 - UPDATED",
  "description": "Giảm 25% cho tất cả đơn hàng mùa hè (đã cập nhật)",
  "discountType": "PERCENTAGE",
  "discountValue": 25.0,
  "minOrderValue": 1000000.0,
  "maxDiscountAmount": 250000.0,
  "startDate": "2025-06-01T00:00:00",
  "endDate": "2025-08-31T23:59:59",
  "usageLimit": 150,
  "status": "ACTIVE",
  "createdBy": 1
}
```

---

### ✅ Test 7: Lấy Chỉ Promotions ACTIVE
**Request:** `GET /api/promotions/active`

**Expected Response:** Chỉ trả về các promotion có `status = "ACTIVE"`

---

### ✅ Test 8: Tạo Mã Promo Code
**Request:** `POST /api/promotions/codes`

**Body:**
```json
{
  "promotionId": 1,
  "code": "SUMMER20",
  "singleUse": false,
  "maxUses": 50,
  "minOrderValue": 1000000.0,
  "expiresAt": "2025-08-31T23:59:59"
}
```

**Expected Response:**
```json
{
    "status": "success",
    "message": "Tạo mã giảm giá thành công",
    "data": {
        "id": 9,
        "promotionId": 1,
        "code": "SUMMER20",
        ...
    }
}
```

---

### ✅ Test 9: Validate Promo Code
**Request:** `POST /api/promotions/validate-code`

**Body:**
```json
{
  "promoCode": "SAVE20",
  "userId": 1,
  "orderValue": 1500000
}
```

**Expected Response (Valid):**
```json
{
    "status": "success",
    "message": "Mã khuyến mãi hợp lệ",
    "data": {
        "valid": true,
        "promoCode": "SAVE20",
        "discountType": "PERCENTAGE",
        "discountValue": 20.0,
        "discountAmount": 200000,
        "finalAmount": 1300000,
        "promotion": {
            "id": 1,
            "name": "Giảm 20% cho đơn hàng từ 1 triệu"
        }
    }
}
```

**Test Cases:**
- ✅ Mã hợp lệ → status: success
- ❌ Mã không tồn tại → "Mã khuyến mãi không tồn tại"
- ❌ Mã hết hạn → "Mã khuyến mãi đã hết hạn"
- ❌ Đơn hàng < minOrderValue → "Giá trị đơn hàng không đạt yêu cầu tối thiểu"
- ❌ Mã đã dùng hết lượt → "Mã khuyến mãi đã hết lượt sử dụng"

---

### ✅ Test 10: Apply Promo Code (Tính Discount)
**Request:** `POST /api/promotions/apply`

**Body:**
```json
{
  "promoCode": "SAVE20",
  "userId": 1,
  "orderValue": 1500000
}
```

**Expected Response:**
```json
{
    "status": "success",
    "message": "Áp dụng mã khuyến mãi thành công",
    "data": {
        "promoCode": "SAVE20",
        "discountType": "PERCENTAGE",
        "discountValue": 20.0,
        "originalAmount": 1500000,
        "discountAmount": 200000,
        "finalAmount": 1300000,
        "saved": 200000
    }
}
```

⚠️ **LƯU Ý:** API này sẽ tăng `used_count` của promo code. Kiểm tra lại DB sau khi gọi!

---

### ✅ Test 11: Tìm Promotion Theo Promo Code
**Request:** `GET /api/promotions/code/SAVE20`

**Expected Response:**
```json
{
    "status": "success",
    "data": {
        "id": 1,
        "name": "Giảm 20% cho đơn hàng từ 1 triệu",
        ...
    }
}
```

---

### ✅ Test 12: Xóa Promotion
**Request:** `DELETE /api/promotions/6`

**Expected Response:**
```json
{
    "status": "success",
    "message": "Xóa chương trình khuyến mãi thành công"
}
```

---

## 💎 TEST SCENARIOS - LOYALTY APIs (7 Tests)

### ✅ Test 1: Health Check
**Request:** `GET /api/loyalty/test`

**Expected Response:**
```json
{
    "status": "success",
    "message": "Loyalty API is working!",
    "timestamp": [2025, 10, 14, 20, 30, 15, 123456]
}
```

---

### ✅ Test 2: Xem Điểm & Tier Của User
**Request:** `GET /api/loyalty/user/1`

**Expected Response:**
```json
{
    "status": "success",
    "data": {
        "userId": 1,
        "points": 150,
        "lifetimePoints": 450,
        "tier": "Bronze",
        "lastUpdated": "2025-10-14T20:30:00"
    }
}
```

**Tiers:**
- Bronze: 0-499 points
- Silver: 500-999 points
- Gold: 1000-1999 points
- Platinum: 2000+ points

---

### ✅ Test 3: Tích Điểm Từ Đơn Hàng (EARN)
**Request:** `POST /api/loyalty/add`

**Body:**
```json
{
  "userId": 1,
  "orderValue": 2500000,
  "description": "Thuê xe Mercedes E-Class 5 ngày"
}
```

**Expected Response:**
```json
{
    "status": "success",
    "message": "Tích điểm thành công",
    "data": {
        "pointsEarned": 25,
        "currentPoints": 175,
        "lifetimePoints": 475,
        "tier": "Bronze",
        "orderValue": 2500000,
        "description": "Thuê xe Mercedes E-Class 5 ngày"
    }
}
```

**Quy tắc tính điểm:** 100,000 VND = 1 điểm

---

### ✅ Test 4: Đổi Điểm Lấy Discount (REDEEM)
**Request:** `POST /api/loyalty/redeem`

**Body:**
```json
{
  "userId": 1,
  "points": 50,
  "description": "Đổi điểm lấy voucher 500k"
}
```

**Expected Response:**
```json
{
    "status": "success",
    "message": "Đổi điểm thành công",
    "data": {
        "pointsRedeemed": 50,
        "discountAmount": 500000,
        "remainingPoints": 125,
        "lifetimePoints": 475,
        "tier": "Bronze"
    }
}
```

**Quy tắc đổi điểm:**
- 1 điểm = 10,000 VND discount
- Tối thiểu đổi: 10 điểm

**Validation:**
- ❌ points < 10 → "Số điểm đổi tối thiểu là 10"
- ❌ points > currentPoints → "Số điểm không đủ"

---

### ✅ Test 5: Xem Lịch Sử Tích Điểm
**Request:** `GET /api/loyalty/history/1`

**Expected Response:**
```json
{
    "status": "success",
    "data": [
        {
            "id": 1,
            "userId": 1,
            "transactionType": "EARN",
            "points": 30,
            "orderValue": 3000000,
            "description": "Thuê xe Mercedes E-Class 3 ngày",
            "createdAt": "2025-10-04T10:30:00"
        },
        {
            "id": 2,
            "userId": 1,
            "transactionType": "REDEEM",
            "points": -50,
            "orderValue": null,
            "description": "Đổi điểm lấy voucher 500k",
            "createdAt": "2025-10-12T14:20:00"
        }
    ],
    "count": 2
}
```

---

### ✅ Test 6: Tính Điểm Từ Giá Trị Đơn Hàng
**Request:** `GET /api/loyalty/calculate?orderValue=3500000`

**Expected Response:**
```json
{
    "status": "success",
    "data": {
        "orderValue": 3500000,
        "pointsEarned": 35,
        "rate": "100,000 VND = 1 điểm"
    }
}
```

---

### ✅ Test 7: Tính Discount Từ Điểm
**Request:** `GET /api/loyalty/discount?points=100`

**Expected Response:**
```json
{
    "status": "success",
    "data": {
        "points": 100,
        "discountAmount": 1000000,
        "rate": "1 điểm = 10,000 VND"
    }
}
```

---

## 🔍 KIỂM TRA DATABASE

### 1. Kiểm tra promotions table
```sql
SELECT * FROM promotions;
SELECT * FROM promotions WHERE status = 'ACTIVE';
```

### 2. Kiểm tra promo_codes table
```sql
SELECT * FROM promo_codes;
SELECT code, used_count, max_uses FROM promo_codes;
```

### 3. Kiểm tra loyalty_points table
```sql
SELECT user_id, points, lifetime_points,
       CASE 
           WHEN lifetime_points >= 2000 THEN 'Platinum'
           WHEN lifetime_points >= 1000 THEN 'Gold'
           WHEN lifetime_points >= 500 THEN 'Silver'
           ELSE 'Bronze'
       END as tier
FROM loyalty_points;
```

### 4. Kiểm tra loyalty_history table
```sql
SELECT * FROM loyalty_history 
WHERE user_id = 1 
ORDER BY created_at DESC;
```

### 5. Kiểm tra used_count sau khi apply promo
```sql
-- Trước khi apply
SELECT code, used_count FROM promo_codes WHERE code = 'SAVE20';

-- Call API: POST /api/promotions/apply với promoCode = "SAVE20"

-- Sau khi apply (used_count phải tăng lên 1)
SELECT code, used_count FROM promo_codes WHERE code = 'SAVE20';
```

---

## 🎯 TEST FLOW HOÀN CHỈNH

### Scenario 1: Khách hàng mới thuê xe
1. **Tạo promotion** (Test 2) → Lưu promotionId
2. **Tạo promo code** (Test 8) → Mã "NEWCUSTOMER"
3. **Khách hàng nhập mã** → Validate (Test 9)
4. **Áp dụng mã giảm giá** → Apply (Test 10)
5. **Thanh toán và tích điểm** → Add points (Test 3)
6. **Kiểm tra điểm** → Get user points (Test 2)

### Scenario 2: Khách hàng VIP đổi điểm
1. **Xem số điểm hiện tại** (Test 2) → User ID 4 (Platinum, 2500 points)
2. **Tính discount được nhận** (Test 7) → 100 points = 1,000,000 VND
3. **Đổi điểm** (Test 4) → Redeem 100 points
4. **Xem lịch sử** (Test 5) → Kiểm tra transaction REDEEM
5. **Xem điểm còn lại** (Test 2) → Còn 2400 points

### Scenario 3: Flash Sale cuối tuần
1. **Tạo Flash Sale promotion** (Test 2) → 30% off
2. **Tạo mã VIP** (Test 8) → "FLASHVIP30"
3. **Khách hàng áp dụng** (Test 9, Test 10)
4. **Kiểm tra DB** → used_count tăng lên
5. **Sau khi hết hạn** → Validate sẽ fail với "Mã đã hết hạn"

---

## 📊 KẾT QUẢ MONG ĐỢI

### ✅ Promotion APIs (12/12 passed)
- [x] Health check OK
- [x] Create promotion (PERCENTAGE) OK
- [x] Create promotion (FIXED_AMOUNT) OK
- [x] Get all promotions OK
- [x] Get by ID OK
- [x] Update promotion OK
- [x] Get active only OK
- [x] Create promo code OK
- [x] Validate code (valid) OK
- [x] Validate code (errors) OK
- [x] Apply promo (used_count++) OK
- [x] Search by code OK
- [x] Delete promotion OK

### ✅ Loyalty APIs (7/7 passed)
- [x] Health check OK
- [x] Get user points & tier OK
- [x] Add points (EARN) OK
- [x] Redeem points (REDEEM) OK
- [x] Get history OK
- [x] Calculate points OK
- [x] Calculate discount OK

---

## 🚨 TROUBLESHOOTING

### Lỗi 404 Not Found
- Kiểm tra server có chạy không: `curl http://localhost:8080/api/promotions/test`
- Kiểm tra URL đúng chưa: `/api/promotions` chứ không phải `/promotions`

### Lỗi 400 Bad Request
- Kiểm tra JSON body có đúng format không
- Kiểm tra required fields: `name`, `discountType`, `discountValue`,...
- Kiểm tra validation: `minOrderValue >= 0`, `discountValue > 0`

### Lỗi 500 Internal Server Error
- Xem log server để biết chi tiết
- Kiểm tra database connection
- Kiểm tra foreign key constraints

### Mã giảm giá không hợp lệ
- Kiểm tra promotion có status = "ACTIVE" không
- Kiểm tra startDate, endDate, expiresAt
- Kiểm tra orderValue >= minOrderValue
- Kiểm tra used_count < maxUses

---

## 📝 GHI CHÚ

### Business Rules
1. **Promotion:**
   - `discountType`: PERCENTAGE hoặc FIXED_AMOUNT
   - PERCENTAGE: phải có `maxDiscountAmount`
   - FIXED_AMOUNT: không cần `maxDiscountAmount`
   - `usageLimit`: Giới hạn tổng số lần sử dụng chương trình

2. **Promo Code:**
   - `code`: Tự động uppercase, phải unique
   - `singleUse`: true = chỉ dùng 1 lần, false = dùng nhiều lần
   - `maxUses`: Giới hạn số lần dùng mã
   - `userRestriction`: null = tất cả user, hoặc userId cụ thể

3. **Loyalty Points:**
   - Tích điểm: 100,000 VND = 1 điểm
   - Đổi điểm: 1 điểm = 10,000 VND discount
   - Tối thiểu đổi: 10 điểm
   - Tier system: Bronze → Silver → Gold → Platinum

---

## 🎉 HOÀN THÀNH

Sau khi test xong 19 APIs, bạn đã hoàn thành:
✅ Promotion Management System (12 APIs)
✅ Loyalty Points System (7 APIs)
✅ Database integration
✅ Security configuration
✅ Error handling
✅ Business logic validation

**Next steps:** 
- Tích hợp vào frontend
- Thêm chức năng transparent pricing
- Tối ưu performance
- Viết unit tests

**Created by:** DriveNow Development Team
**Date:** October 14, 2025
**Version:** 1.0
