-- =====================================================
-- CREATE PAYMENTS TABLE FOR VNPAY INTEGRATION
-- =====================================================

USE drivenow_db;
GO

-- Drop table if exists
IF OBJECT_ID('vnpay_payments', 'U') IS NOT NULL
    DROP TABLE vnpay_payments;
GO

-- Create vnpay_payments table
CREATE TABLE vnpay_payments (
    id BIGINT IDENTITY(1,1) PRIMARY KEY,
    order_id NVARCHAR(50) NOT NULL UNIQUE,
    user_id BIGINT NOT NULL,
    amount DECIMAL(18,2) NOT NULL,
    order_info NVARCHAR(500),
    transaction_no NVARCHAR(50),
    bank_code NVARCHAR(20),
    payment_status NVARCHAR(20) NOT NULL DEFAULT 'PENDING',
    vnpay_response_code NVARCHAR(10),
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    updated_at DATETIME2,
    
    CONSTRAINT CHK_payment_status CHECK (payment_status IN ('PENDING', 'SUCCESS', 'FAILED'))
);
GO

-- Create indexes for better performance
CREATE INDEX idx_vnpay_payments_order_id ON vnpay_payments(order_id);
CREATE INDEX idx_vnpay_payments_user_id ON vnpay_payments(user_id);
CREATE INDEX idx_vnpay_payments_status ON vnpay_payments(payment_status);
CREATE INDEX idx_vnpay_payments_created_at ON vnpay_payments(created_at);
GO

-- Insert test payment data
INSERT INTO vnpay_payments (order_id, user_id, amount, order_info, payment_status)
VALUES 
    ('ORDER00000001', 1, 150000, N'Test thanh toán thuê xe Toyota Vios', 'PENDING'),
    ('ORDER00000002', 1, 300000, N'Test thanh toán thuê xe Honda City', 'SUCCESS');
GO

PRINT 'VNPay Payments table created successfully!';
PRINT 'Test data inserted.';
GO

-- View test data
SELECT * FROM vnpay_payments;
GO
