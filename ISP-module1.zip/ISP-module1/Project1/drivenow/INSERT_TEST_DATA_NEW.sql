-- =====================================================
-- DỮ LIỆU TEST CHO HỆ THỐNG QUẢN LÝ TIỀN CỌC
-- =====================================================

USE drivenow_db;
GO

PRINT 'Thêm dữ liệu test...';
GO

-- Xóa dữ liệu cũ (nếu có)
DELETE FROM deposit_management;
DELETE FROM transaction_management;
GO

-- =====================================================
-- Test với customer_id = 1 (giả sử đã có trong bảng customer)
-- =====================================================

-- Transaction 1: Giao dịch cọc cho booking 1
INSERT INTO transaction_management (
    transaction_code, booking_id, user_id, transaction_type, 
    amount, payment_method, status, description, reference_code
) VALUES (
    'TXN-20251014001', 
    1, 
    1, 
    'DEPOSIT',
    5000000.00,
    'VNPAY',
    'COMPLETED',
    N'Giao dịch cọc xe Mercedes C200',
    'VNPAY-REF-001'
);

-- Transaction 2: Giao dịch cọc cho booking 2
INSERT INTO transaction_management (
    transaction_code, booking_id, user_id, transaction_type, 
    amount, payment_method, status, description, reference_code
) VALUES (
    'TXN-20251014002', 
    2, 
    1, 
    'DEPOSIT',
    3000000.00,
    'VNPAY',
    'PENDING',
    N'Giao dịch cọc xe Toyota Camry',
    'VNPAY-REF-002'
);

PRINT '✅ Đã thêm 2 transactions';
GO

-- Deposit 1: Đã thanh toán
INSERT INTO deposit_management (
    deposit_code, booking_id, user_id, transaction_id,
    deposit_amount, refund_amount, penalty_amount,
    deposit_status, payment_method, notes
) VALUES (
    'DEP-20251014001',
    1,
    1,
    1,
    5000000.00,
    0.00,
    0.00,
    'PAID',
    'VNPAY',
    N'Cọc xe Mercedes C200 - Đã thanh toán'
);

-- Deposit 2: Chờ thanh toán
INSERT INTO deposit_management (
    deposit_code, booking_id, user_id, transaction_id,
    deposit_amount, refund_amount, penalty_amount,
    deposit_status, payment_method, notes
) VALUES (
    'DEP-20251014002',
    2,
    1,
    2,
    3000000.00,
    0.00,
    0.00,
    'PENDING',
    'VNPAY',
    N'Cọc xe Toyota Camry - Chờ thanh toán'
);

PRINT '✅ Đã thêm 2 deposits';
GO

-- Kiểm tra kết quả
PRINT '';
PRINT '=================================================';
PRINT 'DỮ LIỆU TEST:';
PRINT '=================================================';

SELECT 
    t.transaction_code AS 'Mã GD',
    t.transaction_type AS 'Loại',
    t.amount AS 'Số tiền',
    t.status AS 'Trạng thái',
    t.payment_method AS 'PT Thanh toán'
FROM transaction_management t
ORDER BY t.created_at DESC;

SELECT 
    d.deposit_code AS 'Mã Cọc',
    d.booking_id AS 'Booking',
    d.deposit_amount AS 'Số tiền',
    d.deposit_status AS 'Trạng thái',
    d.payment_method AS 'PT Thanh toán',
    d.notes AS 'Ghi chú'
FROM deposit_management d
ORDER BY d.created_at DESC;

PRINT '';
PRINT '✅ Hoàn tất! Dữ liệu test đã sẵn sàng.';
GO
