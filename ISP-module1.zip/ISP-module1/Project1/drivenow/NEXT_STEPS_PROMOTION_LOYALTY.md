# 🎯 HƯỚNG DẪN HOÀN THIỆN HỆ THỐNG PROMOTION & LOYALTY

## ✅ ĐÃ HOÀN THÀNH:
- ✅ Deposit Management (Quản lý tiền cọc) - 9 APIs
- ✅ Database có sẵn: promotions, promo_codes, loyalty_points, loyalty_history
- ✅ Created: Promotion.java, PromoCode.java entities

## 🔨 CẦN LÀM TIẾP (20 files còn lại):

### 1. Entities (2 files)
```
drivenow/src/main/java/com/carrentleproject/drivenow/model/
- LoyaltyPoints.java
- LoyaltyHistory.java
```

### 2. Repositories (4 files)
```
drivenow/src/main/java/com/carrentleproject/drivenow/dao/
- PromotionRepository.java
- PromoCodeRepository.java
- LoyaltyPointsRepository.java
- LoyaltyHistoryRepository.java
```

### 3. DTOs (4 files)
```
drivenow/src/main/java/com/carrentleproject/drivenow/dto/
- PromotionRequest.java
- PromoCodeRequest.java
- ApplyPromoRequest.java
- LoyaltyRequest.java
```

### 4. Services (2 files)
```
drivenow/src/main/java/com/carrentleproject/drivenow/service/
- PromotionService.java (create, validate, apply discount)
- LoyaltyService.java (add points, redeem, check balance)
```

### 5. Controllers (2 files)
```
drivenow/src/main/java/com/carrentleproject/drivenow/controller/
- PromotionController.java (10 APIs)
- LoyaltyController.java (6 APIs)
```

### 6. Testing & Documentation (4 files)
- insert_promotion_test_data.sql
- insert_loyalty_test_data.sql
- drivenow-promotion-loyalty.postman_collection.json
- PROMOTION_LOYALTY_GUIDE.md

### 7. Update SecurityConfig
Thêm permit cho /api/promotions/** và /api/loyalty/**

---

## 📊 16 APIs CẦN TẠO:

### **Promotion APIs (10 endpoints):**
1. GET /api/promotions/test - Health check
2. POST /api/promotions - Tạo promotion mới
3. GET /api/promotions - Lấy tất cả promotions
4. GET /api/promotions/{id} - Xem chi tiết promotion
5. PUT /api/promotions/{id} - Cập nhật promotion
6. DELETE /api/promotions/{id} - Xóa promotion
7. POST /api/promotions/validate-code - Validate promo code
8. POST /api/promotions/apply - Áp dụng giảm giá
9. GET /api/promotions/active - Lấy promotions đang active
10. GET /api/promotions/code/{code} - Tìm promotion theo code

### **Loyalty APIs (6 endpoints):**
1. GET /api/loyalty/test - Health check
2. GET /api/loyalty/user/{userId} - Xem điểm của user
3. POST /api/loyalty/add - Thêm điểm
4. POST /api/loyalty/redeem - Đổi điểm
5. GET /api/loyalty/history/{userId} - Lịch sử tích điểm
6. GET /api/loyalty/calculate - Tính điểm từ số tiền

---

## 🚀 CẤU TRÚC CODE MẪU:

### LoyaltyPoints.java
```java
@Entity
@Table(name = "loyalty_points")
public class LoyaltyPoints {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "loyalty_id")
    private Long id;
    
    @Column(name = "user_id", nullable = false)
    private Long userId;
    
    @Column(name = "points")
    private Integer points = 0;
    
    @Column(name = "lifetime_points")
    private Integer lifetimePoints = 0;
    
    @Column(name = "last_updated")
    private LocalDateTime lastUpdated;
    
    // getters/setters
}
```

### PromotionService - Tính giảm giá
```java
public Long calculateDiscount(Promotion promo, Long orderValue) {
    if (promo.getDiscountType() == DiscountType.PERCENTAGE) {
        Long discount = (long)(orderValue * promo.getDiscountValue().doubleValue() / 100);
        if (promo.getMaxDiscountAmount() != null) {
            discount = Math.min(discount, promo.getMaxDiscountAmount());
        }
        return discount;
    } else {
        return promo.getDiscountValue().longValue();
    }
}
```

### LoyaltyService - Tích điểm
```java
public void addPoints(Long userId, Long orderValue) {
    // Quy tắc: 100,000 VND = 1 điểm
    int points = (int)(orderValue / 100000);
    
    LoyaltyPoints loyalty = repository.findByUserId(userId)
        .orElseGet(() -> new LoyaltyPoints(userId));
    
    loyalty.setPoints(loyalty.getPoints() + points);
    loyalty.setLifetimePoints(loyalty.getLifetimePoints() + points);
    loyalty.setLastUpdated(LocalDateTime.now());
    
    repository.save(loyalty);
    
    // Lưu history
    loyaltyHistoryRepository.save(new LoyaltyHistory(
        userId, "EARN", points, orderValue, "Tích điểm từ đơn hàng"
    ));
}
```

---

## 💡 LOGIC QUAN TRỌNG:

### 1. Validate Promo Code
- Kiểm tra code tồn tại
- Kiểm tra hạn sử dụng (start_date, end_date, expires_at)
- Kiểm tra usage_limit vs used_count
- Kiểm tra min_order_value
- Kiểm tra user_restriction (nếu có)

### 2. Apply Discount
- Tính giảm giá theo discount_type (PERCENTAGE hoặc FIXED_AMOUNT)
- Áp dụng max_discount_amount (nếu có)
- Tăng used_count sau khi apply thành công

### 3. Loyalty Points Calculation
- Earning: 100,000 VND = 1 point
- Redeeming: 1 point = 10,000 VND discount
- Min redeem: 10 points

### 4. Loyalty Tiers
- Bronze: 0-499 points
- Silver: 500-999 points  
- Gold: 1000-1999 points
- Platinum: 2000+ points

---

## 🧪 TEST DATA MẪU:

### Promotions:
```sql
-- Giảm 10% tối đa 50k
INSERT INTO promotions VALUES (
    'GIAM10', 'Giảm 10% cho đơn từ 200k',
    'PERCENTAGE', 10, 200000, 50000,
    '2025-10-01', '2025-12-31', 100, 0, 'ACTIVE', 1, GETDATE(), NULL
);

-- Giảm 100k cố định
INSERT INTO promotions VALUES (
    'GIAM100K', 'Giảm 100k cho đơn từ 1 triệu',
    'FIXED_AMOUNT', 100000, 1000000, NULL,
    '2025-10-01', '2025-12-31', 50, 0, 'ACTIVE', 1, GETDATE(), NULL
);
```

### Promo Codes:
```sql
INSERT INTO promo_codes VALUES (
    1, 'NEWUSER2025', 1, 3, 0, NULL, NULL, GETDATE(), '2025-12-31'
);
```

### Loyalty Points:
```sql
INSERT INTO loyalty_points VALUES (
    1, 150, 350, GETDATE()
);
```

---

## 📝 POSTMAN TEST EXAMPLES:

### Apply Promo Code:
```json
POST /api/promotions/apply
{
    "promoCode": "NEWUSER2025",
    "userId": 1,
    "orderValue": 500000
}

Response:
{
    "status": "success",
    "data": {
        "originalAmount": 500000,
        "discountAmount": 50000,
        "finalAmount": 450000,
        "promotionName": "GIAM10"
    }
}
```

### Add Loyalty Points:
```json
POST /api/loyalty/add
{
    "userId": 1,
    "orderValue": 800000,
    "transactionType": "RENTAL"
}

Response:
{
    "status": "success",
    "data": {
        "pointsEarned": 8,
        "currentPoints": 158,
        "lifetimePoints": 358
    }
}
```

---

## ⏭️ BƯỚC TIẾP THEO:

Bạn muốn tôi:
1. ✅ Tiếp tục generate code cho 20 files còn lại
2. ✅ Tạo file SQL test data
3. ✅ Tạo Postman collection
4. ✅ Test toàn bộ APIs

**Trả lời "tiếp tục" để tôi làm tiếp!** 🚀
