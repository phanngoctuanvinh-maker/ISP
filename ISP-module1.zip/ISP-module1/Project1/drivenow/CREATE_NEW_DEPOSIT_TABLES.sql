-- =====================================================
-- TẠO BẢNG MỚI CHO QUẢN LÝ TIỀN CỌC
-- Không ảnh hưởng đến các bảng cũ (deposits, payments...)
-- =====================================================

USE drivenow_db;
GO

PRINT 'Bắt đầu tạo bảng mới cho hệ thống quản lý tiền cọc...';
GO

-- =====================================================
-- 1. Bảng TRANSACTION_MANAGEMENT - Quản lý giao dịch
-- =====================================================
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'transaction_management')
BEGIN
    PRINT 'Xóa bảng transaction_management cũ...';
    DROP TABLE transaction_management;
END
GO

CREATE TABLE transaction_management (
    id BIGINT PRIMARY KEY IDENTITY(1,1),
    transaction_code VARCHAR(50) UNIQUE NOT NULL,
    booking_id BIGINT NULL,
    user_id BIGINT NOT NULL,
    transaction_type VARCHAR(20) NOT NULL CHECK (transaction_type IN ('DEPOSIT', 'PAYMENT', 'REFUND', 'PENALTY')),
    amount DECIMAL(15,2) NOT NULL CHECK (amount > 0),
    payment_method VARCHAR(50) NOT NULL CHECK (payment_method IN ('VNPAY', 'CASH', 'BANK_TRANSFER', 'CREDIT_CARD')),
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'COMPLETED', 'FAILED', 'REFUNDED', 'CANCELLED')),
    description NVARCHAR(500),
    reference_code VARCHAR(100),
    created_at DATETIME2 DEFAULT GETDATE(),
    updated_at DATETIME2 DEFAULT GETDATE(),
    completed_at DATETIME2 NULL,
    CONSTRAINT fk_transaction_user FOREIGN KEY (user_id) REFERENCES customer(customer_id)
);

CREATE INDEX idx_trans_mgmt_user ON transaction_management(user_id);
CREATE INDEX idx_trans_mgmt_booking ON transaction_management(booking_id);
CREATE INDEX idx_trans_mgmt_type ON transaction_management(transaction_type);
CREATE INDEX idx_trans_mgmt_status ON transaction_management(status);
CREATE INDEX idx_trans_mgmt_created ON transaction_management(created_at);

PRINT '✅ Đã tạo bảng transaction_management';
GO

-- =====================================================
-- 2. Bảng DEPOSIT_MANAGEMENT - Quản lý tiền cọc chi tiết
-- =====================================================
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'deposit_management')
BEGIN
    PRINT 'Xóa bảng deposit_management cũ...';
    DROP TABLE deposit_management;
END
GO

CREATE TABLE deposit_management (
    id BIGINT PRIMARY KEY IDENTITY(1,1),
    deposit_code VARCHAR(50) UNIQUE NOT NULL,
    booking_id BIGINT NOT NULL,
    user_id BIGINT NOT NULL,
    transaction_id BIGINT NULL,
    deposit_amount DECIMAL(15,2) NOT NULL CHECK (deposit_amount > 0),
    refund_amount DECIMAL(15,2) DEFAULT 0 CHECK (refund_amount >= 0),
    penalty_amount DECIMAL(15,2) DEFAULT 0 CHECK (penalty_amount >= 0),
    deposit_status VARCHAR(20) NOT NULL DEFAULT 'PENDING' CHECK (deposit_status IN ('PENDING', 'PAID', 'REFUNDED', 'PARTIALLY_REFUNDED', 'FORFEITED')),
    payment_method VARCHAR(50),
    deposit_date DATETIME2 DEFAULT GETDATE(),
    refund_date DATETIME2 NULL,
    notes NVARCHAR(1000),
    created_at DATETIME2 DEFAULT GETDATE(),
    updated_at DATETIME2 DEFAULT GETDATE(),
    CONSTRAINT fk_deposit_user FOREIGN KEY (user_id) REFERENCES customer(customer_id),
    CONSTRAINT fk_deposit_transaction FOREIGN KEY (transaction_id) REFERENCES transaction_management(id)
);

CREATE INDEX idx_dep_mgmt_user ON deposit_management(user_id);
CREATE INDEX idx_dep_mgmt_booking ON deposit_management(booking_id);
CREATE INDEX idx_dep_mgmt_status ON deposit_management(deposit_status);
CREATE INDEX idx_dep_mgmt_code ON deposit_management(deposit_code);

PRINT '✅ Đã tạo bảng deposit_management';
GO

-- =====================================================
-- 3. Bảng RENTAL_PAYMENTS - Thanh toán thuê xe
-- =====================================================
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'rental_payments')
BEGIN
    PRINT 'Xóa bảng rental_payments cũ...';
    DROP TABLE rental_payments;
END
GO

CREATE TABLE rental_payments (
    id BIGINT PRIMARY KEY IDENTITY(1,1),
    payment_code VARCHAR(50) UNIQUE NOT NULL,
    booking_id BIGINT NOT NULL,
    user_id BIGINT NOT NULL,
    transaction_id BIGINT NULL,
    rental_amount DECIMAL(15,2) NOT NULL CHECK (rental_amount > 0),
    discount_amount DECIMAL(15,2) DEFAULT 0 CHECK (discount_amount >= 0),
    additional_fee DECIMAL(15,2) DEFAULT 0 CHECK (additional_fee >= 0),
    total_amount DECIMAL(15,2) NOT NULL CHECK (total_amount > 0),
    payment_status VARCHAR(20) NOT NULL DEFAULT 'PENDING' CHECK (payment_status IN ('PENDING', 'PAID', 'FAILED', 'REFUNDED', 'CANCELLED')),
    payment_method VARCHAR(50),
    payment_date DATETIME2 DEFAULT GETDATE(),
    due_date DATETIME2 NULL,
    notes NVARCHAR(500),
    created_at DATETIME2 DEFAULT GETDATE(),
    updated_at DATETIME2 DEFAULT GETDATE(),
    CONSTRAINT fk_rental_user FOREIGN KEY (user_id) REFERENCES customer(customer_id),
    CONSTRAINT fk_rental_transaction FOREIGN KEY (transaction_id) REFERENCES transaction_management(id)
);

CREATE INDEX idx_rental_user ON rental_payments(user_id);
CREATE INDEX idx_rental_booking ON rental_payments(booking_id);
CREATE INDEX idx_rental_status ON rental_payments(payment_status);

PRINT '✅ Đã tạo bảng rental_payments';
GO

-- =====================================================
-- 4. Bảng REVENUE_REPORTS - Báo cáo doanh thu
-- =====================================================
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'revenue_reports')
BEGIN
    PRINT 'Xóa bảng revenue_reports cũ...';
    DROP TABLE revenue_reports;
END
GO

CREATE TABLE revenue_reports (
    id BIGINT PRIMARY KEY IDENTITY(1,1),
    report_code VARCHAR(50) UNIQUE NOT NULL,
    report_date DATE NOT NULL,
    total_deposits DECIMAL(15,2) DEFAULT 0,
    total_payments DECIMAL(15,2) DEFAULT 0,
    total_refunds DECIMAL(15,2) DEFAULT 0,
    total_penalties DECIMAL(15,2) DEFAULT 0,
    net_revenue DECIMAL(15,2) DEFAULT 0,
    transaction_count INT DEFAULT 0,
    notes NVARCHAR(500),
    created_at DATETIME2 DEFAULT GETDATE(),
    updated_at DATETIME2 DEFAULT GETDATE()
);

CREATE INDEX idx_revenue_date ON revenue_reports(report_date);

PRINT '✅ Đã tạo bảng revenue_reports';
GO

-- =====================================================
-- TRIGGER tự động cập nhật updated_at
-- =====================================================
IF EXISTS (SELECT * FROM sys.triggers WHERE name = 'trg_trans_mgmt_update')
    DROP TRIGGER trg_trans_mgmt_update;
GO

CREATE TRIGGER trg_trans_mgmt_update
ON transaction_management
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE transaction_management
    SET updated_at = GETDATE()
    FROM transaction_management t
    INNER JOIN inserted i ON t.id = i.id;
END;
GO

IF EXISTS (SELECT * FROM sys.triggers WHERE name = 'trg_dep_mgmt_update')
    DROP TRIGGER trg_dep_mgmt_update;
GO

CREATE TRIGGER trg_dep_mgmt_update
ON deposit_management
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE deposit_management
    SET updated_at = GETDATE()
    FROM deposit_management d
    INNER JOIN inserted i ON d.id = i.id;
END;
GO

PRINT '';
PRINT '=================================================';
PRINT '✅ HOÀN TẤT! Đã tạo 4 bảng mới:';
PRINT '1. transaction_management - Quản lý giao dịch';
PRINT '2. deposit_management - Quản lý tiền cọc';
PRINT '3. rental_payments - Thanh toán thuê xe';
PRINT '4. revenue_reports - Báo cáo doanh thu';
PRINT '=================================================';
PRINT '';
PRINT 'Các bảng cũ (deposits, payments...) KHÔNG bị ảnh hưởng!';
GO

-- Kiểm tra kết quả
SELECT 
    t.name AS 'Tên Bảng',
    (SELECT COUNT(*) FROM sys.columns c WHERE c.object_id = t.object_id) AS 'Số Cột'
FROM sys.tables t
WHERE t.name IN ('transaction_management', 'deposit_management', 'rental_payments', 'revenue_reports')
ORDER BY t.name;
GO
