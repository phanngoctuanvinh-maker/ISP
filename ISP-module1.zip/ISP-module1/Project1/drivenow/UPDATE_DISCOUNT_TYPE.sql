-- ===================================
-- UPDATE DISCOUNT_TYPE FROM 'PERCENT' TO 'PERCENTAGE'
-- ===================================
-- Fix lỗi: "No enum constant PERCENT"

USE drivenow_db;
GO

-- Kiểm tra giá trị hiện tại
SELECT discount_type, COUNT(*) as Count 
FROM promotions 
GROUP BY discount_type;
GO

-- Update PERCENT → PERCENTAGE
UPDATE promotions
SET discount_type = 'PERCENTAGE'
WHERE discount_type = 'PERCENT';
GO

-- Verify
SELECT discount_type, COUNT(*) as Count 
FROM promotions 
GROUP BY discount_type;
GO

PRINT '✅ Updated discount_type successfully!';
GO

-- Hiển thị tất cả promotions
SELECT promotion_id, name, discount_type, discount_value, status
FROM promotions;
GO
