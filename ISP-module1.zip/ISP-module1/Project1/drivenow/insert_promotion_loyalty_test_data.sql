-- ===================================
-- INSERT TEST DATA FOR PROMOTION & LOYALTY SYSTEM
-- ===================================

-- 1. INSERT PROMOTIONS (chương trình khuyến mãi)
-- Promotion 1: Giảm 20% (PERCENTAGE)
INSERT INTO promotions (name, description, discount_type, discount_value, min_order_value, max_discount_amount, start_date, end_date, usage_limit, used_count, status, created_by, created_at, updated_at)
VALUES ('Giảm 20% cho đơn hàng từ 1 triệu', 'Khuyến mãi giảm 20% cho tất cả đơn hàng từ 1,000,000 VND trở lên. Tối đa giảm 200,000 VND', 'PERCENTAGE', 20.0, 1000000.0, 200000.0, '2025-01-01 00:00:00', '2025-12-31 23:59:59', 100, 0, 'ACTIVE', 1, GETDATE(), GETDATE());

-- Promotion 2: Giảm 15% (PERCENTAGE)
INSERT INTO promotions (name, description, discount_type, discount_value, min_order_value, max_discount_amount, start_date, end_date, usage_limit, used_count, status, created_by, created_at, updated_at)
VALUES ('Giảm 15% cho khách hàng mới', 'Chương trình dành riêng cho khách hàng mới. Giảm 15% tối đa 150,000 VND', 'PERCENTAGE', 15.0, 500000.0, 150000.0, '2025-01-01 00:00:00', '2025-12-31 23:59:59', 200, 5, 'ACTIVE', 1, GETDATE(), GETDATE());

-- Promotion 3: Giảm 100k (FIXED_AMOUNT)
INSERT INTO promotions (name, description, discount_type, discount_value, min_order_value, max_discount_amount, start_date, end_date, usage_limit, used_count, status, created_by, created_at, updated_at)
VALUES ('Giảm 100,000 VND', 'Giảm cố định 100,000 VND cho đơn hàng từ 800,000 VND', 'FIXED_AMOUNT', 100000.0, 800000.0, NULL, '2025-01-01 00:00:00', '2025-06-30 23:59:59', 50, 10, 'ACTIVE', 1, GETDATE(), GETDATE());

-- Promotion 4: Flash Sale (PERCENTAGE)
INSERT INTO promotions (name, description, discount_type, discount_value, min_order_value, max_discount_amount, start_date, end_date, usage_limit, used_count, status, created_by, created_at, updated_at)
VALUES ('Flash Sale 30%', 'Flash sale cuối tuần - Giảm 30% tối đa 300,000 VND', 'PERCENTAGE', 30.0, 1500000.0, 300000.0, '2025-06-01 00:00:00', '2025-06-30 23:59:59', 20, 15, 'ACTIVE', 1, GETDATE(), GETDATE());

-- Promotion 5: Khuyến mãi hết hạn (INACTIVE)
INSERT INTO promotions (name, description, discount_type, discount_value, min_order_value, max_discount_amount, start_date, end_date, usage_limit, used_count, status, created_by, created_at, updated_at)
VALUES ('Khuyến mãi tháng 3', 'Đã hết hạn - Giảm 25%', 'PERCENTAGE', 25.0, 1000000.0, 250000.0, '2024-03-01 00:00:00', '2024-03-31 23:59:59', 100, 80, 'INACTIVE', 1, GETDATE(), GETDATE());

-- 2. INSERT PROMO CODES (mã giảm giá)
-- Promo code cho Promotion 1
INSERT INTO promo_codes (promotion_id, code, single_use, max_uses, used_count, user_restriction, min_order_value, created_at, expires_at)
VALUES (1, 'SAVE20', 0, 100, 10, NULL, 1000000.0, GETDATE(), '2025-12-31 23:59:59');

-- Promo code cho Promotion 2 (dành cho user cụ thể)
INSERT INTO promo_codes (promotion_id, code, single_use, max_uses, used_count, user_restriction, min_order_value, created_at, expires_at)
VALUES (2, 'NEWCUSTOMER15', 1, 1, 0, 2, 500000.0, GETDATE(), '2025-12-31 23:59:59');

-- Promo code cho Promotion 3
INSERT INTO promo_codes (promotion_id, code, single_use, max_uses, used_count, user_restriction, min_order_value, created_at, expires_at)
VALUES (3, 'FLAT100K', 0, 50, 5, NULL, 800000.0, GETDATE(), '2025-06-30 23:59:59');

-- Promo code cho Promotion 4 (Flash Sale)
INSERT INTO promo_codes (promotion_id, code, single_use, max_uses, used_count, user_restriction, min_order_value, created_at, expires_at)
VALUES (4, 'FLASHSALE30', 0, 20, 8, NULL, 1500000.0, GETDATE(), '2025-06-30 23:59:59');

-- Promo code chung
INSERT INTO promo_codes (promotion_id, code, single_use, max_uses, used_count, user_restriction, min_order_value, created_at, expires_at)
VALUES (1, 'WELCOME2024', 0, 200, 25, NULL, 500000.0, GETDATE(), '2025-12-31 23:59:59');

-- Promo code hết hạn
INSERT INTO promo_codes (promotion_id, code, single_use, max_uses, used_count, user_restriction, min_order_value, created_at, expires_at)
VALUES (5, 'MARCH2024', 0, 100, 75, NULL, 1000000.0, '2024-03-01 00:00:00', '2024-03-31 23:59:59');

-- Promo code chỉ dùng 1 lần
INSERT INTO promo_codes (promotion_id, code, single_use, max_uses, used_count, user_restriction, min_order_value, created_at, expires_at)
VALUES (2, 'ONETIME15', 1, 1, 0, 3, 500000.0, GETDATE(), '2025-12-31 23:59:59');

-- Promo code VIP
INSERT INTO promo_codes (promotion_id, code, single_use, max_uses, used_count, user_restriction, min_order_value, created_at, expires_at)
VALUES (4, 'VIP30', 0, 10, 3, NULL, 2000000.0, GETDATE(), '2025-12-31 23:59:59');

-- 3. INSERT LOYALTY POINTS (điểm tích lũy)
-- User 1: Bronze tier
INSERT INTO loyalty_points (user_id, points, lifetime_points, last_updated)
VALUES (1, 150, 450, GETDATE());

-- User 2: Silver tier
INSERT INTO loyalty_points (user_id, points, lifetime_points, last_updated)
VALUES (2, 650, 850, GETDATE());

-- User 3: Gold tier
INSERT INTO loyalty_points (user_id, points, lifetime_points, last_updated)
VALUES (3, 1200, 1500, GETDATE());

-- User 4: Platinum tier
INSERT INTO loyalty_points (user_id, points, lifetime_points, last_updated)
VALUES (4, 2500, 3200, GETDATE());

-- User 5: Bronze tier (mới)
INSERT INTO loyalty_points (user_id, points, lifetime_points, last_updated)
VALUES (5, 80, 80, GETDATE());

-- 4. INSERT LOYALTY HISTORY (lịch sử giao dịch điểm)
-- User 1 transactions
INSERT INTO loyalty_history (user_id, transaction_type, points, order_value, description, created_at)
VALUES (1, 'EARN', 30, 3000000, 'Thuê xe Mercedes E-Class 3 ngày', DATEADD(day, -10, GETDATE()));

INSERT INTO loyalty_history (user_id, transaction_type, points, order_value, description, created_at)
VALUES (1, 'EARN', 20, 2000000, 'Thuê xe Toyota Camry 2 ngày', DATEADD(day, -5, GETDATE()));

INSERT INTO loyalty_history (user_id, transaction_type, points, order_value, description, created_at)
VALUES (1, 'REDEEM', -50, NULL, 'Đổi điểm lấy voucher 500k', DATEADD(day, -2, GETDATE()));

-- User 2 transactions
INSERT INTO loyalty_history (user_id, transaction_type, points, order_value, description, created_at)
VALUES (2, 'EARN', 50, 5000000, 'Thuê xe BMW 5 Series 5 ngày', DATEADD(day, -15, GETDATE()));

INSERT INTO loyalty_history (user_id, transaction_type, points, order_value, description, created_at)
VALUES (2, 'EARN', 40, 4000000, 'Thuê xe Audi A6 4 ngày', DATEADD(day, -8, GETDATE()));

INSERT INTO loyalty_history (user_id, transaction_type, points, order_value, description, created_at)
VALUES (2, 'REDEEM', -20, NULL, 'Đổi điểm lấy voucher 200k', DATEADD(day, -3, GETDATE()));

-- User 3 transactions
INSERT INTO loyalty_history (user_id, transaction_type, points, order_value, description, created_at)
VALUES (3, 'EARN', 80, 8000000, 'Thuê xe Lexus RX 8 ngày', DATEADD(day, -20, GETDATE()));

INSERT INTO loyalty_history (user_id, transaction_type, points, order_value, description, created_at)
VALUES (3, 'EARN', 60, 6000000, 'Thuê xe Mercedes S-Class 6 ngày', DATEADD(day, -12, GETDATE()));

INSERT INTO loyalty_history (user_id, transaction_type, points, order_value, description, created_at)
VALUES (3, 'REDEEM', -100, NULL, 'Đổi điểm lấy voucher 1 triệu', DATEADD(day, -4, GETDATE()));

-- User 4 transactions (VIP customer)
INSERT INTO loyalty_history (user_id, transaction_type, points, order_value, description, created_at)
VALUES (4, 'EARN', 120, 12000000, 'Thuê xe Porsche Cayenne 12 ngày', DATEADD(day, -25, GETDATE()));

INSERT INTO loyalty_history (user_id, transaction_type, points, order_value, description, created_at)
VALUES (4, 'EARN', 100, 10000000, 'Thuê xe Range Rover 10 ngày', DATEADD(day, -18, GETDATE()));

INSERT INTO loyalty_history (user_id, transaction_type, points, order_value, description, created_at)
VALUES (4, 'REDEEM', -200, NULL, 'Đổi điểm lấy voucher 2 triệu', DATEADD(day, -7, GETDATE()));

-- User 5 transactions (khách hàng mới)
INSERT INTO loyalty_history (user_id, transaction_type, points, order_value, description, created_at)
VALUES (5, 'EARN', 15, 1500000, 'Thuê xe Honda City 3 ngày - Khách hàng mới', DATEADD(day, -2, GETDATE()));

INSERT INTO loyalty_history (user_id, transaction_type, points, order_value, description, created_at)
VALUES (5, 'EARN', 10, 1000000, 'Thuê xe Toyota Vios 2 ngày', GETDATE());

-- ===================================
-- VERIFY DATA
-- ===================================

-- Kiểm tra promotions
SELECT 'PROMOTIONS' as TableName, COUNT(*) as RecordCount FROM promotions;
SELECT * FROM promotions;

-- Kiểm tra promo_codes
SELECT 'PROMO_CODES' as TableName, COUNT(*) as RecordCount FROM promo_codes;
SELECT * FROM promo_codes;

-- Kiểm tra loyalty_points
SELECT 'LOYALTY_POINTS' as TableName, COUNT(*) as RecordCount FROM loyalty_points;
SELECT user_id, points, lifetime_points,
       CASE 
           WHEN lifetime_points >= 2000 THEN 'Platinum'
           WHEN lifetime_points >= 1000 THEN 'Gold'
           WHEN lifetime_points >= 500 THEN 'Silver'
           ELSE 'Bronze'
       END as Tier
FROM loyalty_points;

-- Kiểm tra loyalty_history
SELECT 'LOYALTY_HISTORY' as TableName, COUNT(*) as RecordCount FROM loyalty_history;
SELECT * FROM loyalty_history ORDER BY created_at DESC;

PRINT 'Test data inserted successfully!';
