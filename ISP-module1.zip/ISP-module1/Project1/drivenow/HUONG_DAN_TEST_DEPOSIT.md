# 🚀 HƯỚNG DẪN TEST CHỨC NĂNG QUẢN LÝ TIỀN CỌC

## ✅ Server đã chạy tại: http://localhost:8080

---

## 📝 BƯỚC 1: SETUP DATABASE (5 phút)

### 1.1. Mở SQL Server Management Studio
- Server: `LAPTOP-T2R4VU8R\SQLEXPRESS`
- Database: `drivenow_db`

### 1.2. Chạy file tạo bảng
```sql
-- Copy toàn bộ nội dung file này và Execute:
drivenow/database_payment_management.sql
```

**Kết quả:** 4 bảng được tạo:
- ✅ `transactions` - Quản lý giao dịch
- ✅ `deposits` - Quản lý tiền cọc
- ✅ `rental_payments` - Thanh toán thuê xe
- ✅ `revenue_reports` - Báo cáo doanh thu

### 1.3. (Tùy chọn) Thêm dữ liệu test
```sql
-- Chạy file này để có sẵn dữ liệu test:
drivenow/insert_deposit_test_data.sql
```

---

## 📬 BƯỚC 2: IMPORT POSTMAN COLLECTION (2 phút)

1. Mở **Postman**
2. Click **Import** (góc trên bên trái)
3. Chọn file: `drivenow/drivenow-deposit.postman_collection.json`
4. ✅ Bạn sẽ thấy folder **"DriveNow - Deposit Management"** với 9 APIs

---

## 🧪 BƯỚC 3: TEST CÁC API (10 phút)

### API 1: ✅ Health Check
```
GET http://localhost:8080/api/deposits/test
```

**Mục đích:** Kiểm tra API hoạt động

**Kết quả mong đợi:**
```json
{
    "status": "success",
    "message": "Deposit API is working!",
    "timestamp": "2025-10-14T..."
}
```

---

### API 2: 📝 Tạo Tiền Cọc Mới
```
POST http://localhost:8080/api/deposits
Content-Type: application/json

{
    "bookingId": 1,
    "userId": 1,
    "depositAmount": 5000000,
    "paymentMethod": "VNPAY",
    "notes": "Cọc xe Mercedes C200"
}
```

**Mục đích:** Tạo đơn cọc mới khi khách đặt xe

**Kết quả mong đợi:**
```json
{
    "status": "success",
    "message": "Deposit created successfully",
    "data": {
        "id": 1,
        "depositCode": "DEP-20251014001",
        "bookingId": 1,
        "userId": 1,
        "transactionId": 1,
        "depositAmount": 5000000.00,
        "refundAmount": 0.00,
        "penaltyAmount": 0.00,
        "depositStatus": "PENDING",
        "paymentMethod": "VNPAY",
        "depositDate": "2025-10-14T...",
        "notes": "Cọc xe Mercedes C200"
    }
}
```

**Lưu ý:** Copy `id` (ví dụ: 1) để dùng cho các API tiếp theo!

---

### API 3: ✔️ Xác Nhận Thanh Toán Cọc
```
PUT http://localhost:8080/api/deposits/{id}/confirm
```

**Ví dụ:** `PUT http://localhost:8080/api/deposits/1/confirm`

**Mục đích:** Xác nhận khách đã thanh toán tiền cọc qua VNPay

**Kết quả mong đợi:**
```json
{
    "status": "success",
    "message": "Deposit payment confirmed",
    "data": {
        "id": 1,
        "depositCode": "DEP-20251014001",
        "depositStatus": "PAID",
        "transactionId": 1
    }
}
```

**Sau API này:** Trạng thái chuyển từ `PENDING` → `PAID`

---

### API 4: 💰 Hoàn Cọc (Không Phạt)
```
POST http://localhost:8080/api/deposits/refund
Content-Type: application/json

{
    "depositId": 1,
    "refundAmount": 5000000,
    "penaltyAmount": 0,
    "reason": "Khách trả xe đúng hạn, không hư hỏng"
}
```

**Mục đích:** Hoàn lại toàn bộ tiền cọc khi khách trả xe

**Kết quả mong đợi:**
```json
{
    "status": "success",
    "message": "Deposit refunded successfully",
    "data": {
        "id": 1,
        "depositCode": "DEP-20251014001",
        "depositAmount": 5000000.00,
        "refundAmount": 5000000.00,
        "penaltyAmount": 0.00,
        "depositStatus": "REFUNDED",
        "refundDate": "2025-10-14T..."
    }
}
```

---

### API 5: 💰 Hoàn Cọc (Có Phạt)
```
POST http://localhost:8080/api/deposits/refund
Content-Type: application/json

{
    "depositId": 2,
    "refundAmount": 4000000,
    "penaltyAmount": 1000000,
    "reason": "Xe bị trầy xước nhẹ - phạt 1 triệu"
}
```

**Mục đích:** Hoàn cọc có trừ tiền phạt

**Kết quả mong đợi:**
```json
{
    "status": "success",
    "message": "Deposit refunded successfully",
    "data": {
        "id": 2,
        "depositAmount": 5000000.00,
        "refundAmount": 4000000.00,
        "penaltyAmount": 1000000.00,
        "depositStatus": "PARTIALLY_REFUNDED"
    }
}
```

**Lưu ý:** Hệ thống tự động tạo 2 giao dịch:
- 1 giao dịch `REFUND` với số tiền 4,000,000 VND
- 1 giao dịch `PENALTY` với số tiền 1,000,000 VND

---

### API 6: 🔍 Xem Chi Tiết Một Đơn Cọc
```
GET http://localhost:8080/api/deposits/1
```

**Mục đích:** Xem thông tin chi tiết của 1 đơn cọc

---

### API 7: 🚗 Xem Cọc Theo Booking
```
GET http://localhost:8080/api/deposits/booking/1
```

**Mục đích:** Xem tất cả tiền cọc của 1 booking (có thể có nhiều lần cọc)

---

### API 8: 👤 Xem Cọc Của User
```
GET http://localhost:8080/api/deposits/user/1
```

**Mục đích:** Xem lịch sử cọc của khách hàng

---

### API 9: 📊 Xem Cọc Theo Trạng Thái
```
GET http://localhost:8080/api/deposits/status/PAID
```

**Trạng thái có thể dùng:**
- `PENDING` - Chờ thanh toán
- `PAID` - Đã thanh toán
- `REFUNDED` - Đã hoàn cọc đầy đủ
- `PARTIALLY_REFUNDED` - Hoàn cọc có trừ phạt
- `FORFEITED` - Mất cọc (vi phạm)

---

## 📊 BƯỚC 4: KIỂM TRA DATABASE

Sau khi test xong, kiểm tra dữ liệu trong SQL Server:

```sql
-- Xem tất cả giao dịch
SELECT * FROM transactions ORDER BY created_at DESC;

-- Xem tất cả tiền cọc
SELECT * FROM deposits ORDER BY deposit_date DESC;

-- Thống kê theo trạng thái
SELECT deposit_status, COUNT(*) as total, SUM(deposit_amount) as total_amount
FROM deposits
GROUP BY deposit_status;
```

---

## ✅ CHECKLIST HOÀN THÀNH

- [ ] Database setup (4 bảng)
- [ ] Import Postman collection
- [ ] Test API 1: Health check ✅
- [ ] Test API 2: Tạo cọc mới 📝
- [ ] Test API 3: Xác nhận thanh toán ✔️
- [ ] Test API 4: Hoàn cọc đầy đủ 💰
- [ ] Test API 5: Hoàn cọc có phạt 💰
- [ ] Test API 6-9: Các API query 🔍
- [ ] Kiểm tra database 📊

---

## 🎯 KẾT QUẢ MONG ĐỢI

Sau khi test xong, bạn sẽ có:

✅ **Hệ thống quản lý tiền cọc hoàn chỉnh:**
- Tạo đơn cọc tự động
- Xác nhận thanh toán qua VNPay
- Hoàn cọc linh hoạt (có/không phạt)
- Tracking đầy đủ lịch sử giao dịch
- Query theo nhiều tiêu chí

✅ **Database có đầy đủ dữ liệu:**
- Transactions table: Mọi giao dịch tài chính
- Deposits table: Chi tiết từng đơn cọc

✅ **Sẵn sàng cho chức năng tiếp theo:**
- Quản lý thanh toán thuê xe (rental_payments)
- Báo cáo doanh thu (revenue_reports)
- Giảm giá & khuyến mãi
- Tích điểm khách hàng

---

## 🐛 TROUBLESHOOTING

### Lỗi: "Foreign key constraint" khi tạo bảng
**Nguyên nhân:** Bảng `users` chưa có

**Giải pháp:** Kiểm tra bảng users:
```sql
SELECT * FROM users;
```

### Lỗi: "Deposit not found" khi test API
**Nguyên nhân:** Database chưa có dữ liệu

**Giải pháp:** Chạy file `insert_deposit_test_data.sql`

### Lỗi: 401 Unauthorized
**Nguyên nhân:** Security block API

**Giải pháp:** Đã fix - endpoints `/api/deposits/**` đã được permit all

---

## 📞 HỖ TRỢ

Nếu gặp lỗi, cung cấp thông tin:
1. API nào bị lỗi?
2. Request body (nếu có)
3. Response error message
4. Screenshot Postman

---

**Chúc bạn test thành công! 🎉**
