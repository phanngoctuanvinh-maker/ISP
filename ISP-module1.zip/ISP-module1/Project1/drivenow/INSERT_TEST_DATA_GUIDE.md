# 🚀 HƯỚNG DẪN NHANH - INSERT TEST DATA

## Bước 1: Mở SQL Server Management Studio (SSMS)

1. Kết nối đến server: `LAPTOP-T2R4VU8R\SQLEXPRESS`
2. Chọn database: `drivenow_db`

## Bước 2: Run SQL Script

### Cách 1: Run toàn bộ file (Khuyến nghị)
1. File → Open → File...
2. Chọn file: `drivenow\insert_promotion_loyalty_test_data.sql`
3. Click **Execute** (F5)

### Cách 2: Copy từng phần và run

#### A. Insert Promotions (5 records)
```sql
INSERT INTO promotions (name, description, discount_type, discount_value, min_order_value, max_discount_amount, start_date, end_date, usage_limit, used_count, status, created_by, created_at, updated_at)
VALUES ('Giảm 20% cho đơn hàng từ 1 triệu', 'Khuyến mãi giảm 20% cho tất cả đơn hàng từ 1,000,000 VND trở lên. Tối đa giảm 200,000 VND', 'PERCENTAGE', 20.0, 1000000.0, 200000.0, '2024-01-01', '2024-12-31', 100, 0, 'ACTIVE', 1, GETDATE(), GETDATE());

INSERT INTO promotions (name, description, discount_type, discount_value, min_order_value, max_discount_amount, start_date, end_date, usage_limit, used_count, status, created_by, created_at, updated_at)
VALUES ('Giảm 15% cho khách hàng mới', 'Chương trình dành riêng cho khách hàng mới. Giảm 15% tối đa 150,000 VND', 'PERCENTAGE', 15.0, 500000.0, 150000.0, '2024-01-01', '2024-12-31', 200, 5, 'ACTIVE', 1, GETDATE(), GETDATE());

INSERT INTO promotions (name, description, discount_type, discount_value, min_order_value, max_discount_amount, start_date, end_date, usage_limit, used_count, status, created_by, created_at, updated_at)
VALUES ('Giảm 100,000 VND', 'Giảm cố định 100,000 VND cho đơn hàng từ 800,000 VND', 'FIXED_AMOUNT', 100000.0, 800000.0, NULL, '2024-01-01', '2024-06-30', 50, 10, 'ACTIVE', 1, GETDATE(), GETDATE());

INSERT INTO promotions (name, description, discount_type, discount_value, min_order_value, max_discount_amount, start_date, end_date, usage_limit, used_count, status, created_by, created_at, updated_at)
VALUES ('Flash Sale 30%', 'Flash sale cuối tuần - Giảm 30% tối đa 300,000 VND', 'PERCENTAGE', 30.0, 1500000.0, 300000.0, '2024-06-01', '2024-06-30', 20, 15, 'ACTIVE', 1, GETDATE(), GETDATE());

INSERT INTO promotions (name, description, discount_type, discount_value, min_order_value, max_discount_amount, start_date, end_date, usage_limit, used_count, status, created_by, created_at, updated_at)
VALUES ('Khuyến mãi tháng 3', 'Đã hết hạn - Giảm 25%', 'PERCENTAGE', 25.0, 1000000.0, 250000.0, '2024-03-01', '2024-03-31', 100, 80, 'INACTIVE', 1, GETDATE(), GETDATE());
```

#### B. Insert Promo Codes (8 records)
```sql
INSERT INTO promo_codes (promotion_id, code, single_use, max_uses, used_count, user_restriction, min_order_value, created_at, expires_at)
VALUES (1, 'SAVE20', 0, 100, 10, NULL, 1000000.0, GETDATE(), '2024-12-31');

INSERT INTO promo_codes (promotion_id, code, single_use, max_uses, used_count, user_restriction, min_order_value, created_at, expires_at)
VALUES (2, 'NEWCUSTOMER15', 1, 1, 0, 2, 500000.0, GETDATE(), '2024-12-31');

INSERT INTO promo_codes (promotion_id, code, single_use, max_uses, used_count, user_restriction, min_order_value, created_at, expires_at)
VALUES (3, 'FLAT100K', 0, 50, 5, NULL, 800000.0, GETDATE(), '2024-06-30');

INSERT INTO promo_codes (promotion_id, code, single_use, max_uses, used_count, user_restriction, min_order_value, created_at, expires_at)
VALUES (4, 'FLASHSALE30', 0, 20, 8, NULL, 1500000.0, GETDATE(), '2024-06-30');

INSERT INTO promo_codes (promotion_id, code, single_use, max_uses, used_count, user_restriction, min_order_value, created_at, expires_at)
VALUES (1, 'WELCOME2024', 0, 200, 25, NULL, 500000.0, GETDATE(), '2024-12-31');

INSERT INTO promo_codes (promotion_id, code, single_use, max_uses, used_count, user_restriction, min_order_value, created_at, expires_at)
VALUES (5, 'MARCH2024', 0, 100, 75, NULL, 1000000.0, '2024-03-01', '2024-03-31');

INSERT INTO promo_codes (promotion_id, code, single_use, max_uses, used_count, user_restriction, min_order_value, created_at, expires_at)
VALUES (2, 'ONETIME15', 1, 1, 0, 3, 500000.0, GETDATE(), '2024-12-31');

INSERT INTO promo_codes (promotion_id, code, single_use, max_uses, used_count, user_restriction, min_order_value, created_at, expires_at)
VALUES (4, 'VIP30', 0, 10, 3, NULL, 2000000.0, GETDATE(), '2024-12-31');
```

#### C. Insert Loyalty Points (5 records)
```sql
INSERT INTO loyalty_points (user_id, points, lifetime_points, last_updated)
VALUES (1, 150, 450, GETDATE());

INSERT INTO loyalty_points (user_id, points, lifetime_points, last_updated)
VALUES (2, 650, 850, GETDATE());

INSERT INTO loyalty_points (user_id, points, lifetime_points, last_updated)
VALUES (3, 1200, 1500, GETDATE());

INSERT INTO loyalty_points (user_id, points, lifetime_points, last_updated)
VALUES (4, 2500, 3200, GETDATE());

INSERT INTO loyalty_points (user_id, points, lifetime_points, last_updated)
VALUES (5, 80, 80, GETDATE());
```

#### D. Insert Loyalty History (14 records)
```sql
-- User 1
INSERT INTO loyalty_history (user_id, transaction_type, points, order_value, description, created_at)
VALUES (1, 'EARN', 30, 3000000, 'Thuê xe Mercedes E-Class 3 ngày', DATEADD(day, -10, GETDATE()));

INSERT INTO loyalty_history (user_id, transaction_type, points, order_value, description, created_at)
VALUES (1, 'EARN', 20, 2000000, 'Thuê xe Toyota Camry 2 ngày', DATEADD(day, -5, GETDATE()));

INSERT INTO loyalty_history (user_id, transaction_type, points, order_value, description, created_at)
VALUES (1, 'REDEEM', -50, NULL, 'Đổi điểm lấy voucher 500k', DATEADD(day, -2, GETDATE()));

-- User 2
INSERT INTO loyalty_history (user_id, transaction_type, points, order_value, description, created_at)
VALUES (2, 'EARN', 50, 5000000, 'Thuê xe BMW 5 Series 5 ngày', DATEADD(day, -15, GETDATE()));

INSERT INTO loyalty_history (user_id, transaction_type, points, order_value, description, created_at)
VALUES (2, 'EARN', 40, 4000000, 'Thuê xe Audi A6 4 ngày', DATEADD(day, -8, GETDATE()));

INSERT INTO loyalty_history (user_id, transaction_type, points, order_value, description, created_at)
VALUES (2, 'REDEEM', -20, NULL, 'Đổi điểm lấy voucher 200k', DATEADD(day, -3, GETDATE()));

-- User 3
INSERT INTO loyalty_history (user_id, transaction_type, points, order_value, description, created_at)
VALUES (3, 'EARN', 80, 8000000, 'Thuê xe Lexus RX 8 ngày', DATEADD(day, -20, GETDATE()));

INSERT INTO loyalty_history (user_id, transaction_type, points, order_value, description, created_at)
VALUES (3, 'EARN', 60, 6000000, 'Thuê xe Mercedes S-Class 6 ngày', DATEADD(day, -12, GETDATE()));

INSERT INTO loyalty_history (user_id, transaction_type, points, order_value, description, created_at)
VALUES (3, 'REDEEM', -100, NULL, 'Đổi điểm lấy voucher 1 triệu', DATEADD(day, -4, GETDATE()));

-- User 4 (VIP)
INSERT INTO loyalty_history (user_id, transaction_type, points, order_value, description, created_at)
VALUES (4, 'EARN', 120, 12000000, 'Thuê xe Porsche Cayenne 12 ngày', DATEADD(day, -25, GETDATE()));

INSERT INTO loyalty_history (user_id, transaction_type, points, order_value, description, created_at)
VALUES (4, 'EARN', 100, 10000000, 'Thuê xe Range Rover 10 ngày', DATEADD(day, -18, GETDATE()));

INSERT INTO loyalty_history (user_id, transaction_type, points, order_value, description, created_at)
VALUES (4, 'REDEEM', -200, NULL, 'Đổi điểm lấy voucher 2 triệu', DATEADD(day, -7, GETDATE()));

-- User 5 (Khách hàng mới)
INSERT INTO loyalty_history (user_id, transaction_type, points, order_value, description, created_at)
VALUES (5, 'EARN', 15, 1500000, 'Thuê xe Honda City 3 ngày - Khách hàng mới', DATEADD(day, -2, GETDATE()));

INSERT INTO loyalty_history (user_id, transaction_type, points, order_value, description, created_at)
VALUES (5, 'EARN', 10, 1000000, 'Thuê xe Toyota Vios 2 ngày', GETDATE());
```

## Bước 3: Verify Data

### Check promotions
```sql
SELECT * FROM promotions;
```
**Expected:** 5 promotions (4 ACTIVE, 1 INACTIVE)

### Check promo_codes
```sql
SELECT code, used_count, max_uses, expires_at FROM promo_codes;
```
**Expected:** 8 promo codes

### Check loyalty_points với tiers
```sql
SELECT user_id, points, lifetime_points,
       CASE 
           WHEN lifetime_points >= 2000 THEN 'Platinum'
           WHEN lifetime_points >= 1000 THEN 'Gold'
           WHEN lifetime_points >= 500 THEN 'Silver'
           ELSE 'Bronze'
       END as Tier
FROM loyalty_points;
```
**Expected:**
- User 1: 150 points, Bronze
- User 2: 650 points, Silver
- User 3: 1200 points, Gold
- User 4: 2500 points, Platinum
- User 5: 80 points, Bronze

### Check loyalty_history
```sql
SELECT user_id, transaction_type, points, order_value, description 
FROM loyalty_history 
ORDER BY created_at DESC;
```
**Expected:** 14 transactions (9 EARN, 5 REDEEM)

## Bước 4: Test APIs với Postman

### Quick Test - Validate Promo Code
```bash
POST http://localhost:8080/api/promotions/validate-code
Content-Type: application/json

{
  "promoCode": "SAVE20",
  "userId": 1,
  "orderValue": 1500000
}
```

**Expected Response:**
```json
{
    "status": "success",
    "message": "Mã khuyến mãi hợp lệ",
    "data": {
        "valid": true,
        "promoCode": "SAVE20",
        "discountAmount": 200000,
        "finalAmount": 1300000
    }
}
```

### Quick Test - Get User Points
```bash
GET http://localhost:8080/api/loyalty/user/1
```

**Expected Response:**
```json
{
    "status": "success",
    "data": {
        "userId": 1,
        "points": 150,
        "lifetimePoints": 450,
        "tier": "Bronze"
    }
}
```

## ✅ Hoàn Thành!

Sau khi insert test data thành công, bạn có thể:
1. Import Postman collection: `drivenow-promotion-loyalty.postman_collection.json`
2. Follow testing guide: `TEST_PROMOTION_LOYALTY_POSTMAN.md`
3. Test all 19 APIs

**Tổng số records:** 32 records
- 5 promotions
- 8 promo codes
- 5 loyalty points
- 14 loyalty history

**Next:** Test các APIs qua Postman!
