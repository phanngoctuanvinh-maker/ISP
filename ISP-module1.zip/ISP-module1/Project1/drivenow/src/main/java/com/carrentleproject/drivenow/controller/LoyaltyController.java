package com.carrentleproject.drivenow.controller;

import com.carrentleproject.drivenow.dto.LoyaltyRequest;
import com.carrentleproject.drivenow.model.LoyaltyHistory;
import com.carrentleproject.drivenow.service.LoyaltyService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/loyalty")
@CrossOrigin(origins = "*")
public class LoyaltyController {

    @Autowired
    private LoyaltyService loyaltyService;

    // 1. Health check
    @GetMapping("/test")
    public ResponseEntity<Map<String, Object>> test() {
        Map<String, Object> response = new HashMap<>();
        response.put("status", "success");
        response.put("message", "Loyalty API is working!");
        response.put("timestamp", LocalDateTime.now());
        return ResponseEntity.ok(response);
    }

    // 2. Xem điểm của user
    @GetMapping("/user/{userId}")
    public ResponseEntity<Map<String, Object>> getUserPoints(@PathVariable Long userId) {
        Map<String, Object> response = new HashMap<>();
        try {
            Map<String, Object> points = loyaltyService.getUserPoints(userId);
            response.put("status", "success");
            response.put("data", points);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    // 3. Thêm điểm (Earn)
    @PostMapping("/add")
    public ResponseEntity<Map<String, Object>> addPoints(@Valid @RequestBody LoyaltyRequest request) {
        Map<String, Object> response = new HashMap<>();
        try {
            if (request.getOrderValue() == null) {
                throw new RuntimeException("Giá trị đơn hàng không được để trống");
            }
            
            Map<String, Object> result = loyaltyService.addPoints(
                request.getUserId(),
                request.getOrderValue(),
                request.getDescription()
            );
            
            response.put("status", "success");
            response.put("message", "Tích điểm thành công");
            response.put("data", result);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    // 4. Đổi điểm (Redeem)
    @PostMapping("/redeem")
    public ResponseEntity<Map<String, Object>> redeemPoints(@Valid @RequestBody LoyaltyRequest request) {
        Map<String, Object> response = new HashMap<>();
        try {
            Map<String, Object> result = loyaltyService.redeemPoints(
                request.getUserId(),
                request.getPoints(),
                request.getDescription()
            );
            
            response.put("status", "success");
            response.put("message", "Đổi điểm thành công");
            response.put("data", result);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    // 5. Xem lịch sử tích điểm
    @GetMapping("/history/{userId}")
    public ResponseEntity<Map<String, Object>> getUserHistory(@PathVariable Long userId) {
        Map<String, Object> response = new HashMap<>();
        try {
            List<LoyaltyHistory> history = loyaltyService.getUserHistory(userId);
            response.put("status", "success");
            response.put("data", history);
            response.put("count", history.size());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    // 6. Tính số điểm từ giá trị đơn hàng
    @GetMapping("/calculate")
    public ResponseEntity<Map<String, Object>> calculatePoints(@RequestParam Long orderValue) {
        Map<String, Object> response = new HashMap<>();
        try {
            Map<String, Object> result = loyaltyService.calculatePoints(orderValue);
            response.put("status", "success");
            response.put("data", result);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    // 7. Tính giá trị chiết khấu từ điểm
    @GetMapping("/discount")
    public ResponseEntity<Map<String, Object>> calculateDiscount(@RequestParam Integer points) {
        Map<String, Object> response = new HashMap<>();
        try {
            Map<String, Object> result = loyaltyService.calculateDiscount(points);
            response.put("status", "success");
            response.put("data", result);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }
}
