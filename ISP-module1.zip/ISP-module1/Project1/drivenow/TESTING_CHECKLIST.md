# ✅ CHECKLIST - FEATURE 2: PROMOTION & LOYALTY SYSTEM

## 📋 PRE-TESTING CHECKLIST

### ☑️ Server Status
- [ ] Server đang chạy trên port 8080
- [ ] Test health check:
  ```bash
  curl http://localhost:8080/api/promotions/test
  curl http://localhost:8080/api/loyalty/test
  ```
- [ ] Cả 2 APIs trả về status 200 OK

### ☑️ Database Setup
- [ ] Đã mở SSMS
- [ ] Đã kết nối đến `LAPTOP-T2R4VU8R\SQLEXPRESS`
- [ ] Database `drivenow_db` tồn tại
- [ ] Đã run script: `insert_promotion_loyalty_test_data.sql`
- [ ] Verify data:
  ```sql
  SELECT COUNT(*) FROM promotions;      -- Expected: 5 records
  SELECT COUNT(*) FROM promo_codes;     -- Expected: 8 records
  SELECT COUNT(*) FROM loyalty_points;  -- Expected: 5 records
  SELECT COUNT(*) FROM loyalty_history; -- Expected: 14 records
  ```

### ☑️ Postman Setup
- [ ] Đã cài đặt Postman
- [ ] Đã import collection: `drivenow-promotion-loyalty.postman_collection.json`
- [ ] Collection có 2 folders: "PROMOTION APIs" và "LOYALTY APIs"
- [ ] Đã đọc file: `TEST_PROMOTION_LOYALTY_POSTMAN.md`

---

## 🎯 TESTING CHECKLIST - PROMOTION APIs

### Test Group 1: Basic CRUD Operations

#### ✅ Test 1.1: Health Check
- [ ] Request: `GET /api/promotions/test`
- [ ] Expected: Status 200, message "Promotion API is working!"
- [ ] Result: ⬜ Pass ⬜ Fail
- [ ] Notes: ___________________________________

#### ✅ Test 1.2: Get All Promotions
- [ ] Request: `GET /api/promotions`
- [ ] Expected: Status 200, array of 5 promotions
- [ ] Result: ⬜ Pass ⬜ Fail
- [ ] Notes: ___________________________________

#### ✅ Test 1.3: Get Promotion By ID
- [ ] Request: `GET /api/promotions/1`
- [ ] Expected: Status 200, promotion details
- [ ] Result: ⬜ Pass ⬜ Fail
- [ ] Notes: ___________________________________

#### ✅ Test 1.4: Create New Promotion (PERCENTAGE)
- [ ] Request: `POST /api/promotions`
- [ ] Body: Summer Sale 20% discount
- [ ] Expected: Status 200, new promotion created
- [ ] Save `promotionId`: ___________
- [ ] Result: ⬜ Pass ⬜ Fail
- [ ] Notes: ___________________________________

#### ✅ Test 1.5: Create New Promotion (FIXED_AMOUNT)
- [ ] Request: `POST /api/promotions`
- [ ] Body: Fixed 150k discount
- [ ] Expected: Status 200, new promotion created
- [ ] Result: ⬜ Pass ⬜ Fail
- [ ] Notes: ___________________________________

#### ✅ Test 1.6: Update Promotion
- [ ] Request: `PUT /api/promotions/{id}`
- [ ] Body: Updated name and discount value
- [ ] Expected: Status 200, promotion updated
- [ ] Result: ⬜ Pass ⬜ Fail
- [ ] Notes: ___________________________________

---

### Test Group 2: Promo Code Management

#### ✅ Test 2.1: Create Promo Code
- [ ] Request: `POST /api/promotions/codes`
- [ ] Body: Code "SUMMER20" for promotion 1
- [ ] Expected: Status 200, promo code created
- [ ] Result: ⬜ Pass ⬜ Fail
- [ ] Notes: ___________________________________

#### ✅ Test 2.2: Search Promotion by Code
- [ ] Request: `GET /api/promotions/code/SAVE20`
- [ ] Expected: Status 200, promotion found
- [ ] Result: ⬜ Pass ⬜ Fail
- [ ] Notes: ___________________________________

---

### Test Group 3: Promo Code Validation

#### ✅ Test 3.1: Validate Valid Code
- [ ] Request: `POST /api/promotions/validate-code`
- [ ] Body: code="SAVE20", userId=1, orderValue=1500000
- [ ] Expected: Status 200, valid=true, discount calculated
- [ ] Result: ⬜ Pass ⬜ Fail
- [ ] Discount Amount: ___________
- [ ] Final Amount: ___________
- [ ] Notes: ___________________________________

#### ✅ Test 3.2: Validate with Low Order Value
- [ ] Request: `POST /api/promotions/validate-code`
- [ ] Body: code="SAVE20", userId=1, orderValue=500000 (< min)
- [ ] Expected: Status 400, error "Giá trị đơn hàng không đạt yêu cầu"
- [ ] Result: ⬜ Pass ⬜ Fail
- [ ] Notes: ___________________________________

#### ✅ Test 3.3: Validate Expired Code
- [ ] Request: `POST /api/promotions/validate-code`
- [ ] Body: code="MARCH2024" (expired)
- [ ] Expected: Status 400, error "Mã khuyến mãi đã hết hạn"
- [ ] Result: ⬜ Pass ⬜ Fail
- [ ] Notes: ___________________________________

---

### Test Group 4: Apply Promo Code

#### ✅ Test 4.1: Apply Valid Code (First Time)
- [ ] Check DB trước: `SELECT used_count FROM promo_codes WHERE code='SAVE20'`
- [ ] used_count before: ___________
- [ ] Request: `POST /api/promotions/apply`
- [ ] Body: code="SAVE20", userId=1, orderValue=1500000
- [ ] Expected: Status 200, discount applied
- [ ] Check DB sau: used_count increased by 1
- [ ] used_count after: ___________
- [ ] Result: ⬜ Pass ⬜ Fail
- [ ] Notes: ___________________________________

#### ✅ Test 4.2: Apply Code Multiple Times
- [ ] Request: Apply "SAVE20" 3 times consecutively
- [ ] Expected: used_count increases each time
- [ ] Initial used_count: ___________
- [ ] After 3 applications: ___________
- [ ] Result: ⬜ Pass ⬜ Fail
- [ ] Notes: ___________________________________

---

### Test Group 5: Edge Cases

#### ✅ Test 5.1: Get Active Promotions Only
- [ ] Request: `GET /api/promotions/active`
- [ ] Expected: Only promotions with status='ACTIVE' (4 out of 5)
- [ ] Count returned: ___________
- [ ] Result: ⬜ Pass ⬜ Fail
- [ ] Notes: ___________________________________

#### ✅ Test 5.2: Delete Promotion
- [ ] Request: `DELETE /api/promotions/{id}`
- [ ] Use promotionId from Test 1.4
- [ ] Expected: Status 200, promotion deleted
- [ ] Verify: GET /api/promotions/{id} returns 404
- [ ] Result: ⬜ Pass ⬜ Fail
- [ ] Notes: ___________________________________

---

## 💎 TESTING CHECKLIST - LOYALTY APIs

### Test Group 6: User Points Management

#### ✅ Test 6.1: Health Check
- [ ] Request: `GET /api/loyalty/test`
- [ ] Expected: Status 200, message "Loyalty API is working!"
- [ ] Result: ⬜ Pass ⬜ Fail
- [ ] Notes: ___________________________________

#### ✅ Test 6.2: Get User Points (Bronze Tier)
- [ ] Request: `GET /api/loyalty/user/1`
- [ ] Expected: userId=1, points=150, tier="Bronze"
- [ ] Actual points: ___________
- [ ] Actual tier: ___________
- [ ] Result: ⬜ Pass ⬜ Fail
- [ ] Notes: ___________________________________

#### ✅ Test 6.3: Get User Points (Silver Tier)
- [ ] Request: `GET /api/loyalty/user/2`
- [ ] Expected: userId=2, points=650, tier="Silver"
- [ ] Result: ⬜ Pass ⬜ Fail
- [ ] Notes: ___________________________________

#### ✅ Test 6.4: Get User Points (Gold Tier)
- [ ] Request: `GET /api/loyalty/user/3`
- [ ] Expected: userId=3, points=1200, tier="Gold"
- [ ] Result: ⬜ Pass ⬜ Fail
- [ ] Notes: ___________________________________

#### ✅ Test 6.5: Get User Points (Platinum Tier)
- [ ] Request: `GET /api/loyalty/user/4`
- [ ] Expected: userId=4, points=2500, tier="Platinum"
- [ ] Result: ⬜ Pass ⬜ Fail
- [ ] Notes: ___________________________________

---

### Test Group 7: Earn Points

#### ✅ Test 7.1: Earn Points from Order
- [ ] Check DB trước: `SELECT points FROM loyalty_points WHERE user_id=1`
- [ ] Points before: ___________
- [ ] Request: `POST /api/loyalty/add`
- [ ] Body: userId=1, orderValue=2500000 (should earn 25 points)
- [ ] Expected: Status 200, pointsEarned=25
- [ ] Check DB sau: points increased by 25
- [ ] Points after: ___________
- [ ] Result: ⬜ Pass ⬜ Fail
- [ ] Notes: ___________________________________

#### ✅ Test 7.2: Earn Points with Large Order
- [ ] Request: `POST /api/loyalty/add`
- [ ] Body: userId=1, orderValue=10000000 (should earn 100 points)
- [ ] Expected: Status 200, pointsEarned=100
- [ ] Result: ⬜ Pass ⬜ Fail
- [ ] Notes: ___________________________________

#### ✅ Test 7.3: Verify Lifetime Points Increase
- [ ] Request: Get user 1 points
- [ ] Verify: lifetimePoints = initial + all earned points
- [ ] lifetimePoints: ___________
- [ ] Result: ⬜ Pass ⬜ Fail
- [ ] Notes: ___________________________________

---

### Test Group 8: Redeem Points

#### ✅ Test 8.1: Redeem Valid Amount (50 points)
- [ ] Check DB trước: `SELECT points FROM loyalty_points WHERE user_id=1`
- [ ] Points before: ___________
- [ ] Request: `POST /api/loyalty/redeem`
- [ ] Body: userId=1, points=50 (should get 500k discount)
- [ ] Expected: Status 200, discountAmount=500000
- [ ] Check DB sau: points decreased by 50
- [ ] Points after: ___________
- [ ] Result: ⬜ Pass ⬜ Fail
- [ ] Notes: ___________________________________

#### ✅ Test 8.2: Redeem Minimum Points (10 points)
- [ ] Request: `POST /api/loyalty/redeem`
- [ ] Body: userId=1, points=10 (minimum allowed)
- [ ] Expected: Status 200, discountAmount=100000
- [ ] Result: ⬜ Pass ⬜ Fail
- [ ] Notes: ___________________________________

#### ✅ Test 8.3: Try Redeem Below Minimum (5 points)
- [ ] Request: `POST /api/loyalty/redeem`
- [ ] Body: userId=1, points=5 (< minimum)
- [ ] Expected: Status 400, error "Số điểm đổi tối thiểu là 10"
- [ ] Result: ⬜ Pass ⬜ Fail
- [ ] Notes: ___________________________________

#### ✅ Test 8.4: Try Redeem More Than Balance
- [ ] Get current points for user 5
- [ ] Current points: ___________
- [ ] Request: `POST /api/loyalty/redeem`
- [ ] Body: userId=5, points=9999 (> balance)
- [ ] Expected: Status 400, error "Số điểm không đủ"
- [ ] Result: ⬜ Pass ⬜ Fail
- [ ] Notes: ___________________________________

---

### Test Group 9: Transaction History

#### ✅ Test 9.1: View User History
- [ ] Request: `GET /api/loyalty/history/1`
- [ ] Expected: Array of transactions (EARN and REDEEM)
- [ ] Count transactions: ___________
- [ ] Has EARN transactions: ⬜ Yes ⬜ No
- [ ] Has REDEEM transactions: ⬜ Yes ⬜ No
- [ ] Result: ⬜ Pass ⬜ Fail
- [ ] Notes: ___________________________________

#### ✅ Test 9.2: Verify History Order
- [ ] Check history is ordered by created_at DESC
- [ ] Most recent transaction date: ___________
- [ ] Oldest transaction date: ___________
- [ ] Result: ⬜ Pass ⬜ Fail
- [ ] Notes: ___________________________________

---

### Test Group 10: Calculation Previews

#### ✅ Test 10.1: Calculate Points from Order Value
- [ ] Request: `GET /api/loyalty/calculate?orderValue=3500000`
- [ ] Expected: pointsEarned=35 (3,500,000 / 100,000)
- [ ] Actual points: ___________
- [ ] Result: ⬜ Pass ⬜ Fail
- [ ] Notes: ___________________________________

#### ✅ Test 10.2: Calculate Discount from Points
- [ ] Request: `GET /api/loyalty/discount?points=100`
- [ ] Expected: discountAmount=1000000 (100 * 10,000)
- [ ] Actual discount: ___________
- [ ] Result: ⬜ Pass ⬜ Fail
- [ ] Notes: ___________________________________

---

## 🔍 DATABASE VERIFICATION CHECKLIST

### ☑️ Promotions Table
```sql
SELECT id, name, discount_type, discount_value, status, used_count 
FROM promotions;
```
- [ ] 5 promotions exist
- [ ] 4 ACTIVE, 1 INACTIVE
- [ ] Result: ⬜ Pass ⬜ Fail

### ☑️ Promo Codes Table
```sql
SELECT code, used_count, max_uses, expires_at 
FROM promo_codes 
ORDER BY used_count DESC;
```
- [ ] 8 promo codes exist
- [ ] used_count updated after apply API
- [ ] Result: ⬜ Pass ⬜ Fail

### ☑️ Loyalty Points Table
```sql
SELECT user_id, points, lifetime_points,
       CASE 
           WHEN lifetime_points >= 2000 THEN 'Platinum'
           WHEN lifetime_points >= 1000 THEN 'Gold'
           WHEN lifetime_points >= 500 THEN 'Silver'
           ELSE 'Bronze'
       END as Tier
FROM loyalty_points;
```
- [ ] 5 users exist
- [ ] All 4 tiers represented
- [ ] Result: ⬜ Pass ⬜ Fail

### ☑️ Loyalty History Table
```sql
SELECT user_id, transaction_type, points, description 
FROM loyalty_history 
ORDER BY created_at DESC;
```
- [ ] At least 14 transactions exist
- [ ] Both EARN and REDEEM types present
- [ ] REDEEM has negative points
- [ ] Result: ⬜ Pass ⬜ Fail

---

## 📊 FINAL CHECKLIST

### ☑️ API Functionality
- [ ] All 19 APIs responding correctly
- [ ] No 500 Internal Server Errors
- [ ] Error messages are clear and helpful
- [ ] Response format consistent (status, message, data)

### ☑️ Business Logic
- [ ] Promotion validation works correctly
- [ ] Points calculation accurate (100k = 1 point)
- [ ] Discount calculation accurate (1 point = 10k)
- [ ] Tier system working (Bronze/Silver/Gold/Platinum)
- [ ] Usage tracking increments properly

### ☑️ Database Integrity
- [ ] used_count increments on apply
- [ ] points decrease on redeem
- [ ] lifetimePoints never decrease
- [ ] History records all transactions

### ☑️ Edge Cases Handled
- [ ] Expired promotions rejected
- [ ] Low order value rejected
- [ ] Insufficient points rejected
- [ ] Below minimum redeem rejected
- [ ] Non-existent codes handled

---

## 📈 TEST RESULTS SUMMARY

### Promotion APIs (12 tests)
- Passed: _____ / 12
- Failed: _____ / 12
- Pass Rate: _____% 

### Loyalty APIs (7 tests)
- Passed: _____ / 7
- Failed: _____ / 7
- Pass Rate: _____%

### Overall (19 tests)
- **Total Passed:** _____ / 19
- **Total Failed:** _____ / 19
- **Overall Pass Rate:** _____%

### Issues Found
1. _________________________________________________
2. _________________________________________________
3. _________________________________________________

### Notes
_____________________________________________________
_____________________________________________________
_____________________________________________________

---

## ✅ SIGN-OFF

- [ ] All tests completed
- [ ] All critical issues resolved
- [ ] Documentation reviewed
- [ ] System ready for production

**Tested By:** ___________________  
**Date:** ___________________  
**Status:** ⬜ APPROVED ⬜ NEEDS WORK

---

**Next Steps:**
1. If all tests pass → Proceed to frontend integration
2. If issues found → Document in "Issues Found" section
3. Review `TEST_PROMOTION_LOYALTY_POSTMAN.md` for troubleshooting
