# 🏦 HƯỚNG DẪN SỬ DỤNG API QUẢN LÝ TIỀN CỌC

## 📋 TỔNG QUAN
Hệ thống quản lý tiền cọc bao gồm:
- **Tạo tiền cọc** khi khách hàng đặt xe
- **Xác nhận thanh toán** tiền cọc
- **Hoàn tiền cọc** khi trả xe (toàn bộ hoặc một phần)
- **Tính phạt** nếu có vi phạm

---

## 🗄️ BƯỚC 1: TẠO DATABASE

### Chạy SQL script:
```bash
# Kết nối SQL Server Management Studio
# Mở file: database_payment_management.sql
# Execute (F5)
```

### Insert test data:
```bash
# Mở file: insert_deposit_test_data.sql
# Execute (F5)
```

---

## 🚀 BƯỚC 2: KHỞI ĐỘNG SERVER

```bash
cd drivenow
mvn clean spring-boot:run
```

Server sẽ chạy tại: `http://localhost:8080`

---

## 🧪 BƯỚC 3: TEST VỚI POSTMAN

### Import Postman Collection:
1. Mở Postman
2. Click **Import**
3. Chọn file: `drivenow-deposit.postman_collection.json`

### Test các API theo thứ tự:

#### **1. Test API (Health Check)** ✅
```
GET http://localhost:8080/api/deposits/test
```
**Expected Response:**
```json
{
  "success": true,
  "message": "Deposit Management API is working!",
  "timestamp": 1728900000000
}
```

#### **2. Create Deposit (Tạo tiền cọc)** 💰
```
POST http://localhost:8080/api/deposits
Content-Type: application/json

{
  "bookingId": 5,
  "userId": 1,
  "depositAmount": 5000000,
  "paymentMethod": "VNPAY",
  "notes": "Deposit for Mercedes rental"
}
```
**Expected Response:**
```json
{
  "success": true,
  "message": "Deposit created successfully",
  "deposit": {
    "id": 3,
    "depositCode": "DEP-ABCD1234",
    "bookingId": 5,
    "userId": 1,
    "depositAmount": 5000000,
    "depositStatus": "PENDING",
    "transactionId": 3
  }
}
```

#### **3. Confirm Deposit Payment (Xác nhận đã thanh toán)** ✔️
```
PUT http://localhost:8080/api/deposits/1/confirm?referenceCode=VNPAY123456
```
**Expected Response:**
```json
{
  "success": true,
  "message": "Deposit payment confirmed",
  "deposit": {
    "id": 1,
    "depositStatus": "PAID"
  }
}
```

#### **4. Refund Deposit (Hoàn tiền cọc - Toàn bộ)** 💸
```
POST http://localhost:8080/api/deposits/refund
Content-Type: application/json

{
  "depositId": 1,
  "refundAmount": 5000000,
  "penaltyAmount": 0,
  "reason": "Completed rental successfully"
}
```
**Expected Response:**
```json
{
  "success": true,
  "message": "Deposit refunded successfully",
  "deposit": {
    "id": 1,
    "depositStatus": "REFUNDED",
    "refundAmount": 5000000,
    "penaltyAmount": 0
  }
}
```

#### **5. Refund Deposit (Hoàn một phần - Có phạt)** ⚠️
```
POST http://localhost:8080/api/deposits/refund
Content-Type: application/json

{
  "depositId": 1,
  "refundAmount": 4000000,
  "penaltyAmount": 1000000,
  "reason": "Car returned with minor damage"
}
```
**Expected Response:**
```json
{
  "success": true,
  "message": "Deposit refunded successfully",
  "deposit": {
    "id": 1,
    "depositStatus": "PARTIALLY_REFUNDED",
    "refundAmount": 4000000,
    "penaltyAmount": 1000000
  }
}
```

#### **6. Get Deposit by ID** 🔍
```
GET http://localhost:8080/api/deposits/1
```

#### **7. Get Deposit by Booking ID** 🔍
```
GET http://localhost:8080/api/deposits/booking/1
```

#### **8. Get Deposits by User ID** 👤
```
GET http://localhost:8080/api/deposits/user/1
```

#### **9. Get Deposits by Status** 📊
```
GET http://localhost:8080/api/deposits/status/PAID
```

**Valid Status Values:**
- `PENDING` - Đang chờ
- `PAID` - Đã trả
- `REFUNDED` - Đã hoàn đầy đủ
- `PARTIALLY_REFUNDED` - Hoàn một phần
- `FORFEITED` - Bị tịch thu

---

## 🔄 LUỒNG HOẠT ĐỘNG

```
1. Khách hàng đặt xe
   ↓
2. Tạo Deposit (PENDING)
   ↓
3. Khách hàng thanh toán qua VNPay/Cash
   ↓
4. Xác nhận Deposit (PAID)
   ↓
5. Khách hàng trả xe
   ↓
6. Hoàn tiền cọc:
   - Không có vấn đề → Hoàn toàn bộ (REFUNDED)
   - Có hư hỏng nhỏ → Hoàn một phần + Phạt (PARTIALLY_REFUNDED)
   - Hư hỏng nặng → Tịch thu toàn bộ (FORFEITED)
```

---

## ✅ CHECKLIST TEST

- [ ] Test API health check thành công
- [ ] Tạo deposit mới thành công
- [ ] Không thể tạo 2 deposit cho cùng 1 booking
- [ ] Xác nhận thanh toán deposit thành công
- [ ] Hoàn tiền cọc toàn bộ thành công
- [ ] Hoàn tiền cọc một phần với phạt thành công
- [ ] Query deposit theo ID thành công
- [ ] Query deposit theo booking ID thành công
- [ ] Query deposits theo user ID thành công
- [ ] Query deposits theo status thành công

---

## 🎯 TÍNH NĂNG ĐÃ HOÀN THÀNH

✅ **Quản lý tiền cọc (Deposit)**
- Tạo tiền cọc
- Xác nhận thanh toán
- Hoàn tiền (toàn bộ/một phần)
- Tính phạt

✅ **Quản lý giao dịch (Transaction)**
- Tự động tạo transaction cho mỗi deposit
- Tự động tạo transaction cho refund
- Tự động tạo transaction cho penalty
- Tracking toàn bộ lịch sử giao dịch

✅ **Query & Reporting**
- Query theo ID
- Query theo Booking
- Query theo User
- Query theo Status

---

## 📞 HỖ TRỢ

Nếu gặp lỗi:
1. Kiểm tra server đang chạy: `http://localhost:8080/api/deposits/test`
2. Kiểm tra database đã tạo tables chưa
3. Kiểm tra SecurityConfig đã permitAll cho `/api/deposits/**`
4. Check console logs để xem lỗi chi tiết

---

**🎉 Chúc bạn test thành công!**
