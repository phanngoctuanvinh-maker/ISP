# 📋 VNPAY PAYMENT - CHECKLIST & COMMANDS

## ✅ DANH SÁCH FILE ĐÃ TẠO

### Backend Files (drivenow/)
- ✅ `model/Payment.java` - Entity cho thanh toán
- ✅ `dao/PaymentRepository.java` - JPA Repository
- ✅ `dto/PaymentRequest.java` - DTO request
- ✅ `dto/PaymentResponse.java` - DTO response
- ✅ `config/VNPayConfig.java` - Cấu hình VNPay
- ✅ `service/VNPayService.java` - Business logic
- ✅ `controller/PaymentController.java` - REST APIs
- ✅ `src/main/resources/application.properties` - Updated với VNPay config
- ✅ `config/SecurityConfig.java` - Updated cho phép payment APIs
- ✅ `create_payments_table.sql` - SQL script

### Frontend Files
- ✅ `html/test-payment-vnpay.html` - Test page HTML

### Documentation Files
- ✅ `README_VNPAY_INTEGRATION.md` - Tài liệu tổng hợp
- ✅ `HUONG_DAN_TEST_VNPAY.md` - Hướng dẫn test chi tiết
- ✅ `POSTMAN_COLLECTION_VNPAY.md` - Postman collection
- ✅ `QUICK_START_VNPAY.md` - Quick start guide
- ✅ `VNPAY_CHECKLIST.md` - File này

### Scripts
- ✅ `start-payment-server.bat` - Script chạy server

---

## 🚀 COMMANDS CHẠY BACKEND

### 1. Build project
```bash
cd drivenow
mvn clean install
```

### 2. Run server
```bash
mvn spring-boot:run
```

### 3. Run với batch file
```bash
.\start-payment-server.bat
```

---

## 🗄️ SQL COMMANDS

### Tạo bảng payments
```sql
USE drivenow_db;
GO

-- Chạy file
:r create_payments_table.sql
GO
```

### Hoặc copy-paste từ file vào SSMS

### Kiểm tra bảng đã tạo
```sql
SELECT * FROM INFORMATION_SCHEMA.TABLES 
WHERE TABLE_NAME = 'payments';
```

### Xem dữ liệu
```sql
SELECT * FROM payments ORDER BY created_at DESC;
```

### Xóa tất cả dữ liệu test
```sql
TRUNCATE TABLE payments;
```

---

## 🧪 TEST COMMANDS (Postman/cURL)

### 1. Test API hoạt động
```bash
curl http://localhost:8080/api/payment/test
```

### 2. Tạo payment
```bash
curl -X POST http://localhost:8080/api/payment/create \
  -H "Content-Type: application/json" \
  -d "{\"userId\":1,\"amount\":100000,\"orderInfo\":\"Test payment\",\"bankCode\":\"NCB\"}"
```

### 3. Lấy payment theo order ID
```bash
curl http://localhost:8080/api/payment/order/ORDER12345678
```

### 4. Lấy payments của user
```bash
curl http://localhost:8080/api/payment/user/1
```

---

## 🌐 POSTMAN REQUESTS

### Request 1: Test API
- **Method:** GET
- **URL:** `http://localhost:8080/api/payment/test`

### Request 2: Create Payment
- **Method:** POST
- **URL:** `http://localhost:8080/api/payment/create`
- **Headers:** `Content-Type: application/json`
- **Body:**
```json
{
    "userId": 1,
    "amount": 100000,
    "orderInfo": "Thanh toan thue xe Honda City 3 ngay",
    "bankCode": "NCB"
}
```

### Request 3: Get Payment by Order ID
- **Method:** GET
- **URL:** `http://localhost:8080/api/payment/order/ORDER12345678`

### Request 4: Get User Payments
- **Method:** GET
- **URL:** `http://localhost:8080/api/payment/user/1`

---

## 🔍 DEBUGGING COMMANDS

### Kiểm tra port đang dùng
```bash
netstat -ano | findstr :8080
```

### Kill process chiếm port
```bash
taskkill /PID <PID> /F
```

### Xem log Spring Boot
- Xem trong console khi chạy `mvn spring-boot:run`
- Hoặc trong file `logs/spring.log` (nếu có config)

### Kiểm tra Java version
```bash
java -version
```

### Kiểm tra Maven version
```bash
mvn -version
```

---

## 📊 VALIDATION QUERIES

### Kiểm tra payments đã tạo
```sql
SELECT 
    id,
    order_id,
    user_id,
    amount,
    payment_status,
    created_at
FROM payments 
ORDER BY created_at DESC;
```

### Đếm số payments theo status
```sql
SELECT 
    payment_status,
    COUNT(*) as total,
    SUM(amount) as total_amount
FROM payments 
GROUP BY payment_status;
```

### Lấy payments của user cụ thể
```sql
SELECT * FROM payments 
WHERE user_id = 1
ORDER BY created_at DESC;
```

### Lấy payments thành công hôm nay
```sql
SELECT * FROM payments 
WHERE payment_status = 'SUCCESS'
AND CAST(created_at AS DATE) = CAST(GETDATE() AS DATE);
```

---

## 🐛 TROUBLESHOOTING COMMANDS

### Lỗi: Database connection
```sql
-- Kiểm tra SQL Server đã chạy
services.msc

-- Test connection string
sqlcmd -S localhost -U sa -P 12345
```

### Lỗi: Table không tồn tại
```sql
-- Kiểm tra bảng
USE drivenow_db;
SELECT * FROM INFORMATION_SCHEMA.TABLES;

-- Tạo lại bảng
DROP TABLE IF EXISTS payments;
-- Rồi chạy lại create_payments_table.sql
```

### Lỗi: Port already in use
```bash
# Windows
netstat -ano | findstr :8080
taskkill /PID <PID> /F

# Hoặc đổi port trong application.properties
server.port=8081
```

### Lỗi: Maven build failed
```bash
# Clean và rebuild
mvn clean
mvn install -DskipTests

# Update dependencies
mvn dependency:purge-local-repository
mvn clean install
```

---

## 📱 THÔNG TIN TEST VNPAY

### Thẻ test NCB
- **Số thẻ:** 9704198526191432198
- **Tên:** NGUYEN VAN A
- **Ngày phát hành:** 07/15
- **OTP:** 123456

### Các bank code khác
- `VCB` - Vietcombank
- `TCB` - Techcombank
- `MB` - MBBank
- `VIB` - VIB
- `ICB` - VietinBank
- `ACB` - ACB

### URL quan trọng
- **Sandbox:** https://sandbox.vnpayment.vn
- **API Docs:** https://sandbox.vnpayment.vn/apis/docs/

---

## ✅ TESTING CHECKLIST

### Backend Tests
- [ ] Server chạy thành công trên port 8080
- [ ] API `/api/payment/test` trả về success
- [ ] Database có bảng `payments`
- [ ] POST `/api/payment/create` tạo payment thành công
- [ ] GET `/api/payment/order/{id}` lấy được data
- [ ] GET `/api/payment/user/{id}` lấy được danh sách

### Integration Tests
- [ ] Mở payment URL trên browser
- [ ] Điền thông tin thẻ test
- [ ] Nhập OTP 123456
- [ ] Callback về return URL thành công
- [ ] Payment status cập nhật thành SUCCESS
- [ ] Database có record mới

### Frontend Tests
- [ ] HTML test page mở được
- [ ] Click "Kiểm tra API" hiển thị online
- [ ] Submit form tạo payment thành công
- [ ] Redirect đến VNPay
- [ ] Return về hiển thị kết quả

---

## 📦 BUILD & DEPLOY

### Development
```bash
mvn spring-boot:run
```

### Production build
```bash
mvn clean package -DskipTests
java -jar target/drivenow-0.0.1-SNAPSHOT.jar
```

### Docker (optional)
```dockerfile
FROM openjdk:17-jdk-slim
WORKDIR /app
COPY target/drivenow-0.0.1-SNAPSHOT.jar app.jar
EXPOSE 8080
ENTRYPOINT ["java", "-jar", "app.jar"]
```

```bash
docker build -t drivenow-payment .
docker run -p 8080:8080 drivenow-payment
```

---

## 📞 SUPPORT & RESOURCES

### Documentation
- README_VNPAY_INTEGRATION.md - Tài liệu đầy đủ
- HUONG_DAN_TEST_VNPAY.md - Hướng dẫn test
- QUICK_START_VNPAY.md - Quick start

### Test Tools
- html/test-payment-vnpay.html - Web test page
- POSTMAN_COLLECTION_VNPAY.md - Postman collection

### VNPay Resources
- Sandbox: https://sandbox.vnpayment.vn
- Docs: https://sandbox.vnpayment.vn/apis/docs/
- Support: Contact VNPay team

---

## 🎯 NEXT STEPS

### Các tính năng có thể mở rộng:
1. ✨ Thêm IPN (Instant Payment Notification)
2. 🔄 Implement refund API
3. 📊 Dashboard thống kê doanh thu
4. 📧 Email notification sau thanh toán
5. 🔗 Tích hợp với booking system
6. 🔒 Thêm authentication cho payment APIs
7. 📱 Mobile app integration
8. 💳 Support thêm payment methods
9. 🌍 Multi-currency support
10. 📈 Analytics và reporting

---

**🎉 Chúc bạn tích hợp thành công!**

```
Mọi thắc mắc vui lòng xem:
- README_VNPAY_INTEGRATION.md (chi tiết)
- QUICK_START_VNPAY.md (chạy nhanh)
- HUONG_DAN_TEST_VNPAY.md (test API)
```
