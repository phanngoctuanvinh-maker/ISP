# 💳 TÍCH HỢP VNPAY THANH TOÁN - DRIVENOW

## 📌 Giới thiệu

Hệ thống tích hợp VNPay Payment Gateway cho phép người dùng thanh toán online an toàn và nhanh chóng.

---

## 🏗️ Cấu trúc Code

```
drivenow/
├── src/main/java/com/carrentleproject/drivenow/
│   ├── config/
│   │   └── VNPayConfig.java          # Cấu hình VNPay
│   ├── controller/
│   │   └── PaymentController.java    # API endpoints
│   ├── dao/
│   │   └── PaymentRepository.java    # JPA Repository
│   ├── dto/
│   │   ├── PaymentRequest.java       # Request DTO
│   │   └── PaymentResponse.java      # Response DTO
│   ├── model/
│   │   └── Payment.java              # Entity model
│   └── service/
│       └── VNPayService.java         # Business logic
├── src/main/resources/
│   └── application.properties        # Config VNPay
└── create_payments_table.sql         # SQL script
```

---

## 🚀 Cài đặt và chạy

### Bước 1: Chuẩn bị Database

1. Mở SQL Server Management Studio (SSMS)
2. Chạy script: `create_payments_table.sql`

```sql
USE drivenow_db;
GO
-- Script sẽ tự động tạo bảng payments
```

### Bước 2: Cấu hình VNPay

File `application.properties` đã được cấu hình sẵn với VNPay Sandbox:

```properties
vnpay.url=https://sandbox.vnpayment.vn/paymentv2/vpcpay.html
vnpay.return-url=http://localhost:8080/api/payment/vnpay-return
vnpay.tmn-code=0FMOMRK9
vnpay.secret-key=O7YW3HX0MTQ1EXWGC3PJGJ8UH8CGIWHC
```

### Bước 3: Build và chạy Backend

```bash
cd drivenow
mvn clean install
mvn spring-boot:run
```

Hoặc dùng file batch:
```bash
.\start-backend.bat
```

### Bước 4: Kiểm tra server

Mở Postman hoặc trình duyệt:
```
http://localhost:8080/api/payment/test
```

Nếu thấy response sau là OK:
```json
{
    "success": true,
    "message": "Payment API is working!"
}
```

---

## 📡 API Endpoints

### 1. Test API
```http
GET /api/payment/test
```

### 2. Tạo URL thanh toán
```http
POST /api/payment/create
Content-Type: application/json

{
    "userId": 1,
    "amount": 100000,
    "orderInfo": "Thanh toan thue xe",
    "bankCode": "NCB"
}
```

### 3. Callback VNPay (tự động)
```http
GET /api/payment/vnpay-return?vnp_Amount=...&vnp_BankCode=...
```

### 4. Lấy thông tin thanh toán
```http
GET /api/payment/order/{orderId}
```

### 5. Lịch sử thanh toán user
```http
GET /api/payment/user/{userId}
```

---

## 🧪 Test với Postman

### Cách 1: Import Collection

1. Mở file: `POSTMAN_COLLECTION_VNPAY.md`
2. Copy JSON collection
3. Postman > Import > Raw text > Paste > Import

### Cách 2: Test thủ công

Chi tiết xem file: `HUONG_DAN_TEST_VNPAY.md`

**Thông tin thẻ test VNPay:**
- Ngân hàng: NCB
- Số thẻ: `9704198526191432198`
- Tên: `NGUYEN VAN A`
- Ngày: `07/15`
- OTP: `123456`

---

## 🔄 Quy trình thanh toán

```
1. User gọi API /api/payment/create
   ↓
2. Backend tạo payment record (status: PENDING)
   ↓
3. Backend trả về paymentUrl
   ↓
4. User mở paymentUrl trên browser
   ↓
5. User nhập thông tin thẻ trên VNPay
   ↓
6. VNPay xử lý thanh toán
   ↓
7. VNPay redirect về /api/payment/vnpay-return
   ↓
8. Backend verify signature và cập nhật payment
   ↓
9. Trả về kết quả (SUCCESS hoặc FAILED)
```

---

## 💾 Database Schema

```sql
CREATE TABLE payments (
    id BIGINT IDENTITY(1,1) PRIMARY KEY,
    order_id NVARCHAR(50) NOT NULL UNIQUE,
    user_id BIGINT NOT NULL,
    amount DECIMAL(18,2) NOT NULL,
    order_info NVARCHAR(500),
    transaction_no NVARCHAR(50),
    bank_code NVARCHAR(20),
    payment_status NVARCHAR(20) NOT NULL DEFAULT 'PENDING',
    vnpay_response_code NVARCHAR(10),
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    updated_at DATETIME2
);
```

---

## 🎨 Tích hợp Frontend

### HTML Form Example

```html
<form id="paymentForm">
    <input type="number" id="userId" placeholder="User ID" required>
    <input type="number" id="amount" placeholder="Số tiền (VNĐ)" required>
    <input type="text" id="orderInfo" placeholder="Thông tin đơn hàng">
    <select id="bankCode">
        <option value="">-- Chọn ngân hàng --</option>
        <option value="NCB">NCB</option>
        <option value="VCB">Vietcombank</option>
        <option value="TCB">Techcombank</option>
    </select>
    <button type="submit">Thanh toán</button>
</form>
```

### JavaScript Example

```javascript
document.getElementById('paymentForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const paymentData = {
        userId: parseInt(document.getElementById('userId').value),
        amount: parseInt(document.getElementById('amount').value),
        orderInfo: document.getElementById('orderInfo').value,
        bankCode: document.getElementById('bankCode').value
    };
    
    try {
        const response = await fetch('http://localhost:8080/api/payment/create', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(paymentData)
        });
        
        const result = await response.json();
        
        if (result.success) {
            // Redirect đến trang thanh toán VNPay
            window.location.href = result.paymentUrl;
        } else {
            alert('Lỗi: ' + result.message);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Có lỗi xảy ra!');
    }
});
```

### Xử lý return URL

```javascript
// Trang return sau khi thanh toán
// Đọc params từ URL
const urlParams = new URLSearchParams(window.location.search);
const orderId = urlParams.get('vnp_TxnRef');
const responseCode = urlParams.get('vnp_ResponseCode');

if (responseCode === '00') {
    alert('Thanh toán thành công!');
    // Lấy chi tiết payment
    fetch(`http://localhost:8080/api/payment/order/${orderId}`)
        .then(res => res.json())
        .then(data => {
            console.log('Payment details:', data.payment);
            // Hiển thị thông tin
        });
} else {
    alert('Thanh toán thất bại!');
}
```

---

## 🛡️ Bảo mật

### Development (Sandbox)
- URL: `https://sandbox.vnpayment.vn`
- TMN Code: `0FMOMRK9`
- Secret Key: `O7YW3HX0MTQ1EXWGC3PJGJ8UH8CGIWHC`

### Production
Khi deploy production, cần:
1. Đăng ký tài khoản VNPay thật
2. Thay đổi trong `application.properties`:
```properties
vnpay.url=https://vnpayment.vn/paymentv2/vpcpay.html
vnpay.tmn-code=YOUR_REAL_TMN_CODE
vnpay.secret-key=YOUR_REAL_SECRET_KEY
vnpay.return-url=https://yourdomain.com/api/payment/vnpay-return
```

---

## 🐛 Troubleshooting

### Lỗi: Cannot connect to database
**Giải pháp:**
```bash
# Kiểm tra SQL Server đã chạy
services.msc

# Kiểm tra database tồn tại
USE drivenow_db;

# Kiểm tra user/password trong application.properties
spring.datasource.username=sa
spring.datasource.password=12345
```

### Lỗi: Invalid signature
**Giải pháp:**
- Kiểm tra `vnpay.secret-key` trong config
- Đảm bảo không có khoảng trắng thừa
- Secret key phải khớp với VNPay

### Lỗi: Port 8080 already in use
**Giải pháp:**
```bash
# Tìm process đang dùng port 8080
netstat -ano | findstr :8080

# Kill process
taskkill /PID <PID> /F

# Hoặc đổi port trong application.properties
server.port=8081
```

---

## 📊 Response Codes

| Code | Ý nghĩa |
|------|---------|
| 00 | Giao dịch thành công |
| 07 | Trừ tiền thành công. Giao dịch bị nghi ngờ |
| 09 | Thẻ/Tài khoản chưa đăng ký dịch vụ |
| 10 | Xác thực thất bại quá số lần quy định |
| 11 | Hết hạn chờ thanh toán |
| 12 | Thẻ/Tài khoản bị khóa |
| 13 | OTP không chính xác |
| 24 | Giao dịch bị hủy |
| 51 | Tài khoản không đủ số dư |
| 65 | Tài khoản vượt quá hạn mức |

Xem đầy đủ: https://sandbox.vnpayment.vn/apis/docs/bang-ma-loi/

---

## 📝 TODO & Nâng cao

- [ ] Thêm webhook IPN để xử lý callback async
- [ ] Implement query transaction API
- [ ] Implement refund API
- [ ] Thêm retry mechanism
- [ ] Log tất cả transactions
- [ ] Email notification sau thanh toán
- [ ] Tích hợp với booking/rental system
- [ ] Dashboard thống kê doanh thu
- [ ] Export báo cáo Excel
- [ ] Multi-currency support

---

## 📚 Tài liệu tham khảo

- [VNPay Developer Portal](https://sandbox.vnpayment.vn/apis/)
- [VNPay API Documentation](https://sandbox.vnpayment.vn/apis/docs/)
- [Spring Boot Documentation](https://spring.io/projects/spring-boot)

---

## 👥 Support

Nếu gặp vấn đề, hãy:
1. Kiểm tra log trong console
2. Xem file `HUONG_DAN_TEST_VNPAY.md`
3. Test từng API endpoint riêng lẻ
4. Kiểm tra database đã có bảng `payments` chưa

---

## ✅ Checklist triển khai

- [x] Tạo model Payment
- [x] Tạo PaymentRepository
- [x] Tạo VNPayConfig
- [x] Tạo VNPayService
- [x] Tạo PaymentController
- [x] Thêm config vào application.properties
- [x] Tạo SQL script
- [x] Viết tài liệu API
- [x] Tạo Postman collection
- [ ] Test đầy đủ các trường hợp
- [ ] Tích hợp với frontend
- [ ] Deploy lên server

---

**Chúc bạn tích hợp thành công! 🎉💳**
