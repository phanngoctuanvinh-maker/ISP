# 🚀 HƯỚNG DẪN CHẠY NHANH VNPAY PAYMENT

## ⚡ Chạy ngay trong 3 bước

### Bước 1: Chuẩn bị Database
1. Mở SQL Server Management Studio
2. Chạy file: `drivenow\create_payments_table.sql`

### Bước 2: Chạy Backend
Double click file:
```
start-payment-server.bat
```

Hoặc chạy thủ công:
```bash
cd drivenow
mvn spring-boot:run
```

### Bước 3: Test Payment

**Cách 1: Dùng HTML test page**
1. Mở file: `html\test-payment-vnpay.html` bằng trình duyệt
2. Click "Kiểm tra API"
3. Nhập thông tin và nhấn "Thanh toán ngay"

**Cách 2: Dùng Postman**
1. Import collection từ: `POSTMAN_COLLECTION_VNPAY.md`
2. Gọi API: POST `http://localhost:8080/api/payment/create`
3. Body:
```json
{
    "userId": 1,
    "amount": 100000,
    "orderInfo": "Test payment",
    "bankCode": "NCB"
}
```

---

## 🧪 Thông tin thẻ test VNPay

- **Ngân hàng:** NCB
- **Số thẻ:** 9704198526191432198
- **Tên:** NGUYEN VAN A
- **Ngày:** 07/15
- **OTP:** 123456

---

## 📡 Các API có sẵn

| Method | Endpoint | Mô tả |
|--------|----------|-------|
| GET | `/api/payment/test` | Kiểm tra API |
| POST | `/api/payment/create` | Tạo thanh toán |
| GET | `/api/payment/vnpay-return` | Callback VNPay |
| GET | `/api/payment/order/{orderId}` | Chi tiết thanh toán |
| GET | `/api/payment/user/{userId}` | Lịch sử user |

---

## ✅ Kiểm tra server đã chạy

Mở trình duyệt:
```
http://localhost:8080/api/payment/test
```

Nếu thấy response này là OK:
```json
{
    "success": true,
    "message": "Payment API is working!"
}
```

---

## 🔥 Test flow hoàn chỉnh

1. **Tạo payment URL**
   ```bash
   POST http://localhost:8080/api/payment/create
   ```

2. **Mở payment URL** trong response

3. **Nhập thông tin thẻ** trên trang VNPay

4. **Xác nhận OTP**: 123456

5. **Xem kết quả** trên callback URL

6. **Kiểm tra database**:
   ```sql
   SELECT * FROM payments ORDER BY created_at DESC;
   ```

---

## 🐛 Lỗi thường gặp

### Server không chạy
```bash
# Kiểm tra port 8080
netstat -ano | findstr :8080

# Kill process nếu bị chiếm
taskkill /PID <PID> /F
```

### Database lỗi
```sql
-- Kiểm tra database tồn tại
USE drivenow_db;

-- Kiểm tra bảng payments
SELECT * FROM INFORMATION_SCHEMA.TABLES 
WHERE TABLE_NAME = 'payments';
```

### CORS lỗi (frontend)
- Đảm bảo `@CrossOrigin(origins = "*")` có trong Controller
- Hoặc thêm CORS config trong Spring Security

---

## 📚 Tài liệu đầy đủ

- **API chi tiết:** `HUONG_DAN_TEST_VNPAY.md`
- **Tích hợp:** `README_VNPAY_INTEGRATION.md`
- **Postman:** `POSTMAN_COLLECTION_VNPAY.md`

---

## 💡 Tips

✅ Dùng HTML test page để test nhanh nhất
✅ Kiểm tra log console để debug
✅ Test với số tiền >= 10,000 VNĐ
✅ Lưu orderId để tra cứu sau
✅ Xem database sau mỗi lần test

---

**Happy Coding! 🎉**
