# VNPAY PAYMENT INTEGRATION - POSTMAN COLLECTION

Dưới đây là các request Postman để test API VNPay:

## 1. Test API
```
GET http://localhost:8080/api/payment/test
```

## 2. Create Payment URL
```
POST http://localhost:8080/api/payment/create
Content-Type: application/json

{
    "userId": 1,
    "amount": 100000,
    "orderInfo": "Thanh toan thue xe Honda City",
    "bankCode": "NCB"
}
```

## 3. Get Payment by Order ID
```
GET http://localhost:8080/api/payment/order/ORDER12345678
```

## 4. Get Payments by User ID
```
GET http://localhost:8080/api/payment/user/1
```

## 5. VNPay Return (Callback)
```
GET http://localhost:8080/api/payment/vnpay-return?vnp_Amount=10000000&vnp_BankCode=NCB&...
```
(VNPay sẽ tự động gọi API này)

---

## Import vào Postman

Copy đoạn JSON dưới đây và import vào Postman (File > Import > Raw text):

```json
{
	"info": {
		"name": "DriveNow - VNPay Payment API",
		"schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
	},
	"item": [
		{
			"name": "1. Test API",
			"request": {
				"method": "GET",
				"header": [],
				"url": {
					"raw": "http://localhost:8080/api/payment/test",
					"protocol": "http",
					"host": ["localhost"],
					"port": "8080",
					"path": ["api", "payment", "test"]
				}
			}
		},
		{
			"name": "2. Create Payment URL",
			"request": {
				"method": "POST",
				"header": [
					{
						"key": "Content-Type",
						"value": "application/json"
					}
				],
				"body": {
					"mode": "raw",
					"raw": "{\n    \"userId\": 1,\n    \"amount\": 100000,\n    \"orderInfo\": \"Thanh toan thue xe Honda City 3 ngay\",\n    \"bankCode\": \"NCB\"\n}"
				},
				"url": {
					"raw": "http://localhost:8080/api/payment/create",
					"protocol": "http",
					"host": ["localhost"],
					"port": "8080",
					"path": ["api", "payment", "create"]
				}
			}
		},
		{
			"name": "3. Get Payment by Order ID",
			"request": {
				"method": "GET",
				"header": [],
				"url": {
					"raw": "http://localhost:8080/api/payment/order/ORDER12345678",
					"protocol": "http",
					"host": ["localhost"],
					"port": "8080",
					"path": ["api", "payment", "order", "ORDER12345678"]
				}
			}
		},
		{
			"name": "4. Get Payments by User ID",
			"request": {
				"method": "GET",
				"header": [],
				"url": {
					"raw": "http://localhost:8080/api/payment/user/1",
					"protocol": "http",
					"host": ["localhost"],
					"port": "8080",
					"path": ["api", "payment", "user", "1"]
				}
			}
		}
	]
}
```
