@echo off
echo ================================================
echo   DRIVENOW - VNPAY PAYMENT INTEGRATION
echo   Starting Backend Server...
echo ================================================
echo.

cd drivenow

echo [1/3] Checking Java...
java -version
if errorlevel 1 (
    echo ERROR: Java not found! Please install JDK 17 or later.
    pause
    exit /b 1
)

echo.
echo [2/3] Building project...
call mvn clean install -DskipTests
if errorlevel 1 (
    echo ERROR: Build failed!
    pause
    exit /b 1
)

echo.
echo [3/3] Starting Spring Boot application...
echo.
echo ================================================
echo   Server is running on: http://localhost:8080
echo   Payment API: http://localhost:8080/api/payment
echo   Test page: ..\html\test-payment-vnpay.html
echo ================================================
echo.

call mvn spring-boot:run

pause
