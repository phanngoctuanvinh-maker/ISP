# HƯỚNG DẪN TEST VNPAY VỚI POSTMAN

## 🎯 Tổng quan

Tài liệu này hướng dẫn cách test chức năng thanh toán VNPay qua Postman.

---

## 📋 CÁC API ENDPOINTS

### 1. Test API hoạt động
- **Method**: GET
- **URL**: `http://localhost:8080/api/payment/test`
- **Mô tả**: Kiểm tra API payment đã hoạt động chưa

**Response mẫu:**
```json
{
    "success": true,
    "message": "Payment API is working!",
    "timestamp": 1728907200000
}
```

---

### 2. Tạo URL thanh toán VNPay
- **Method**: POST
- **URL**: `http://localhost:8080/api/payment/create`
- **Headers**: 
  - `Content-Type`: `application/json`
- **Body** (raw JSON):
```json
{
    "userId": 1,
    "amount": 100000,
    "orderInfo": "Thanh toan thue xe Honda City 3 ngay",
    "bankCode": "NCB"
}
```

**Các tham số:**
- `userId` (bắt buộc): ID của user thực hiện thanh toán
- `amount` (bắt buộc): Số tiền thanh toán (VNĐ, tối thiểu 10,000)
- `orderInfo` (tùy chọn): Thông tin đơn hàng
- `bankCode` (tùy chọn): Mã ngân hàng (NCB, VCB, TCB, MB, VIB, ICB, etc.)

**Response mẫu:**
```json
{
    "success": true,
    "message": "Tạo URL thanh toán thành công",
    "paymentUrl": "https://sandbox.vnpayment.vn/paymentv2/vpcpay.html?vnp_Amount=10000000&vnp_Command=pay&..."
}
```

**Cách test:**
1. Copy `paymentUrl` từ response
2. Dán vào trình duyệt
3. Thực hiện thanh toán trên trang VNPay

**Thông tin test VNPay Sandbox:**
- Ngân hàng: NCB
- Số thẻ: `9704198526191432198`
- Tên chủ thẻ: `NGUYEN VAN A`
- Ngày phát hành: `07/15`
- Mật khẩu OTP: `123456`

---

### 3. Xử lý callback từ VNPay (IPN/Return URL)
- **Method**: GET
- **URL**: `http://localhost:8080/api/payment/vnpay-return`
- **Query Params**: VNPay sẽ tự động gửi các params về

**Lưu ý**: Endpoint này được VNPay tự động gọi sau khi thanh toán. Bạn không cần test thủ công.

**Response mẫu (thành công):**
```json
{
    "success": true,
    "message": "Thanh toán thành công",
    "payment": {
        "id": 1,
        "orderId": "ORDER12345678",
        "userId": 1,
        "amount": 100000,
        "orderInfo": "Thanh toan thue xe Honda City 3 ngay",
        "transactionNo": "14123456",
        "bankCode": "NCB",
        "paymentStatus": "SUCCESS",
        "vnpayResponseCode": "00",
        "createdAt": "2025-10-14T10:30:00",
        "updatedAt": "2025-10-14T10:35:00"
    }
}
```

**Response mẫu (thất bại):**
```json
{
    "success": false,
    "message": "Thanh toán thất bại. Mã lỗi: 24",
    "payment": {
        ...
        "paymentStatus": "FAILED",
        "vnpayResponseCode": "24"
    }
}
```

---

### 4. Lấy thông tin thanh toán theo Order ID
- **Method**: GET
- **URL**: `http://localhost:8080/api/payment/order/{orderId}`
- **Path Variable**: `orderId` - Mã đơn hàng (ví dụ: ORDER12345678)

**Ví dụ:**
```
GET http://localhost:8080/api/payment/order/ORDER12345678
```

**Response mẫu:**
```json
{
    "success": true,
    "payment": {
        "id": 1,
        "orderId": "ORDER12345678",
        "userId": 1,
        "amount": 100000,
        "orderInfo": "Thanh toan thue xe Honda City 3 ngay",
        "transactionNo": "14123456",
        "bankCode": "NCB",
        "paymentStatus": "SUCCESS",
        "vnpayResponseCode": "00",
        "createdAt": "2025-10-14T10:30:00",
        "updatedAt": "2025-10-14T10:35:00"
    }
}
```

---

### 5. Lấy danh sách thanh toán của user
- **Method**: GET
- **URL**: `http://localhost:8080/api/payment/user/{userId}`
- **Path Variable**: `userId` - ID của user

**Ví dụ:**
```
GET http://localhost:8080/api/payment/user/1
```

**Response mẫu:**
```json
{
    "success": true,
    "payments": [
        {
            "id": 1,
            "orderId": "ORDER12345678",
            "userId": 1,
            "amount": 100000,
            "paymentStatus": "SUCCESS",
            ...
        },
        {
            "id": 2,
            "orderId": "ORDER87654321",
            "userId": 1,
            "amount": 200000,
            "paymentStatus": "PENDING",
            ...
        }
    ],
    "total": 2
}
```

---

## 🔧 CÀI ĐẶT VÀ CHẠY

### Bước 1: Cài đặt dependencies
```bash
cd drivenow
mvn clean install
```

### Bước 2: Chạy backend
```bash
mvn spring-boot:run
```

Hoặc sử dụng file batch:
```bash
.\start-backend.bat
```

### Bước 3: Kiểm tra server đã chạy
Mở trình duyệt hoặc Postman, truy cập:
```
http://localhost:8080/api/payment/test
```

---

## 📝 QUY TRÌNH TEST ĐẦY ĐỦ

### Scenario 1: Thanh toán thành công

1. **Tạo payment URL**
   - POST `http://localhost:8080/api/payment/create`
   - Body:
   ```json
   {
       "userId": 1,
       "amount": 100000,
       "orderInfo": "Test thanh toan",
       "bankCode": "NCB"
   }
   ```
   - Lưu lại `paymentUrl` và `orderId` từ response

2. **Thực hiện thanh toán**
   - Copy `paymentUrl` dán vào trình duyệt
   - Điền thông tin thẻ test (xem phần trên)
   - Nhập OTP: `123456`
   - Nhấn "Thanh toán"

3. **Kiểm tra kết quả**
   - VNPay sẽ redirect về: `http://localhost:8080/api/payment/vnpay-return?...`
   - Xem response JSON trong trình duyệt

4. **Xác minh payment đã lưu**
   - GET `http://localhost:8080/api/payment/order/{orderId}`
   - Kiểm tra `paymentStatus` phải là `SUCCESS`

### Scenario 2: Xem lịch sử thanh toán

1. **Lấy danh sách payment của user**
   - GET `http://localhost:8080/api/payment/user/1`
   - Xem tất cả các giao dịch của user ID = 1

---

## 🏦 MÃ NGÂN HÀNG (Bank Code)

Các mã ngân hàng phổ biến để test:
- `NCB` - Ngân hàng NCB
- `VCB` - Vietcombank
- `TCB` - Techcombank
- `MB` - MBBank
- `VIB` - VIB
- `ICB` - VietinBank
- `ACB` - ACB
- Để trống - Cho phép user chọn trên trang VNPay

---

## 🐛 XỬ LÝ LỖI THƯỜNG GẶP

### Lỗi 1: Connection refused
- **Nguyên nhân**: Server chưa chạy
- **Giải pháp**: Chạy `mvn spring-boot:run` trong thư mục `drivenow`

### Lỗi 2: Invalid signature
- **Nguyên nhân**: Secret key không đúng
- **Giải pháp**: Kiểm tra `vnpay.secret-key` trong `application.properties`

### Lỗi 3: Database connection error
- **Nguyên nhân**: SQL Server chưa chạy hoặc cấu hình sai
- **Giải pháp**: 
  - Kiểm tra SQL Server đã start
  - Kiểm tra database `drivenow_db` đã tạo
  - Kiểm tra username/password trong `application.properties`

### Lỗi 4: Amount too small
- **Nguyên nhân**: Số tiền < 10,000 VNĐ
- **Giải pháp**: Đảm bảo `amount >= 10000`

---

## 📊 TRẠNG THÁI THANH TOÁN

| paymentStatus | Ý nghĩa |
|--------------|---------|
| `PENDING` | Đang chờ thanh toán |
| `SUCCESS` | Thanh toán thành công |
| `FAILED` | Thanh toán thất bại |

---

## 🔐 BẢO MẬT

**Lưu ý quan trọng:**
- Đây là môi trường **SANDBOX** (test), không dùng cho production
- Secret key và TMN code đang dùng là của VNPay sandbox
- Khi deploy lên production, cần đăng ký tài khoản VNPay thật và thay đổi:
  - `vnpay.url`
  - `vnpay.tmn-code`
  - `vnpay.secret-key`
  - `vnpay.return-url` (domain thật)

---

## 📞 HỖ TRỢ

Nếu gặp vấn đề, kiểm tra:
1. Log của Spring Boot trong console
2. Database có bảng `payments` chưa
3. SQL Server đã start chưa
4. Port 8080 có bị chiếm dụng không

---

## ✅ CHECKLIST TEST

- [ ] Test API hoạt động (`/api/payment/test`)
- [ ] Tạo payment URL thành công
- [ ] Mở payment URL trên trình duyệt
- [ ] Thanh toán thành công với thẻ test
- [ ] Kiểm tra callback return về đúng
- [ ] Lấy thông tin payment theo orderId
- [ ] Xem danh sách payment của user
- [ ] Test thanh toán thất bại (hủy giao dịch)
- [ ] Kiểm tra database có lưu payment chưa

---

**Chúc bạn test thành công! 🎉**
